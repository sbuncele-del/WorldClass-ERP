"use strict";
/**
 * Item Category Repository
 *
 * Handles all database operations for inventory item categories
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.itemCategoryRepository = exports.ItemCategoryRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class ItemCategoryRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'item_categories';
        this.schema = 'inventory';
    }
    /**
     * Get all active categories for a tenant
     */
    async getActiveCategories(ctx) {
        const result = await this.findAll(ctx, { is_active: true }, { limit: 1000 });
        return result.data;
    }
    /**
     * Get category hierarchy (categories with their children)
     */
    async getCategoryTree(ctx) {
        const sql = `
      WITH RECURSIVE category_tree AS (
        SELECT *, 0 as level
        FROM ${this.fullTableName}
        WHERE tenant_id = $1 AND parent_id IS NULL AND deleted_at IS NULL
        
        UNION ALL
        
        SELECT c.*, ct.level + 1
        FROM ${this.fullTableName} c
        INNER JOIN category_tree ct ON c.parent_id = ct.id
        WHERE c.tenant_id = $1 AND c.deleted_at IS NULL
      )
      SELECT * FROM category_tree ORDER BY level, name
    `;
        return this.rawQuery(ctx, sql);
    }
    /**
     * Get subcategories of a parent category
     */
    async getSubcategories(ctx, parentId) {
        return this.findBy(ctx, 'parent_id', parentId);
    }
    /**
     * Check if category code is unique for tenant
     */
    async isCodeUnique(ctx, code, excludeId) {
        const existing = await this.findOne(ctx, { code });
        if (!existing)
            return true;
        if (excludeId && existing.id === excludeId)
            return true;
        return false;
    }
    /**
     * Search categories by name or code
     */
    async search(ctx, searchTerm, pagination) {
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND (name ILIKE $2 OR code ILIKE $2 OR description ILIKE $2)
      ORDER BY name
      LIMIT $3 OFFSET $4
    `;
        const countSql = `
      SELECT COUNT(*) FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND (name ILIKE $2 OR code ILIKE $2 OR description ILIKE $2)
    `;
        const { page = 1, limit = 50 } = pagination || {};
        const offset = (page - 1) * limit;
        const searchPattern = `%${searchTerm}%`;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, [searchPattern, limit, offset]),
            this.rawQuery(ctx, countSql, [searchPattern])
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit)
            }
        };
    }
}
exports.ItemCategoryRepository = ItemCategoryRepository;
// Singleton instance
exports.itemCategoryRepository = new ItemCategoryRepository();
exports.default = exports.itemCategoryRepository;
//# sourceMappingURL=ItemCategoryRepository.js.map