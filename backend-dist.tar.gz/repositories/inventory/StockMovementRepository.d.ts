/**
 * Stock Movement Repository
 *
 * Handles all database operations for stock movements (receipts, issues, transfers)
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type MovementType = 'IN' | 'OUT' | 'TRANSFER' | 'ADJUSTMENT' | 'RETURN';
export interface StockMovement {
    id: string;
    tenant_id: string;
    item_id: string;
    warehouse_id: string;
    to_warehouse_id?: string;
    quantity: number;
    movement_type: MovementType;
    reference_type?: string;
    reference_id?: string;
    reason?: string;
    notes?: string;
    unit_cost?: number;
    batch_number?: string;
    serial_numbers?: string[];
    created_at: Date;
    created_by?: string;
}
export declare class StockMovementRepository extends BaseRepository<StockMovement> {
    protected tableName: string;
    protected schema: string;
    protected softDelete: boolean;
    /**
     * Get movements for an item
     */
    getItemMovements(ctx: TenantContext, itemId: string, pagination?: PaginationOptions): Promise<PaginatedResult<StockMovement>>;
    /**
     * Get movements for a warehouse
     */
    getWarehouseMovements(ctx: TenantContext, warehouseId: string, pagination?: PaginationOptions): Promise<PaginatedResult<StockMovement>>;
    /**
     * Get movements by date range
     */
    getMovementsByDateRange(ctx: TenantContext, startDate: Date, endDate: Date, filters?: {
        itemId?: string;
        warehouseId?: string;
        movementType?: MovementType;
    }, pagination?: PaginationOptions): Promise<PaginatedResult<StockMovement>>;
    /**
     * Create a stock receipt (goods in)
     */
    createReceipt(ctx: TenantContext, data: {
        itemId: string;
        warehouseId: string;
        quantity: number;
        referenceType?: string;
        referenceId?: string;
        unitCost?: number;
        batchNumber?: string;
        serialNumbers?: string[];
        notes?: string;
    }): Promise<StockMovement>;
    /**
     * Create a stock issue (goods out)
     */
    createIssue(ctx: TenantContext, data: {
        itemId: string;
        warehouseId: string;
        quantity: number;
        referenceType?: string;
        referenceId?: string;
        reason?: string;
        notes?: string;
    }): Promise<StockMovement>;
    /**
     * Create a stock transfer between warehouses
     */
    createTransfer(ctx: TenantContext, data: {
        itemId: string;
        fromWarehouseId: string;
        toWarehouseId: string;
        quantity: number;
        notes?: string;
    }): Promise<{
        outMovement: StockMovement;
        inMovement: StockMovement;
    }>;
    /**
     * Get movement summary for reporting
     */
    getMovementSummary(ctx: TenantContext, startDate: Date, endDate: Date): Promise<{
        total_in: number;
        total_out: number;
        total_transfers: number;
        net_movement: number;
    }>;
}
export declare const stockMovementRepository: StockMovementRepository;
export default stockMovementRepository;
//# sourceMappingURL=StockMovementRepository.d.ts.map