"use strict";
/**
 * Inventory Repositories Index
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.stockMovementRepository = exports.StockMovementRepository = exports.warehouseRepository = exports.WarehouseRepository = exports.inventoryItemRepository = exports.InventoryItemRepository = exports.itemCategoryRepository = exports.ItemCategoryRepository = void 0;
var ItemCategoryRepository_1 = require("./ItemCategoryRepository");
Object.defineProperty(exports, "ItemCategoryRepository", { enumerable: true, get: function () { return ItemCategoryRepository_1.ItemCategoryRepository; } });
Object.defineProperty(exports, "itemCategoryRepository", { enumerable: true, get: function () { return ItemCategoryRepository_1.itemCategoryRepository; } });
var InventoryItemRepository_1 = require("./InventoryItemRepository");
Object.defineProperty(exports, "InventoryItemRepository", { enumerable: true, get: function () { return InventoryItemRepository_1.InventoryItemRepository; } });
Object.defineProperty(exports, "inventoryItemRepository", { enumerable: true, get: function () { return InventoryItemRepository_1.inventoryItemRepository; } });
var WarehouseRepository_1 = require("./WarehouseRepository");
Object.defineProperty(exports, "WarehouseRepository", { enumerable: true, get: function () { return WarehouseRepository_1.WarehouseRepository; } });
Object.defineProperty(exports, "warehouseRepository", { enumerable: true, get: function () { return WarehouseRepository_1.warehouseRepository; } });
var StockMovementRepository_1 = require("./StockMovementRepository");
Object.defineProperty(exports, "StockMovementRepository", { enumerable: true, get: function () { return StockMovementRepository_1.StockMovementRepository; } });
Object.defineProperty(exports, "stockMovementRepository", { enumerable: true, get: function () { return StockMovementRepository_1.stockMovementRepository; } });
//# sourceMappingURL=index.js.map