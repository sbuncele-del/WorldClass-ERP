/**
 * Warehouse Repository
 *
 * Handles all database operations for warehouses
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export interface Warehouse {
    id: string;
    tenant_id: string;
    code: string;
    name: string;
    description?: string;
    address?: string;
    city?: string;
    state?: string;
    country?: string;
    postal_code?: string;
    phone?: string;
    email?: string;
    manager_id?: string;
    is_active: boolean;
    is_default: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class WarehouseRepository extends BaseRepository<Warehouse> {
    protected tableName: string;
    protected schema: string;
    /**
     * Get the default warehouse for a tenant
     */
    getDefaultWarehouse(ctx: TenantContext): Promise<Warehouse | null>;
    /**
     * Set a warehouse as the default
     */
    setDefaultWarehouse(ctx: TenantContext, warehouseId: string): Promise<void>;
    /**
     * Get all active warehouses
     */
    getActiveWarehouses(ctx: TenantContext): Promise<Warehouse[]>;
    /**
     * Get warehouse with stock summary
     */
    getWarehouseWithStock(ctx: TenantContext, warehouseId: string): Promise<Warehouse & {
        total_items: number;
        total_stock_value: number;
    } | null>;
    /**
     * Check if warehouse code is unique
     */
    isCodeUnique(ctx: TenantContext, code: string, excludeId?: string): Promise<boolean>;
}
export declare const warehouseRepository: WarehouseRepository;
export default warehouseRepository;
//# sourceMappingURL=WarehouseRepository.d.ts.map