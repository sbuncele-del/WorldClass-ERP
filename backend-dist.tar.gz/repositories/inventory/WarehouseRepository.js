"use strict";
/**
 * Warehouse Repository
 *
 * Handles all database operations for warehouses
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.warehouseRepository = exports.WarehouseRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class WarehouseRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'warehouses';
        this.schema = 'inventory';
    }
    /**
     * Get the default warehouse for a tenant
     */
    async getDefaultWarehouse(ctx) {
        return this.findOne(ctx, { is_default: true, is_active: true });
    }
    /**
     * Set a warehouse as the default
     */
    async setDefaultWarehouse(ctx, warehouseId) {
        const client = await this.beginTransaction();
        try {
            // Remove default from all warehouses
            await client.query(`
        UPDATE ${this.fullTableName}
        SET is_default = false, updated_at = NOW()
        WHERE tenant_id = $1
      `, [ctx.tenantId]);
            // Set the new default
            await client.query(`
        UPDATE ${this.fullTableName}
        SET is_default = true, updated_at = NOW()
        WHERE tenant_id = $1 AND id = $2
      `, [ctx.tenantId, warehouseId]);
            await this.commitTransaction(client);
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
    /**
     * Get all active warehouses
     */
    async getActiveWarehouses(ctx) {
        const result = await this.findAll(ctx, { is_active: true });
        return result.data;
    }
    /**
     * Get warehouse with stock summary
     */
    async getWarehouseWithStock(ctx, warehouseId) {
        const sql = `
      SELECT 
        w.*,
        COUNT(DISTINCT sl.item_id) as total_items,
        COALESCE(SUM(sl.quantity_on_hand * i.cost_price), 0) as total_stock_value
      FROM ${this.fullTableName} w
      LEFT JOIN inventory.stock_levels sl ON sl.warehouse_id = w.id
      LEFT JOIN inventory.items i ON i.id = sl.item_id
      WHERE w.tenant_id = $1 AND w.id = $2 AND w.deleted_at IS NULL
      GROUP BY w.id
    `;
        const result = await this.rawQuery(ctx, sql, [warehouseId]);
        return result[0] || null;
    }
    /**
     * Check if warehouse code is unique
     */
    async isCodeUnique(ctx, code, excludeId) {
        const existing = await this.findOne(ctx, { code });
        if (!existing)
            return true;
        if (excludeId && existing.id === excludeId)
            return true;
        return false;
    }
}
exports.WarehouseRepository = WarehouseRepository;
// Singleton instance
exports.warehouseRepository = new WarehouseRepository();
exports.default = exports.warehouseRepository;
//# sourceMappingURL=WarehouseRepository.js.map