/**
 * Inventory Item Repository
 *
 * Handles all database operations for inventory items
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export interface InventoryItem {
    id: string;
    tenant_id: string;
    code: string;
    name: string;
    description?: string;
    category_id?: string;
    unit_of_measure: string;
    sku?: string;
    barcode?: string;
    cost_price: number;
    selling_price: number;
    min_stock_level?: number;
    max_stock_level?: number;
    reorder_point?: number;
    reorder_quantity?: number;
    is_active: boolean;
    is_service: boolean;
    is_serialized: boolean;
    is_batch_tracked: boolean;
    weight?: number;
    dimensions?: {
        length?: number;
        width?: number;
        height?: number;
    };
    tax_code?: string;
    gl_account_id?: string;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export interface StockLevel {
    item_id: string;
    warehouse_id: string;
    warehouse_name: string;
    quantity_on_hand: number;
    quantity_reserved: number;
    quantity_available: number;
}
export declare class InventoryItemRepository extends BaseRepository<InventoryItem> {
    protected tableName: string;
    protected schema: string;
    /**
     * Get items with stock levels
     */
    getItemsWithStock(ctx: TenantContext, warehouseId?: string, pagination?: PaginationOptions): Promise<PaginatedResult<InventoryItem & {
        stock: number;
    }>>;
    /**
     * Get stock levels for an item across all warehouses
     */
    getStockLevels(ctx: TenantContext, itemId: string): Promise<StockLevel[]>;
    /**
     * Get low stock items (below reorder point)
     */
    getLowStockItems(ctx: TenantContext): Promise<(InventoryItem & {
        current_stock: number;
    })[]>;
    /**
     * Search items by name, code, SKU, or barcode
     */
    search(ctx: TenantContext, searchTerm: string, filters?: {
        categoryId?: string;
        isActive?: boolean;
        isService?: boolean;
    }, pagination?: PaginationOptions): Promise<PaginatedResult<InventoryItem>>;
    /**
     * Check if item code is unique for tenant
     */
    isCodeUnique(ctx: TenantContext, code: string, excludeId?: string): Promise<boolean>;
    /**
     * Get items by category
     */
    getByCategory(ctx: TenantContext, categoryId: string): Promise<InventoryItem[]>;
    /**
     * Update stock level for an item in a warehouse
     */
    updateStockLevel(ctx: TenantContext, itemId: string, warehouseId: string, quantityChange: number, reason: string): Promise<void>;
}
export declare const inventoryItemRepository: InventoryItemRepository;
export default inventoryItemRepository;
//# sourceMappingURL=InventoryItemRepository.d.ts.map