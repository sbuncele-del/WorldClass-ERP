/**
 * Item Category Repository
 *
 * Handles all database operations for inventory item categories
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export interface ItemCategory {
    id: string;
    tenant_id: string;
    name: string;
    code: string;
    description?: string;
    parent_id?: string;
    is_active: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
    deleted_by?: string;
}
export declare class ItemCategoryRepository extends BaseRepository<ItemCategory> {
    protected tableName: string;
    protected schema: string;
    /**
     * Get all active categories for a tenant
     */
    getActiveCategories(ctx: TenantContext): Promise<ItemCategory[]>;
    /**
     * Get category hierarchy (categories with their children)
     */
    getCategoryTree(ctx: TenantContext): Promise<ItemCategory[]>;
    /**
     * Get subcategories of a parent category
     */
    getSubcategories(ctx: TenantContext, parentId: string): Promise<ItemCategory[]>;
    /**
     * Check if category code is unique for tenant
     */
    isCodeUnique(ctx: TenantContext, code: string, excludeId?: string): Promise<boolean>;
    /**
     * Search categories by name or code
     */
    search(ctx: TenantContext, searchTerm: string, pagination?: PaginationOptions): Promise<PaginatedResult<ItemCategory>>;
}
export declare const itemCategoryRepository: ItemCategoryRepository;
export default itemCategoryRepository;
//# sourceMappingURL=ItemCategoryRepository.d.ts.map