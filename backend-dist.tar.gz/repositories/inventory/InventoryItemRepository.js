"use strict";
/**
 * Inventory Item Repository
 *
 * Handles all database operations for inventory items
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.inventoryItemRepository = exports.InventoryItemRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class InventoryItemRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'items';
        this.schema = 'inventory';
    }
    /**
     * Get items with stock levels
     */
    async getItemsWithStock(ctx, warehouseId, pagination) {
        const { page = 1, limit = 50, sortBy = 'name', sortOrder = 'ASC' } = pagination || {};
        const offset = (page - 1) * limit;
        let sql = `
      SELECT i.*, COALESCE(SUM(sl.quantity_on_hand), 0) as stock
      FROM ${this.fullTableName} i
      LEFT JOIN inventory.stock_levels sl ON sl.item_id = i.id
      WHERE i.tenant_id = $1 AND i.deleted_at IS NULL
    `;
        const params = [];
        if (warehouseId) {
            sql += ` AND sl.warehouse_id = $2`;
            params.push(warehouseId);
        }
        sql += `
      GROUP BY i.id
      ORDER BY ${sortBy} ${sortOrder}
      LIMIT $${params.length + 2} OFFSET $${params.length + 3}
    `;
        params.push(limit, offset);
        const countSql = `
      SELECT COUNT(DISTINCT i.id) FROM ${this.fullTableName} i
      WHERE i.tenant_id = $1 AND i.deleted_at IS NULL
    `;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, params),
            this.rawQuery(ctx, countSql)
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
        };
    }
    /**
     * Get stock levels for an item across all warehouses
     */
    async getStockLevels(ctx, itemId) {
        const sql = `
      SELECT 
        sl.item_id,
        sl.warehouse_id,
        w.name as warehouse_name,
        sl.quantity_on_hand,
        sl.quantity_reserved,
        (sl.quantity_on_hand - sl.quantity_reserved) as quantity_available
      FROM inventory.stock_levels sl
      JOIN inventory.warehouses w ON w.id = sl.warehouse_id
      WHERE sl.tenant_id = $1 AND sl.item_id = $2
    `;
        return this.rawQuery(ctx, sql, [itemId]);
    }
    /**
     * Get low stock items (below reorder point)
     */
    async getLowStockItems(ctx) {
        const sql = `
      SELECT i.*, COALESCE(SUM(sl.quantity_on_hand), 0) as current_stock
      FROM ${this.fullTableName} i
      LEFT JOIN inventory.stock_levels sl ON sl.item_id = i.id
      WHERE i.tenant_id = $1 
        AND i.deleted_at IS NULL
        AND i.reorder_point IS NOT NULL
      GROUP BY i.id
      HAVING COALESCE(SUM(sl.quantity_on_hand), 0) <= i.reorder_point
      ORDER BY (COALESCE(SUM(sl.quantity_on_hand), 0) / NULLIF(i.reorder_point, 0))
    `;
        return this.rawQuery(ctx, sql);
    }
    /**
     * Search items by name, code, SKU, or barcode
     */
    async search(ctx, searchTerm, filters, pagination) {
        const { page = 1, limit = 50 } = pagination || {};
        const offset = (page - 1) * limit;
        const searchPattern = `%${searchTerm}%`;
        const params = [searchPattern];
        let conditions = `
      (name ILIKE $2 OR code ILIKE $2 OR sku ILIKE $2 OR barcode ILIKE $2)
    `;
        let paramIndex = 3;
        if (filters?.categoryId) {
            conditions += ` AND category_id = $${paramIndex}`;
            params.push(filters.categoryId);
            paramIndex++;
        }
        if (filters?.isActive !== undefined) {
            conditions += ` AND is_active = $${paramIndex}`;
            params.push(filters.isActive);
            paramIndex++;
        }
        if (filters?.isService !== undefined) {
            conditions += ` AND is_service = $${paramIndex}`;
            params.push(filters.isService);
            paramIndex++;
        }
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND deleted_at IS NULL AND ${conditions}
      ORDER BY name
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
        params.push(limit, offset);
        const countSql = `
      SELECT COUNT(*) FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND deleted_at IS NULL AND ${conditions}
    `;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, params),
            this.rawQuery(ctx, countSql, params.slice(0, -2))
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
        };
    }
    /**
     * Check if item code is unique for tenant
     */
    async isCodeUnique(ctx, code, excludeId) {
        const existing = await this.findOne(ctx, { code });
        if (!existing)
            return true;
        if (excludeId && existing.id === excludeId)
            return true;
        return false;
    }
    /**
     * Get items by category
     */
    async getByCategory(ctx, categoryId) {
        return this.findBy(ctx, 'category_id', categoryId);
    }
    /**
     * Update stock level for an item in a warehouse
     */
    async updateStockLevel(ctx, itemId, warehouseId, quantityChange, reason) {
        const client = await this.beginTransaction();
        try {
            // Update or insert stock level
            await client.query(`
        INSERT INTO inventory.stock_levels (tenant_id, item_id, warehouse_id, quantity_on_hand)
        VALUES ($1, $2, $3, $4)
        ON CONFLICT (tenant_id, item_id, warehouse_id)
        DO UPDATE SET 
          quantity_on_hand = inventory.stock_levels.quantity_on_hand + $4,
          updated_at = NOW()
      `, [ctx.tenantId, itemId, warehouseId, quantityChange]);
            // Record the movement
            await client.query(`
        INSERT INTO inventory.stock_movements 
        (tenant_id, item_id, warehouse_id, quantity, movement_type, reason, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [ctx.tenantId, itemId, warehouseId, quantityChange,
                quantityChange > 0 ? 'IN' : 'OUT', reason, ctx.userId]);
            await this.commitTransaction(client);
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
}
exports.InventoryItemRepository = InventoryItemRepository;
// Singleton instance
exports.inventoryItemRepository = new InventoryItemRepository();
exports.default = exports.inventoryItemRepository;
//# sourceMappingURL=InventoryItemRepository.js.map