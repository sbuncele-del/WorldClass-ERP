/**
 * Quotation Repository
 *
 * Handles all database operations for sales quotations/quotes
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type QuotationStatus = 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired' | 'converted';
export interface QuotationLine {
    id: string;
    quotation_id: string;
    item_id: string;
    item_code?: string;
    item_name?: string;
    description?: string;
    quantity: number;
    unit_price: number;
    discount_percent?: number;
    discount_amount?: number;
    tax_rate?: number;
    tax_amount?: number;
    line_total: number;
}
export interface Quotation {
    id: string;
    tenant_id: string;
    quote_number: string;
    customer_id: string;
    customer_name?: string;
    quote_date: Date;
    expiry_date: Date;
    status: QuotationStatus;
    subtotal: number;
    discount_amount?: number;
    tax_amount?: number;
    total_amount: number;
    currency_code: string;
    notes?: string;
    terms_and_conditions?: string;
    sales_rep_id?: string;
    lines?: QuotationLine[];
    converted_order_id?: string;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class QuotationRepository extends BaseRepository<Quotation> {
    protected tableName: string;
    protected schema: string;
    protected softDelete: boolean;
    /**
     * Get quotations by status
     */
    getQuotationsByStatus(ctx: TenantContext, status: QuotationStatus, pagination?: PaginationOptions): Promise<PaginatedResult<Quotation>>;
    /**
     * Get quotation with lines
     */
    getQuotationWithLines(ctx: TenantContext, quotationId: string): Promise<Quotation | null>;
    /**
     * Get expiring quotations (within X days)
     */
    getExpiringQuotations(ctx: TenantContext, withinDays?: number): Promise<Quotation[]>;
    /**
     * Convert quotation to sales order
     */
    convertToOrder(ctx: TenantContext, quotationId: string): Promise<string>;
    /**
     * Get quotation conversion rate
     */
    getConversionRate(ctx: TenantContext, startDate: Date, endDate: Date): Promise<{
        total_quotations: number;
        converted_quotations: number;
        conversion_rate: number;
        total_value: number;
        converted_value: number;
    }>;
    /**
     * Generate next quote number
     */
    generateQuoteNumber(ctx: TenantContext): Promise<string>;
    /**
     * Create quotation with lines
     */
    createQuotationWithLines(ctx: TenantContext, quotationData: Partial<Quotation>, lines: Partial<QuotationLine>[]): Promise<Quotation>;
}
export declare const quotationRepository: QuotationRepository;
export default quotationRepository;
//# sourceMappingURL=QuotationRepository.d.ts.map