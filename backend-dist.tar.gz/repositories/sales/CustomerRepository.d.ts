/**
 * Customer Repository
 *
 * Handles all database operations for customers/clients.
 * Note: This table uses a simpler schema without multi-tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions, QueryOptions } from '../BaseRepository';
export interface Customer {
    customer_id: number;
    company_name: string;
    contact_person?: string;
    email?: string;
    phone?: string;
    vat_number?: string;
    customer_type?: string;
    source?: string;
    created_from_document?: string;
    status: string;
    created_at: Date;
    updated_at?: Date;
    billing_address?: string;
    shipping_address?: string;
    payment_terms?: string;
    credit_limit?: number;
    id?: number;
    name?: string;
}
export interface CustomerBalance {
    customer_id: string;
    total_invoiced: number;
    total_paid: number;
    balance_due: number;
    overdue_amount: number;
}
export declare class CustomerRepository extends BaseRepository<Customer> {
    protected tableName: string;
    protected schema: string;
    protected softDelete: boolean;
    protected primaryKey: string;
    protected tenantIsolation: boolean;
    private readonly columns;
    /**
     * Override rawQuery to NOT prepend tenant_id since this table isn't multi-tenant
     */
    rawQuery<R = any>(ctx: TenantContext, sql: string, params?: any[], _options?: QueryOptions): Promise<R[]>;
    /**
     * Find all customers without tenant filtering
     */
    findAll(_ctx: TenantContext, filters?: Record<string, any>, pagination?: PaginationOptions, _options?: QueryOptions): Promise<PaginatedResult<Customer>>;
    /**
     * Create customer without tenant fields
     */
    create(_ctx: TenantContext, data: Partial<Customer>, _options?: QueryOptions): Promise<Customer>;
    /**
     * Update customer without tenant fields
     */
    update(_ctx: TenantContext, id: string | number, data: Partial<Customer>, _options?: QueryOptions): Promise<Customer | null>;
    /**
     * Delete customer without tenant fields
     */
    delete(_ctx: TenantContext, id: string | number, _options?: QueryOptions): Promise<boolean>;
    /**
     * Find by ID without tenant filtering
     */
    findById(_ctx: TenantContext, id: string | number, _options?: QueryOptions): Promise<Customer | null>;
    /**
     * Get all active customers
     */
    getActiveCustomers(ctx: TenantContext): Promise<Customer[]>;
    /**
     * Search customers by company name, contact, email, or phone
     */
    search(ctx: TenantContext, searchTerm: string, pagination?: PaginationOptions): Promise<PaginatedResult<Customer>>;
    /**
     * Get customer with balance information
     */
    getCustomerWithBalance(ctx: TenantContext, customerId: string): Promise<(Customer & CustomerBalance) | null>;
    /**
     * Get customers with outstanding balances
     */
    getCustomersWithBalances(ctx: TenantContext): Promise<(Customer & CustomerBalance)[]>;
    /**
     * Get overdue customers
     */
    getOverdueCustomers(ctx: TenantContext): Promise<(Customer & {
        overdue_amount: number;
        oldest_overdue: Date;
    })[]>;
    /**
     * Check if customer company name is unique
     */
    isNameUnique(ctx: TenantContext, companyName: string, excludeId?: number): Promise<boolean>;
    /**
     * Get customer by email
     */
    findByEmail(ctx: TenantContext, email: string): Promise<Customer | null>;
    /**
     * Update customer credit limit
     */
    updateCreditLimit(ctx: TenantContext, customerId: number, newLimit: number): Promise<Customer | null>;
    /**
     * Get top customers by revenue within invoices
     */
    getTopCustomersByRevenue(ctx: TenantContext, limit?: number): Promise<Array<Customer & {
        revenue: number;
    }>>;
}
export declare const customerRepository: CustomerRepository;
export default customerRepository;
//# sourceMappingURL=CustomerRepository.d.ts.map