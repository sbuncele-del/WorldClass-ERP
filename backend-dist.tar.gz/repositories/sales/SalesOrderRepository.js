"use strict";
/**
 * Sales Order Repository
 *
 * Handles all database operations for sales orders
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.salesOrderRepository = exports.SalesOrderRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class SalesOrderRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'orders';
        this.schema = 'sales';
        this.softDelete = false; // Table doesn't have deleted_at column
    }
    /**
     * Get orders by status
     */
    async getOrdersByStatus(ctx, status, pagination) {
        return this.findAll(ctx, { status }, pagination);
    }
    /**
     * Get orders for a customer
     */
    async getCustomerOrders(ctx, customerId, pagination) {
        return this.findAll(ctx, { customer_id: customerId }, pagination);
    }
    /**
     * Get order with lines
     */
    async getOrderWithLines(ctx, orderId) {
        const order = await this.findById(ctx, orderId);
        if (!order)
            return null;
        const linesSql = `
      SELECT ol.*, i.code as item_code, i.name as item_name
      FROM sales.order_lines ol
      LEFT JOIN inventory.items i ON i.id = ol.item_id
      WHERE ol.order_id = $2 AND ol.tenant_id = $1
      ORDER BY ol.line_number
    `;
        const lines = await this.rawQuery(ctx, linesSql, [orderId]);
        return { ...order, lines };
    }
    /**
     * Create order with lines
     */
    async createOrderWithLines(ctx, orderData, lines) {
        const client = await this.beginTransaction();
        try {
            // Generate order number
            const orderNumber = await this.generateOrderNumber(ctx, client);
            // Create order
            const orderResult = await client.query(`
        INSERT INTO ${this.fullTableName}
        (tenant_id, order_number, customer_id, order_date, status, warehouse_id,
         subtotal, discount_amount, tax_amount, shipping_amount, total_amount,
         currency_code, payment_terms, notes, sales_rep_id, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
        RETURNING *
      `, [
                ctx.tenantId,
                orderNumber,
                orderData.customer_id,
                orderData.order_date || new Date(),
                orderData.status || 'draft',
                orderData.warehouse_id,
                orderData.subtotal || 0,
                orderData.discount_amount || 0,
                orderData.tax_amount || 0,
                orderData.shipping_amount || 0,
                orderData.total_amount || 0,
                orderData.currency_code || 'ZAR',
                orderData.payment_terms,
                orderData.notes,
                orderData.sales_rep_id,
                ctx.userId
            ]);
            const order = orderResult.rows[0];
            // Create lines
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                await client.query(`
          INSERT INTO sales.order_lines
          (tenant_id, order_id, line_number, item_id, quantity, unit_price,
           discount_percent, discount_amount, tax_rate, tax_amount, line_total, notes)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        `, [
                    ctx.tenantId,
                    order.id,
                    i + 1,
                    line.item_id,
                    line.quantity,
                    line.unit_price,
                    line.discount_percent || 0,
                    line.discount_amount || 0,
                    line.tax_rate || 0,
                    line.tax_amount || 0,
                    line.line_total,
                    line.notes
                ]);
            }
            await this.commitTransaction(client);
            return order;
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
    /**
     * Generate next order number
     */
    async generateOrderNumber(ctx, client) {
        const queryClient = client || this.pool;
        const result = await queryClient.query(`
      SELECT COALESCE(MAX(CAST(SUBSTRING(order_number FROM '[0-9]+$') AS INTEGER)), 0) + 1 as next_num
      FROM ${this.fullTableName}
      WHERE tenant_id = $1
    `, [ctx.tenantId]);
        const nextNum = result.rows[0].next_num;
        return `SO-${String(nextNum).padStart(6, '0')}`;
    }
    /**
     * Update order status
     */
    async updateStatus(ctx, orderId, status) {
        return this.update(ctx, orderId, { status });
    }
    /**
     * Get orders by date range
     */
    async getOrdersByDateRange(ctx, startDate, endDate, pagination) {
        const { page = 1, limit = 50 } = pagination || {};
        const offset = (page - 1) * limit;
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND order_date BETWEEN $2 AND $3
      ORDER BY order_date DESC
      LIMIT $4 OFFSET $5
    `;
        const countSql = `
      SELECT COUNT(*) FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND order_date BETWEEN $2 AND $3
    `;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, [startDate, endDate, limit, offset]),
            this.rawQuery(ctx, countSql, [startDate, endDate])
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
        };
    }
    /**
     * Get sales summary for dashboard
     */
    async getSalesSummary(ctx, startDate, endDate) {
        const sql = `
      SELECT 
        COUNT(*) as total_orders,
        COALESCE(SUM(total_amount), 0) as total_amount,
        COALESCE(AVG(total_amount), 0) as average_order_value
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND order_date BETWEEN $2 AND $3
    `;
        const statusSql = `
      SELECT status, COUNT(*) as count
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND order_date BETWEEN $2 AND $3
      GROUP BY status
    `;
        const [summary, statusCounts] = await Promise.all([
            this.rawQuery(ctx, sql, [startDate, endDate]),
            this.rawQuery(ctx, statusSql, [startDate, endDate])
        ]);
        const orders_by_status = {};
        statusCounts.forEach(row => {
            orders_by_status[row.status] = parseInt(row.count, 10);
        });
        return {
            total_orders: parseInt(summary[0]?.total_orders || '0', 10),
            total_amount: parseFloat(summary[0]?.total_amount || '0'),
            average_order_value: parseFloat(summary[0]?.average_order_value || '0'),
            orders_by_status
        };
    }
}
exports.SalesOrderRepository = SalesOrderRepository;
// Singleton instance
exports.salesOrderRepository = new SalesOrderRepository();
exports.default = exports.salesOrderRepository;
//# sourceMappingURL=SalesOrderRepository.js.map