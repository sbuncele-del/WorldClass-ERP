/**
 * Invoice Repository
 *
 * Handles all database operations for sales invoices
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type InvoiceStatus = 'draft' | 'sent' | 'partial' | 'paid' | 'overdue' | 'cancelled' | 'void';
export interface InvoiceLine {
    id: string;
    invoice_id: string;
    item_id: string;
    item_code?: string;
    item_name?: string;
    description?: string;
    quantity: number;
    unit_price: number;
    discount_percent?: number;
    discount_amount?: number;
    tax_rate?: number;
    tax_amount?: number;
    line_total: number;
}
export interface Invoice {
    id: string;
    tenant_id: string;
    invoice_number: string;
    customer_id: string;
    customer_name?: string;
    order_id?: string;
    invoice_date: Date;
    due_date: Date;
    status: InvoiceStatus;
    subtotal: number;
    discount_amount?: number;
    tax_amount?: number;
    total_amount: number;
    amount_paid: number;
    balance_due: number;
    currency_code: string;
    exchange_rate?: number;
    payment_terms?: number;
    notes?: string;
    terms_and_conditions?: string;
    lines?: InvoiceLine[];
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class InvoiceRepository extends BaseRepository<Invoice> {
    protected tableName: string;
    protected schema: string;
    protected softDelete: boolean;
    /**
     * Get invoices by status
     */
    getInvoicesByStatus(ctx: TenantContext, status: InvoiceStatus, pagination?: PaginationOptions): Promise<PaginatedResult<Invoice>>;
    /**
     * Get invoice with lines
     */
    getInvoiceWithLines(ctx: TenantContext, invoiceId: string): Promise<Invoice | null>;
    /**
     * Get unpaid invoices for a customer
     */
    getUnpaidInvoices(ctx: TenantContext, customerId?: string): Promise<Invoice[]>;
    /**
     * Get invoices for a specific customer with pagination
     */
    getCustomerInvoices(ctx: TenantContext, customerId: string, pagination?: PaginationOptions): Promise<PaginatedResult<Invoice>>;
    /**
     * Get invoices within a date range
     */
    getInvoicesByDateRange(ctx: TenantContext, startDate: Date, endDate: Date, pagination?: PaginationOptions): Promise<PaginatedResult<Invoice>>;
    /**
     * Create invoice with lines
     */
    createInvoiceWithLines(ctx: TenantContext, invoiceData: Partial<Invoice>, lines: Partial<InvoiceLine>[]): Promise<Invoice>;
    /**
     * Sales report grouped by period or customer
     */
    getSalesReport(ctx: TenantContext, startDate: Date, endDate: Date, groupBy?: 'day' | 'week' | 'month' | 'customer'): Promise<any[]>;
    /**
     * Get overdue invoices
     */
    getOverdueInvoices(ctx: TenantContext): Promise<Invoice[]>;
    /**
     * Record a payment against an invoice
     */
    recordPayment(ctx: TenantContext, invoiceId: string, amount: number, paymentMethod: string, reference?: string): Promise<Invoice | null>;
    /**
     * Get invoice aging report
     */
    getAgingReport(ctx: TenantContext): Promise<{
        current: number;
        days_1_30: number;
        days_31_60: number;
        days_61_90: number;
        over_90: number;
        total: number;
    }>;
    /**
     * Generate next invoice number
     */
    generateInvoiceNumber(ctx: TenantContext): Promise<string>;
    /**
     * Create invoice from sales order
     */
    createFromOrder(ctx: TenantContext, orderId: string): Promise<Invoice>;
}
export declare const invoiceRepository: InvoiceRepository;
export default invoiceRepository;
//# sourceMappingURL=InvoiceRepository.d.ts.map