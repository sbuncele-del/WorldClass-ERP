"use strict";
/**
 * Sales Repositories Index
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.quotationRepository = exports.QuotationRepository = exports.invoiceRepository = exports.InvoiceRepository = exports.salesOrderRepository = exports.SalesOrderRepository = exports.customerRepository = exports.CustomerRepository = void 0;
var CustomerRepository_1 = require("./CustomerRepository");
Object.defineProperty(exports, "CustomerRepository", { enumerable: true, get: function () { return CustomerRepository_1.CustomerRepository; } });
Object.defineProperty(exports, "customerRepository", { enumerable: true, get: function () { return CustomerRepository_1.customerRepository; } });
var SalesOrderRepository_1 = require("./SalesOrderRepository");
Object.defineProperty(exports, "SalesOrderRepository", { enumerable: true, get: function () { return SalesOrderRepository_1.SalesOrderRepository; } });
Object.defineProperty(exports, "salesOrderRepository", { enumerable: true, get: function () { return SalesOrderRepository_1.salesOrderRepository; } });
var InvoiceRepository_1 = require("./InvoiceRepository");
Object.defineProperty(exports, "InvoiceRepository", { enumerable: true, get: function () { return InvoiceRepository_1.InvoiceRepository; } });
Object.defineProperty(exports, "invoiceRepository", { enumerable: true, get: function () { return InvoiceRepository_1.invoiceRepository; } });
var QuotationRepository_1 = require("./QuotationRepository");
Object.defineProperty(exports, "QuotationRepository", { enumerable: true, get: function () { return QuotationRepository_1.QuotationRepository; } });
Object.defineProperty(exports, "quotationRepository", { enumerable: true, get: function () { return QuotationRepository_1.quotationRepository; } });
//# sourceMappingURL=index.js.map