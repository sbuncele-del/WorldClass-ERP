/**
 * Sales Order Repository
 *
 * Handles all database operations for sales orders
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type OrderStatus = 'draft' | 'confirmed' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
export interface SalesOrderLine {
    id: string;
    order_id: string;
    item_id: string;
    item_code?: string;
    item_name?: string;
    quantity: number;
    unit_price: number;
    discount_percent?: number;
    discount_amount?: number;
    tax_rate?: number;
    tax_amount?: number;
    line_total: number;
    notes?: string;
}
export interface SalesOrder {
    id: string;
    tenant_id: string;
    order_number: string;
    customer_id: string;
    customer_name?: string;
    order_date: Date;
    delivery_date?: Date;
    status: OrderStatus;
    warehouse_id?: string;
    shipping_address?: {
        street?: string;
        city?: string;
        state?: string;
        postal_code?: string;
        country?: string;
    };
    subtotal: number;
    discount_amount?: number;
    tax_amount?: number;
    shipping_amount?: number;
    total_amount: number;
    currency_code: string;
    exchange_rate?: number;
    payment_terms?: number;
    notes?: string;
    internal_notes?: string;
    sales_rep_id?: string;
    quotation_id?: string;
    lines?: SalesOrderLine[];
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class SalesOrderRepository extends BaseRepository<SalesOrder> {
    protected tableName: string;
    protected schema: string;
    protected softDelete: boolean;
    /**
     * Get orders by status
     */
    getOrdersByStatus(ctx: TenantContext, status: OrderStatus, pagination?: PaginationOptions): Promise<PaginatedResult<SalesOrder>>;
    /**
     * Get orders for a customer
     */
    getCustomerOrders(ctx: TenantContext, customerId: string, pagination?: PaginationOptions): Promise<PaginatedResult<SalesOrder>>;
    /**
     * Get order with lines
     */
    getOrderWithLines(ctx: TenantContext, orderId: string): Promise<SalesOrder | null>;
    /**
     * Create order with lines
     */
    createOrderWithLines(ctx: TenantContext, orderData: Partial<SalesOrder>, lines: Partial<SalesOrderLine>[]): Promise<SalesOrder>;
    /**
     * Generate next order number
     */
    private generateOrderNumber;
    /**
     * Update order status
     */
    updateStatus(ctx: TenantContext, orderId: string, status: OrderStatus): Promise<SalesOrder | null>;
    /**
     * Get orders by date range
     */
    getOrdersByDateRange(ctx: TenantContext, startDate: Date, endDate: Date, pagination?: PaginationOptions): Promise<PaginatedResult<SalesOrder>>;
    /**
     * Get sales summary for dashboard
     */
    getSalesSummary(ctx: TenantContext, startDate: Date, endDate: Date): Promise<{
        total_orders: number;
        total_amount: number;
        average_order_value: number;
        orders_by_status: Record<string, number>;
    }>;
}
export declare const salesOrderRepository: SalesOrderRepository;
export default salesOrderRepository;
//# sourceMappingURL=SalesOrderRepository.d.ts.map