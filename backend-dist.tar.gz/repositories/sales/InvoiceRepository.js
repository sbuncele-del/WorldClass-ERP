"use strict";
/**
 * Invoice Repository
 *
 * Handles all database operations for sales invoices
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.invoiceRepository = exports.InvoiceRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class InvoiceRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'invoices';
        this.schema = 'sales';
        this.softDelete = false; // Table doesn't have deleted_at column
    }
    /**
     * Get invoices by status
     */
    async getInvoicesByStatus(ctx, status, pagination) {
        return this.findAll(ctx, { status }, pagination);
    }
    /**
     * Get invoice with lines
     */
    async getInvoiceWithLines(ctx, invoiceId) {
        const invoice = await this.findById(ctx, invoiceId);
        if (!invoice)
            return null;
        const linesSql = `
      SELECT il.*, i.code as item_code, i.name as item_name
      FROM sales.invoice_lines il
      LEFT JOIN inventory.items i ON i.id = il.item_id
      WHERE il.invoice_id = $2 AND il.tenant_id = $1
      ORDER BY il.line_number
    `;
        const lines = await this.rawQuery(ctx, linesSql, [invoiceId]);
        return { ...invoice, lines };
    }
    /**
     * Get unpaid invoices for a customer
     */
    async getUnpaidInvoices(ctx, customerId) {
        let sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND status NOT IN ('paid', 'cancelled', 'void')
    `;
        const params = [];
        if (customerId) {
            sql += ` AND customer_id = $2`;
            params.push(customerId);
        }
        sql += ` ORDER BY due_date ASC`;
        return this.rawQuery(ctx, sql, params);
    }
    /**
     * Get invoices for a specific customer with pagination
     */
    async getCustomerInvoices(ctx, customerId, pagination) {
        return this.findAll(ctx, { customer_id: customerId }, pagination);
    }
    /**
     * Get invoices within a date range
     */
    async getInvoicesByDateRange(ctx, startDate, endDate, pagination) {
        const { page = 1, limit = 50, sortBy = 'invoice_date', sortOrder = 'DESC' } = pagination || {};
        const offset = (page - 1) * limit;
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND invoice_date BETWEEN $2 AND $3
      ORDER BY ${sortBy} ${sortOrder}
      LIMIT $4 OFFSET $5
    `;
        const countSql = `
      SELECT COUNT(*) FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND invoice_date BETWEEN $2 AND $3
    `;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, [startDate, endDate, limit, offset]),
            this.rawQuery(ctx, countSql, [startDate, endDate])
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
        };
    }
    /**
     * Create invoice with lines
     */
    async createInvoiceWithLines(ctx, invoiceData, lines) {
        const client = await this.beginTransaction();
        try {
            const invoiceNumber = await this.generateInvoiceNumber(ctx);
            const invoiceResult = await client.query(`
        INSERT INTO ${this.fullTableName}
        (tenant_id, invoice_number, customer_id, order_id, invoice_date, due_date, status,
         subtotal, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
         currency_code, payment_terms, notes, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
        RETURNING *
      `, [
                ctx.tenantId,
                invoiceNumber,
                invoiceData.customer_id,
                invoiceData.order_id,
                invoiceData.invoice_date || new Date(),
                invoiceData.due_date || new Date(),
                invoiceData.status || 'draft',
                invoiceData.subtotal || 0,
                invoiceData.discount_amount || 0,
                invoiceData.tax_amount || 0,
                invoiceData.total_amount || 0,
                invoiceData.amount_paid || 0,
                invoiceData.balance_due ?? (invoiceData.total_amount || 0),
                invoiceData.currency_code || 'ZAR',
                invoiceData.payment_terms,
                invoiceData.notes,
                ctx.userId
            ]);
            const invoice = invoiceResult.rows[0];
            // Insert lines
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                await client.query(`
          INSERT INTO sales.invoice_lines
          (tenant_id, invoice_id, line_number, item_id, description, quantity, unit_price,
           discount_percent, discount_amount, tax_rate, tax_amount, line_total)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        `, [
                    ctx.tenantId,
                    invoice.id,
                    i + 1,
                    line.item_id,
                    line.description,
                    line.quantity,
                    line.unit_price,
                    line.discount_percent || 0,
                    line.discount_amount || 0,
                    line.tax_rate || 0,
                    line.tax_amount || 0,
                    line.line_total || 0
                ]);
            }
            await this.commitTransaction(client);
            return invoice;
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
    /**
     * Sales report grouped by period or customer
     */
    async getSalesReport(ctx, startDate, endDate, groupBy = 'day') {
        const groupExpression = groupBy === 'customer'
            ? 'customer_id'
            : `DATE_TRUNC('${groupBy}', invoice_date)`;
        const sql = `
      SELECT ${groupExpression} as period,
             SUM(total_amount) as total_amount,
             SUM(tax_amount) as tax_amount,
             SUM(discount_amount) as discount_amount,
             SUM(balance_due) as balance_due,
             COUNT(*) as invoice_count
      FROM ${this.fullTableName}
      WHERE tenant_id = $1
        AND deleted_at IS NULL
        AND invoice_date BETWEEN $2 AND $3
      GROUP BY period
      ORDER BY period ASC
    `;
        return this.rawQuery(ctx, sql, [startDate, endDate]);
    }
    /**
     * Get overdue invoices
     */
    async getOverdueInvoices(ctx) {
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND due_date < CURRENT_DATE
        AND status NOT IN ('paid', 'cancelled', 'void')
      ORDER BY due_date ASC
    `;
        return this.rawQuery(ctx, sql);
    }
    /**
     * Record a payment against an invoice
     */
    async recordPayment(ctx, invoiceId, amount, paymentMethod, reference) {
        const client = await this.beginTransaction();
        try {
            // Get current invoice
            const invoiceResult = await client.query(`
        SELECT * FROM ${this.fullTableName}
        WHERE id = $1 AND tenant_id = $2 AND deleted_at IS NULL
      `, [invoiceId, ctx.tenantId]);
            const invoice = invoiceResult.rows[0];
            if (!invoice) {
                await this.rollbackTransaction(client);
                return null;
            }
            const newAmountPaid = parseFloat(invoice.amount_paid) + amount;
            const newBalanceDue = parseFloat(invoice.total_amount) - newAmountPaid;
            let newStatus = invoice.status;
            if (newBalanceDue <= 0) {
                newStatus = 'paid';
            }
            else if (newAmountPaid > 0) {
                newStatus = 'partial';
            }
            // Update invoice
            await client.query(`
        UPDATE ${this.fullTableName}
        SET amount_paid = $1, balance_due = $2, status = $3, updated_at = NOW(), updated_by = $4
        WHERE id = $5 AND tenant_id = $6
      `, [newAmountPaid, Math.max(0, newBalanceDue), newStatus, ctx.userId, invoiceId, ctx.tenantId]);
            // Record payment
            await client.query(`
        INSERT INTO sales.payments
        (tenant_id, invoice_id, customer_id, amount, payment_date, payment_method, reference, created_by)
        VALUES ($1, $2, $3, $4, CURRENT_DATE, $5, $6, $7)
      `, [ctx.tenantId, invoiceId, invoice.customer_id, amount, paymentMethod, reference, ctx.userId]);
            await this.commitTransaction(client);
            return this.findById(ctx, invoiceId);
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
    /**
     * Get invoice aging report
     */
    async getAgingReport(ctx) {
        const sql = `
      SELECT
        COALESCE(SUM(CASE WHEN due_date >= CURRENT_DATE THEN balance_due ELSE 0 END), 0) as current,
        COALESCE(SUM(CASE WHEN due_date < CURRENT_DATE AND due_date >= CURRENT_DATE - 30 THEN balance_due ELSE 0 END), 0) as days_1_30,
        COALESCE(SUM(CASE WHEN due_date < CURRENT_DATE - 30 AND due_date >= CURRENT_DATE - 60 THEN balance_due ELSE 0 END), 0) as days_31_60,
        COALESCE(SUM(CASE WHEN due_date < CURRENT_DATE - 60 AND due_date >= CURRENT_DATE - 90 THEN balance_due ELSE 0 END), 0) as days_61_90,
        COALESCE(SUM(CASE WHEN due_date < CURRENT_DATE - 90 THEN balance_due ELSE 0 END), 0) as over_90,
        COALESCE(SUM(balance_due), 0) as total
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND status NOT IN ('paid', 'cancelled', 'void')
    `;
        const result = await this.rawQuery(ctx, sql);
        return {
            current: parseFloat(result[0]?.current || '0'),
            days_1_30: parseFloat(result[0]?.days_1_30 || '0'),
            days_31_60: parseFloat(result[0]?.days_31_60 || '0'),
            days_61_90: parseFloat(result[0]?.days_61_90 || '0'),
            over_90: parseFloat(result[0]?.over_90 || '0'),
            total: parseFloat(result[0]?.total || '0')
        };
    }
    /**
     * Generate next invoice number
     */
    async generateInvoiceNumber(ctx) {
        const result = await this.pool.query(`
      SELECT COALESCE(MAX(CAST(SUBSTRING(invoice_number FROM '[0-9]+$') AS INTEGER)), 0) + 1 as next_num
      FROM ${this.fullTableName}
      WHERE tenant_id = $1
    `, [ctx.tenantId]);
        const nextNum = result.rows[0].next_num;
        return `INV-${String(nextNum).padStart(6, '0')}`;
    }
    /**
     * Create invoice from sales order
     */
    async createFromOrder(ctx, orderId) {
        const client = await this.beginTransaction();
        try {
            // Get order with lines
            const orderResult = await client.query(`
        SELECT * FROM sales.orders
        WHERE id = $1 AND tenant_id = $2 AND deleted_at IS NULL
      `, [orderId, ctx.tenantId]);
            const order = orderResult.rows[0];
            if (!order) {
                throw new Error('Order not found');
            }
            const invoiceNumber = await this.generateInvoiceNumber(ctx);
            const dueDate = new Date();
            dueDate.setDate(dueDate.getDate() + (order.payment_terms || 30));
            // Create invoice
            const invoiceResult = await client.query(`
        INSERT INTO ${this.fullTableName}
        (tenant_id, invoice_number, customer_id, order_id, invoice_date, due_date, status,
         subtotal, discount_amount, tax_amount, total_amount, amount_paid, balance_due,
         currency_code, payment_terms, notes, created_by)
        VALUES ($1, $2, $3, $4, CURRENT_DATE, $5, 'draft', $6, $7, $8, $9, 0, $9, $10, $11, $12, $13)
        RETURNING *
      `, [
                ctx.tenantId, invoiceNumber, order.customer_id, orderId, dueDate,
                order.subtotal, order.discount_amount, order.tax_amount, order.total_amount,
                order.currency_code, order.payment_terms, order.notes, ctx.userId
            ]);
            const invoice = invoiceResult.rows[0];
            // Copy order lines to invoice lines
            await client.query(`
        INSERT INTO sales.invoice_lines
        (tenant_id, invoice_id, line_number, item_id, description, quantity, unit_price,
         discount_percent, discount_amount, tax_rate, tax_amount, line_total)
        SELECT tenant_id, $1, line_number, item_id, notes, quantity, unit_price,
               discount_percent, discount_amount, tax_rate, tax_amount, line_total
        FROM sales.order_lines
        WHERE order_id = $2 AND tenant_id = $3
      `, [invoice.id, orderId, ctx.tenantId]);
            await this.commitTransaction(client);
            return invoice;
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
}
exports.InvoiceRepository = InvoiceRepository;
// Singleton instance
exports.invoiceRepository = new InvoiceRepository();
exports.default = exports.invoiceRepository;
//# sourceMappingURL=InvoiceRepository.js.map