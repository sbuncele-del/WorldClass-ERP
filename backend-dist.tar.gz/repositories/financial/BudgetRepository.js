"use strict";
/**
 * Budget Repository
 *
 * Handles all database operations for budgets
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.budgetRepository = exports.BudgetRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class BudgetRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'budgets';
        this.schema = 'financial';
    }
    /**
     * Get budget with lines
     */
    async getBudgetWithLines(ctx, budgetId) {
        const budget = await this.findById(ctx, budgetId);
        if (!budget)
            return null;
        const linesSql = `
      SELECT bl.*, a.account_number, a.name as account_name
      FROM financial.budget_lines bl
      JOIN financial.accounts a ON a.id = bl.account_id
      WHERE bl.budget_id = $2 AND bl.tenant_id = $1
      ORDER BY a.account_number
    `;
        const lines = await this.rawQuery(ctx, linesSql, [budgetId]);
        return { ...budget, lines };
    }
    /**
     * Get active budget for current period
     */
    async getActiveBudget(ctx) {
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND status = 'active'
        AND CURRENT_DATE BETWEEN start_date AND end_date
      LIMIT 1
    `;
        const result = await this.rawQuery(ctx, sql);
        return result[0] || null;
    }
    /**
     * Get budget vs actual comparison
     */
    async getBudgetVsActual(ctx, budgetId, asOfDate) {
        const budget = await this.findById(ctx, budgetId);
        if (!budget)
            throw new Error('Budget not found');
        const sql = `
      SELECT 
        a.id as account_id,
        a.account_number,
        a.name as account_name,
        COALESCE(bl.total_budget, 0) as budget_amount,
        COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as actual_amount,
        COALESCE(bl.total_budget, 0) - COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as variance,
        CASE WHEN COALESCE(bl.total_budget, 0) = 0 THEN 0
          ELSE ((COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) / bl.total_budget) - 1) * 100
        END as variance_percent
      FROM financial.accounts a
      LEFT JOIN financial.budget_lines bl ON bl.account_id = a.id AND bl.budget_id = $2
      LEFT JOIN journal_entry_lines jel ON jel.account_id = a.id AND jel.tenant_id = $1
      LEFT JOIN journal_entries je ON je.entry_id = jel.journal_entry_id 
        AND je.status = 'posted' 
        AND je.posting_date BETWEEN $3 AND $4
      WHERE a.tenant_id = $1 
        AND a.deleted_at IS NULL 
        AND a.is_header = false
        AND a.account_type IN ('expense', 'revenue')
      GROUP BY a.id, a.account_number, a.name, bl.total_budget
      HAVING COALESCE(bl.total_budget, 0) > 0 OR COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) != 0
      ORDER BY a.account_number
    `;
        return this.rawQuery(ctx, sql, [budgetId, budget.start_date, asOfDate || budget.end_date]);
    }
    /**
     * Approve budget
     */
    async approveBudget(ctx, budgetId) {
        return this.update(ctx, budgetId, { status: 'approved' });
    }
    /**
     * Activate budget
     */
    async activateBudget(ctx, budgetId) {
        return this.update(ctx, budgetId, { status: 'active' });
    }
}
exports.BudgetRepository = BudgetRepository;
// Singleton instance
exports.budgetRepository = new BudgetRepository();
exports.default = exports.budgetRepository;
//# sourceMappingURL=BudgetRepository.js.map