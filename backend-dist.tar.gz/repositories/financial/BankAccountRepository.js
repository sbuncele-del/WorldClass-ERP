"use strict";
/**
 * Bank Account Repository
 *
 * Handles all database operations for bank accounts
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.bankAccountRepository = exports.BankAccountRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class BankAccountRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'bank_accounts';
        this.schema = 'financial';
    }
    /**
     * Get all active bank accounts
     */
    async getActiveAccounts(ctx) {
        const result = await this.findAll(ctx, { is_active: true });
        return result.data;
    }
    /**
     * Get default bank account
     */
    async getDefaultAccount(ctx) {
        return this.findOne(ctx, { is_default: true, is_active: true });
    }
    /**
     * Set default bank account
     */
    async setDefaultAccount(ctx, accountId) {
        const client = await this.beginTransaction();
        try {
            await client.query(`
        UPDATE ${this.fullTableName}
        SET is_default = false, updated_at = NOW()
        WHERE tenant_id = $1
      `, [ctx.tenantId]);
            await client.query(`
        UPDATE ${this.fullTableName}
        SET is_default = true, updated_at = NOW()
        WHERE tenant_id = $1 AND id = $2
      `, [ctx.tenantId, accountId]);
            await this.commitTransaction(client);
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
    /**
     * Update balance after transaction
     */
    async updateBalance(ctx, accountId, amount) {
        const sql = `
      UPDATE ${this.fullTableName}
      SET current_balance = current_balance + $1, updated_at = NOW(), updated_by = $2
      WHERE id = $3 AND tenant_id = $4
      RETURNING *
    `;
        const result = await this.query(sql, [amount, ctx.userId, accountId, ctx.tenantId]);
        return result.rows[0] || null;
    }
    /**
     * Get total cash balance across all accounts
     */
    async getTotalBalance(ctx) {
        const sql = `
      SELECT currency_code, SUM(current_balance) as total
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND deleted_at IS NULL AND is_active = true
      GROUP BY currency_code
    `;
        return this.rawQuery(ctx, sql);
    }
    /**
     * Record reconciliation
     */
    async recordReconciliation(ctx, accountId, reconcileDate, reconcileBalance) {
        return this.update(ctx, accountId, {
            last_reconciled_date: reconcileDate,
            last_reconciled_balance: reconcileBalance
        });
    }
}
exports.BankAccountRepository = BankAccountRepository;
// Singleton instance
exports.bankAccountRepository = new BankAccountRepository();
exports.default = exports.bankAccountRepository;
//# sourceMappingURL=BankAccountRepository.js.map