"use strict";
/**
 * Journal Entry Repository
 *
 * Handles all database operations for journal entries
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.journalEntryRepository = exports.JournalEntryRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class JournalEntryRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'journal_entries';
        this.schema = 'public';
        this.primaryKey = 'entry_id';
    }
    /**
     * Get entry with lines
     */
    async getEntryWithLines(ctx, entryId) {
        const entry = await this.findById(ctx, entryId);
        if (!entry)
            return null;
        const linesSql = `
      SELECT jel.*, a.account_number, a.name as account_name
      FROM journal_entry_lines jel
      JOIN financial.accounts a ON a.id = jel.account_id
      WHERE jel.journal_entry_id = $2 AND jel.tenant_id = $1
      ORDER BY jel.line_number
    `;
        const lines = await this.rawQuery(ctx, linesSql, [entryId]);
        return { ...entry, lines };
    }
    /**
     * Create journal entry with lines
     */
    async createEntry(ctx, entryData, lines) {
        // Validate debits = credits
        const totalDebit = lines.reduce((sum, l) => sum + (l.debit_amount || 0), 0);
        const totalCredit = lines.reduce((sum, l) => sum + (l.credit_amount || 0), 0);
        if (Math.abs(totalDebit - totalCredit) > 0.01) {
            throw new Error(`Journal entry must balance. Debits: ${totalDebit}, Credits: ${totalCredit}`);
        }
        const client = await this.beginTransaction();
        try {
            // Generate entry number
            const numResult = await client.query(`
        SELECT COALESCE(MAX(CAST(SUBSTRING(entry_number FROM '[0-9]+$') AS INTEGER)), 0) + 1 as next_num
        FROM ${this.fullTableName}
        WHERE tenant_id = $1
      `, [ctx.tenantId]);
            const entryNumber = `JE-${String(numResult.rows[0].next_num).padStart(6, '0')}`;
            // Create entry
            const entryResult = await client.query(`
        INSERT INTO ${this.fullTableName}
        (tenant_id, entry_number, journal_type, posting_date, description, reference,
         status, total_debit, total_credit, source_type, source_id, created_by)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        RETURNING *
      `, [
                ctx.tenantId, entryNumber, entryData.journal_type || 'general',
                entryData.posting_date || new Date(), entryData.description,
                entryData.reference, entryData.status || 'draft',
                totalDebit, totalCredit, entryData.source_type, entryData.source_id, ctx.userId
            ]);
            const entry = entryResult.rows[0];
            // Create lines
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                await client.query(`
          INSERT INTO journal_entry_lines
          (tenant_id, journal_entry_id, line_number, account_id, description,
           debit_amount, credit_amount, cost_center_id, project_id)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        `, [
                    ctx.tenantId, entry.entry_id, i + 1, line.account_id, line.description,
                    line.debit_amount || 0, line.credit_amount || 0,
                    line.cost_center_id, line.project_id
                ]);
            }
            await this.commitTransaction(client);
            return entry;
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
    /**
     * Post a journal entry
     */
    async postEntry(ctx, entryId) {
        const entry = await this.findById(ctx, entryId);
        if (!entry || entry.status !== 'draft') {
            throw new Error('Entry cannot be posted');
        }
        return this.update(ctx, entryId, {
            status: 'posted',
            posted_by: ctx.userId,
            posted_at: new Date()
        });
    }
    /**
     * Reverse a posted journal entry
     */
    async reverseEntry(ctx, entryId, reversalDate) {
        const entry = await this.getEntryWithLines(ctx, entryId);
        if (!entry || entry.status !== 'posted') {
            throw new Error('Only posted entries can be reversed');
        }
        // Create reversal entry with swapped debits/credits
        const reversalLines = (entry.lines || []).map(line => ({
            account_id: line.account_id,
            description: `Reversal of ${entry.entry_number}: ${line.description || ''}`,
            debit_amount: line.credit_amount,
            credit_amount: line.debit_amount,
            cost_center_id: line.cost_center_id,
            project_id: line.project_id
        }));
        const reversalEntry = await this.createEntry(ctx, {
            journal_type: entry.journal_type,
            posting_date: reversalDate,
            description: `Reversal of ${entry.entry_number}`,
            reference: entry.reference,
            status: 'posted',
            reversal_of_id: entryId
        }, reversalLines);
        // Mark original entry as reversed
        await this.update(ctx, entryId, {
            status: 'reversed',
            reversed_by_id: reversalEntry.id
        });
        return reversalEntry;
    }
    /**
     * Get entries by date range
     */
    async getEntriesByDateRange(ctx, startDate, endDate, status, pagination) {
        const { page = 1, limit = 50 } = pagination || {};
        const offset = (page - 1) * limit;
        const params = [startDate, endDate];
        let conditions = 'posting_date BETWEEN $2 AND $3';
        let paramIndex = 4;
        if (status) {
            conditions += ` AND status = $${paramIndex}`;
            params.push(status);
            paramIndex++;
        }
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND deleted_at IS NULL AND ${conditions}
      ORDER BY posting_date DESC, entry_number DESC
      LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
    `;
        params.push(limit, offset);
        const countSql = `
      SELECT COUNT(*) FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND deleted_at IS NULL AND ${conditions}
    `;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, params),
            this.rawQuery(ctx, countSql, params.slice(0, -2))
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
        };
    }
    /**
     * Get account ledger (all entries for an account)
     */
    async getAccountLedger(ctx, accountId, startDate, endDate) {
        const sql = `
      WITH entries AS (
        SELECT 
          je.posting_date as date,
          je.entry_number,
          COALESCE(jel.description, je.description) as description,
          jel.debit_amount as debit,
          jel.credit_amount as credit
        FROM journal_entry_lines jel
        JOIN ${this.fullTableName} je ON je.entry_id = jel.journal_entry_id
        WHERE jel.tenant_id = $1 
          AND jel.account_id = $2
          AND je.status = 'posted'
          AND je.posting_date BETWEEN $3 AND $4
        ORDER BY je.posting_date, je.entry_number
      )
      SELECT 
        *,
        SUM(debit - credit) OVER (ORDER BY date, entry_number) as running_balance
      FROM entries
    `;
        return this.rawQuery(ctx, sql, [accountId, startDate, endDate]);
    }
}
exports.JournalEntryRepository = JournalEntryRepository;
// Singleton instance
exports.journalEntryRepository = new JournalEntryRepository();
exports.default = exports.journalEntryRepository;
//# sourceMappingURL=JournalEntryRepository.js.map