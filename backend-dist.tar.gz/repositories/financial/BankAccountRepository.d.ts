/**
 * Bank Account Repository
 *
 * Handles all database operations for bank accounts
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export interface BankAccount {
    id: string;
    tenant_id: string;
    name: string;
    account_number: string;
    bank_name: string;
    branch_code?: string;
    swift_code?: string;
    iban?: string;
    currency_code: string;
    gl_account_id?: string;
    current_balance: number;
    is_default: boolean;
    is_active: boolean;
    last_reconciled_date?: Date;
    last_reconciled_balance?: number;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class BankAccountRepository extends BaseRepository<BankAccount> {
    protected tableName: string;
    protected schema: string;
    /**
     * Get all active bank accounts
     */
    getActiveAccounts(ctx: TenantContext): Promise<BankAccount[]>;
    /**
     * Get default bank account
     */
    getDefaultAccount(ctx: TenantContext): Promise<BankAccount | null>;
    /**
     * Set default bank account
     */
    setDefaultAccount(ctx: TenantContext, accountId: string): Promise<void>;
    /**
     * Update balance after transaction
     */
    updateBalance(ctx: TenantContext, accountId: string, amount: number): Promise<BankAccount | null>;
    /**
     * Get total cash balance across all accounts
     */
    getTotalBalance(ctx: TenantContext): Promise<{
        currency_code: string;
        total: number;
    }[]>;
    /**
     * Record reconciliation
     */
    recordReconciliation(ctx: TenantContext, accountId: string, reconcileDate: Date, reconcileBalance: number): Promise<BankAccount | null>;
}
export declare const bankAccountRepository: BankAccountRepository;
export default bankAccountRepository;
//# sourceMappingURL=BankAccountRepository.d.ts.map