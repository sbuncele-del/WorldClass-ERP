/**
 * Account Repository (Chart of Accounts)
 *
 * Handles all database operations for GL accounts
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type AccountType = 'asset' | 'liability' | 'equity' | 'revenue' | 'expense';
export interface Account {
    id: string;
    tenant_id: string;
    account_number: string;
    name: string;
    description?: string;
    account_type: AccountType;
    parent_id?: string;
    is_header: boolean;
    is_active: boolean;
    is_system: boolean;
    currency_code?: string;
    opening_balance?: number;
    current_balance?: number;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class AccountRepository extends BaseRepository<Account> {
    protected tableName: string;
    protected schema: string;
    /**
     * Get chart of accounts tree
     */
    getChartOfAccounts(ctx: TenantContext): Promise<Account[]>;
    /**
     * Get accounts by type
     */
    getAccountsByType(ctx: TenantContext, accountType: AccountType): Promise<Account[]>;
    /**
     * Get posting accounts only (non-header accounts)
     */
    getPostingAccounts(ctx: TenantContext): Promise<Account[]>;
    /**
     * Check if account number is unique
     */
    isAccountNumberUnique(ctx: TenantContext, accountNumber: string, excludeId?: string): Promise<boolean>;
    /**
     * Get account balance
     */
    getAccountBalance(ctx: TenantContext, accountId: string, asOfDate?: Date): Promise<number>;
    /**
     * Get trial balance
     */
    getTrialBalance(ctx: TenantContext, asOfDate: Date): Promise<{
        account_id: string;
        account_number: string;
        account_name: string;
        account_type: AccountType;
        debit_balance: number;
        credit_balance: number;
    }[]>;
}
export declare const accountRepository: AccountRepository;
export default accountRepository;
//# sourceMappingURL=AccountRepository.d.ts.map