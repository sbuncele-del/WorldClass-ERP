/**
 * Journal Entry Repository
 *
 * Handles all database operations for journal entries
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type JournalEntryStatus = 'draft' | 'pending_approval' | 'posted' | 'reversed';
export type JournalType = 'general' | 'sales' | 'purchase' | 'cash' | 'adjustment' | 'closing';
export interface JournalEntryLine {
    id: string;
    journal_entry_id: string;
    account_id: string;
    account_number?: string;
    account_name?: string;
    description?: string;
    debit_amount: number;
    credit_amount: number;
    cost_center_id?: string;
    project_id?: string;
}
export interface JournalEntry {
    id: string;
    tenant_id: string;
    entry_number: string;
    journal_type: JournalType;
    posting_date: Date;
    description: string;
    reference?: string;
    status: JournalEntryStatus;
    total_debit: number;
    total_credit: number;
    source_type?: string;
    source_id?: string;
    fiscal_year_id?: string;
    fiscal_period_id?: string;
    approved_by?: string;
    approved_at?: Date;
    posted_by?: string;
    posted_at?: Date;
    reversal_of_id?: string;
    reversed_by_id?: string;
    lines?: JournalEntryLine[];
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class JournalEntryRepository extends BaseRepository<JournalEntry> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    /**
     * Get entry with lines
     */
    getEntryWithLines(ctx: TenantContext, entryId: string): Promise<JournalEntry | null>;
    /**
     * Create journal entry with lines
     */
    createEntry(ctx: TenantContext, entryData: Partial<JournalEntry>, lines: Partial<JournalEntryLine>[]): Promise<JournalEntry>;
    /**
     * Post a journal entry
     */
    postEntry(ctx: TenantContext, entryId: string): Promise<JournalEntry | null>;
    /**
     * Reverse a posted journal entry
     */
    reverseEntry(ctx: TenantContext, entryId: string, reversalDate: Date): Promise<JournalEntry>;
    /**
     * Get entries by date range
     */
    getEntriesByDateRange(ctx: TenantContext, startDate: Date, endDate: Date, status?: JournalEntryStatus, pagination?: PaginationOptions): Promise<PaginatedResult<JournalEntry>>;
    /**
     * Get account ledger (all entries for an account)
     */
    getAccountLedger(ctx: TenantContext, accountId: string, startDate: Date, endDate: Date): Promise<{
        date: Date;
        entry_number: string;
        description: string;
        debit: number;
        credit: number;
        running_balance: number;
    }[]>;
}
export declare const journalEntryRepository: JournalEntryRepository;
export default journalEntryRepository;
//# sourceMappingURL=JournalEntryRepository.d.ts.map