/**
 * Budget Repository
 *
 * Handles all database operations for budgets
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type BudgetStatus = 'draft' | 'approved' | 'active' | 'closed';
export interface BudgetLine {
    id: string;
    budget_id: string;
    account_id: string;
    account_number?: string;
    account_name?: string;
    period_1?: number;
    period_2?: number;
    period_3?: number;
    period_4?: number;
    period_5?: number;
    period_6?: number;
    period_7?: number;
    period_8?: number;
    period_9?: number;
    period_10?: number;
    period_11?: number;
    period_12?: number;
    total_budget: number;
}
export interface Budget {
    id: string;
    tenant_id: string;
    name: string;
    description?: string;
    fiscal_year_id?: string;
    start_date: Date;
    end_date: Date;
    status: BudgetStatus;
    total_budget: number;
    lines?: BudgetLine[];
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export interface BudgetVsActual {
    account_id: string;
    account_number: string;
    account_name: string;
    budget_amount: number;
    actual_amount: number;
    variance: number;
    variance_percent: number;
}
export declare class BudgetRepository extends BaseRepository<Budget> {
    protected tableName: string;
    protected schema: string;
    /**
     * Get budget with lines
     */
    getBudgetWithLines(ctx: TenantContext, budgetId: string): Promise<Budget | null>;
    /**
     * Get active budget for current period
     */
    getActiveBudget(ctx: TenantContext): Promise<Budget | null>;
    /**
     * Get budget vs actual comparison
     */
    getBudgetVsActual(ctx: TenantContext, budgetId: string, asOfDate?: Date): Promise<BudgetVsActual[]>;
    /**
     * Approve budget
     */
    approveBudget(ctx: TenantContext, budgetId: string): Promise<Budget | null>;
    /**
     * Activate budget
     */
    activateBudget(ctx: TenantContext, budgetId: string): Promise<Budget | null>;
}
export declare const budgetRepository: BudgetRepository;
export default budgetRepository;
//# sourceMappingURL=BudgetRepository.d.ts.map