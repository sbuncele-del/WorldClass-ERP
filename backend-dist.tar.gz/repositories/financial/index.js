"use strict";
/**
 * Financial Repositories Index
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.budgetRepository = exports.BudgetRepository = exports.bankAccountRepository = exports.BankAccountRepository = exports.journalEntryRepository = exports.JournalEntryRepository = exports.accountRepository = exports.AccountRepository = void 0;
var AccountRepository_1 = require("./AccountRepository");
Object.defineProperty(exports, "AccountRepository", { enumerable: true, get: function () { return AccountRepository_1.AccountRepository; } });
Object.defineProperty(exports, "accountRepository", { enumerable: true, get: function () { return AccountRepository_1.accountRepository; } });
var JournalEntryRepository_1 = require("./JournalEntryRepository");
Object.defineProperty(exports, "JournalEntryRepository", { enumerable: true, get: function () { return JournalEntryRepository_1.JournalEntryRepository; } });
Object.defineProperty(exports, "journalEntryRepository", { enumerable: true, get: function () { return JournalEntryRepository_1.journalEntryRepository; } });
var BankAccountRepository_1 = require("./BankAccountRepository");
Object.defineProperty(exports, "BankAccountRepository", { enumerable: true, get: function () { return BankAccountRepository_1.BankAccountRepository; } });
Object.defineProperty(exports, "bankAccountRepository", { enumerable: true, get: function () { return BankAccountRepository_1.bankAccountRepository; } });
var BudgetRepository_1 = require("./BudgetRepository");
Object.defineProperty(exports, "BudgetRepository", { enumerable: true, get: function () { return BudgetRepository_1.BudgetRepository; } });
Object.defineProperty(exports, "budgetRepository", { enumerable: true, get: function () { return BudgetRepository_1.budgetRepository; } });
//# sourceMappingURL=index.js.map