/**
 * Goods Receipt Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type GoodsReceiptStatus = 'draft' | 'confirmed' | 'cancelled';
export interface GoodsReceiptLine {
    line_id: number;
    gr_id: number;
    po_line_id?: number;
    item_code?: string;
    description?: string;
    quantity_ordered?: number;
    quantity_received: number;
    quantity_rejected?: number;
    rejection_reason?: string;
    unit_of_measure?: string;
    notes?: string;
    line_number?: number;
}
export interface GoodsReceipt {
    gr_id: number;
    tenant_id: string;
    gr_number: string;
    gr_date: Date;
    po_id?: number;
    supplier_id?: number;
    delivery_note_number?: string;
    received_by?: number;
    status: GoodsReceiptStatus;
    total_quantity: number;
    warehouse_id?: number;
    notes?: string;
    confirmed?: boolean;
    confirmed_by?: number;
    confirmed_date?: Date;
    created_at: Date;
    created_by?: number;
    updated_at?: Date;
    updated_by?: number;
    deleted_at?: Date;
    lines?: GoodsReceiptLine[];
}
export declare class GoodsReceiptRepository extends BaseRepository<GoodsReceipt> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getWithLines(ctx: TenantContext, grId: string): Promise<GoodsReceipt | null>;
    createWithLines(ctx: TenantContext, data: Partial<GoodsReceipt>, lines: Partial<GoodsReceiptLine>[]): Promise<GoodsReceipt>;
}
export declare const goodsReceiptRepository: GoodsReceiptRepository;
export default goodsReceiptRepository;
//# sourceMappingURL=GoodsReceiptRepository.d.ts.map