"use strict";
/**
 * Purchase Repositories Index
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.goodsReceiptRepository = exports.GoodsReceiptRepository = exports.requisitionRepository = exports.RequisitionRepository = exports.purchaseInvoiceRepository = exports.PurchaseInvoiceRepository = exports.purchaseOrderRepository = exports.PurchaseOrderRepository = exports.supplierRepository = exports.SupplierRepository = void 0;
var SupplierRepository_1 = require("./SupplierRepository");
Object.defineProperty(exports, "SupplierRepository", { enumerable: true, get: function () { return SupplierRepository_1.SupplierRepository; } });
Object.defineProperty(exports, "supplierRepository", { enumerable: true, get: function () { return SupplierRepository_1.supplierRepository; } });
var PurchaseOrderRepository_1 = require("./PurchaseOrderRepository");
Object.defineProperty(exports, "PurchaseOrderRepository", { enumerable: true, get: function () { return PurchaseOrderRepository_1.PurchaseOrderRepository; } });
Object.defineProperty(exports, "purchaseOrderRepository", { enumerable: true, get: function () { return PurchaseOrderRepository_1.purchaseOrderRepository; } });
var PurchaseInvoiceRepository_1 = require("./PurchaseInvoiceRepository");
Object.defineProperty(exports, "PurchaseInvoiceRepository", { enumerable: true, get: function () { return PurchaseInvoiceRepository_1.PurchaseInvoiceRepository; } });
Object.defineProperty(exports, "purchaseInvoiceRepository", { enumerable: true, get: function () { return PurchaseInvoiceRepository_1.purchaseInvoiceRepository; } });
var RequisitionRepository_1 = require("./RequisitionRepository");
Object.defineProperty(exports, "RequisitionRepository", { enumerable: true, get: function () { return RequisitionRepository_1.RequisitionRepository; } });
Object.defineProperty(exports, "requisitionRepository", { enumerable: true, get: function () { return RequisitionRepository_1.requisitionRepository; } });
var GoodsReceiptRepository_1 = require("./GoodsReceiptRepository");
Object.defineProperty(exports, "GoodsReceiptRepository", { enumerable: true, get: function () { return GoodsReceiptRepository_1.GoodsReceiptRepository; } });
Object.defineProperty(exports, "goodsReceiptRepository", { enumerable: true, get: function () { return GoodsReceiptRepository_1.goodsReceiptRepository; } });
//# sourceMappingURL=index.js.map