"use strict";
/**
 * Goods Receipt Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.goodsReceiptRepository = exports.GoodsReceiptRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class GoodsReceiptRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'goods_receipts';
        this.schema = 'purchase';
        this.primaryKey = 'gr_id';
        this.softDelete = false;
    }
    async getWithLines(ctx, grId) {
        const receipt = await this.findById(ctx, grId);
        if (!receipt)
            return null;
        const linesSql = `
      SELECT line_id, gr_id, po_line_id, line_number, item_code, description, quantity_ordered,
             quantity_received, unit_of_measure, notes
      FROM purchase.gr_line_items
      WHERE tenant_id = $1 AND gr_id = $2
      ORDER BY line_number
    `;
        const lines = await this.rawQuery(ctx, linesSql, [grId]);
        return { ...receipt, lines };
    }
    async createWithLines(ctx, data, lines) {
        const client = await this.beginTransaction();
        try {
            const numResult = await client.query(`
        SELECT COALESCE(MAX(CAST(SUBSTRING(gr_number FROM '[0-9]+$') AS INTEGER)), 0) + 1 as next_num
        FROM ${this.fullTableName}
        WHERE tenant_id = $1
      `, [ctx.tenantId]);
            const grNumber = `GR-${String(numResult.rows[0].next_num).padStart(6, '0')}`;
            const totalQty = lines.reduce((sum, l) => sum + (l.quantity_received || 0), 0);
            const grResult = await client.query(`
        INSERT INTO ${this.fullTableName}
        (tenant_id, gr_number, gr_date, po_id, supplier_id, delivery_note_number, received_by, status, total_quantity, warehouse_id, notes, created_by)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
        RETURNING *
      `, [
                ctx.tenantId,
                grNumber,
                data.gr_date || new Date(),
                data.po_id,
                data.supplier_id,
                data.delivery_note_number,
                data.received_by,
                data.status || 'draft',
                totalQty,
                data.warehouse_id,
                data.notes,
                ctx.userId
            ]);
            const receipt = grResult.rows[0];
            for (let i = 0; i < lines.length; i++) {
                const line = lines[i];
                await client.query(`
          INSERT INTO purchase.gr_line_items
          (tenant_id, gr_id, line_number, po_line_id, item_code, description, quantity_ordered, quantity_received, unit_of_measure, notes)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        `, [
                    ctx.tenantId,
                    receipt.gr_id,
                    i + 1,
                    line.po_line_id,
                    line.item_code,
                    line.description,
                    line.quantity_ordered || 0,
                    line.quantity_received || 0,
                    line.unit_of_measure || 'EA',
                    line.notes
                ]);
            }
            await this.commitTransaction(client);
            return receipt;
        }
        catch (error) {
            await this.rollbackTransaction(client);
            throw error;
        }
    }
}
exports.GoodsReceiptRepository = GoodsReceiptRepository;
exports.goodsReceiptRepository = new GoodsReceiptRepository();
exports.default = exports.goodsReceiptRepository;
//# sourceMappingURL=GoodsReceiptRepository.js.map