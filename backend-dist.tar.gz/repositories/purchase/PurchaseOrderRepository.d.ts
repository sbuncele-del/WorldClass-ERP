/**
 * Purchase Order Repository
 *
 * Handles all database operations for purchase orders
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type PurchaseOrderStatus = 'draft' | 'pending_approval' | 'approved' | 'sent' | 'partial' | 'received' | 'cancelled';
export interface PurchaseOrderLine {
    line_id: number;
    po_id: number;
    item_code?: string;
    description?: string;
    quantity: number;
    unit_of_measure?: string;
    unit_price: number;
    discount_percentage?: number;
    discount_amount?: number;
    vat_rate?: number;
    vat_amount?: number;
    line_total: number;
    quantity_received?: number;
    notes?: string;
}
export interface PurchaseOrder {
    po_id: number;
    tenant_id: string;
    po_number: string;
    po_date: Date;
    order_date?: Date;
    expected_date?: Date;
    supplier_id?: number;
    requisition_id?: number;
    delivery_date?: Date;
    payment_terms?: string;
    status: string;
    subtotal: number;
    discount_amount?: number;
    vat_rate?: number;
    vat_amount?: number;
    total: number;
    currency_code?: string;
    sent_to_supplier?: boolean;
    acknowledged_by_supplier?: boolean;
    warehouse_id?: number;
    notes?: string;
    created_at: Date;
    created_by?: number;
    updated_at?: Date;
    updated_by?: number;
    deleted_at?: Date;
    lines?: PurchaseOrderLine[];
}
export declare class PurchaseOrderRepository extends BaseRepository<PurchaseOrder> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    /**
     * Get orders by status
     */
    getOrdersByStatus(ctx: TenantContext, status: PurchaseOrderStatus, pagination?: PaginationOptions): Promise<PaginatedResult<PurchaseOrder>>;
    /**
     * Get orders pending approval
     */
    getPendingApproval(ctx: TenantContext): Promise<PurchaseOrder[]>;
    /**
     * Get order with lines
     */
    getOrderWithLines(ctx: TenantContext, orderId: string): Promise<PurchaseOrder | null>;
    /**
     * Create order with lines
     */
    createOrderWithLines(ctx: TenantContext, orderData: Partial<PurchaseOrder>, lines: Partial<PurchaseOrderLine>[]): Promise<PurchaseOrder>;
    /**
     * Approve a purchase order
     */
    approveOrder(ctx: TenantContext, orderId: string): Promise<PurchaseOrder | null>;
    /**
     * Receive goods against a purchase order
     */
    receiveGoods(ctx: TenantContext, orderId: string, receivedItems: {
        lineId: string;
        quantityReceived: number;
    }[]): Promise<PurchaseOrder | null>;
    /**
     * Get purchase summary
     */
    getPurchaseSummary(ctx: TenantContext, startDate: Date, endDate: Date): Promise<{
        total_orders: number;
        total_amount: number;
        average_order_value: number;
        orders_by_status: Record<string, number>;
    }>;
}
export declare const purchaseOrderRepository: PurchaseOrderRepository;
export default purchaseOrderRepository;
//# sourceMappingURL=PurchaseOrderRepository.d.ts.map