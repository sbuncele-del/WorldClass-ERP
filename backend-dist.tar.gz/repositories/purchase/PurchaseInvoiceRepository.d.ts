/**
 * Purchase Invoice Repository
 *
 * Handles all database operations for supplier/purchase invoices
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type PurchaseInvoiceStatus = 'draft' | 'received' | 'partial' | 'paid' | 'overdue' | 'cancelled';
export interface PurchaseInvoice {
    invoice_id: number;
    tenant_id: string;
    invoice_number: string;
    supplier_id?: number;
    po_id?: number;
    gr_id?: number;
    invoice_date: Date;
    due_date?: Date;
    status: PurchaseInvoiceStatus;
    subtotal: number;
    discount_amount?: number;
    vat_rate?: number;
    vat_amount?: number;
    total_amount: number;
    amount_paid: number;
    amount_outstanding?: number;
    currency_code?: string;
    notes?: string;
    created_at: Date;
    created_by?: number;
    updated_at?: Date;
    updated_by?: number;
    deleted_at?: Date;
}
export declare class PurchaseInvoiceRepository extends BaseRepository<PurchaseInvoice> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    /**
     * Get invoices by status
     */
    getInvoicesByStatus(ctx: TenantContext, status: PurchaseInvoiceStatus, pagination?: PaginationOptions): Promise<PaginatedResult<PurchaseInvoice>>;
    /**
     * Get unpaid invoices
     */
    getUnpaidInvoices(ctx: TenantContext, supplierId?: string): Promise<PurchaseInvoice[]>;
    /**
     * Get overdue invoices
     */
    getOverdueInvoices(ctx: TenantContext): Promise<PurchaseInvoice[]>;
    /**
     * Record a payment
     */
    recordPayment(ctx: TenantContext, invoiceId: string, amount: number, paymentMethod: string, reference?: string): Promise<PurchaseInvoice | null>;
    /**
     * Get accounts payable aging
     */
    getAgingReport(ctx: TenantContext): Promise<{
        current: number;
        days_1_30: number;
        days_31_60: number;
        days_61_90: number;
        over_90: number;
        total: number;
    }>;
    /**
     * Create from purchase order
     */
    createFromOrder(ctx: TenantContext, orderId: string, supplierInvoiceNumber: string): Promise<PurchaseInvoice>;
}
export declare const purchaseInvoiceRepository: PurchaseInvoiceRepository;
export default purchaseInvoiceRepository;
//# sourceMappingURL=PurchaseInvoiceRepository.d.ts.map