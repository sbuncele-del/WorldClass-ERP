/**
 * Supplier Repository
 *
 * Handles all database operations for suppliers/vendors
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export interface Supplier {
    id: number;
    tenant_id: string;
    code: string;
    name: string;
    trading_name?: string;
    supplier_type: 'individual' | 'company';
    tax_number?: string;
    registration_number?: string;
    email?: string;
    phone?: string;
    mobile?: string;
    payment_terms?: string;
    currency_code?: string;
    notes?: string;
    is_active: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export interface SupplierBalance {
    supplier_id: string;
    total_invoiced: number;
    total_paid: number;
    balance_owed: number;
    overdue_amount: number;
}
export declare class SupplierRepository extends BaseRepository<Supplier> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    private mapSupplier;
    /**
     * Find suppliers with legacy schema mapping
     */
    findAll(ctx: TenantContext, filters?: Record<string, any>, pagination?: PaginationOptions): Promise<PaginatedResult<Supplier>>;
    /**
     * Search suppliers
     */
    search(ctx: TenantContext, searchTerm: string, pagination?: PaginationOptions): Promise<PaginatedResult<Supplier>>;
    /**
     * Get supplier with balance
     */
    getSupplierWithBalance(ctx: TenantContext, supplierId: string): Promise<(Supplier & SupplierBalance) | null>;
    /**
     * Get suppliers with outstanding balances
     */
    getSuppliersWithBalances(ctx: TenantContext): Promise<(Supplier & SupplierBalance)[]>;
    /**
     * Create supplier
     */
    create(ctx: TenantContext, data: Partial<Supplier>): Promise<Supplier>;
    /**
     * Update supplier
     */
    update(ctx: TenantContext, id: string | number, data: Partial<Supplier>): Promise<Supplier | null>;
    /**
     * Check if supplier code is unique
     */
    isCodeUnique(ctx: TenantContext, code: string, excludeId?: string): Promise<boolean>;
}
export declare const supplierRepository: SupplierRepository;
export default supplierRepository;
//# sourceMappingURL=SupplierRepository.d.ts.map