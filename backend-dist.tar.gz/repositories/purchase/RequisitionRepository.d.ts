/**
 * Requisition Repository
 *
 * Handles purchase requisitions with tenant isolation.
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type RequisitionStatus = 'draft' | 'pending_approval' | 'approved' | 'rejected' | 'cancelled';
export interface RequisitionLine {
    id: string;
    requisition_id: string;
    item_code?: string;
    description: string;
    quantity: number;
    unit_of_measure?: string;
    estimated_unit_price?: number;
    estimated_total?: number;
    required_by_date?: Date;
    notes?: string;
}
export interface Requisition {
    id: string;
    requisition_id?: number;
    tenant_id: string;
    requisition_number: string;
    requisition_date: Date;
    required_by_date?: Date;
    department?: string;
    requested_by?: string;
    priority?: string;
    status: RequisitionStatus;
    total_amount: number;
    notes?: string;
    approved_by?: string;
    approved_date?: Date;
    rejection_reason?: string;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
    lines?: RequisitionLine[];
}
export declare class RequisitionRepository extends BaseRepository<Requisition> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getWithLines(ctx: TenantContext, requisitionId: string): Promise<Requisition | null>;
    createWithLines(ctx: TenantContext, data: Partial<Requisition>, lines: Partial<RequisitionLine>[]): Promise<Requisition>;
    updateStatus(ctx: TenantContext, requisitionId: string, status: RequisitionStatus, meta?: Partial<Requisition>): Promise<Requisition | null>;
    deleteIfNoPurchaseOrder(ctx: TenantContext, requisitionId: string): Promise<boolean>;
}
export declare const requisitionRepository: RequisitionRepository;
export default requisitionRepository;
//# sourceMappingURL=RequisitionRepository.d.ts.map