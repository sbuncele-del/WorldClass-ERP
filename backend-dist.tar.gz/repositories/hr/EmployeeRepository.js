"use strict";
/**
 * Employee Repository
 *
 * Handles all database operations for employees
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.employeeRepository = exports.EmployeeRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class EmployeeRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'employees';
        this.schema = 'hr';
        this.primaryKey = 'employee_id';
        this.softDelete = false; // hr.employees does not use deleted_at
    }
    async getActiveEmployees(ctx) {
        const result = await this.findAll(ctx, { is_active: true, employment_status: 'Active' });
        return result.data;
    }
    async search(ctx, searchTerm, pagination) {
        const { page = 1, limit = 50 } = pagination || {};
        const offset = (page - 1) * limit;
        const searchPattern = `%${searchTerm}%`;
        const sql = `
      SELECT e.*, d.department_name, p.position_title,
             m.first_name || ' ' || m.last_name as manager_name
      FROM ${this.fullTableName} e
      LEFT JOIN hr.departments d ON d.department_id = e.department_id
      LEFT JOIN hr.positions p ON p.position_id = e.position_id
      LEFT JOIN ${this.fullTableName} m ON m.employee_id = e.manager_id
      WHERE e.tenant_id = $1
        AND (
          e.first_name ILIKE $2 
          OR e.last_name ILIKE $2 
          OR e.employee_number ILIKE $2
          OR e.email ILIKE $2
        )
      ORDER BY e.last_name, e.first_name
      LIMIT $3 OFFSET $4
    `;
        const countSql = `
      SELECT COUNT(*) FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND (
          first_name ILIKE $2 
          OR last_name ILIKE $2 
          OR employee_number ILIKE $2
          OR email ILIKE $2
        )
    `;
        const [data, countResult] = await Promise.all([
            this.rawQuery(ctx, sql, [searchPattern, limit, offset]),
            this.rawQuery(ctx, countSql, [searchPattern])
        ]);
        const total = parseInt(countResult[0]?.count || '0', 10);
        return {
            data,
            pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
        };
    }
    async getByDepartment(ctx, departmentId) {
        return this.findBy(ctx, 'department_id', departmentId);
    }
    async getDirectReports(ctx, managerId) {
        return this.findBy(ctx, 'manager_id', managerId);
    }
    async getHeadcountByDepartment(ctx) {
        const sql = `
      SELECT 
        e.department_id,
        d.department_name,
        COUNT(*) as count
      FROM ${this.fullTableName} e
      LEFT JOIN hr.departments d ON d.department_id = e.department_id
      WHERE e.tenant_id = $1 
        AND e.is_active = true
        AND e.employment_status = 'Active'
      GROUP BY e.department_id, d.department_name
      ORDER BY count DESC
    `;
        return this.rawQuery(ctx, sql);
    }
    async terminateEmployee(ctx, employeeId, terminationDate) {
        return this.update(ctx, employeeId, {
            employment_status: 'Terminated',
            termination_date: terminationDate,
            is_active: false
        });
    }
    async isEmployeeNumberUnique(ctx, employeeNumber, excludeId) {
        const existing = await this.findOne(ctx, { employee_number: employeeNumber });
        if (!existing)
            return true;
        if (excludeId && existing.employee_id === excludeId)
            return true;
        return false;
    }
}
exports.EmployeeRepository = EmployeeRepository;
exports.employeeRepository = new EmployeeRepository();
exports.default = exports.employeeRepository;
//# sourceMappingURL=EmployeeRepository.js.map