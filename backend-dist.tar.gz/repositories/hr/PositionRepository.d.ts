/**
 * Position Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export interface Position {
    position_id: string;
    tenant_id: string;
    position_code: string;
    position_title: string;
    department_id?: string;
    reports_to_position_id?: string;
    job_level?: string;
    job_category?: string;
    description?: string;
    requirements?: string;
    is_active: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
}
export declare class PositionRepository extends BaseRepository<Position> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getActivePositions(ctx: TenantContext): Promise<Position[]>;
    isCodeUnique(ctx: TenantContext, code: string, excludeId?: string): Promise<boolean>;
}
export declare const positionRepository: PositionRepository;
export default positionRepository;
//# sourceMappingURL=PositionRepository.d.ts.map