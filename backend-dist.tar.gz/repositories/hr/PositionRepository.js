"use strict";
/**
 * Position Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.positionRepository = exports.PositionRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class PositionRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'positions';
        this.schema = 'hr';
        this.primaryKey = 'position_id';
        this.softDelete = false;
    }
    async getActivePositions(ctx) {
        const result = await this.findAll(ctx, { is_active: true });
        return result.data;
    }
    async isCodeUnique(ctx, code, excludeId) {
        const existing = await this.findOne(ctx, { position_code: code });
        if (!existing)
            return true;
        if (excludeId && existing.position_id === excludeId)
            return true;
        return false;
    }
}
exports.PositionRepository = PositionRepository;
exports.positionRepository = new PositionRepository();
exports.default = exports.positionRepository;
//# sourceMappingURL=PositionRepository.js.map