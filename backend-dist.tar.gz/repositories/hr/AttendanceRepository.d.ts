/**
 * Attendance Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export interface AttendanceRecord {
    attendance_id: string;
    tenant_id: string;
    employee_id: string;
    attendance_date: Date;
    clock_in_time?: string;
    clock_out_time?: string;
    hours_worked?: number;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
}
export declare class AttendanceRepository extends BaseRepository<AttendanceRecord> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getForDate(ctx: TenantContext, employeeId: string, date: Date): Promise<AttendanceRecord | null>;
}
export declare const attendanceRepository: AttendanceRepository;
export default attendanceRepository;
//# sourceMappingURL=AttendanceRepository.d.ts.map