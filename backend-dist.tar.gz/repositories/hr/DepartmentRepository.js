"use strict";
/**
 * Department Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.departmentRepository = exports.DepartmentRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class DepartmentRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'departments';
        this.schema = 'hr';
        this.primaryKey = 'department_id';
        this.softDelete = false; // hr.departments does not use deleted_at
    }
    async getActiveDepartments(ctx) {
        const result = await this.findAll(ctx, { is_active: true });
        return result.data;
    }
    async getDepartmentTree(ctx) {
        const sql = `
      WITH RECURSIVE dept_tree AS (
        SELECT *, 0 as level
        FROM ${this.fullTableName}
        WHERE tenant_id = $1 AND parent_department_id IS NULL
        UNION ALL
        SELECT d.*, dt.level + 1
        FROM ${this.fullTableName} d
        INNER JOIN dept_tree dt ON d.parent_department_id = dt.department_id
        WHERE d.tenant_id = $1
      )
      SELECT * FROM dept_tree ORDER BY level, department_name
    `;
        return this.rawQuery(ctx, sql);
    }
}
exports.DepartmentRepository = DepartmentRepository;
exports.departmentRepository = new DepartmentRepository();
exports.default = exports.departmentRepository;
//# sourceMappingURL=DepartmentRepository.js.map