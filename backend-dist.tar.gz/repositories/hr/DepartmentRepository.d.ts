/**
 * Department Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export interface Department {
    department_id: string;
    tenant_id: string;
    department_code: string;
    department_name: string;
    description?: string;
    parent_department_id?: string;
    manager_id?: string;
    cost_center_code?: string;
    is_active: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
}
export declare class DepartmentRepository extends BaseRepository<Department> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getActiveDepartments(ctx: TenantContext): Promise<Department[]>;
    getDepartmentTree(ctx: TenantContext): Promise<Department[]>;
}
export declare const departmentRepository: DepartmentRepository;
export default departmentRepository;
//# sourceMappingURL=DepartmentRepository.d.ts.map