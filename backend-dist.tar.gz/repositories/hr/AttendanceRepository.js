"use strict";
/**
 * Attendance Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.attendanceRepository = exports.AttendanceRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class AttendanceRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'attendance_records';
        this.schema = 'hr';
        this.primaryKey = 'attendance_id';
        this.softDelete = false;
    }
    async getForDate(ctx, employeeId, date) {
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND employee_id = $2 AND attendance_date = $3
      LIMIT 1
    `;
        const rows = await this.rawQuery(ctx, sql, [ctx.tenantId, employeeId, date]);
        return rows[0] || null;
    }
}
exports.AttendanceRepository = AttendanceRepository;
exports.attendanceRepository = new AttendanceRepository();
exports.default = exports.attendanceRepository;
//# sourceMappingURL=AttendanceRepository.js.map