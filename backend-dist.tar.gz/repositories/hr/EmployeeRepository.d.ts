/**
 * Employee Repository
 *
 * Handles all database operations for employees
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext, PaginatedResult, PaginationOptions } from '../BaseRepository';
export type EmploymentStatus = 'Active' | 'Probation' | 'Suspended' | 'Terminated' | 'Resigned' | 'On Leave';
export type EmploymentType = 'full_time' | 'part_time' | 'contract' | 'temporary' | 'intern';
export interface Employee {
    employee_id: string;
    tenant_id: string;
    employee_number: string;
    first_name: string;
    last_name: string;
    middle_name?: string;
    email: string;
    phone_mobile?: string;
    phone_home?: string;
    date_of_birth?: Date;
    gender?: string;
    id_number?: string;
    passport_number?: string;
    tax_number?: string;
    department_id?: string;
    department_name?: string;
    position_id?: string;
    position_title?: string;
    manager_id?: string;
    manager_name?: string;
    hire_date: Date;
    termination_date?: Date;
    employment_status: EmploymentStatus;
    employment_type?: EmploymentType;
    basic_salary?: number;
    pay_frequency?: 'weekly' | 'bi_weekly' | 'monthly';
    address_line1?: string;
    address_line2?: string;
    city?: string;
    province?: string;
    postal_code?: string;
    country?: string;
    is_active: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
}
export declare class EmployeeRepository extends BaseRepository<Employee> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getActiveEmployees(ctx: TenantContext): Promise<Employee[]>;
    search(ctx: TenantContext, searchTerm: string, pagination?: PaginationOptions): Promise<PaginatedResult<Employee>>;
    getByDepartment(ctx: TenantContext, departmentId: string): Promise<Employee[]>;
    getDirectReports(ctx: TenantContext, managerId: string): Promise<Employee[]>;
    getHeadcountByDepartment(ctx: TenantContext): Promise<{
        department_id: string;
        department_name: string;
        count: number;
    }[]>;
    terminateEmployee(ctx: TenantContext, employeeId: string, terminationDate: Date): Promise<Employee | null>;
    isEmployeeNumberUnique(ctx: TenantContext, employeeNumber: string, excludeId?: string): Promise<boolean>;
}
export declare const employeeRepository: EmployeeRepository;
export default employeeRepository;
//# sourceMappingURL=EmployeeRepository.d.ts.map