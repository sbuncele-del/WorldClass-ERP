"use strict";
/**
 * Leave Request Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.leaveRequestRepository = exports.LeaveRequestRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class LeaveRequestRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'leave_requests';
        this.schema = 'hr';
        this.primaryKey = 'request_id';
        this.softDelete = false;
    }
    async getPendingRequests(ctx) {
        const sql = `
      SELECT lr.*, e.first_name || ' ' || e.last_name as employee_name
      FROM ${this.fullTableName} lr
      JOIN hr.employees e ON e.employee_id = lr.employee_id AND e.tenant_id = lr.tenant_id
      WHERE lr.tenant_id = $1 AND lr.status = 'Pending'
      ORDER BY lr.start_date
    `;
        return this.rawQuery(ctx, sql);
    }
    async getEmployeeLeave(ctx, employeeId, year) {
        const targetYear = year || new Date().getFullYear();
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND employee_id = $2 
        AND EXTRACT(YEAR FROM start_date) = $3
      ORDER BY start_date DESC
    `;
        return this.rawQuery(ctx, sql, [ctx.tenantId, employeeId, targetYear]);
    }
    async approveLeave(ctx, requestId) {
        return this.update(ctx, requestId, {
            status: 'Approved',
            approved_by: ctx.userId,
            approved_at: new Date()
        });
    }
    async rejectLeave(ctx, requestId, reason) {
        return this.update(ctx, requestId, {
            status: 'Rejected',
            rejection_reason: reason
        });
    }
    async getLeaveBalance(ctx, employeeId, leaveType, year) {
        const targetYear = year || new Date().getFullYear();
        // Get entitlement (simplified - in real system would come from policy)
        const entitlement = leaveType === 'annual' ? 21 : leaveType === 'sick' ? 30 : 0;
        const sql = `
      SELECT 
        COALESCE(SUM(CASE WHEN status = 'Approved' THEN days_requested ELSE 0 END), 0) as taken,
        COALESCE(SUM(CASE WHEN status = 'Pending' THEN days_requested ELSE 0 END), 0) as pending
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND employee_id = $2 
        AND leave_type = $3
        AND EXTRACT(YEAR FROM start_date) = $4
    `;
        const result = await this.rawQuery(ctx, sql, [ctx.tenantId, employeeId, leaveType, targetYear]);
        const taken = parseFloat(result[0]?.taken || '0');
        const pending = parseFloat(result[0]?.pending || '0');
        return {
            entitled: entitlement,
            taken,
            pending,
            balance: entitlement - taken - pending
        };
    }
}
exports.LeaveRequestRepository = LeaveRequestRepository;
exports.leaveRequestRepository = new LeaveRequestRepository();
exports.default = exports.leaveRequestRepository;
//# sourceMappingURL=LeaveRequestRepository.js.map