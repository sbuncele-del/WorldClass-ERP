/**
 * Payroll Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type PayrollStatus = 'draft' | 'processing' | 'approved' | 'paid' | 'cancelled';
export interface PayrollRun {
    id: string;
    tenant_id: string;
    name: string;
    pay_period_start: Date;
    pay_period_end: Date;
    payment_date: Date;
    status: PayrollStatus;
    total_gross: number;
    total_deductions: number;
    total_net: number;
    employee_count: number;
    approved_by?: string;
    approved_at?: Date;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class PayrollRepository extends BaseRepository<PayrollRun> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getPayrollByStatus(ctx: TenantContext, status: PayrollStatus): Promise<PayrollRun[]>;
    approvePayroll(ctx: TenantContext, payrollId: string): Promise<PayrollRun | null>;
    getPayrollSummary(ctx: TenantContext, year: number): Promise<{
        month: number;
        total_gross: number;
        total_net: number;
        employee_count: number;
    }[]>;
}
export declare const payrollRepository: PayrollRepository;
export default payrollRepository;
//# sourceMappingURL=PayrollRepository.d.ts.map