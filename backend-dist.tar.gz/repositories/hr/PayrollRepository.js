"use strict";
/**
 * Payroll Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.payrollRepository = exports.PayrollRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class PayrollRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'payroll_runs';
        this.schema = 'hr';
        this.primaryKey = 'run_id';
        this.softDelete = false;
    }
    async getPayrollByStatus(ctx, status) {
        const result = await this.findAll(ctx, { status });
        return result.data;
    }
    async approvePayroll(ctx, payrollId) {
        return this.update(ctx, payrollId, {
            status: 'approved',
            approved_by: ctx.userId,
            approved_at: new Date()
        });
    }
    async getPayrollSummary(ctx, year) {
        const sql = `
      SELECT 
        EXTRACT(MONTH FROM payment_date) as month,
        SUM(total_gross) as total_gross,
        SUM(total_net) as total_net,
        SUM(employee_count) as employee_count
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 
        AND deleted_at IS NULL
        AND status = 'paid'
        AND EXTRACT(YEAR FROM payment_date) = $2
      GROUP BY EXTRACT(MONTH FROM payment_date)
      ORDER BY month
    `;
        return this.rawQuery(ctx, sql, [year]);
    }
}
exports.PayrollRepository = PayrollRepository;
exports.payrollRepository = new PayrollRepository();
exports.default = exports.payrollRepository;
//# sourceMappingURL=PayrollRepository.js.map