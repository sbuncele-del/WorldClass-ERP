"use strict";
/**
 * Payroll Period Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.payrollPeriodRepository = exports.PayrollPeriodRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class PayrollPeriodRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'payroll_periods';
        this.schema = 'hr';
        this.primaryKey = 'period_id';
        this.softDelete = false;
    }
    async getByYear(ctx, year) {
        const sql = `
      SELECT * FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND EXTRACT(YEAR FROM period_start_date) = $2
      ORDER BY period_start_date DESC
    `;
        return this.rawQuery(ctx, sql, [ctx.tenantId, year]);
    }
}
exports.PayrollPeriodRepository = PayrollPeriodRepository;
exports.payrollPeriodRepository = new PayrollPeriodRepository();
exports.default = exports.payrollPeriodRepository;
//# sourceMappingURL=PayrollPeriodRepository.js.map