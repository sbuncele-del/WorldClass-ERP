"use strict";
/**
 * HR Repositories Index
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.payrollPeriodRepository = exports.PayrollPeriodRepository = exports.attendanceRepository = exports.AttendanceRepository = exports.positionRepository = exports.PositionRepository = exports.payrollRepository = exports.PayrollRepository = exports.leaveRequestRepository = exports.LeaveRequestRepository = exports.departmentRepository = exports.DepartmentRepository = exports.employeeRepository = exports.EmployeeRepository = void 0;
var EmployeeRepository_1 = require("./EmployeeRepository");
Object.defineProperty(exports, "EmployeeRepository", { enumerable: true, get: function () { return EmployeeRepository_1.EmployeeRepository; } });
Object.defineProperty(exports, "employeeRepository", { enumerable: true, get: function () { return EmployeeRepository_1.employeeRepository; } });
var DepartmentRepository_1 = require("./DepartmentRepository");
Object.defineProperty(exports, "DepartmentRepository", { enumerable: true, get: function () { return DepartmentRepository_1.DepartmentRepository; } });
Object.defineProperty(exports, "departmentRepository", { enumerable: true, get: function () { return DepartmentRepository_1.departmentRepository; } });
var LeaveRequestRepository_1 = require("./LeaveRequestRepository");
Object.defineProperty(exports, "LeaveRequestRepository", { enumerable: true, get: function () { return LeaveRequestRepository_1.LeaveRequestRepository; } });
Object.defineProperty(exports, "leaveRequestRepository", { enumerable: true, get: function () { return LeaveRequestRepository_1.leaveRequestRepository; } });
var PayrollRepository_1 = require("./PayrollRepository");
Object.defineProperty(exports, "PayrollRepository", { enumerable: true, get: function () { return PayrollRepository_1.PayrollRepository; } });
Object.defineProperty(exports, "payrollRepository", { enumerable: true, get: function () { return PayrollRepository_1.payrollRepository; } });
var PositionRepository_1 = require("./PositionRepository");
Object.defineProperty(exports, "PositionRepository", { enumerable: true, get: function () { return PositionRepository_1.PositionRepository; } });
Object.defineProperty(exports, "positionRepository", { enumerable: true, get: function () { return PositionRepository_1.positionRepository; } });
var AttendanceRepository_1 = require("./AttendanceRepository");
Object.defineProperty(exports, "AttendanceRepository", { enumerable: true, get: function () { return AttendanceRepository_1.AttendanceRepository; } });
Object.defineProperty(exports, "attendanceRepository", { enumerable: true, get: function () { return AttendanceRepository_1.attendanceRepository; } });
var PayrollPeriodRepository_1 = require("./PayrollPeriodRepository");
Object.defineProperty(exports, "PayrollPeriodRepository", { enumerable: true, get: function () { return PayrollPeriodRepository_1.PayrollPeriodRepository; } });
Object.defineProperty(exports, "payrollPeriodRepository", { enumerable: true, get: function () { return PayrollPeriodRepository_1.payrollPeriodRepository; } });
//# sourceMappingURL=index.js.map