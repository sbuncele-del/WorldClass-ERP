/**
 * Payroll Period Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type PayrollPeriodStatus = 'Draft' | 'Open' | 'Closed';
export interface PayrollPeriod {
    period_id: string;
    tenant_id: string;
    period_code: string;
    period_name?: string;
    period_start_date: Date;
    period_end_date: Date;
    payment_date: Date;
    frequency?: string;
    status: PayrollPeriodStatus;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
}
export declare class PayrollPeriodRepository extends BaseRepository<PayrollPeriod> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getByYear(ctx: TenantContext, year: number): Promise<PayrollPeriod[]>;
}
export declare const payrollPeriodRepository: PayrollPeriodRepository;
export default payrollPeriodRepository;
//# sourceMappingURL=PayrollPeriodRepository.d.ts.map