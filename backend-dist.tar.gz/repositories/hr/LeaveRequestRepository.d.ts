/**
 * Leave Request Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type LeaveStatus = 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';
export type LeaveType = 'annual' | 'sick' | 'family' | 'maternity' | 'paternity' | 'study' | 'unpaid';
export interface LeaveRequest {
    request_id: string;
    tenant_id: string;
    employee_id: string;
    employee_name?: string;
    leave_type: LeaveType;
    start_date: Date;
    end_date: Date;
    days_requested: number;
    reason?: string;
    status: LeaveStatus;
    approved_by?: string;
    approved_at?: Date;
    rejection_reason?: string;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class LeaveRequestRepository extends BaseRepository<LeaveRequest> {
    protected tableName: string;
    protected schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    getPendingRequests(ctx: TenantContext): Promise<LeaveRequest[]>;
    getEmployeeLeave(ctx: TenantContext, employeeId: string, year?: number): Promise<LeaveRequest[]>;
    approveLeave(ctx: TenantContext, requestId: string): Promise<LeaveRequest | null>;
    rejectLeave(ctx: TenantContext, requestId: string, reason: string): Promise<LeaveRequest | null>;
    getLeaveBalance(ctx: TenantContext, employeeId: string, leaveType: LeaveType, year?: number): Promise<{
        entitled: number;
        taken: number;
        pending: number;
        balance: number;
    }>;
}
export declare const leaveRequestRepository: LeaveRequestRepository;
export default leaveRequestRepository;
//# sourceMappingURL=LeaveRequestRepository.d.ts.map