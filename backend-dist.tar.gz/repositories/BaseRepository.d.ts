/**
 * Base Repository - Multi-Tenant ERP Pattern
 *
 * Provides automatic tenant isolation for all database operations.
 * All module repositories extend this class to ensure data isolation.
 *
 * Features:
 * - Automatic tenant_id filtering on all queries
 * - Type-safe operations with generics
 * - Audit trail support (created_by, updated_by)
 * - Soft delete support
 * - Pagination helpers
 */
import { Pool, PoolClient, QueryResult } from 'pg';
export interface TenantContext {
    tenantId: string;
    userId?: string;
}
export interface PaginationOptions {
    page?: number;
    limit?: number;
    sortBy?: string;
    sortOrder?: 'ASC' | 'DESC';
}
export interface PaginatedResult<T> {
    data: T[];
    pagination: {
        page: number;
        limit: number;
        total: number;
        totalPages: number;
    };
}
export interface QueryOptions {
    includeDeleted?: boolean;
    client?: PoolClient;
}
export declare abstract class BaseRepository<T> {
    protected pool: Pool;
    protected abstract tableName: string;
    protected abstract schema: string;
    protected primaryKey: string;
    protected softDelete: boolean;
    /**
     * Get the fully qualified table name (schema.table)
     */
    protected get fullTableName(): string;
    /**
     * Execute a query with tenant isolation
     */
    protected query<R = any>(sql: string, params?: any[], options?: QueryOptions): Promise<QueryResult<R>>;
    /**
     * Find all records for a tenant with optional filters
     */
    findAll(ctx: TenantContext, filters?: Record<string, any>, pagination?: PaginationOptions, options?: QueryOptions): Promise<PaginatedResult<T>>;
    /**
     * Find a single record by ID with tenant isolation
     */
    findById(ctx: TenantContext, id: string | number, options?: QueryOptions): Promise<T | null>;
    /**
     * Find records by a specific field with tenant isolation
     */
    findBy(ctx: TenantContext, field: string, value: any, options?: QueryOptions): Promise<T[]>;
    /**
     * Find one record by criteria with tenant isolation
     */
    findOne(ctx: TenantContext, criteria: Record<string, any>, options?: QueryOptions): Promise<T | null>;
    /**
     * Create a new record with tenant isolation
     */
    create(ctx: TenantContext, data: Partial<T>, options?: QueryOptions): Promise<T>;
    /**
     * Create multiple records with tenant isolation
     */
    createMany(ctx: TenantContext, records: Partial<T>[], options?: QueryOptions): Promise<T[]>;
    /**
     * Update a record with tenant isolation
     */
    update(ctx: TenantContext, id: string | number, data: Partial<T>, options?: QueryOptions): Promise<T | null>;
    /**
     * Soft delete a record (if enabled) or hard delete
     */
    delete(ctx: TenantContext, id: string | number, options?: QueryOptions): Promise<boolean>;
    /**
     * Count records with tenant isolation
     */
    count(ctx: TenantContext, filters?: Record<string, any>, options?: QueryOptions): Promise<number>;
    /**
     * Check if a record exists with tenant isolation
     */
    exists(ctx: TenantContext, criteria: Record<string, any>, options?: QueryOptions): Promise<boolean>;
    /**
     * Execute a raw query with automatic tenant filtering
     * Use this for complex queries that can't be expressed with the other methods
     */
    rawQuery<R = any>(ctx: TenantContext, sql: string, params?: any[], options?: QueryOptions): Promise<R[]>;
    /**
     * Begin a transaction and return a client
     */
    beginTransaction(): Promise<PoolClient>;
    /**
     * Commit a transaction
     */
    commitTransaction(client: PoolClient): Promise<void>;
    /**
     * Rollback a transaction
     */
    rollbackTransaction(client: PoolClient): Promise<void>;
}
export default BaseRepository;
//# sourceMappingURL=BaseRepository.d.ts.map