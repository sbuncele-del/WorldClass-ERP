"use strict";
/**
 * Asset Category Repository
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.assetCategoryRepository = exports.AssetCategoryRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class AssetCategoryRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'categories';
        this.schema = 'assets';
    }
    async getActiveCategories(ctx) {
        const result = await this.findAll(ctx, { is_active: true });
        return result.data;
    }
    async getCategoryTree(ctx) {
        const sql = `
      WITH RECURSIVE cat_tree AS (
        SELECT *, 0 as level
        FROM ${this.fullTableName}
        WHERE tenant_id = $1 AND parent_id IS NULL AND deleted_at IS NULL
        UNION ALL
        SELECT c.*, ct.level + 1
        FROM ${this.fullTableName} c
        INNER JOIN cat_tree ct ON c.parent_id = ct.id
        WHERE c.tenant_id = $1 AND c.deleted_at IS NULL
      )
      SELECT * FROM cat_tree ORDER BY level, name
    `;
        return this.rawQuery(ctx, sql);
    }
}
exports.AssetCategoryRepository = AssetCategoryRepository;
exports.assetCategoryRepository = new AssetCategoryRepository();
exports.default = exports.assetCategoryRepository;
//# sourceMappingURL=AssetCategoryRepository.js.map