/**
 * Asset Repository
 *
 * Handles all database operations for fixed assets
 * with automatic tenant isolation.
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export type AssetStatus = 'draft' | 'active' | 'disposed' | 'sold' | 'written_off';
export interface Asset {
    id: string;
    tenant_id: string;
    asset_number: string;
    name: string;
    description?: string;
    category_id?: string;
    category_name?: string;
    location?: string;
    department_id?: string;
    assigned_to?: string;
    serial_number?: string;
    purchase_date: Date;
    purchase_price: number;
    salvage_value: number;
    useful_life_months: number;
    depreciation_method: 'straight_line' | 'declining_balance' | 'units_of_production';
    accumulated_depreciation: number;
    book_value: number;
    status: AssetStatus;
    disposal_date?: Date;
    disposal_amount?: number;
    gl_asset_account_id?: string;
    gl_depreciation_account_id?: string;
    gl_expense_account_id?: string;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class AssetRepository extends BaseRepository<Asset> {
    protected tableName: string;
    protected schema: string;
    getActiveAssets(ctx: TenantContext): Promise<Asset[]>;
    getAssetWithCategory(ctx: TenantContext, assetId: string): Promise<Asset | null>;
    getAssetsByCategory(ctx: TenantContext, categoryId: string): Promise<Asset[]>;
    getDepreciationSchedule(ctx: TenantContext, assetId: string): Promise<{
        period: number;
        date: Date;
        depreciation_amount: number;
        accumulated_depreciation: number;
        book_value: number;
    }[]>;
    recordDepreciation(ctx: TenantContext, assetId: string, amount: number): Promise<Asset | null>;
    disposeAsset(ctx: TenantContext, assetId: string, disposalDate: Date, disposalAmount: number): Promise<Asset | null>;
    getAssetSummary(ctx: TenantContext): Promise<{
        total_assets: number;
        total_purchase_value: number;
        total_book_value: number;
        total_accumulated_depreciation: number;
        by_category: {
            category_name: string;
            count: number;
            book_value: number;
        }[];
    }>;
}
export declare const assetRepository: AssetRepository;
export default assetRepository;
//# sourceMappingURL=AssetRepository.d.ts.map