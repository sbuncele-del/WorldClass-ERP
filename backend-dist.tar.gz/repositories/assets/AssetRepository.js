"use strict";
/**
 * Asset Repository
 *
 * Handles all database operations for fixed assets
 * with automatic tenant isolation.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.assetRepository = exports.AssetRepository = void 0;
const BaseRepository_1 = require("../BaseRepository");
class AssetRepository extends BaseRepository_1.BaseRepository {
    constructor() {
        super(...arguments);
        this.tableName = 'assets';
        this.schema = 'assets';
    }
    async getActiveAssets(ctx) {
        const result = await this.findAll(ctx, { status: 'active' });
        return result.data;
    }
    async getAssetWithCategory(ctx, assetId) {
        const sql = `
      SELECT a.*, ac.name as category_name
      FROM ${this.fullTableName} a
      LEFT JOIN assets.categories ac ON ac.id = a.category_id
      WHERE a.tenant_id = $1 AND a.id = $2 AND a.deleted_at IS NULL
    `;
        const result = await this.rawQuery(ctx, sql, [assetId]);
        return result[0] || null;
    }
    async getAssetsByCategory(ctx, categoryId) {
        return this.findBy(ctx, 'category_id', categoryId);
    }
    async getDepreciationSchedule(ctx, assetId) {
        const asset = await this.findById(ctx, assetId);
        if (!asset)
            return [];
        const monthlyDepreciation = (asset.purchase_price - asset.salvage_value) / asset.useful_life_months;
        const schedule = [];
        let accumulated = asset.accumulated_depreciation;
        let bookValue = asset.book_value;
        const startDate = new Date(asset.purchase_date);
        for (let i = 1; i <= asset.useful_life_months; i++) {
            const date = new Date(startDate);
            date.setMonth(date.getMonth() + i);
            const depreciation = Math.min(monthlyDepreciation, bookValue - asset.salvage_value);
            accumulated += depreciation;
            bookValue -= depreciation;
            schedule.push({
                period: i,
                date,
                depreciation_amount: depreciation,
                accumulated_depreciation: accumulated,
                book_value: bookValue
            });
        }
        return schedule;
    }
    async recordDepreciation(ctx, assetId, amount) {
        const asset = await this.findById(ctx, assetId);
        if (!asset)
            return null;
        return this.update(ctx, assetId, {
            accumulated_depreciation: asset.accumulated_depreciation + amount,
            book_value: asset.book_value - amount
        });
    }
    async disposeAsset(ctx, assetId, disposalDate, disposalAmount) {
        return this.update(ctx, assetId, {
            status: 'disposed',
            disposal_date: disposalDate,
            disposal_amount: disposalAmount
        });
    }
    async getAssetSummary(ctx) {
        const summarySql = `
      SELECT 
        COUNT(*) as total_assets,
        COALESCE(SUM(purchase_price), 0) as total_purchase_value,
        COALESCE(SUM(book_value), 0) as total_book_value,
        COALESCE(SUM(accumulated_depreciation), 0) as total_accumulated_depreciation
      FROM ${this.fullTableName}
      WHERE tenant_id = $1 AND deleted_at IS NULL AND status = 'active'
    `;
        const categorySql = `
      SELECT 
        COALESCE(ac.name, 'Uncategorized') as category_name,
        COUNT(*) as count,
        COALESCE(SUM(a.book_value), 0) as book_value
      FROM ${this.fullTableName} a
      LEFT JOIN assets.categories ac ON ac.id = a.category_id
      WHERE a.tenant_id = $1 AND a.deleted_at IS NULL AND a.status = 'active'
      GROUP BY ac.name
      ORDER BY book_value DESC
    `;
        const [summary, categories] = await Promise.all([
            this.rawQuery(ctx, summarySql),
            this.rawQuery(ctx, categorySql)
        ]);
        return {
            total_assets: parseInt(summary[0]?.total_assets || '0', 10),
            total_purchase_value: parseFloat(summary[0]?.total_purchase_value || '0'),
            total_book_value: parseFloat(summary[0]?.total_book_value || '0'),
            total_accumulated_depreciation: parseFloat(summary[0]?.total_accumulated_depreciation || '0'),
            by_category: categories
        };
    }
}
exports.AssetRepository = AssetRepository;
exports.assetRepository = new AssetRepository();
exports.default = exports.assetRepository;
//# sourceMappingURL=AssetRepository.js.map