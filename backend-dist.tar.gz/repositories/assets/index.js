"use strict";
/**
 * Assets Repositories Index
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.assetCategoryRepository = exports.AssetCategoryRepository = exports.assetRepository = exports.AssetRepository = void 0;
var AssetRepository_1 = require("./AssetRepository");
Object.defineProperty(exports, "AssetRepository", { enumerable: true, get: function () { return AssetRepository_1.AssetRepository; } });
Object.defineProperty(exports, "assetRepository", { enumerable: true, get: function () { return AssetRepository_1.assetRepository; } });
var AssetCategoryRepository_1 = require("./AssetCategoryRepository");
Object.defineProperty(exports, "AssetCategoryRepository", { enumerable: true, get: function () { return AssetCategoryRepository_1.AssetCategoryRepository; } });
Object.defineProperty(exports, "assetCategoryRepository", { enumerable: true, get: function () { return AssetCategoryRepository_1.assetCategoryRepository; } });
//# sourceMappingURL=index.js.map