/**
 * Asset Category Repository
 */
import { BaseRepository, TenantContext } from '../BaseRepository';
export interface AssetCategory {
    id: string;
    tenant_id: string;
    code: string;
    name: string;
    description?: string;
    parent_id?: string;
    default_useful_life_months?: number;
    default_depreciation_method?: 'straight_line' | 'declining_balance' | 'units_of_production';
    default_salvage_value_percent?: number;
    gl_asset_account_id?: string;
    gl_depreciation_account_id?: string;
    gl_expense_account_id?: string;
    is_active: boolean;
    created_at: Date;
    created_by?: string;
    updated_at?: Date;
    updated_by?: string;
    deleted_at?: Date;
}
export declare class AssetCategoryRepository extends BaseRepository<AssetCategory> {
    protected tableName: string;
    protected schema: string;
    getActiveCategories(ctx: TenantContext): Promise<AssetCategory[]>;
    getCategoryTree(ctx: TenantContext): Promise<AssetCategory[]>;
}
export declare const assetCategoryRepository: AssetCategoryRepository;
export default assetCategoryRepository;
//# sourceMappingURL=AssetCategoryRepository.d.ts.map