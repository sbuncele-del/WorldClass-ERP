/**
 * Assets Repositories Index
 */
export { AssetRepository, assetRepository, Asset, AssetStatus } from './AssetRepository';
export { AssetCategoryRepository, assetCategoryRepository, AssetCategory } from './AssetCategoryRepository';
//# sourceMappingURL=index.d.ts.map