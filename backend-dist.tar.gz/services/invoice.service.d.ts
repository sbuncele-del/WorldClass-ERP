interface InvoiceData {
    tenantId: string;
    amount: number;
    currency: string;
    plan: string;
    billingCycle: string;
    transactionId?: string;
    dueDate?: Date;
}
interface Invoice {
    id: string;
    invoiceNumber: string;
    tenantId: string;
    amount: number;
    currency: string;
    status: string;
    dueDate: Date;
    paidAt?: Date;
    s3Url?: string;
    createdAt: Date;
}
export declare class InvoiceService {
    /**
     * Generate invoice number (format: INV-YYYYMMDD-XXXXX)
     */
    private static generateInvoiceNumber;
    /**
     * Generate PDF invoice
     */
    private static generateInvoicePDF;
    /**
     * Format plan name for display
     */
    private static formatPlanName;
    /**
     * Format currency amount
     */
    private static formatCurrency;
    /**
     * Upload PDF to S3
     */
    private static uploadToS3;
    /**
     * Generate and store invoice
     */
    static generateInvoice(data: InvoiceData): Promise<Invoice>;
    /**
     * Get invoice by ID
     */
    static getInvoiceById(invoiceId: string, tenantId: string): Promise<Invoice | null>;
    /**
     * Get invoice history for tenant
     */
    static getInvoiceHistory(tenantId: string, limit?: number): Promise<Invoice[]>;
    /**
     * Get signed download URL for invoice PDF
     */
    static getDownloadUrl(invoiceId: string, tenantId: string): Promise<string | null>;
    /**
     * Mark invoice as paid
     */
    static markInvoicePaid(invoiceId: string, transactionId: string, paidAt?: Date): Promise<void>;
    /**
     * Mark invoice as failed
     */
    static markInvoiceFailed(invoiceId: string, reason?: string): Promise<void>;
    /**
     * Handle failed payment - implements retry logic
     */
    static handleFailedPayment(invoiceId: string): Promise<{
        success: boolean;
        message: string;
        retryScheduled: boolean;
    }>;
    /**
     * Send invoice email to customer
     */
    static sendInvoiceEmail(invoiceId: string, tenantId: string): Promise<{
        success: boolean;
        message: string;
    }>;
}
export default InvoiceService;
//# sourceMappingURL=invoice.service.d.ts.map