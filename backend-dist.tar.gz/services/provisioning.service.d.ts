interface ProvisioningData {
    tenantId: string;
    country?: string;
    industry?: string;
    financialYearEnd?: string;
    currency?: string;
}
export declare class ProvisioningService {
    /**
     * Complete tenant provisioning after signup
     * Creates chart of accounts, sample data, and sends welcome email
     */
    static provisionNewTenant(data: ProvisioningData): Promise<void>;
    /**
     * Create Chart of Accounts based on industry template
     */
    private static createChartOfAccounts;
    /**
     * Get Chart of Accounts template
     */
    private static getChartOfAccountsTemplate;
    /**
     * South African Base Chart of Accounts
     */
    private static getSouthAfricanBaseTemplate;
    /**
     * Additional accounts for Manufacturing industry
     */
    private static getManufacturingAccounts;
    /**
     * Additional accounts for Retail industry
     */
    private static getRetailAccounts;
    /**
     * Additional accounts for Services industry
     */
    private static getServicesAccounts;
    /**
     * Additional accounts for Construction industry
     */
    private static getConstructionAccounts;
    /**
     * International (Generic) Chart of Accounts Template
     */
    private static getInternationalTemplate;
    /**
     * Create South African Tax Rates
     */
    private static createSouthAfricanTaxRates;
    /**
     * Create Financial Periods for current year
     */
    private static createFinancialPeriods;
    /**
     * Create Default Payment Terms
     */
    private static createDefaultPaymentTerms;
    /**
     * Create Document Numbering Sequences
     */
    private static createDocumentNumbering;
}
export default ProvisioningService;
//# sourceMappingURL=provisioning.service.d.ts.map