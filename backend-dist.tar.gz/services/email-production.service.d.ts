/**
 * Production Email Service
 * Supports: Amazon SES, SendGrid, Generic SMTP
 * Features: Retry logic, console fallback, rate limiting
 */
interface EmailOptions {
    to: string | string[];
    subject: string;
    html: string;
    text?: string;
    from?: string;
    replyTo?: string;
}
interface TemplateEmailOptions {
    to: string | string[];
    subject: string;
    template: string;
    variables: Record<string, string>;
    from?: string;
}
declare class ProductionEmailService {
    private transporter;
    private sesClient;
    private initialized;
    private provider;
    constructor();
    private detectProvider;
    private initialize;
    private initializeSES;
    private initializeSendGrid;
    private initializeSMTP;
    private delay;
    private getFromAddress;
    /**
     * Send email with retry logic
     */
    send(options: EmailOptions): Promise<boolean>;
    private sendViaSES;
    private sendViaSMTP;
    private logToConsole;
    private htmlToText;
    /**
     * Load and send templated email
     */
    sendTemplate(options: TemplateEmailOptions): Promise<boolean>;
    private loadTemplate;
    sendPasswordReset(email: string, resetUrl: string, userName: string): Promise<boolean>;
    sendTripCompleted(email: string, tripDetails: {
        tripNumber: string;
        origin: string;
        destination: string;
        driver: string;
        completedAt: string;
    }): Promise<boolean>;
    sendInvoiceNotification(email: string, invoiceDetails: {
        invoiceNumber: string;
        amount: string;
        dueDate: string;
        customerName: string;
    }): Promise<boolean>;
    /**
     * Health check
     */
    healthCheck(): Promise<{
        status: string;
        provider: string;
        message: string;
    }>;
}
export declare const emailService: ProductionEmailService;
export default emailService;
//# sourceMappingURL=email-production.service.d.ts.map