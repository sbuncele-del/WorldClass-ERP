import { EmailJobData } from '../queues/email.queue';
/**
 * Email Queue Service
 *
 * High-level service for queuing emails with priority handling.
 * Use this service instead of calling sendEmail directly for non-critical emails.
 *
 * Priority Guidelines:
 * - HIGH: Transactional emails (password reset, email verification, payment confirmations)
 * - NORMAL: Notifications (team invites, security alerts, low stock)
 * - LOW: Marketing emails, newsletters, product updates
 */
export declare class EmailQueueService {
    /**
     * Queue a high-priority email (processed immediately)
     *
     * Use for: Password resets, email verification, payment confirmations
     */
    static queueHighPriority(emailData: Omit<EmailJobData, 'priority'>): Promise<void>;
    /**
     * Queue a normal-priority email
     *
     * Use for: Notifications, alerts, team invitations
     */
    static queueNormalPriority(emailData: Omit<EmailJobData, 'priority'>): Promise<void>;
    /**
     * Queue a low-priority email
     *
     * Use for: Marketing emails, newsletters, product updates
     */
    static queueLowPriority(emailData: Omit<EmailJobData, 'priority'>): Promise<void>;
    /**
     * Queue a scheduled email (drip campaigns, delayed sends)
     *
     * @param emailData - Email data
     * @param scheduledFor - Date or Unix timestamp when email should be sent
     * @param priority - Priority level (default: normal)
     */
    static queueScheduled(emailData: Omit<EmailJobData, 'priority' | 'scheduledFor'>, scheduledFor: Date | number, priority?: 'high' | 'normal' | 'low'): Promise<void>;
    /**
     * Queue a batch of emails (e.g., newsletter to multiple recipients)
     *
     * @param recipients - Array of recipient emails
     * @param emailData - Common email data (subject, template, variables)
     * @param priority - Priority level (default: low)
     */
    static queueBatch(recipients: string[], emailData: Omit<EmailJobData, 'to' | 'priority'>, priority?: 'high' | 'normal' | 'low'): Promise<void>;
    /**
     * Queue a drip campaign email
     *
     * Drip campaigns send a series of emails over time.
     *
     * @param emailData - Email data
     * @param delayInMinutes - Delay in minutes before sending
     */
    static queueDripCampaign(emailData: Omit<EmailJobData, 'priority' | 'scheduledFor'>, delayInMinutes: number): Promise<void>;
    /**
     * Queue email verification email (high priority)
     */
    static queueEmailVerification(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue password reset email (high priority)
     */
    static queuePasswordReset(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue welcome email (normal priority)
     */
    static queueWelcomeEmail(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue payment success email (high priority)
     */
    static queuePaymentSuccess(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue payment failed email (high priority)
     */
    static queuePaymentFailed(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue team invitation email (normal priority)
     */
    static queueTeamInvitation(to: string, variables: Record<string, string>): Promise<void>;
    /**
     * Queue security alert email (high priority)
     */
    static queueSecurityAlert(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue low stock alert email (normal priority)
     */
    static queueLowStockAlert(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue subscription expiring email (normal priority)
     */
    static queueSubscriptionExpiring(to: string, userId: number, tenantId: number, variables: Record<string, string>): Promise<void>;
    /**
     * Queue marketing email (low priority)
     */
    static queueMarketingEmail(to: string, userId: number, tenantId: number, subject: string, template: string, variables: Record<string, string>): Promise<void>;
}
export default EmailQueueService;
//# sourceMappingURL=email-queue.service.d.ts.map