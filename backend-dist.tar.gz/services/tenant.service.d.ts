import { Tenant } from '../types';
export declare class TenantService {
    /**
     * Get tenant by ID
     */
    static getById(tenantId: string): Promise<Tenant | null>;
    /**
     * Get tenant by slug
     */
    static getBySlug(slug: string): Promise<Tenant | null>;
    /**
     * Check if slug is available
     */
    static isSlugAvailable(slug: string): Promise<boolean>;
    /**
     * Generate unique slug from company name
     */
    static generateSlug(companyName: string): Promise<string>;
    /**
     * Create new tenant (company signup)
     */
    static create(data: Partial<Tenant>): Promise<Tenant>;
    /**
     * Update tenant
     */
    static update(tenantId: string, data: Partial<Tenant>): Promise<Tenant>;
    /**
     * Suspend tenant (non-payment, abuse, etc.)
     */
    static suspend(tenantId: string, reason?: string): Promise<Tenant>;
    /**
     * Reactivate suspended tenant
     */
    static reactivate(tenantId: string): Promise<Tenant>;
    /**
     * Soft delete tenant
     */
    static delete(tenantId: string): Promise<void>;
    /**
     * Get all tenants (super admin only)
     */
    static getAll(filters?: {
        status?: string;
        subscription_plan?: string;
        limit?: number;
        offset?: number;
    }): Promise<{
        tenants: Tenant[];
        total: number;
    }>;
    /**
     * Get tenant statistics
     */
    static getStats(tenantId: string): Promise<any>;
    /**
     * Check if tenant can add more users
     */
    static canAddUser(tenantId: string): Promise<boolean>;
    /**
     * Extend trial period
     */
    static extendTrial(tenantId: string, days: number): Promise<Tenant>;
    /**
     * Activate subscription (after payment)
     */
    static activateSubscription(tenantId: string, plan: string): Promise<Tenant>;
    /**
     * Get platform-wide statistics (super admin)
     */
    static getPlatformStats(): Promise<any>;
}
export default TenantService;
//# sourceMappingURL=tenant.service.d.ts.map