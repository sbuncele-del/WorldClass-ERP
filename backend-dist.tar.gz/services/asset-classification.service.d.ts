/**
 * Capital vs Expense Classification Service
 * IAS 16 compliant asset recognition and classification
 */
export interface AssetClassificationParams {
    acquisition_cost: number;
    expected_useful_life_years: number;
    is_tangible: boolean;
    provides_future_benefits: boolean;
    is_controlled_by_entity: boolean;
    cost_is_measurable: boolean;
    maintenance_nature?: 'improvement' | 'repair' | 'replacement';
    enhances_useful_life?: boolean;
    enhances_capacity?: boolean;
}
export interface ClassificationResult {
    should_capitalize: boolean;
    classification: 'capital' | 'expense' | 'requires_review';
    reason: string;
    ias16_paragraph?: string;
    recommended_useful_life?: number;
    recommended_depreciation_method?: string;
}
export interface CapitalizationThresholds {
    minimum_amount: number;
    minimum_useful_life_years: number;
    low_value_asset_threshold: number;
}
export declare class AssetClassificationService {
    private thresholds;
    constructor(thresholds?: Partial<CapitalizationThresholds>);
    /**
     * Determine if expenditure should be capitalized as asset or expensed
     * Based on IAS 16.7-8 recognition criteria
     */
    classifyExpenditure(params: AssetClassificationParams): ClassificationResult;
    /**
     * Classify maintenance expenditure (IAS 16.12-14)
     */
    private classifyMaintenance;
    /**
     * Suggest useful life based on asset type and cost
     */
    private suggestUsefulLife;
    /**
     * Suggest depreciation method based on asset characteristics
     */
    private suggestDepreciationMethod;
    /**
     * Get current thresholds
     */
    getThresholds(): CapitalizationThresholds;
    /**
     * Update thresholds
     */
    updateThresholds(newThresholds: Partial<CapitalizationThresholds>): void;
}
export default AssetClassificationService;
//# sourceMappingURL=asset-classification.service.d.ts.map