/**
 * Email Preferences Service
 * Manages user email notification preferences and unsubscribe functionality
 */
export interface EmailPreferences {
    userId: number;
    tenantId: number;
    marketingEmails: boolean;
    productUpdates: boolean;
    securityAlerts: boolean;
    paymentNotifications: boolean;
    subscriptionNotifications: boolean;
    inventoryAlerts: boolean;
    teamNotifications: boolean;
    systemNotifications: boolean;
    unsubscribedAll: boolean;
    digestFrequency: 'instant' | 'daily' | 'weekly' | 'never';
}
export interface EmailCategory {
    id: string;
    name: string;
    description: string;
    canDisable: boolean;
    enabled: boolean;
}
/**
 * Get user's email preferences
 */
export declare function getUserEmailPreferences(userId: number, tenantId: number): Promise<EmailPreferences>;
/**
 * Update user's email preferences
 */
export declare function updateEmailPreferences(userId: number, tenantId: number, preferences: Partial<EmailPreferences>): Promise<EmailPreferences>;
/**
 * Generate unsubscribe token
 */
export declare function generateUnsubscribeToken(userId: number, tenantId: number, category?: string): Promise<string>;
/**
 * Process unsubscribe via token
 */
export declare function processUnsubscribe(token: string): Promise<{
    success: boolean;
    category?: string;
    email?: string;
}>;
/**
 * Check if user can receive email of specific type
 */
export declare function canSendEmail(userId: number, tenantId: number, category: string): Promise<boolean>;
/**
 * Log email send for compliance
 */
export declare function logEmailSend(data: {
    userId?: number;
    tenantId?: number;
    emailAddress: string;
    emailType: string;
    emailCategory: string;
    subject: string;
}): Promise<void>;
/**
 * Get email categories with descriptions
 */
export declare function getEmailCategories(preferences: EmailPreferences): EmailCategory[];
export declare const EmailPreferencesService: {
    getUserEmailPreferences: typeof getUserEmailPreferences;
    updateEmailPreferences: typeof updateEmailPreferences;
    generateUnsubscribeToken: typeof generateUnsubscribeToken;
    processUnsubscribe: typeof processUnsubscribe;
    canSendEmail: typeof canSendEmail;
    logEmailSend: typeof logEmailSend;
    getEmailCategories: typeof getEmailCategories;
};
export default EmailPreferencesService;
//# sourceMappingURL=email-preferences.service.d.ts.map