import { RedisClient } from '../config/redis-connection';
/**
 * RedisService
 * Shared Redis utilities for caching, health, and pub/sub helpers.
 *
 * MULTI-TENANCY:
 * - Use tenant-prefixed methods (getTenant, setTenant, etc.) for tenant-specific data
 * - Regular methods (get, set, etc.) are for global/system data only
 * - Tenant keys follow format: tenant:{tenantId}:{key}
 */
export declare class RedisService {
    private client;
    constructor(client?: RedisClient);
    getClient(): RedisClient;
    ping(): Promise<boolean>;
    /**
     * Build a tenant-scoped key
     */
    private tenantKey;
    /**
     * Get a tenant-scoped value
     */
    getTenant<T = unknown>(tenantId: string, key: string): Promise<T | null>;
    /**
     * Set a tenant-scoped value
     */
    setTenant<T = unknown>(tenantId: string, key: string, value: T, ttlSeconds?: number): Promise<'OK' | null>;
    /**
     * Delete a tenant-scoped key
     */
    delTenant(tenantId: string, key: string | string[]): Promise<number>;
    /**
     * Get TTL for a tenant-scoped key
     */
    ttlTenant(tenantId: string, key: string): Promise<number>;
    /**
     * Flush all keys for a specific tenant
     */
    flushTenant(tenantId: string): Promise<number>;
    /**
     * Get all keys for a tenant matching a pattern
     */
    keysTenant(tenantId: string, pattern?: string): Promise<string[]>;
    get<T = unknown>(key: string): Promise<T | null>;
    set<T = unknown>(key: string, value: T, ttlSeconds?: number): Promise<'OK' | null>;
    del(key: string | string[]): Promise<number>;
    ttl(key: string): Promise<number>;
    flushPrefix(prefix: string): Promise<number>;
}
export declare function redisHealthCheck(): Promise<{
    status: 'up' | 'down';
    latencyMs: number;
}>;
export declare const redisService: RedisService;
/**
 * Helper to build new pub/sub clients (Socket.IO adapter)
 */
export declare const buildPubSubClients: () => {
    pubClient: RedisClient;
    subClient: RedisClient;
};
//# sourceMappingURL=redis.service.d.ts.map