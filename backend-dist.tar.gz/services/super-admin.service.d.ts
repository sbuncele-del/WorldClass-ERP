/**
 * Super Admin Service
 *
 * Provides system-wide administration capabilities:
 * - Tenant management (list, view, suspend, activate, delete)
 * - User impersonation for support
 * - System statistics and analytics
 * - Feature flags management
 * - System health monitoring
 *
 * Security: All endpoints should be protected by super admin auth
 */
interface TenantListFilter {
    status?: 'active' | 'suspended' | 'trial' | 'cancelled';
    plan?: string;
    search?: string;
    limit?: number;
    offset?: number;
}
interface SystemStats {
    totalTenants: number;
    activeTenants: number;
    trialTenants: number;
    suspendedTenants: number;
    totalUsers: number;
    totalRevenue: number;
    newTenantsLast30Days: number;
    activeUsersLast7Days: number;
}
declare class SuperAdminService {
    /**
     * Get list of all tenants with filters
     */
    getTenants(filters?: TenantListFilter): Promise<{
        tenants: any[];
        total: number;
        limit: number;
        offset: number;
    }>;
    /**
     * Get detailed tenant information
     */
    getTenantDetails(tenantId: string): Promise<{
        tenant: any;
        payments: any[];
        users: any[];
        storage: {
            used: number;
            limit: number;
        };
    }>;
    /**
     * Suspend a tenant account
     */
    suspendTenant(tenantId: string, reason: string, suspendedBy: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Activate a suspended tenant
     */
    activateTenant(tenantId: string, activatedBy: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Delete a tenant (soft delete - marks as deleted)
     */
    deleteTenant(tenantId: string, deletedBy: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Generate impersonation token
     * Allows super admin to log in as any user for support purposes
     */
    generateImpersonationToken(userId: string, adminEmail: string): Promise<{
        token: string;
        user: {
            id: any;
            email: any;
            firstName: any;
            lastName: any;
            role: any;
            tenantId: any;
            tenantName: any;
        };
        expiresIn: string;
    }>;
    /**
     * Get system-wide statistics
     */
    getSystemStats(): Promise<SystemStats>;
    /**
     * Get system health metrics
     */
    getSystemHealth(): Promise<{
        status: string;
        database: {
            connected: boolean;
            latency: number;
        };
        errors: {
            lastHour: number;
        };
        payments: {
            failedLast24h: number;
        };
        activeSessions: number;
        timestamp: string;
    }>;
    /**
     * Get feature flags (for gradual rollout)
     */
    getFeatureFlags(): Promise<any[]>;
    /**
     * Update feature flag
     */
    updateFeatureFlag(name: string, enabled: boolean, rolloutPercentage?: number): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Get recent audit logs (system-wide)
     */
    getAuditLogs(limit?: number, offset?: number): Promise<{
        logs: any[];
        total: number;
        limit: number;
        offset: number;
    }>;
}
declare const _default: SuperAdminService;
export default _default;
//# sourceMappingURL=super-admin.service.d.ts.map