"use strict";
/**
 * Email Service
 * Core email sending functionality using Nodemailer
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendEmail = sendEmail;
exports.sendPlainEmail = sendPlainEmail;
exports.sendBulkEmails = sendBulkEmails;
const nodemailer_1 = __importDefault(require("nodemailer"));
const util_1 = require("util");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const email_preferences_service_1 = __importDefault(require("./email-preferences.service"));
const readFile = (0, util_1.promisify)(fs_1.default.readFile);
// Email configuration
const emailConfig = {
    host: process.env.EMAIL_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.EMAIL_PORT || '587'),
    secure: process.env.EMAIL_SECURE === 'true', // true for 465, false for other ports
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
    },
};
// Create transporter - only if email is enabled
const EMAIL_ENABLED = process.env.ENABLE_EMAIL !== 'false' && process.env.EMAIL_USER && process.env.EMAIL_PASSWORD;
const transporter = EMAIL_ENABLED
    ? nodemailer_1.default.createTransport(emailConfig)
    : null; // Dummy transporter when disabled
// Verify connection configuration
if (EMAIL_ENABLED && transporter) {
    transporter.verify((error, success) => {
        if (error) {
            console.error('Email service configuration error:', error);
        }
        else {
            console.log('✅ Email service is ready to send messages');
        }
    });
}
else {
    console.log('⚠️  Email service disabled (no credentials configured)');
}
/**
 * Email template loader
 * Loads and processes email templates with variable substitution
 */
async function loadTemplate(templateName, variables) {
    try {
        const templatePath = path_1.default.join(__dirname, '../templates/email', `${templateName}.html`);
        let template = await readFile(templatePath, 'utf-8');
        // Replace variables in template
        Object.keys(variables).forEach(key => {
            const regex = new RegExp(`{{${key}}}`, 'g');
            template = template.replace(regex, variables[key]);
        });
        return template;
    }
    catch (error) {
        console.error(`Failed to load email template: ${templateName}`, error);
        throw new Error(`Email template not found: ${templateName}`);
    }
}
/**
 * Send email using template
 */
async function sendEmail(options) {
    try {
        const { to, subject, template, variables, from, userId, tenantId, category } = options;
        // Check email preferences if user info provided
        if (userId && tenantId && category) {
            const canSend = await email_preferences_service_1.default.canSendEmail(userId, tenantId, category);
            if (!canSend) {
                console.log(`⏭️ Skipping email to ${to} - user preference: ${category}`);
                return;
            }
        }
        // Generate unsubscribe token if user info provided
        let unsubscribeUrl = '';
        if (userId && tenantId) {
            const token = await email_preferences_service_1.default.generateUnsubscribeToken(userId, tenantId, category);
            unsubscribeUrl = `${process.env.FRONTEND_URL}/api/email-preferences/unsubscribe/${token}`;
            variables.unsubscribeUrl = unsubscribeUrl;
        }
        // Check if email is enabled
        if (!EMAIL_ENABLED || !transporter) {
            console.log(`⚠️ Email service disabled - would have sent to: ${to}, subject: ${subject}`);
            return; // Silently return if email is not configured
        }
        // Load and process template
        const html = await loadTemplate(template, variables);
        // Send email
        const info = await transporter.sendMail({
            from: from || `"Worldclass ERP" <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`,
            to,
            subject,
            html,
        });
        console.log('✅ Email sent:', {
            messageId: info.messageId,
            to,
            subject,
        });
        // Log email send for compliance
        if (userId && tenantId && category) {
            await email_preferences_service_1.default.logEmailSend({
                userId,
                tenantId,
                emailAddress: to,
                emailType: template,
                emailCategory: category,
                subject,
            });
        }
    }
    catch (error) {
        console.error('❌ Failed to send email:', error);
        throw error;
    }
}
/**
 * Send plain text email (no template)
 */
async function sendPlainEmail(options) {
    try {
        const { to, subject, text, html, from } = options;
        const info = await transporter.sendMail({
            from: from || `"Worldclass ERP" <${process.env.EMAIL_FROM || process.env.EMAIL_USER}>`,
            to,
            subject,
            text,
            html: html || text,
        });
        console.log('✅ Email sent:', {
            messageId: info.messageId,
            to,
            subject,
        });
    }
    catch (error) {
        console.error('❌ Failed to send email:', error);
        throw error;
    }
}
/**
 * Send bulk emails (with rate limiting)
 */
async function sendBulkEmails(emails, delayMs = 100) {
    const results = {
        sent: 0,
        failed: 0,
        errors: [],
    };
    for (const email of emails) {
        try {
            await sendEmail(email);
            results.sent++;
            // Delay between emails to avoid rate limiting
            if (delayMs > 0) {
                await new Promise(resolve => setTimeout(resolve, delayMs));
            }
        }
        catch (error) {
            results.failed++;
            results.errors.push({
                email: email.to,
                error: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    }
    return results;
}
exports.default = {
    sendEmail,
    sendPlainEmail,
    sendBulkEmails,
};
//# sourceMappingURL=email.service.js.map