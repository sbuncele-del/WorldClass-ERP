/**
 * Vehicle Tracking Provider Integration Service
 *
 * Consolidates data from multiple tracking providers:
 * - MiX Telematics
 * - Netstar
 * - Ctrack
 * - Tracker SA
 * - Cartrack
 * - Custom API providers
 *
 * Normalizes data into a unified format for the ERP system.
 */
export interface VehiclePosition {
    vehicleId: string;
    registration: string;
    providerId: string;
    providerName: string;
    lat: number;
    lng: number;
    speed: number;
    heading: number;
    altitude?: number;
    ignition: boolean;
    odometer?: number;
    fuelLevel?: number;
    driver?: string;
    tripId?: string;
    timestamp: Date;
    rawData?: Record<string, unknown>;
}
export interface TrackingProviderConfig {
    id: string;
    name: string;
    type: 'mix_telematics' | 'netstar' | 'ctrack' | 'tracker_sa' | 'cartrack' | 'custom';
    apiUrl: string;
    apiKey?: string;
    username?: string;
    password?: string;
    clientId?: string;
    clientSecret?: string;
    webhookSecret?: string;
    refreshToken?: string;
    accessToken?: string;
    tokenExpiry?: Date;
    enabled: boolean;
    syncInterval: number;
    lastSync?: Date;
}
export interface ProviderStatus {
    id: string;
    name: string;
    connected: boolean;
    vehicleCount: number;
    lastSync: Date | null;
    errorMessage?: string;
}
declare class TrackingProvidersService {
    private providers;
    private apiClients;
    private positions;
    constructor();
    /**
     * Load provider configurations from database
     */
    loadProviders(): Promise<void>;
    /**
     * Initialize API client for a provider
     */
    private initializeApiClient;
    /**
     * MiX Telematics OAuth token management
     */
    private getMixToken;
    /**
     * Fetch positions from all providers
     */
    fetchAllPositions(): Promise<VehiclePosition[]>;
    /**
     * Fetch positions from a specific provider
     */
    private fetchProviderPositions;
    /**
     * MiX Telematics API Integration
     */
    private fetchMixPositions;
    /**
     * Netstar API Integration
     */
    private fetchNetstarPositions;
    /**
     * Ctrack API Integration
     */
    private fetchCtrackPositions;
    /**
     * Tracker SA API Integration
     */
    private fetchTrackerSAPositions;
    /**
     * Cartrack API Integration
     */
    private fetchCartrackPositions;
    /**
     * Custom API Integration (Generic)
     */
    private fetchCustomPositions;
    /**
     * Process incoming webhook from tracking provider
     */
    processWebhook(providerId: string, data: Record<string, unknown>): Promise<VehiclePosition | null>;
    private parseMixWebhook;
    private parseNetstarWebhook;
    private parseCustomWebhook;
    /**
     * Store position in database
     */
    private storePosition;
    /**
     * Get current position for a vehicle
     */
    getPosition(vehicleId: string): VehiclePosition | undefined;
    /**
     * Get all current positions
     */
    getAllPositions(): VehiclePosition[];
    /**
     * Get provider status
     */
    getProviderStatus(): Promise<ProviderStatus[]>;
    /**
     * Add or update provider configuration
     */
    upsertProvider(config: Partial<TrackingProviderConfig>): Promise<TrackingProviderConfig | null>;
    /**
     * Delete provider
     */
    deleteProvider(providerId: string): Promise<boolean>;
}
export declare const trackingProvidersService: TrackingProvidersService;
export default trackingProvidersService;
//# sourceMappingURL=tracking-providers.service.d.ts.map