"use strict";
/**
 * Vehicle Tracking Provider Integration Service
 *
 * Consolidates data from multiple tracking providers:
 * - MiX Telematics
 * - Netstar
 * - Ctrack
 * - Tracker SA
 * - Cartrack
 * - Custom API providers
 *
 * Normalizes data into a unified format for the ERP system.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.trackingProvidersService = void 0;
const axios_1 = __importDefault(require("axios"));
const database_1 = __importDefault(require("../../config/database"));
class TrackingProvidersService {
    constructor() {
        this.providers = new Map();
        this.apiClients = new Map();
        this.positions = new Map();
        this.loadProviders();
    }
    /**
     * Load provider configurations from database
     */
    async loadProviders() {
        try {
            const result = await database_1.default.query(`
        SELECT * FROM logistics.tracking_providers WHERE enabled = true
      `);
            result.rows.forEach((row) => {
                this.providers.set(row.id, row);
                this.initializeApiClient(row);
            });
            console.log(`Loaded ${this.providers.size} tracking providers`);
        }
        catch (error) {
            console.error('Error loading tracking providers:', error);
        }
    }
    /**
     * Initialize API client for a provider
     */
    initializeApiClient(config) {
        const client = axios_1.default.create({
            baseURL: config.apiUrl,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
            }
        });
        // Add auth interceptor based on provider type
        client.interceptors.request.use(async (requestConfig) => {
            const provider = this.providers.get(config.id);
            if (!provider)
                return requestConfig;
            switch (provider.type) {
                case 'mix_telematics':
                    requestConfig.headers['Authorization'] = `Bearer ${await this.getMixToken(provider)}`;
                    break;
                case 'netstar':
                    requestConfig.headers['X-Api-Key'] = provider.apiKey;
                    break;
                case 'ctrack':
                    requestConfig.headers['Authorization'] = `Basic ${Buffer.from(`${provider.username}:${provider.password}`).toString('base64')}`;
                    break;
                case 'tracker_sa':
                    requestConfig.headers['Authorization'] = `Bearer ${provider.apiKey}`;
                    break;
                case 'cartrack':
                    requestConfig.params = { ...requestConfig.params, api_key: provider.apiKey };
                    break;
                case 'custom':
                    if (provider.apiKey) {
                        requestConfig.headers['Authorization'] = `Bearer ${provider.apiKey}`;
                    }
                    break;
            }
            return requestConfig;
        });
        this.apiClients.set(config.id, client);
    }
    /**
     * MiX Telematics OAuth token management
     */
    async getMixToken(provider) {
        // Check if token is still valid
        if (provider.accessToken && provider.tokenExpiry && new Date() < provider.tokenExpiry) {
            return provider.accessToken;
        }
        // Refresh token
        try {
            const response = await axios_1.default.post(`${provider.apiUrl}/oauth/token`, {
                grant_type: 'client_credentials',
                client_id: provider.clientId,
                client_secret: provider.clientSecret,
            });
            provider.accessToken = response.data.access_token;
            provider.tokenExpiry = new Date(Date.now() + (response.data.expires_in * 1000));
            // Update in database
            await database_1.default.query(`
        UPDATE logistics.tracking_providers 
        SET access_token = $1, token_expiry = $2 
        WHERE id = $3
      `, [provider.accessToken, provider.tokenExpiry, provider.id]);
            return provider.accessToken;
        }
        catch (error) {
            console.error('Error refreshing MiX token:', error);
            throw error;
        }
    }
    /**
     * Fetch positions from all providers
     */
    async fetchAllPositions() {
        const allPositions = [];
        for (const [providerId, provider] of this.providers) {
            try {
                const positions = await this.fetchProviderPositions(provider);
                allPositions.push(...positions);
                // Update last sync
                provider.lastSync = new Date();
                await database_1.default.query(`
          UPDATE logistics.tracking_providers SET last_sync = $1 WHERE id = $2
        `, [provider.lastSync, providerId]);
            }
            catch (error) {
                console.error(`Error fetching from provider ${provider.name}:`, error);
            }
        }
        // Store positions in memory
        allPositions.forEach(pos => {
            this.positions.set(pos.vehicleId, pos);
        });
        return allPositions;
    }
    /**
     * Fetch positions from a specific provider
     */
    async fetchProviderPositions(provider) {
        const client = this.apiClients.get(provider.id);
        if (!client)
            return [];
        switch (provider.type) {
            case 'mix_telematics':
                return this.fetchMixPositions(client, provider);
            case 'netstar':
                return this.fetchNetstarPositions(client, provider);
            case 'ctrack':
                return this.fetchCtrackPositions(client, provider);
            case 'tracker_sa':
                return this.fetchTrackerSAPositions(client, provider);
            case 'cartrack':
                return this.fetchCartrackPositions(client, provider);
            case 'custom':
                return this.fetchCustomPositions(client, provider);
            default:
                return [];
        }
    }
    /**
     * MiX Telematics API Integration
     */
    async fetchMixPositions(client, provider) {
        try {
            const response = await client.get('/api/v2/positions/latest');
            return response.data.map((item) => ({
                vehicleId: `MIX-${item.AssetId}`,
                registration: item.RegistrationNumber,
                providerId: provider.id,
                providerName: 'MiX Telematics',
                lat: item.Latitude,
                lng: item.Longitude,
                speed: item.SpeedKmh || 0,
                heading: item.Heading || 0,
                ignition: item.IgnitionOn || false,
                odometer: item.OdometerKm,
                fuelLevel: item.FuelPercentage,
                timestamp: new Date(item.Timestamp),
                rawData: item
            }));
        }
        catch (error) {
            console.error('MiX Telematics API error:', error);
            return [];
        }
    }
    /**
     * Netstar API Integration
     */
    async fetchNetstarPositions(client, provider) {
        try {
            const response = await client.get('/fleet/vehicles/positions');
            return response.data.vehicles.map((item) => ({
                vehicleId: `NET-${item.vehicle_id}`,
                registration: item.registration,
                providerId: provider.id,
                providerName: 'Netstar',
                lat: item.latitude,
                lng: item.longitude,
                speed: item.speed || 0,
                heading: item.direction || 0,
                ignition: item.status === 'moving' || item.status === 'idling',
                timestamp: new Date(item.timestamp),
                rawData: item
            }));
        }
        catch (error) {
            console.error('Netstar API error:', error);
            return [];
        }
    }
    /**
     * Ctrack API Integration
     */
    async fetchCtrackPositions(client, provider) {
        try {
            const response = await client.get('/v1/vehicles/positions');
            return response.data.data.map((item) => ({
                vehicleId: `CTR-${item.id}`,
                registration: item.reg_number,
                providerId: provider.id,
                providerName: 'Ctrack',
                lat: item.position?.lat,
                lng: item.position?.lon,
                speed: item.speed || 0,
                heading: item.bearing || 0,
                ignition: item.ignition_on,
                odometer: item.odometer,
                timestamp: new Date(item.gps_time),
                rawData: item
            }));
        }
        catch (error) {
            console.error('Ctrack API error:', error);
            return [];
        }
    }
    /**
     * Tracker SA API Integration
     */
    async fetchTrackerSAPositions(client, provider) {
        try {
            const response = await client.get('/api/fleet/current-positions');
            return response.data.map((item) => ({
                vehicleId: `TRK-${item.unit_id}`,
                registration: item.vehicle_reg,
                providerId: provider.id,
                providerName: 'Tracker SA',
                lat: item.lat,
                lng: item.lon,
                speed: item.speed_kmh || 0,
                heading: item.course || 0,
                ignition: item.ignition,
                timestamp: new Date(item.event_time),
                rawData: item
            }));
        }
        catch (error) {
            console.error('Tracker SA API error:', error);
            return [];
        }
    }
    /**
     * Cartrack API Integration
     */
    async fetchCartrackPositions(client, provider) {
        try {
            const response = await client.get('/api/v1/fleet/positions');
            return response.data.results.map((item) => ({
                vehicleId: `CAR-${item.asset_id}`,
                registration: item.registration,
                providerId: provider.id,
                providerName: 'Cartrack',
                lat: item.latitude,
                lng: item.longitude,
                speed: item.speed || 0,
                heading: item.heading || 0,
                ignition: item.state !== 'parked',
                fuelLevel: item.fuel_percent,
                timestamp: new Date(item.timestamp),
                rawData: item
            }));
        }
        catch (error) {
            console.error('Cartrack API error:', error);
            return [];
        }
    }
    /**
     * Custom API Integration (Generic)
     */
    async fetchCustomPositions(client, provider) {
        try {
            const response = await client.get('/positions');
            // Assuming standard format - can be customized per provider
            return response.data.map((item) => ({
                vehicleId: `CUSTOM-${provider.id}-${item.id}`,
                registration: (item.registration || item.reg || item.vehicle_number),
                providerId: provider.id,
                providerName: provider.name,
                lat: (item.lat || item.latitude),
                lng: (item.lng || item.lon || item.longitude),
                speed: (item.speed || item.speed_kmh || 0),
                heading: (item.heading || item.direction || 0),
                ignition: (item.ignition || item.engine_on || false),
                timestamp: new Date((item.timestamp || item.time || new Date())),
                rawData: item
            }));
        }
        catch (error) {
            console.error(`Custom provider ${provider.name} API error:`, error);
            return [];
        }
    }
    /**
     * Process incoming webhook from tracking provider
     */
    async processWebhook(providerId, data) {
        const provider = this.providers.get(providerId);
        if (!provider) {
            console.error(`Unknown provider: ${providerId}`);
            return null;
        }
        let position = null;
        switch (provider.type) {
            case 'mix_telematics':
                position = this.parseMixWebhook(data, provider);
                break;
            case 'netstar':
                position = this.parseNetstarWebhook(data, provider);
                break;
            case 'custom':
                position = this.parseCustomWebhook(data, provider);
                break;
            default:
                console.warn(`Webhook parsing not implemented for ${provider.type}`);
        }
        if (position) {
            this.positions.set(position.vehicleId, position);
            // Store in database
            await this.storePosition(position);
        }
        return position;
    }
    parseMixWebhook(data, provider) {
        return {
            vehicleId: `MIX-${data.AssetId}`,
            registration: data.RegistrationNumber,
            providerId: provider.id,
            providerName: 'MiX Telematics',
            lat: data.Latitude,
            lng: data.Longitude,
            speed: data.SpeedKmh || 0,
            heading: data.Heading || 0,
            ignition: data.IgnitionOn,
            timestamp: new Date(data.Timestamp),
            rawData: data
        };
    }
    parseNetstarWebhook(data, provider) {
        return {
            vehicleId: `NET-${data.vehicle_id}`,
            registration: data.registration,
            providerId: provider.id,
            providerName: 'Netstar',
            lat: data.latitude,
            lng: data.longitude,
            speed: data.speed || 0,
            heading: data.direction || 0,
            ignition: data.status === 'moving',
            timestamp: new Date(data.timestamp),
            rawData: data
        };
    }
    parseCustomWebhook(data, provider) {
        return {
            vehicleId: `CUSTOM-${provider.id}-${data.id}`,
            registration: (data.registration || data.reg),
            providerId: provider.id,
            providerName: provider.name,
            lat: (data.lat || data.latitude),
            lng: (data.lng || data.longitude),
            speed: (data.speed || 0),
            heading: (data.heading || 0),
            ignition: (data.ignition || false),
            timestamp: new Date((data.timestamp || new Date())),
            rawData: data
        };
    }
    /**
     * Store position in database
     */
    async storePosition(position) {
        try {
            await database_1.default.query(`
        INSERT INTO logistics.vehicle_positions 
        (vehicle_id, registration, provider_id, provider_name, lat, lng, speed, heading, ignition, timestamp, raw_data)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
        ON CONFLICT (vehicle_id) DO UPDATE SET
          lat = EXCLUDED.lat,
          lng = EXCLUDED.lng,
          speed = EXCLUDED.speed,
          heading = EXCLUDED.heading,
          ignition = EXCLUDED.ignition,
          timestamp = EXCLUDED.timestamp,
          raw_data = EXCLUDED.raw_data,
          updated_at = NOW()
      `, [
                position.vehicleId,
                position.registration,
                position.providerId,
                position.providerName,
                position.lat,
                position.lng,
                position.speed,
                position.heading,
                position.ignition,
                position.timestamp,
                JSON.stringify(position.rawData)
            ]);
        }
        catch (error) {
            console.error('Error storing position:', error);
        }
    }
    /**
     * Get current position for a vehicle
     */
    getPosition(vehicleId) {
        return this.positions.get(vehicleId);
    }
    /**
     * Get all current positions
     */
    getAllPositions() {
        return Array.from(this.positions.values());
    }
    /**
     * Get provider status
     */
    async getProviderStatus() {
        const statuses = [];
        for (const [, provider] of this.providers) {
            const vehicleCount = Array.from(this.positions.values())
                .filter(p => p.providerId === provider.id).length;
            statuses.push({
                id: provider.id,
                name: provider.name,
                connected: provider.enabled,
                vehicleCount,
                lastSync: provider.lastSync || null
            });
        }
        return statuses;
    }
    /**
     * Add or update provider configuration
     */
    async upsertProvider(config) {
        try {
            const result = await database_1.default.query(`
        INSERT INTO logistics.tracking_providers 
        (id, name, type, api_url, api_key, username, password, client_id, client_secret, webhook_secret, enabled, sync_interval)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
        ON CONFLICT (id) DO UPDATE SET
          name = COALESCE(EXCLUDED.name, logistics.tracking_providers.name),
          type = COALESCE(EXCLUDED.type, logistics.tracking_providers.type),
          api_url = COALESCE(EXCLUDED.api_url, logistics.tracking_providers.api_url),
          api_key = COALESCE(EXCLUDED.api_key, logistics.tracking_providers.api_key),
          username = COALESCE(EXCLUDED.username, logistics.tracking_providers.username),
          password = COALESCE(EXCLUDED.password, logistics.tracking_providers.password),
          client_id = COALESCE(EXCLUDED.client_id, logistics.tracking_providers.client_id),
          client_secret = COALESCE(EXCLUDED.client_secret, logistics.tracking_providers.client_secret),
          webhook_secret = COALESCE(EXCLUDED.webhook_secret, logistics.tracking_providers.webhook_secret),
          enabled = COALESCE(EXCLUDED.enabled, logistics.tracking_providers.enabled),
          sync_interval = COALESCE(EXCLUDED.sync_interval, logistics.tracking_providers.sync_interval),
          updated_at = NOW()
        RETURNING *
      `, [
                config.id,
                config.name,
                config.type,
                config.apiUrl,
                config.apiKey,
                config.username,
                config.password,
                config.clientId,
                config.clientSecret,
                config.webhookSecret,
                config.enabled ?? true,
                config.syncInterval ?? 60
            ]);
            const newProvider = result.rows[0];
            this.providers.set(newProvider.id, newProvider);
            this.initializeApiClient(newProvider);
            return newProvider;
        }
        catch (error) {
            console.error('Error upserting provider:', error);
            return null;
        }
    }
    /**
     * Delete provider
     */
    async deleteProvider(providerId) {
        try {
            await database_1.default.query(`DELETE FROM logistics.tracking_providers WHERE id = $1`, [providerId]);
            this.providers.delete(providerId);
            this.apiClients.delete(providerId);
            return true;
        }
        catch (error) {
            console.error('Error deleting provider:', error);
            return false;
        }
    }
}
// Singleton instance
exports.trackingProvidersService = new TrackingProvidersService();
exports.default = exports.trackingProvidersService;
//# sourceMappingURL=tracking-providers.service.js.map