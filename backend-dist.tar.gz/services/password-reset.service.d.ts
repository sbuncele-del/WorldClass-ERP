/**
 * Password Reset Service
 * Handles password reset token generation and validation
 */
/**
 * Send password reset email
 */
export declare function sendPasswordResetEmail(email: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Verify password reset token
 */
export declare function verifyResetToken(token: string): Promise<{
    success: boolean;
    userId?: string;
    message: string;
}>;
/**
 * Reset password with token
 */
export declare function resetPassword(token: string, newPassword: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Validate password strength
 */
export declare function validatePasswordStrength(password: string): {
    valid: boolean;
    errors: string[];
    strength: 'weak' | 'fair' | 'good' | 'strong';
};
/**
 * Clean up expired tokens (should be run periodically)
 */
export declare function cleanupExpiredResetTokens(): Promise<number>;
declare const _default: {
    sendPasswordResetEmail: typeof sendPasswordResetEmail;
    verifyResetToken: typeof verifyResetToken;
    resetPassword: typeof resetPassword;
    validatePasswordStrength: typeof validatePasswordStrength;
    cleanupExpiredResetTokens: typeof cleanupExpiredResetTokens;
};
export default _default;
//# sourceMappingURL=password-reset.service.d.ts.map