/**
 * GPS Provider Interface
 * Unified abstraction for multiple GPS tracking providers
 */
export interface UnifiedPosition {
    vehicleId: string;
    latitude: number;
    longitude: number;
    speed: number;
    heading: number;
    timestamp: string;
    ignition: boolean;
    odometer: number;
    fuelLevel?: number;
    provider: 'cartrack' | 'mix' | 'ctrack';
    raw: any;
}
export interface GPSHistoryQuery {
    vehicleId: string;
    startDate: Date;
    endDate: Date;
    limit?: number;
}
export interface IGPSProvider {
    /**
     * Get current position for a single vehicle
     */
    getVehiclePosition(vehicleId: string): Promise<UnifiedPosition | null>;
    /**
     * Get current positions for all vehicles in fleet
     */
    getFleetPositions(): Promise<UnifiedPosition[]>;
    /**
     * Get historical positions for a vehicle
     */
    getTripHistory(query: GPSHistoryQuery): Promise<UnifiedPosition[]>;
    /**
     * Validate webhook payload signature/authentication
     */
    validateWebhook(payload: any, headers: any): boolean;
    /**
     * Parse webhook payload into unified format
     */
    parsePosition(rawData: any): UnifiedPosition;
    /**
     * Provider name
     */
    getProviderName(): string;
    /**
     * Check if provider is healthy/reachable
     */
    healthCheck(): Promise<boolean>;
}
export interface GPSProviderConfig {
    provider: 'cartrack' | 'mix' | 'ctrack';
    apiKey?: string;
    apiSecret?: string;
    baseUrl?: string;
    webhookSecret?: string;
    customerId?: string;
    enabled: boolean;
}
//# sourceMappingURL=IGPSProvider.d.ts.map