/**
 * Cartrack GPS Provider Implementation
 * Documentation: https://www.cartrack.com/za/developers
 */
import { IGPSProvider, UnifiedPosition, GPSHistoryQuery, GPSProviderConfig } from './IGPSProvider';
export declare class CartrackProvider implements IGPSProvider {
    private client;
    private config;
    constructor(config: GPSProviderConfig);
    getVehiclePosition(vehicleId: string): Promise<UnifiedPosition | null>;
    getFleetPositions(): Promise<UnifiedPosition[]>;
    getTripHistory(query: GPSHistoryQuery): Promise<UnifiedPosition[]>;
    validateWebhook(payload: any, headers: any): boolean;
    parsePosition(rawData: any): UnifiedPosition;
    getProviderName(): string;
    healthCheck(): Promise<boolean>;
}
//# sourceMappingURL=CartrackProvider.d.ts.map