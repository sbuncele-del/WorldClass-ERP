"use strict";
/**
 * GPS Provider Interface
 * Unified abstraction for multiple GPS tracking providers
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=IGPSProvider.js.map