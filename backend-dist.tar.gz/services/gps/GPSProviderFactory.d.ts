/**
 * GPS Provider Factory
 * Manages multiple GPS providers and routes requests
 */
import { IGPSProvider, GPSProviderConfig } from './IGPSProvider';
export declare class GPSProviderFactory {
    private providers;
    private defaultProvider;
    /**
     * Initialize GPS providers from configuration
     */
    initialize(configs: GPSProviderConfig[]): void;
    /**
     * Get a specific provider
     */
    getProvider(providerName: string): IGPSProvider | null;
    /**
     * Get default provider (first enabled provider)
     */
    getDefaultProvider(): IGPSProvider | null;
    /**
     * Get all enabled providers
     */
    getAllProviders(): IGPSProvider[];
    /**
     * Check if any GPS provider is available
     */
    hasProviders(): boolean;
    /**
     * Get provider for a specific vehicle
     * This allows different vehicles to use different providers
     */
    getProviderForVehicle(vehicleId: string): IGPSProvider | null;
    /**
     * Health check all providers
     */
    healthCheckAll(): Promise<Map<string, boolean>>;
}
export declare const gpsProviderFactory: GPSProviderFactory;
//# sourceMappingURL=GPSProviderFactory.d.ts.map