"use strict";
/**
 * GPS Provider Factory
 * Manages multiple GPS providers and routes requests
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.gpsProviderFactory = exports.GPSProviderFactory = void 0;
const CartrackProvider_1 = require("./CartrackProvider");
// Future imports:
// import { MixTelematicsProvider } from './MixTelematicsProvider';
// import { CtrackProvider } from './CtrackProvider';
class GPSProviderFactory {
    constructor() {
        this.providers = new Map();
        this.defaultProvider = null;
    }
    /**
     * Initialize GPS providers from configuration
     */
    initialize(configs) {
        for (const config of configs) {
            if (!config.enabled) {
                continue;
            }
            let provider = null;
            switch (config.provider) {
                case 'cartrack':
                    provider = new CartrackProvider_1.CartrackProvider(config);
                    break;
                // Future providers:
                // case 'mix':
                //   provider = new MixTelematicsProvider(config);
                //   break;
                // case 'ctrack':
                //   provider = new CtrackProvider(config);
                //   break;
                default:
                    console.warn(`Unknown GPS provider: ${config.provider}`);
                    continue;
            }
            if (provider) {
                this.providers.set(config.provider, provider);
                console.log(`✅ GPS Provider initialized: ${provider.getProviderName()}`);
                // Set first provider as default
                if (!this.defaultProvider) {
                    this.defaultProvider = config.provider;
                }
            }
        }
        if (this.providers.size === 0) {
            console.warn('⚠️ No GPS providers configured. GPS tracking will not be available.');
        }
    }
    /**
     * Get a specific provider
     */
    getProvider(providerName) {
        return this.providers.get(providerName) || null;
    }
    /**
     * Get default provider (first enabled provider)
     */
    getDefaultProvider() {
        if (!this.defaultProvider) {
            return null;
        }
        return this.providers.get(this.defaultProvider) || null;
    }
    /**
     * Get all enabled providers
     */
    getAllProviders() {
        return Array.from(this.providers.values());
    }
    /**
     * Check if any GPS provider is available
     */
    hasProviders() {
        return this.providers.size > 0;
    }
    /**
     * Get provider for a specific vehicle
     * This allows different vehicles to use different providers
     */
    getProviderForVehicle(vehicleId) {
        // TODO: Implement vehicle-to-provider mapping from database
        // For now, return default provider
        return this.getDefaultProvider();
    }
    /**
     * Health check all providers
     */
    async healthCheckAll() {
        const results = new Map();
        for (const [name, provider] of this.providers.entries()) {
            const isHealthy = await provider.healthCheck();
            results.set(name, isHealthy);
        }
        return results;
    }
}
exports.GPSProviderFactory = GPSProviderFactory;
// Singleton instance
exports.gpsProviderFactory = new GPSProviderFactory();
//# sourceMappingURL=GPSProviderFactory.js.map