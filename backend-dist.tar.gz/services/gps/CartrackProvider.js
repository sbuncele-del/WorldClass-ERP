"use strict";
/**
 * Cartrack GPS Provider Implementation
 * Documentation: https://www.cartrack.com/za/developers
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CartrackProvider = void 0;
const axios_1 = __importDefault(require("axios"));
const crypto_1 = __importDefault(require("crypto"));
class CartrackProvider {
    constructor(config) {
        this.config = config;
        this.client = axios_1.default.create({
            baseURL: config.baseUrl || 'https://api.cartrack.com/rest',
            timeout: 10000,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${config.apiKey}`,
            },
        });
    }
    async getVehiclePosition(vehicleId) {
        try {
            // Cartrack API: GET /vehicles/{vehicleId}/position
            const response = await this.client.get(`/vehicles/${vehicleId}/position`);
            if (!response.data) {
                return null;
            }
            return this.parsePosition(response.data);
        }
        catch (error) {
            console.error(`Cartrack: Failed to get position for vehicle ${vehicleId}:`, error.message);
            return null;
        }
    }
    async getFleetPositions() {
        try {
            // Cartrack API: GET /vehicles/positions
            const response = await this.client.get('/vehicles/positions', {
                params: {
                    customerId: this.config.customerId,
                },
            });
            if (!response.data || !Array.isArray(response.data.vehicles)) {
                return [];
            }
            return response.data.vehicles
                .map((vehicle) => this.parsePosition(vehicle))
                .filter((pos) => pos !== null);
        }
        catch (error) {
            console.error('Cartrack: Failed to get fleet positions:', error.message);
            return [];
        }
    }
    async getTripHistory(query) {
        try {
            // Cartrack API: GET /vehicles/{vehicleId}/history
            const response = await this.client.get(`/vehicles/${query.vehicleId}/history`, {
                params: {
                    startDate: query.startDate.toISOString(),
                    endDate: query.endDate.toISOString(),
                    limit: query.limit || 1000,
                },
            });
            if (!response.data || !Array.isArray(response.data.positions)) {
                return [];
            }
            return response.data.positions
                .map((pos) => this.parsePosition(pos))
                .filter((p) => p !== null);
        }
        catch (error) {
            console.error(`Cartrack: Failed to get trip history for ${query.vehicleId}:`, error.message);
            return [];
        }
    }
    validateWebhook(payload, headers) {
        // Cartrack webhook signature validation
        const signature = headers['x-cartrack-signature'];
        if (!signature || !this.config.webhookSecret) {
            return false;
        }
        const expectedSignature = crypto_1.default
            .createHmac('sha256', this.config.webhookSecret)
            .update(JSON.stringify(payload))
            .digest('hex');
        return crypto_1.default.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature));
    }
    parsePosition(rawData) {
        // Cartrack data format:
        // {
        //   vehicleId: "ABC123GP",
        //   lat: -26.2041,
        //   lon: 28.0473,
        //   speed: 60,
        //   heading: 180,
        //   timestamp: "2025-11-25T10:30:00Z",
        //   ignition: true,
        //   odometer: 123456,
        //   fuelLevel: 75
        // }
        return {
            vehicleId: rawData.vehicleId || rawData.registration || rawData.id,
            latitude: parseFloat(rawData.lat || rawData.latitude),
            longitude: parseFloat(rawData.lon || rawData.longitude),
            speed: parseFloat(rawData.speed || 0),
            heading: parseInt(rawData.heading || rawData.direction || 0),
            timestamp: rawData.timestamp || new Date().toISOString(),
            ignition: rawData.ignition === true || rawData.ignition === 1 || rawData.engineOn === true,
            odometer: parseFloat(rawData.odometer || rawData.mileage || 0),
            fuelLevel: rawData.fuelLevel ? parseFloat(rawData.fuelLevel) : undefined,
            provider: 'cartrack',
            raw: rawData,
        };
    }
    getProviderName() {
        return 'Cartrack';
    }
    async healthCheck() {
        try {
            // Simple ping to check API availability
            const response = await this.client.get('/health');
            return response.status === 200;
        }
        catch (error) {
            console.error('Cartrack: Health check failed:', error);
            return false;
        }
    }
}
exports.CartrackProvider = CartrackProvider;
//# sourceMappingURL=CartrackProvider.js.map