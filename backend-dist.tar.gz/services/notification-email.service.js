"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationEmailService = void 0;
exports.sendPaymentSuccessEmail = sendPaymentSuccessEmail;
exports.sendPaymentFailedEmail = sendPaymentFailedEmail;
exports.sendSubscriptionExpiringEmail = sendSubscriptionExpiringEmail;
exports.sendSubscriptionCancelledEmail = sendSubscriptionCancelledEmail;
exports.sendTeamInvitationEmail = sendTeamInvitationEmail;
exports.sendSecurityAlertEmail = sendSecurityAlertEmail;
exports.sendMaintenanceNotificationEmail = sendMaintenanceNotificationEmail;
exports.sendDataExportReadyEmail = sendDataExportReadyEmail;
exports.sendLowStockAlertEmail = sendLowStockAlertEmail;
const database_1 = require("../config/database");
const email_service_1 = require("./email.service");
/**
 * Send payment success notification
 */
async function sendPaymentSuccessEmail(email, userId, paymentDetails) {
    try {
        // Fetch user details
        const userResult = await database_1.pool.query(`SELECT first_name, last_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0) {
            console.error('User not found for payment success email:', userId);
            return;
        }
        const user = userResult.rows[0];
        const userName = user.first_name;
        // Send payment success email
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: `Payment Received - ${paymentDetails.planName}`,
            template: 'payment-success',
            variables: {
                userName,
                amount: paymentDetails.amount.toFixed(2),
                currency: paymentDetails.currency.toUpperCase(),
                planName: paymentDetails.planName,
                invoiceNumber: paymentDetails.invoiceNumber,
                paymentDate: paymentDetails.paymentDate,
                dashboardUrl: `${process.env.FRONTEND_URL}/billing`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Payment success email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send payment success email:', error);
        // Don't throw - email failure shouldn't block payment processing
    }
}
/**
 * Send payment failed notification
 */
async function sendPaymentFailedEmail(email, userId, failureDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: 'Payment Failed - Action Required',
            template: 'payment-failed',
            variables: {
                userName,
                amount: failureDetails.amount.toFixed(2),
                currency: failureDetails.currency.toUpperCase(),
                planName: failureDetails.planName,
                reason: failureDetails.reason,
                attemptDate: failureDetails.attemptDate,
                updatePaymentUrl: `${process.env.FRONTEND_URL}/billing/payment-methods`,
                supportUrl: `${process.env.FRONTEND_URL}/help`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Payment failed email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send payment failed email:', error);
    }
}
/**
 * Send subscription expiring soon notification
 */
async function sendSubscriptionExpiringEmail(email, userId, expiryDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: `Your ${expiryDetails.planName} Plan Expires in ${expiryDetails.daysRemaining} Days`,
            template: 'subscription-expiring',
            variables: {
                userName,
                planName: expiryDetails.planName,
                expiryDate: expiryDetails.expiryDate,
                daysRemaining: expiryDetails.daysRemaining.toString(),
                renewUrl: `${process.env.FRONTEND_URL}/billing`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Subscription expiring email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send subscription expiring email:', error);
    }
}
/**
 * Send subscription cancelled notification
 */
async function sendSubscriptionCancelledEmail(email, userId, cancellationDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: 'Subscription Cancelled',
            template: 'subscription-cancelled',
            variables: {
                userName,
                planName: cancellationDetails.planName,
                cancellationDate: cancellationDetails.cancellationDate,
                accessUntil: cancellationDetails.accessUntil,
                reason: cancellationDetails.reason || 'User requested',
                reactivateUrl: `${process.env.FRONTEND_URL}/billing`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Subscription cancelled email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send subscription cancelled email:', error);
    }
}
/**
 * Send team member invitation
 */
async function sendTeamInvitationEmail(email, inviterName, companyName, role, invitationToken) {
    try {
        const inviteUrl = `${process.env.FRONTEND_URL}/accept-invitation?token=${invitationToken}`;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: `You've been invited to join ${companyName} on Worldclass ERP`,
            template: 'team-invitation',
            variables: {
                inviterName,
                companyName,
                role,
                inviteUrl,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Team invitation email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send team invitation email:', error);
    }
}
/**
 * Send security alert notification
 */
async function sendSecurityAlertEmail(email, userId, alertDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: `Security Alert: ${alertDetails.alertType}`,
            template: 'security-alert',
            variables: {
                userName,
                alertType: alertDetails.alertType,
                description: alertDetails.description,
                timestamp: alertDetails.timestamp,
                ipAddress: alertDetails.ipAddress,
                location: alertDetails.location || 'Unknown',
                securityUrl: `${process.env.FRONTEND_URL}/settings/security`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Security alert email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send security alert email:', error);
    }
}
/**
 * Send system maintenance notification
 */
async function sendMaintenanceNotificationEmail(email, userId, maintenanceDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: 'Scheduled Maintenance Notification',
            template: 'maintenance-notification',
            variables: {
                userName,
                startTime: maintenanceDetails.startTime,
                endTime: maintenanceDetails.endTime,
                duration: maintenanceDetails.duration,
                affectedServices: maintenanceDetails.affectedServices.join(', '),
                reason: maintenanceDetails.reason,
                statusUrl: `${process.env.FRONTEND_URL}/status`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Maintenance notification email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send maintenance notification email:', error);
    }
}
/**
 * Send data export ready notification
 */
async function sendDataExportReadyEmail(email, userId, exportDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: 'Your Data Export is Ready',
            template: 'data-export-ready',
            variables: {
                userName,
                exportType: exportDetails.exportType,
                fileName: exportDetails.fileName,
                fileSize: exportDetails.fileSize,
                downloadUrl: exportDetails.downloadUrl,
                expiresIn: exportDetails.expiresIn,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Data export ready email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send data export ready email:', error);
    }
}
/**
 * Send low stock alert
 */
async function sendLowStockAlertEmail(email, userId, stockDetails) {
    try {
        const userResult = await database_1.pool.query(`SELECT first_name FROM users WHERE id = $1`, [userId]);
        if (userResult.rows.length === 0)
            return;
        const userName = userResult.rows[0].first_name;
        await (0, email_service_1.sendEmail)({
            to: email,
            subject: `Low Stock Alert: ${stockDetails.productName}`,
            template: 'low-stock-alert',
            variables: {
                userName,
                productName: stockDetails.productName,
                currentStock: stockDetails.currentStock.toString(),
                reorderPoint: stockDetails.reorderPoint.toString(),
                sku: stockDetails.sku,
                inventoryUrl: `${process.env.FRONTEND_URL}/inventory`,
                frontendUrl: process.env.FRONTEND_URL || 'http://localhost:5173',
            },
        });
        console.log('✅ Low stock alert email sent to:', email);
    }
    catch (error) {
        console.error('❌ Failed to send low stock alert email:', error);
    }
}
exports.NotificationEmailService = {
    sendPaymentSuccessEmail,
    sendPaymentFailedEmail,
    sendSubscriptionExpiringEmail,
    sendSubscriptionCancelledEmail,
    sendTeamInvitationEmail,
    sendSecurityAlertEmail,
    sendMaintenanceNotificationEmail,
    sendDataExportReadyEmail,
    sendLowStockAlertEmail,
};
exports.default = exports.NotificationEmailService;
//# sourceMappingURL=notification-email.service.js.map