/**
 * AI Learning System for SiyaBusa ERP
 *
 * This service handles:
 * 1. Storing conversation history for learning
 * 2. Tracking which responses were helpful
 * 3. Building FAQ from common questions
 * 4. Continuous improvement through feedback
 */
export interface ConversationEntry {
    id?: number;
    tenant_id: string;
    user_id: string;
    session_id: string;
    user_message: string;
    ai_response: string;
    was_helpful?: boolean;
    feedback?: string;
    topic_category?: string;
    action_taken?: string;
    created_at?: Date;
}
export interface LearnedPattern {
    id?: number;
    tenant_id: string;
    pattern: string;
    response_template: string;
    category: string;
    confidence_score: number;
    usage_count: number;
    success_rate: number;
    created_at?: Date;
    updated_at?: Date;
}
export interface FAQ {
    id?: number;
    tenant_id: string;
    question: string;
    answer: string;
    category: string;
    helpful_count: number;
    total_count: number;
    is_featured: boolean;
    created_at?: Date;
    updated_at?: Date;
}
/**
 * Database migrations for AI learning tables
 */
export declare const AI_LEARNING_MIGRATIONS = "\n-- Conversation history for learning\nCREATE TABLE IF NOT EXISTS ai_conversations (\n  id SERIAL PRIMARY KEY,\n  tenant_id VARCHAR(100) NOT NULL,\n  user_id VARCHAR(100) NOT NULL,\n  session_id VARCHAR(100) NOT NULL,\n  user_message TEXT NOT NULL,\n  ai_response TEXT NOT NULL,\n  was_helpful BOOLEAN,\n  feedback TEXT,\n  topic_category VARCHAR(100),\n  action_taken VARCHAR(200),\n  response_time_ms INTEGER,\n  tokens_used INTEGER,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\n-- Index for quick lookups\nCREATE INDEX IF NOT EXISTS idx_ai_conversations_tenant ON ai_conversations(tenant_id);\nCREATE INDEX IF NOT EXISTS idx_ai_conversations_session ON ai_conversations(session_id);\nCREATE INDEX IF NOT EXISTS idx_ai_conversations_category ON ai_conversations(topic_category);\n\n-- Learned patterns from successful interactions\nCREATE TABLE IF NOT EXISTS ai_learned_patterns (\n  id SERIAL PRIMARY KEY,\n  tenant_id VARCHAR(100) NOT NULL,\n  pattern TEXT NOT NULL,\n  response_template TEXT NOT NULL,\n  category VARCHAR(100),\n  confidence_score DECIMAL(5,4) DEFAULT 0.5,\n  usage_count INTEGER DEFAULT 0,\n  success_rate DECIMAL(5,4) DEFAULT 0.5,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\nCREATE INDEX IF NOT EXISTS idx_ai_patterns_tenant ON ai_learned_patterns(tenant_id);\nCREATE INDEX IF NOT EXISTS idx_ai_patterns_confidence ON ai_learned_patterns(confidence_score DESC);\n\n-- FAQ generated from common questions\nCREATE TABLE IF NOT EXISTS ai_faq (\n  id SERIAL PRIMARY KEY,\n  tenant_id VARCHAR(100),\n  question TEXT NOT NULL,\n  answer TEXT NOT NULL,\n  category VARCHAR(100),\n  helpful_count INTEGER DEFAULT 0,\n  total_count INTEGER DEFAULT 0,\n  is_featured BOOLEAN DEFAULT false,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);\n\nCREATE INDEX IF NOT EXISTS idx_ai_faq_tenant ON ai_faq(tenant_id);\nCREATE INDEX IF NOT EXISTS idx_ai_faq_featured ON ai_faq(is_featured);\n\n-- User preferences for AI\nCREATE TABLE IF NOT EXISTS ai_user_preferences (\n  id SERIAL PRIMARY KEY,\n  tenant_id VARCHAR(100) NOT NULL,\n  user_id VARCHAR(100) NOT NULL,\n  preferred_response_style VARCHAR(50) DEFAULT 'detailed',\n  preferred_language VARCHAR(10) DEFAULT 'en',\n  common_topics TEXT[],\n  last_context JSONB,\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,\n  UNIQUE(tenant_id, user_id)\n);\n";
export declare class AILearningService {
    private pool;
    constructor();
    /**
     * Initialize database tables
     */
    initializeTables(): Promise<void>;
    /**
     * Store a conversation for learning
     */
    storeConversation(entry: ConversationEntry): Promise<number | null>;
    /**
     * Record feedback on a conversation
     */
    recordFeedback(conversationId: number, wasHelpful: boolean, feedback?: string): Promise<boolean>;
    /**
     * Attempt to learn a pattern from a helpful conversation
     */
    private potentiallyLearnPattern;
    /**
     * Extract keywords from a message
     */
    private extractKeywords;
    /**
     * Create a generalized pattern from a message
     */
    private createPatternFromMessage;
    /**
     * Find matching learned patterns
     */
    findMatchingPatterns(tenantId: string, message: string, limit?: number): Promise<LearnedPattern[]>;
    /**
     * Get frequently asked questions for a tenant
     */
    getFAQs(tenantId: string, category?: string): Promise<FAQ[]>;
    /**
     * Add or update an FAQ
     */
    upsertFAQ(faq: FAQ): Promise<void>;
    /**
     * Get recent conversation context for a user
     */
    getRecentContext(tenantId: string, userId: string, limit?: number): Promise<ConversationEntry[]>;
    /**
     * Get conversation analytics
     */
    getAnalytics(tenantId: string): Promise<{
        totalConversations: number;
        helpfulRate: number;
        topCategories: {
            category: string;
            count: number;
        }[];
        commonQuestions: string[];
    }>;
    /**
     * Generate FAQ from conversation history
     */
    generateFAQsFromHistory(tenantId: string): Promise<void>;
    /**
     * Get user preferences
     */
    getUserPreferences(tenantId: string, userId: string): Promise<any>;
    /**
     * Update user preferences
     */
    updateUserPreferences(tenantId: string, userId: string, preferences: Partial<{
        preferred_response_style: string;
        preferred_language: string;
        common_topics: string[];
        last_context: any;
    }>): Promise<void>;
}
export declare function getAILearningService(): AILearningService;
export default AILearningService;
//# sourceMappingURL=AILearningService.d.ts.map