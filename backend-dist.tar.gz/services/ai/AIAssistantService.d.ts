/**
 * SiyaBusa ERP AI Assistant Service
 *
 * THE SMARTEST THING EVER - Your first point of contact before asking a human.
 *
 * Converts natural language into accounting and business operations.
 * This is the core differentiator - making ERP accessible to business owners.
 *
 * Features:
 * - Complete ERP knowledge base - knows every module, feature, and workflow
 * - Machine learning - improves from every conversation
 * - Context-aware - remembers your preferences and history
 * - South African compliance aware - VAT, SARS, PAYE, POPIA
 *
 * Model: OpenAI GPT-4o-mini (best balance of cost/quality for structured tasks)
 * Estimated cost: ~R0.50-2 per customer per month at typical usage
 */
import { EventEmitter } from 'events';
export interface AIMessage {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
    action?: AIAction;
    confirmationRequired?: boolean;
    tokenUsage?: {
        prompt: number;
        completion: number;
        total: number;
        estimatedCost: number;
    };
}
export interface AIAction {
    type: AIActionType;
    status: 'pending' | 'confirmed' | 'executed' | 'cancelled';
    data: Record<string, any>;
    description: string;
    requiresConfirmation: boolean;
    validations?: AIValidation[];
}
export interface AIValidation {
    field: string;
    status: 'pass' | 'warning' | 'fail';
    message: string;
    value?: any;
}
export type AIActionType = 'create_invoice' | 'create_quote' | 'create_purchase_order' | 'record_payment' | 'process_refund' | 'check_inventory' | 'check_customer_balance' | 'create_journal_entry' | 'run_report' | 'create_expense' | 'process_payroll' | 'update_stock' | 'create_customer' | 'create_supplier' | 'schedule_delivery' | 'general_query' | 'unknown';
export interface ConversationContext {
    tenantId: string;
    userId: string;
    sessionId: string;
    messages: AIMessage[];
    currentAction?: AIAction;
}
export interface AIAssistantConfig {
    openaiApiKey: string;
    model?: string;
    maxTokens?: number;
    temperature?: number;
}
export declare class AIAssistantService extends EventEmitter {
    private openai;
    private model;
    private maxTokens;
    private temperature;
    private dataService;
    private conversations;
    private learningService;
    constructor(config: AIAssistantConfig);
    /**
     * Process a user message and return AI response with actions
     */
    processMessage(message: string, context: {
        tenantId: string;
        userId: string;
        sessionId: string;
    }): Promise<AIMessage>;
    /**
     * Categorize the question for learning and analytics
     */
    private categorizeQuestion;
    /**
     * Record user feedback on a response
     */
    recordFeedback(conversationId: number, wasHelpful: boolean, feedback?: string): Promise<boolean>;
    /**
     * Get FAQs for display
     */
    getFAQs(tenantId: string, category?: string): Promise<import("./AILearningService").FAQ[]>;
    /**
     * Get AI analytics for admin dashboard
     */
    getAnalytics(tenantId: string): Promise<{
        totalConversations: number;
        helpfulRate: number;
        topCategories: {
            category: string;
            count: number;
        }[];
        commonQuestions: string[];
    }>;
    /**
     * Confirm and execute a pending action
     */
    confirmAction(sessionId: string): Promise<AIMessage>;
    /**
     * Cancel a pending action
     */
    cancelAction(sessionId: string): Promise<AIMessage>;
    /**
     * Enrich context with relevant data based on message content
     */
    private enrichContext;
    /**
     * Execute a confirmed action
     */
    private executeAction;
    /**
     * Get conversation history
     */
    getConversation(sessionId: string): ConversationContext | undefined;
    /**
     * Clear conversation history
     */
    clearConversation(sessionId: string): void;
    /**
     * Get total token usage for a session (for billing)
     */
    getSessionTokenUsage(sessionId: string): {
        tokens: number;
        estimatedCostUSD: number;
    };
}
export declare function createAIAssistant(apiKey?: string): AIAssistantService;
export default AIAssistantService;
//# sourceMappingURL=AIAssistantService.d.ts.map