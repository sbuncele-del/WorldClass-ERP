/**
 * SiyaBusa ERP Knowledge Base
 *
 * Comprehensive knowledge about the ERP system for the AI Assistant.
 * This makes the AI truly understand the system and help users effectively.
 */
export interface ModuleKnowledge {
    name: string;
    description: string;
    capabilities: string[];
    commonQuestions: {
        question: string;
        answer: string;
    }[];
    navigation: string;
    relatedModules: string[];
}
export interface ERPKnowledge {
    systemOverview: string;
    modules: Record<string, ModuleKnowledge>;
    glossary: Record<string, string>;
    workflows: Record<string, string[]>;
    compliance: Record<string, string>;
    troubleshooting: Record<string, string>;
}
export declare const ERP_KNOWLEDGE: ERPKnowledge;
/**
 * Get knowledge for a specific module
 */
export declare function getModuleKnowledge(moduleName: string): ModuleKnowledge | undefined;
/**
 * Search knowledge base for relevant information
 */
export declare function searchKnowledge(query: string): {
    category: string;
    content: string;
}[];
/**
 * Generate context for AI about the ERP system
 */
export declare function generateERPContext(): string;
export default ERP_KNOWLEDGE;
//# sourceMappingURL=ERPKnowledgeBase.d.ts.map