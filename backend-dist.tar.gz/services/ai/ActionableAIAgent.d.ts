/**
 * Actionable AI Agent Service
 *
 * This is a TRUE AI AGENT that can:
 * 1. Understand natural language requests
 * 2. Ask clarifying questions when needed
 * 3. Execute real business actions (create invoices, record expenses, etc.)
 * 4. Maintain conversation context
 *
 * NOT just a chatbot - an actual business automation agent.
 */
export interface AgentMessage {
    id: string;
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
    actionRequired?: AgentAction;
    questionsNeeded?: ClarifyingQuestion[];
    executionResult?: ExecutionResult;
}
export interface AgentAction {
    type: AgentActionType;
    status: 'collecting_info' | 'ready_to_execute' | 'executing' | 'completed' | 'failed' | 'cancelled';
    data: Record<string, any>;
    missingFields: string[];
    description: string;
}
export type AgentActionType = 'create_invoice' | 'create_quote' | 'record_expense' | 'record_payment' | 'create_journal_entry' | 'send_email' | 'create_customer' | 'create_supplier' | 'check_balance' | 'generate_report' | 'schedule_payment' | 'create_purchase_order';
export interface ClarifyingQuestion {
    field: string;
    question: string;
    type: 'text' | 'number' | 'date' | 'select' | 'boolean';
    options?: string[];
    required: boolean;
    validation?: string;
}
export interface ExecutionResult {
    success: boolean;
    message: string;
    data?: Record<string, any>;
    referenceNumber?: string;
    nextSteps?: string[];
}
export interface ConversationContext {
    sessionId: string;
    tenantId: string;
    userId: string;
    currentAction?: AgentAction;
    collectedData: Record<string, any>;
    messageHistory: AgentMessage[];
}
declare class ActionableAIAgent {
    private openai;
    private conversations;
    constructor();
    /**
     * Main entry point - process user message
     */
    processMessage(sessionId: string, tenantId: string, userId: string, userMessage: string): Promise<AgentMessage>;
    /**
     * Detect user intent using AI or pattern matching
     */
    private detectIntent;
    /**
     * Start a new action
     */
    private startAction;
    /**
     * Handle info collection responses
     */
    private handleInfoCollection;
    /**
     * Ask for confirmation before executing
     */
    private askForConfirmation;
    /**
     * Execute the action
     */
    private executeAction;
    /**
     * Cancel the current action
     */
    private cancelAction;
    /**
     * Handle general queries (not actions)
     */
    private handleGeneralQuery;
    /**
     * Actually perform the action in the database
     */
    private performAction;
    private getActionDescription;
    private buildQuestionMessage;
    private buildConfirmationSummary;
    private getFallbackResponse;
    /**
     * Get conversation history
     */
    getConversation(sessionId: string): ConversationContext | undefined;
    /**
     * Clear conversation
     */
    clearConversation(sessionId: string): void;
}
export declare const actionableAIAgent: ActionableAIAgent;
export default actionableAIAgent;
//# sourceMappingURL=ActionableAIAgent.d.ts.map