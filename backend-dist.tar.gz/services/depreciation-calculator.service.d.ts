/**
 * Depreciation Calculation Service
 * Implements 3 depreciation methods: Straight Line, Reducing Balance, Units of Production
 */
import { DepreciationMethod, DepreciationCalculationParams, DepreciationCalculationResult } from '../models/asset-management.model';
export declare class DepreciationCalculator {
    /**
     * Calculate depreciation for a given period using the specified method
     */
    static calculateDepreciation(method: DepreciationMethod, params: DepreciationCalculationParams): DepreciationCalculationResult;
    /**
     * Straight Line Depreciation
     * Formula: (Cost - Residual Value) / Useful Life
     * Equal depreciation each period
     */
    private static calculateStraightLine;
    /**
     * Reducing Balance (Declining Balance) Depreciation
     * Formula: Book Value × Depreciation Rate
     * Accelerated depreciation - more in early years
     */
    private static calculateReducingBalance;
    /**
     * Units of Production Depreciation
     * Formula: (Cost - Residual) × (Units This Period / Total Expected Units)
     * Depreciation based on usage
     */
    private static calculateUnitsOfProduction;
    /**
     * Generate depreciation schedule for entire life of asset
     * Returns array of monthly depreciation entries
     */
    static generateFullSchedule(method: DepreciationMethod, acquisition_cost: number, residual_value: number, useful_life_years: number, depreciation_rate?: number, useful_life_units?: number): Array<{
        period_number: number;
        opening_balance: number;
        depreciation: number;
        accumulated_depreciation: number;
        closing_balance: number;
    }>;
    /**
     * Calculate remaining useful life based on current depreciation
     */
    static calculateRemainingLife(method: DepreciationMethod, acquisition_cost: number, residual_value: number, accumulated_depreciation: number, useful_life_years?: number, depreciation_rate?: number): number;
}
//# sourceMappingURL=depreciation-calculator.service.d.ts.map