interface SubscriptionDetails {
    tenantId: string;
    plan: string;
    status: string;
    billingCycle: string;
    amount: number;
    currency: string;
    startDate: Date;
    endDate: Date;
    nextBillingDate?: Date;
    paymentGateway: string;
    autoRenew: boolean;
    cancelAtPeriodEnd: boolean;
    features: {
        maxUsers: number;
        maxStorageGb: number;
        [key: string]: any;
    };
}
export declare class SubscriptionService {
    /**
     * Get plan limits based on subscription tier
     */
    private static getPlanLimits;
    /**
     * Get current subscription details for a tenant
     */
    static getCurrentSubscription(tenantId: string): Promise<SubscriptionDetails | null>;
    /**
     * Upgrade subscription to a higher tier (immediate)
     */
    static upgradePlan(tenantId: string, newPlan: 'starter' | 'professional' | 'enterprise', billingCycle?: 'monthly' | 'annual'): Promise<{
        success: boolean;
        message: string;
        prorationAmount?: number;
    }>;
    /**
     * Downgrade subscription (takes effect at end of billing period)
     */
    static downgradePlan(tenantId: string, newPlan: 'starter' | 'professional'): Promise<{
        success: boolean;
        message: string;
        effectiveDate?: Date;
    }>;
    /**
     * Cancel subscription (takes effect at end of billing period)
     */
    static cancelSubscription(tenantId: string, reason?: string): Promise<{
        success: boolean;
        message: string;
        effectiveDate?: Date;
    }>;
    /**
     * Reactivate a cancelled subscription
     */
    static reactivateSubscription(tenantId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Update payment method (switch between Ozow and Stripe)
     */
    static updatePaymentMethod(tenantId: string, newGateway: 'ozow' | 'stripe'): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Check subscription status and handle expirations
     */
    static checkSubscriptionStatus(tenantId: string): Promise<{
        isActive: boolean;
        status: string;
        daysRemaining: number;
        needsRenewal: boolean;
    }>;
    /**
     * Update tenant feature limits based on plan
     */
    static updateTenantLimits(tenantId: string, plan: string): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Get tenant country for gateway selection
     */
    private static getTenantCountry;
    /**
     * Get usage statistics for a tenant
     */
    static getUsageStatistics(tenantId: string): Promise<{
        currentUsers: number;
        maxUsers: number;
        storageUsedGb: number;
        maxStorageGb: number;
        usersPercentage: number;
        storagePercentage: number;
    }>;
}
export default SubscriptionService;
//# sourceMappingURL=subscription.service.d.ts.map