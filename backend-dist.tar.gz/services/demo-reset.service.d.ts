declare class DemoResetService {
    private resetInProgress;
    private lastResetTime;
    private resetCount;
    /**
     * Initialize cron job to reset demo tenant daily at 2:00 AM
     */
    initializeCronJob(): void;
    /**
     * Manually trigger demo tenant reset (for testing or emergency)
     */
    resetDemoTenant(): Promise<{
        success: boolean;
        message: string;
        timestamp: Date;
    }>;
    /**
     * Clear all transactional data created after initial setup
     * Preserves: Chart of accounts, tax rates, payment terms, financial periods
     * Deletes: Journal entries, invoices, purchase orders, inventory transactions, etc.
     */
    private clearTransactionalData;
    /**
     * Reset document numbering sequences to start fresh
     */
    private resetDocumentSequences;
    /**
     * Restore demo user credentials
     * Preserves email and password so demo users can always log in
     */
    private restoreDemoUser;
    /**
     * Reprovision demo tenant with fresh sample data
     */
    private reprovisionDemoTenant;
    /**
     * Log reset event in audit trail
     */
    private logReset;
    /**
     * Get reset statistics
     */
    getResetStats(): {
        lastResetTime: Date | null;
        resetCount: number;
        resetInProgress: boolean;
    };
    /**
     * Check if demo tenant needs reset (for manual trigger)
     * Returns true if last reset was more than 24 hours ago
     */
    needsReset(): boolean;
}
declare const _default: DemoResetService;
export default _default;
//# sourceMappingURL=demo-reset.service.d.ts.map