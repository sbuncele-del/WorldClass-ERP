/**
 * AI Agent Service
 * Core service for AI-powered assistants
 */
interface Message {
    role: 'system' | 'user' | 'assistant';
    content: string;
}
interface AgentConfig {
    agent_id: string;
    agent_code: string;
    agent_name: string;
    module_name: string;
    system_prompt: string;
    capabilities: string[];
    model_name: string;
    temperature: number;
    max_tokens: number;
}
declare class AIAgentService {
    private openaiClient;
    private anthropicClient;
    constructor();
    /**
     * Get AI agent configuration
     */
    getAgent(agentCode: string): Promise<AgentConfig | null>;
    /**
     * Create or get conversation
     */
    getOrCreateConversation(tenantId: string, userId: string, agentCode: string, contextData?: any): Promise<string>;
    /**
     * Get conversation history
     */
    getConversationHistory(conversationId: string, limit?: number): Promise<Message[]>;
    /**
     * Save message to conversation
     */
    saveMessage(conversationId: string, role: 'user' | 'assistant' | 'system', content: string, tokensUsed?: number, functionCalls?: any): Promise<void>;
    /**
     * Chat with agent using OpenAI
     */
    chatWithAgent(agentCode: string, tenantId: string, userId: string, userMessage: string, contextData?: any): Promise<{
        response: string;
        conversationId: string;
    }>;
    /**
     * Stream chat response (for real-time UX)
     */
    streamChatWithAgent(agentCode: string, tenantId: string, userId: string, userMessage: string, contextData?: any): AsyncGenerator<string, void, unknown>;
    /**
     * Generate proactive suggestion
     */
    generateSuggestion(tenantId: string, agentCode: string, userId: string | null, suggestionType: string, title: string, description: string, actionUrl?: string, priority?: string): Promise<string>;
    /**
     * Get pending suggestions for user
     */
    getUserSuggestions(tenantId: string, userId: string): Promise<any[]>;
    /**
     * Update usage analytics
     */
    private updateUsageAnalytics;
    /**
     * Get agent capabilities
     */
    getAgentCapabilities(agentCode: string): Promise<string[]>;
    /**
     * List all available agents
     */
    listAgents(): Promise<AgentConfig[]>;
    /**
     * Archive conversation
     */
    archiveConversation(conversationId: string): Promise<void>;
    /**
     * Get user's conversations
     */
    getUserConversations(tenantId: string, userId: string, includeArchived?: boolean): Promise<any[]>;
}
declare const _default: AIAgentService;
export default _default;
//# sourceMappingURL=ai-agent.service.d.ts.map