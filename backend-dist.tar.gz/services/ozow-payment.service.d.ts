interface OzowPaymentRequest {
    tenantId: string;
    userId: string;
    amount: number;
    plan: string;
    billingCycle: 'monthly' | 'annual';
    customerEmail: string;
    customerName: string;
}
interface OzowPaymentResponse {
    url: string;
    transactionReference: string;
}
interface OzowNotification {
    SiteCode: string;
    TransactionId: string;
    TransactionReference: string;
    Amount: string;
    Status: string;
    StatusMessage: string;
    CurrencyCode: string;
    IsTest: string;
    Hash: string;
}
export declare class OzowPaymentService {
    /**
     * Generate Ozow payment request URL
     */
    static createPaymentRequest(data: OzowPaymentRequest): Promise<OzowPaymentResponse>;
    /**
     * Handle Ozow payment notification (webhook)
     */
    static handleNotification(notification: OzowNotification): Promise<void>;
    /**
     * Verify Ozow notification hash
     */
    private static verifyNotificationHash;
    /**
     * Activate subscription after successful payment
     */
    private static activateSubscription;
    /**
     * Generate unique transaction reference
     */
    private static generateTransactionReference;
    /**
     * Get payment status
     */
    static getPaymentStatus(transactionReference: string): Promise<any>;
    /**
     * Get tenant payment history
     */
    static getPaymentHistory(tenantId: string): Promise<any[]>;
    /**
     * Cancel pending payment
     */
    static cancelPayment(transactionReference: string, tenantId: string): Promise<void>;
    /**
     * Check if Ozow is configured
     */
    static isConfigured(): boolean;
    /**
     * Get pricing for plan
     */
    static getPlanPricing(plan: string, billingCycle: string): number;
}
export default OzowPaymentService;
//# sourceMappingURL=ozow-payment.service.d.ts.map