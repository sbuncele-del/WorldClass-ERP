"use strict";
/**
 * Production Email Service
 * Supports: Amazon SES, SendGrid, Generic SMTP
 * Features: Retry logic, console fallback, rate limiting
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.emailService = void 0;
const nodemailer_1 = __importDefault(require("nodemailer"));
const client_ses_1 = require("@aws-sdk/client-ses");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
// Configuration
const EMAIL_PROVIDER = process.env.EMAIL_PROVIDER || 'smtp';
const MAX_RETRIES = 3;
const RETRY_DELAY_MS = 1000;
class ProductionEmailService {
    constructor() {
        this.transporter = null;
        this.sesClient = null;
        this.initialized = false;
        this.provider = this.detectProvider();
        this.initialize();
    }
    detectProvider() {
        // Auto-detect based on available credentials
        if (process.env.SENDGRID_API_KEY)
            return 'sendgrid';
        if (process.env.AWS_SES_ACCESS_KEY_ID || process.env.AWS_ACCESS_KEY_ID)
            return 'ses';
        if (process.env.SMTP_USER && process.env.SMTP_PASS)
            return 'smtp';
        return 'console'; // Fallback to console logging
    }
    initialize() {
        try {
            switch (this.provider) {
                case 'ses':
                    this.initializeSES();
                    break;
                case 'sendgrid':
                    this.initializeSendGrid();
                    break;
                case 'smtp':
                    this.initializeSMTP();
                    break;
                default:
                    console.log('📧 Email provider: Console (emails will be logged, not sent)');
            }
            this.initialized = true;
        }
        catch (error) {
            console.error('❌ Failed to initialize email service:', error);
            this.provider = 'console';
        }
    }
    initializeSES() {
        this.sesClient = new client_ses_1.SESClient({
            region: process.env.AWS_SES_REGION || process.env.AWS_REGION || 'eu-north-1',
            credentials: process.env.AWS_SES_ACCESS_KEY_ID ? {
                accessKeyId: process.env.AWS_SES_ACCESS_KEY_ID,
                secretAccessKey: process.env.AWS_SES_SECRET_ACCESS_KEY,
            } : undefined, // Use IAM role if no explicit credentials
        });
        console.log('✅ Email provider: Amazon SES');
    }
    initializeSendGrid() {
        this.transporter = nodemailer_1.default.createTransport({
            host: 'smtp.sendgrid.net',
            port: 587,
            secure: false,
            auth: {
                user: 'apikey',
                pass: process.env.SENDGRID_API_KEY,
            },
        });
        console.log('✅ Email provider: SendGrid');
    }
    initializeSMTP() {
        this.transporter = nodemailer_1.default.createTransport({
            host: process.env.SMTP_HOST || 'smtp.gmail.com',
            port: parseInt(process.env.SMTP_PORT || '587'),
            secure: process.env.SMTP_SECURE === 'true',
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS,
            },
        });
        // Verify connection
        this.transporter.verify((error) => {
            if (error) {
                console.error('❌ SMTP connection failed:', error.message);
                this.provider = 'console';
            }
            else {
                console.log('✅ Email provider: SMTP (' + process.env.SMTP_HOST + ')');
            }
        });
    }
    async delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
    getFromAddress() {
        const name = process.env.EMAIL_FROM_NAME || 'WorldClass ERP';
        const email = process.env.EMAIL_FROM || process.env.SMTP_USER || 'noreply@aetheros.co.za';
        return `"${name}" <${email}>`;
    }
    /**
     * Send email with retry logic
     */
    async send(options) {
        const { to, subject, html, text, from, replyTo } = options;
        const recipients = Array.isArray(to) ? to : [to];
        for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            try {
                switch (this.provider) {
                    case 'ses':
                        await this.sendViaSES(recipients, subject, html, text, from);
                        break;
                    case 'sendgrid':
                    case 'smtp':
                        await this.sendViaSMTP(recipients, subject, html, text, from, replyTo);
                        break;
                    default:
                        this.logToConsole(recipients, subject, html);
                        return true;
                }
                console.log(`✅ Email sent to ${recipients.join(', ')}: ${subject}`);
                return true;
            }
            catch (error) {
                console.error(`❌ Email attempt ${attempt}/${MAX_RETRIES} failed:`, error.message);
                if (attempt < MAX_RETRIES) {
                    await this.delay(RETRY_DELAY_MS * attempt);
                }
                else {
                    // Final fallback: log to console
                    console.error('📧 FALLBACK: Logging email to console after all retries failed');
                    this.logToConsole(recipients, subject, html);
                    return false;
                }
            }
        }
        return false;
    }
    async sendViaSES(to, subject, html, text, from) {
        if (!this.sesClient)
            throw new Error('SES client not initialized');
        const command = new client_ses_1.SendEmailCommand({
            Source: from || this.getFromAddress(),
            Destination: { ToAddresses: to },
            Message: {
                Subject: { Data: subject, Charset: 'UTF-8' },
                Body: {
                    Html: { Data: html, Charset: 'UTF-8' },
                    Text: { Data: text || this.htmlToText(html), Charset: 'UTF-8' },
                },
            },
        });
        await this.sesClient.send(command);
    }
    async sendViaSMTP(to, subject, html, text, from, replyTo) {
        if (!this.transporter)
            throw new Error('SMTP transporter not initialized');
        await this.transporter.sendMail({
            from: from || this.getFromAddress(),
            to: to.join(', '),
            subject,
            html,
            text: text || this.htmlToText(html),
            replyTo,
        });
    }
    logToConsole(to, subject, html) {
        console.log('\n' + '='.repeat(60));
        console.log('📧 EMAIL (Console Mode)');
        console.log('='.repeat(60));
        console.log(`To: ${to.join(', ')}`);
        console.log(`Subject: ${subject}`);
        console.log('Body (first 500 chars):');
        console.log(this.htmlToText(html).substring(0, 500));
        console.log('='.repeat(60) + '\n');
    }
    htmlToText(html) {
        return html
            .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
            .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }
    /**
     * Load and send templated email
     */
    async sendTemplate(options) {
        const { to, subject, template, variables, from } = options;
        try {
            const html = await this.loadTemplate(template, variables);
            return this.send({ to, subject, html, from });
        }
        catch (error) {
            console.error(`❌ Failed to send template email: ${error.message}`);
            return false;
        }
    }
    async loadTemplate(templateName, variables) {
        const templatePath = path_1.default.join(__dirname, '../templates/email', `${templateName}.html`);
        if (!fs_1.default.existsSync(templatePath)) {
            throw new Error(`Template not found: ${templateName}`);
        }
        let html = fs_1.default.readFileSync(templatePath, 'utf-8');
        // Replace variables
        Object.entries(variables).forEach(([key, value]) => {
            html = html.replace(new RegExp(`{{${key}}}`, 'g'), value);
        });
        return html;
    }
    // ============================================================
    // Convenience Methods for Common Emails
    // ============================================================
    async sendPasswordReset(email, resetUrl, userName) {
        return this.sendTemplate({
            to: email,
            subject: 'Reset Your Password - WorldClass ERP',
            template: 'reset-password',
            variables: {
                userName,
                resetUrl,
                expiryTime: '1 hour',
                companyName: 'WorldClass ERP',
            },
        });
    }
    async sendTripCompleted(email, tripDetails) {
        return this.sendTemplate({
            to: email,
            subject: `Trip ${tripDetails.tripNumber} Completed - WorldClass ERP`,
            template: 'trip-completed',
            variables: {
                tripNumber: tripDetails.tripNumber,
                origin: tripDetails.origin,
                destination: tripDetails.destination,
                driverName: tripDetails.driver,
                completedAt: tripDetails.completedAt,
                dashboardUrl: `${process.env.FRONTEND_URL}/logistics/trips`,
            },
        });
    }
    async sendInvoiceNotification(email, invoiceDetails) {
        return this.sendTemplate({
            to: email,
            subject: `Invoice ${invoiceDetails.invoiceNumber} - WorldClass ERP`,
            template: 'invoice-notification',
            variables: {
                invoiceNumber: invoiceDetails.invoiceNumber,
                amount: invoiceDetails.amount,
                dueDate: invoiceDetails.dueDate,
                customerName: invoiceDetails.customerName,
                viewUrl: `${process.env.FRONTEND_URL}/invoices/${invoiceDetails.invoiceNumber}`,
            },
        });
    }
    /**
     * Health check
     */
    async healthCheck() {
        return {
            status: this.initialized ? 'ok' : 'degraded',
            provider: this.provider,
            message: this.initialized
                ? `Email service ready (${this.provider})`
                : 'Email service running in console mode',
        };
    }
}
// Export singleton instance
exports.emailService = new ProductionEmailService();
exports.default = exports.emailService;
//# sourceMappingURL=email-production.service.js.map