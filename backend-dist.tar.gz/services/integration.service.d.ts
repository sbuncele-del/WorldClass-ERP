/**
 * Integration Service - Business-to-Accounting Bridge
 *
 * This service automates the posting of business transactions to the General Ledger.
 * It creates journal entries from:
 * - Sales Invoices → Revenue & Accounts Receivable
 * - Purchase Bills → Expenses & Accounts Payable
 * - Inventory Movements → Cost of Goods Sold
 * - Payroll Runs → Salary Expenses & Liabilities
 * - Asset Depreciation → Depreciation Expense & Accumulated Depreciation
 *
 * Each posting follows GAAP/IFRS standards and creates a proper audit trail.
 */
export interface PostingResult {
    success: boolean;
    journalEntryId?: string;
    journalNumber?: string;
    message: string;
    details?: any;
}
export interface InvoiceForPosting {
    id: string;
    invoice_number: string;
    customer_id: string;
    customer_name: string;
    invoice_date: string;
    subtotal: number;
    vat_amount: number;
    total_amount: number;
    lines: Array<{
        description: string;
        quantity: number;
        unit_price: number;
        line_total: number;
        vat_rate?: number;
        gl_account_code?: string;
    }>;
}
export interface BillForPosting {
    id: string;
    bill_number: string;
    supplier_id: string;
    supplier_name: string;
    bill_date: string;
    subtotal: number;
    vat_amount: number;
    total_amount: number;
    lines: Array<{
        description: string;
        quantity: number;
        unit_price: number;
        line_total: number;
        vat_rate?: number;
        expense_account_code?: string;
    }>;
}
export interface PayrollForPosting {
    id: string;
    period_name: string;
    pay_date: string;
    total_gross: number;
    total_paye: number;
    total_uif_employee: number;
    total_uif_employer: number;
    total_net: number;
    department_breakdown?: Array<{
        department_id: string;
        department_name: string;
        amount: number;
    }>;
}
export declare class IntegrationService {
    private journalService;
    constructor();
    /**
     * Post a Sales Invoice to the General Ledger
     * Creates: DR Accounts Receivable, CR Revenue, CR VAT Output
     */
    postSalesInvoiceToGL(tenantId: string, invoice: InvoiceForPosting, userId: string): Promise<PostingResult>;
    /**
     * Post a Purchase Bill to the General Ledger
     * Creates: DR Expense/Inventory, DR VAT Input, CR Accounts Payable
     */
    postPurchaseBillToGL(tenantId: string, bill: BillForPosting, userId: string): Promise<PostingResult>;
    /**
     * Post a Payroll Run to the General Ledger
     * Creates: DR Salary Expense, CR PAYE Payable, CR UIF Payable, CR Salaries Payable
     */
    postPayrollToGL(tenantId: string, payroll: PayrollForPosting, userId: string): Promise<PostingResult>;
    /**
     * Post Inventory Movement to GL (for COGS on sales)
     * Creates: DR Cost of Goods Sold, CR Inventory
     */
    postInventoryCOGSToGL(tenantId: string, movementData: {
        id: string;
        movement_date: string;
        item_name: string;
        quantity: number;
        unit_cost: number;
        total_cost: number;
        reference_type: string;
        reference_number: string;
    }, userId: string): Promise<PostingResult>;
    /**
     * Record a payment received against an invoice
     * Creates: DR Bank, CR Accounts Receivable
     */
    postPaymentReceivedToGL(tenantId: string, payment: {
        id: string;
        payment_date: string;
        amount: number;
        invoice_number: string;
        customer_name: string;
        bank_account_code?: string;
        payment_reference: string;
    }, userId: string): Promise<PostingResult>;
    /**
     * Record a payment made to supplier
     * Creates: DR Accounts Payable, CR Bank
     */
    postPaymentMadeToGL(tenantId: string, payment: {
        id: string;
        payment_date: string;
        amount: number;
        bill_number: string;
        supplier_name: string;
        bank_account_code?: string;
        payment_reference: string;
    }, userId: string): Promise<PostingResult>;
    /**
     * Get posting status for a document
     */
    getPostingStatus(tenantId: string, sourceType: string, sourceId: string): Promise<{
        posted: boolean;
        journalEntryId?: string;
        postedAt?: Date;
    }>;
    /**
     * Reverse a GL posting (creates reversing journal entry)
     */
    reversePosting(tenantId: string, sourceType: string, sourceId: string, reason: string, userId: string): Promise<PostingResult>;
}
export declare const integrationService: IntegrationService;
//# sourceMappingURL=integration.service.d.ts.map