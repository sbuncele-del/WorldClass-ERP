"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildPubSubClients = exports.redisService = exports.RedisService = void 0;
exports.redisHealthCheck = redisHealthCheck;
const redis_connection_1 = require("../config/redis-connection");
/**
 * RedisService
 * Shared Redis utilities for caching, health, and pub/sub helpers.
 *
 * MULTI-TENANCY:
 * - Use tenant-prefixed methods (getTenant, setTenant, etc.) for tenant-specific data
 * - Regular methods (get, set, etc.) are for global/system data only
 * - Tenant keys follow format: tenant:{tenantId}:{key}
 */
class RedisService {
    constructor(client) {
        this.client = client ?? (0, redis_connection_1.createRedisClient)('client');
    }
    getClient() {
        return this.client;
    }
    async ping() {
        const result = await this.client.ping();
        return result === 'PONG';
    }
    // ============================================
    // TENANT-SCOPED METHODS (Use for tenant data)
    // ============================================
    /**
     * Build a tenant-scoped key
     */
    tenantKey(tenantId, key) {
        return `tenant:${tenantId}:${key}`;
    }
    /**
     * Get a tenant-scoped value
     */
    async getTenant(tenantId, key) {
        const fullKey = this.tenantKey(tenantId, key);
        const value = await this.client.get(fullKey);
        if (!value)
            return null;
        try {
            return JSON.parse(value);
        }
        catch {
            return null;
        }
    }
    /**
     * Set a tenant-scoped value
     */
    async setTenant(tenantId, key, value, ttlSeconds) {
        const fullKey = this.tenantKey(tenantId, key);
        const payload = JSON.stringify(value);
        if (ttlSeconds && ttlSeconds > 0) {
            return this.client.set(fullKey, payload, 'EX', ttlSeconds);
        }
        return this.client.set(fullKey, payload);
    }
    /**
     * Delete a tenant-scoped key
     */
    async delTenant(tenantId, key) {
        const keys = Array.isArray(key)
            ? key.map(k => this.tenantKey(tenantId, k))
            : [this.tenantKey(tenantId, key)];
        return this.client.del(keys);
    }
    /**
     * Get TTL for a tenant-scoped key
     */
    async ttlTenant(tenantId, key) {
        return this.client.ttl(this.tenantKey(tenantId, key));
    }
    /**
     * Flush all keys for a specific tenant
     */
    async flushTenant(tenantId) {
        const prefix = `tenant:${tenantId}:`;
        const keys = await this.client.keys(`${prefix}*`);
        if (!keys.length)
            return 0;
        const pipeline = this.client.pipeline();
        keys.forEach((k) => pipeline.del(k));
        const results = await pipeline.exec();
        return results?.length || 0;
    }
    /**
     * Get all keys for a tenant matching a pattern
     */
    async keysTenant(tenantId, pattern = '*') {
        const prefix = `tenant:${tenantId}:`;
        const keys = await this.client.keys(`${prefix}${pattern}`);
        // Strip tenant prefix for cleaner return
        return keys.map(k => k.substring(prefix.length));
    }
    // ============================================
    // GLOBAL METHODS (Use for system/config data)
    // ============================================
    async get(key) {
        const value = await this.client.get(key);
        if (!value)
            return null;
        try {
            return JSON.parse(value);
        }
        catch {
            return null;
        }
    }
    async set(key, value, ttlSeconds) {
        const payload = JSON.stringify(value);
        if (ttlSeconds && ttlSeconds > 0) {
            return this.client.set(key, payload, 'EX', ttlSeconds);
        }
        return this.client.set(key, payload);
    }
    async del(key) {
        return this.client.del(Array.isArray(key) ? key : [key]);
    }
    async ttl(key) {
        return this.client.ttl(key);
    }
    async flushPrefix(prefix) {
        const keys = await this.client.keys(`${prefix}*`);
        if (!keys.length)
            return 0;
        const pipeline = this.client.pipeline();
        keys.forEach((k) => pipeline.del(k));
        const results = await pipeline.exec();
        return results?.length || 0;
    }
}
exports.RedisService = RedisService;
async function redisHealthCheck() {
    const client = (0, redis_connection_1.createRedisClient)('client');
    const start = Date.now();
    try {
        await client.ping();
        const latencyMs = Date.now() - start;
        await client.quit();
        return { status: 'up', latencyMs };
    }
    catch (error) {
        console.error('Redis health check failed:', error);
        await client.quit();
        return { status: 'down', latencyMs: -1 };
    }
}
exports.redisService = new RedisService();
/**
 * Helper to build new pub/sub clients (Socket.IO adapter)
 */
const buildPubSubClients = () => {
    const pubClient = (0, redis_connection_1.createRedisClient)('client');
    const subClient = (0, redis_connection_1.createRedisClient)('subscriber');
    return { pubClient, subClient };
};
exports.buildPubSubClients = buildPubSubClients;
//# sourceMappingURL=redis.service.js.map