/**
 * Email Service
 * Core email sending functionality using Nodemailer
 */
/**
 * Send email using template
 */
export declare function sendEmail(options: {
    to: string;
    subject: string;
    template: string;
    variables: Record<string, string>;
    from?: string;
    userId?: number;
    tenantId?: number;
    category?: string;
}): Promise<void>;
/**
 * Send plain text email (no template)
 */
export declare function sendPlainEmail(options: {
    to: string;
    subject: string;
    text: string;
    html?: string;
    from?: string;
}): Promise<void>;
/**
 * Send bulk emails (with rate limiting)
 */
export declare function sendBulkEmails(emails: Array<{
    to: string;
    subject: string;
    template: string;
    variables: Record<string, string>;
}>, delayMs?: number): Promise<{
    sent: number;
    failed: number;
    errors: any[];
}>;
declare const _default: {
    sendEmail: typeof sendEmail;
    sendPlainEmail: typeof sendPlainEmail;
    sendBulkEmails: typeof sendBulkEmails;
};
export default _default;
//# sourceMappingURL=email.service.d.ts.map