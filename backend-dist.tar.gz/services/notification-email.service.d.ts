/**
 * Send payment success notification
 */
export declare function sendPaymentSuccessEmail(email: string, userId: number, paymentDetails: {
    amount: number;
    currency: string;
    planName: string;
    invoiceNumber: string;
    paymentDate: string;
}): Promise<void>;
/**
 * Send payment failed notification
 */
export declare function sendPaymentFailedEmail(email: string, userId: number, failureDetails: {
    amount: number;
    currency: string;
    planName: string;
    reason: string;
    attemptDate: string;
}): Promise<void>;
/**
 * Send subscription expiring soon notification
 */
export declare function sendSubscriptionExpiringEmail(email: string, userId: number, expiryDetails: {
    planName: string;
    expiryDate: string;
    daysRemaining: number;
}): Promise<void>;
/**
 * Send subscription cancelled notification
 */
export declare function sendSubscriptionCancelledEmail(email: string, userId: number, cancellationDetails: {
    planName: string;
    cancellationDate: string;
    accessUntil: string;
    reason?: string;
}): Promise<void>;
/**
 * Send team member invitation
 */
export declare function sendTeamInvitationEmail(email: string, inviterName: string, companyName: string, role: string, invitationToken: string): Promise<void>;
/**
 * Send security alert notification
 */
export declare function sendSecurityAlertEmail(email: string, userId: number, alertDetails: {
    alertType: string;
    description: string;
    timestamp: string;
    ipAddress: string;
    location?: string;
}): Promise<void>;
/**
 * Send system maintenance notification
 */
export declare function sendMaintenanceNotificationEmail(email: string, userId: number, maintenanceDetails: {
    startTime: string;
    endTime: string;
    duration: string;
    affectedServices: string[];
    reason: string;
}): Promise<void>;
/**
 * Send data export ready notification
 */
export declare function sendDataExportReadyEmail(email: string, userId: number, exportDetails: {
    exportType: string;
    fileName: string;
    fileSize: string;
    downloadUrl: string;
    expiresIn: string;
}): Promise<void>;
/**
 * Send low stock alert
 */
export declare function sendLowStockAlertEmail(email: string, userId: number, stockDetails: {
    productName: string;
    currentStock: number;
    reorderPoint: number;
    sku: string;
}): Promise<void>;
export declare const NotificationEmailService: {
    sendPaymentSuccessEmail: typeof sendPaymentSuccessEmail;
    sendPaymentFailedEmail: typeof sendPaymentFailedEmail;
    sendSubscriptionExpiringEmail: typeof sendSubscriptionExpiringEmail;
    sendSubscriptionCancelledEmail: typeof sendSubscriptionCancelledEmail;
    sendTeamInvitationEmail: typeof sendTeamInvitationEmail;
    sendSecurityAlertEmail: typeof sendSecurityAlertEmail;
    sendMaintenanceNotificationEmail: typeof sendMaintenanceNotificationEmail;
    sendDataExportReadyEmail: typeof sendDataExportReadyEmail;
    sendLowStockAlertEmail: typeof sendLowStockAlertEmail;
};
export default NotificationEmailService;
//# sourceMappingURL=notification-email.service.d.ts.map