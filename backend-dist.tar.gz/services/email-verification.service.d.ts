/**
 * Email Verification Service
 * Handles email verification token generation and validation
 */
/**
 * Send verification email to user
 */
export declare function sendVerificationEmail(email: string, userId: string, tenantId?: string): Promise<void>;
/**
 * Verify email token
 */
export declare function verifyEmailToken(token: string): Promise<{
    success: boolean;
    userId?: string;
    tenantId?: string;
    message: string;
}>;
/**
 * Resend verification email
 */
export declare function resendVerificationEmail(email: string): Promise<{
    success: boolean;
    message: string;
}>;
/**
 * Check if email is verified
 */
export declare function isEmailVerified(userId: string): Promise<boolean>;
/**
 * Get verification status
 */
export declare function getVerificationStatus(userId: string): Promise<{
    verified: boolean;
    verifiedAt?: Date;
    pendingToken?: boolean;
    tokenExpiresAt?: Date;
}>;
/**
 * Clean up expired tokens (should be run periodically)
 */
export declare function cleanupExpiredTokens(): Promise<number>;
declare const _default: {
    sendVerificationEmail: typeof sendVerificationEmail;
    verifyEmailToken: typeof verifyEmailToken;
    resendVerificationEmail: typeof resendVerificationEmail;
    isEmailVerified: typeof isEmailVerified;
    getVerificationStatus: typeof getVerificationStatus;
    cleanupExpiredTokens: typeof cleanupExpiredTokens;
};
export default _default;
//# sourceMappingURL=email-verification.service.d.ts.map