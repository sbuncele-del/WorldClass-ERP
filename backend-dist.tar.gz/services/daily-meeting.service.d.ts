/**
 * Daily.co Video Meeting Service (Multi-Tenant)
 *
 * Provides video conferencing capabilities for the Communications Hub.
 * Uses Daily.co's API for creating and managing video meeting rooms.
 *
 * Multi-Tenancy:
 * - All rooms are prefixed with tenant ID for isolation
 * - Room operations require tenant context
 * - Listing/searching is scoped to tenant
 *
 * Free tier includes:
 * - 2,000 participant minutes/month
 * - Up to 50 participants per room
 * - Screen sharing
 * - Recording (limited)
 *
 * @see https://docs.daily.co/reference
 */
interface TenantContext {
    tenantId: string;
    userId?: string;
}
interface DailyRoomConfig {
    name?: string;
    privacy?: 'public' | 'private';
    properties?: {
        exp?: number;
        nbf?: number;
        max_participants?: number;
        enable_screenshare?: boolean;
        enable_chat?: boolean;
        enable_knocking?: boolean;
        start_video_off?: boolean;
        start_audio_off?: boolean;
        owner_only_broadcast?: boolean;
        enable_recording?: 'cloud' | 'local' | 'raw-tracks' | undefined;
        eject_at_room_exp?: boolean;
        lang?: string;
    };
}
interface DailyRoom {
    id: string;
    name: string;
    api_created: boolean;
    privacy: 'public' | 'private';
    url: string;
    created_at: string;
    config: DailyRoomConfig['properties'];
}
declare class DailyMeetingService {
    private _apiClient;
    private get apiClient();
    /**
     * Check if Daily.co is configured
     */
    isConfigured(): boolean;
    /**
     * Generate tenant-scoped room name prefix
     */
    private getTenantRoomPrefix;
    /**
     * Generate a tenant-scoped room name
     */
    private generateRoomName;
    /**
     * Check if a room belongs to a tenant
     */
    private isRoomOwnedByTenant;
    /**
     * Create a new meeting room (tenant-scoped)
     * @param tenant Tenant context
     * @param options Room configuration options
     */
    createRoom(tenant: TenantContext, options?: {
        name?: string;
        expiryMinutes?: number;
        maxParticipants?: number;
        enableWaitingRoom?: boolean;
        enableRecording?: boolean;
        isWebinar?: boolean;
    }): Promise<DailyRoom>;
    /**
     * Get an existing room by name (tenant-scoped)
     */
    getRoom(tenant: TenantContext, roomName: string): Promise<DailyRoom | null>;
    /**
     * List all rooms for a tenant
     */
    listRooms(tenant: TenantContext, limit?: number): Promise<DailyRoom[]>;
    /**
     * Delete a room (tenant-scoped)
     */
    deleteRoom(tenant: TenantContext, roomName: string): Promise<boolean>;
    /**
     * Create a meeting token for a participant (tenant-scoped)
     * Tokens can have restricted permissions (e.g., for guests vs hosts)
     */
    createMeetingToken(tenant: TenantContext, options: {
        roomName: string;
        userName: string;
        isOwner?: boolean;
        expiryMinutes?: number;
        participantUserId?: string;
    }): Promise<string>;
    /**
     * Get meeting analytics/logs for a room (tenant-scoped)
     */
    getMeetingLogs(tenant: TenantContext, roomName: string): Promise<any>;
    /**
     * Get domain/account information (admin only - not tenant-scoped)
     */
    getAccountInfo(): Promise<any>;
    /**
     * Create an instant meeting (quick room with short expiry) - tenant-scoped
     */
    createInstantMeeting(tenant: TenantContext, hostName: string): Promise<{
        room: DailyRoom;
        hostToken: string;
        guestUrl: string;
    }>;
    /**
     * Schedule a meeting (room with future start time) - tenant-scoped
     */
    scheduleMeeting(tenant: TenantContext, options: {
        title: string;
        startTime: Date;
        durationMinutes: number;
        hostName: string;
        maxParticipants?: number;
        enableWaitingRoom?: boolean;
    }): Promise<{
        room: DailyRoom;
        hostToken: string;
        guestUrl: string;
        startTime: Date;
        endTime: Date;
    }>;
    /**
     * Generate a guest invitation link - tenant-scoped
     */
    createGuestInvite(tenant: TenantContext, roomName: string, guestName: string, expiryMinutes?: number): Promise<{
        url: string;
        token: string;
    }>;
    /**
     * Get meeting usage statistics for a tenant
     */
    getTenantUsageStats(tenant: TenantContext): Promise<{
        activeRooms: number;
        totalRooms: number;
    }>;
}
export declare const dailyMeetingService: DailyMeetingService;
export default dailyMeetingService;
//# sourceMappingURL=daily-meeting.service.d.ts.map