/**
 * Feature Flag Service
 * Checks tenant-level feature flags from tenant_feature_flags table
 */
export declare class FeatureFlagService {
    /**
     * Check if a feature is enabled for a tenant
     */
    static isEnabled(tenantId: string, featureName: string): Promise<boolean>;
    /**
     * Enable a feature for a tenant
     */
    static enable(tenantId: string, featureName: string, category?: string, updatedBy?: string): Promise<void>;
    /**
     * Disable a feature for a tenant
     */
    static disable(tenantId: string, featureName: string, updatedBy?: string): Promise<void>;
    /**
     * Enable feature globally (all tenants)
     */
    static enableGlobal(featureName: string): Promise<void>;
    /**
     * Get all features for a tenant
     */
    static getAll(tenantId: string): Promise<Array<{
        feature_name: string;
        enabled: boolean;
        config: any;
    }>>;
}
export default FeatureFlagService;
//# sourceMappingURL=feature-flag.service.d.ts.map