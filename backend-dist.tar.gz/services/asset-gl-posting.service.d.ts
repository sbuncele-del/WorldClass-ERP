/**
 * Asset GL Posting Service
 * Creates journal entries for depreciation, disposals, revaluations, and impairments (IAS 16)
 */
import { PoolClient } from 'pg';
export interface DepreciationPostingParams {
    asset_id: string;
    period_year: number;
    period_month: number;
    depreciation_amount: number;
    depreciation_expense_account: string;
    accumulated_depreciation_account: string;
    cost_center_id?: string;
    department_id?: string;
}
export interface DisposalPostingParams {
    asset_id: string;
    disposal_date: Date;
    original_cost: number;
    accumulated_depreciation: number;
    net_book_value: number;
    sale_proceeds: number;
    removal_cost: number;
    disposal_method: string;
    asset_account: string;
    accumulated_depreciation_account: string;
    cash_account: string;
    gain_account: string;
    loss_account: string;
    cost_center_id?: string;
}
export interface RevaluationPostingParams {
    asset_id: string;
    valuation_date: Date;
    previous_book_value: number;
    revalued_amount: number;
    revaluation_surplus_account: string;
    asset_account: string;
    cost_center_id?: string;
}
export interface ImpairmentPostingParams {
    asset_id: string;
    impairment_date: Date;
    impairment_amount: number;
    previous_book_value: number;
    impairment_loss_account: string;
    accumulated_impairment_account: string;
    cost_center_id?: string;
}
export declare class AssetGLPostingService {
    /**
     * Create journal entry for monthly depreciation
     */
    static postDepreciation(client: PoolClient, params: DepreciationPostingParams, userId?: string): Promise<{
        journal_entry_id: string;
        entry_number: string;
    }>;
    /**
     * Create journal entry for asset disposal (sale, scrapping, write-off)
     * IAS 16.67-72: Gain/loss on disposal
     */
    static postDisposal(client: PoolClient, params: DisposalPostingParams, userId?: string): Promise<{
        journal_entry_id: string;
        entry_number: string;
        gain_loss: number;
    }>;
    /**
     * Create journal entry for asset revaluation (IAS 16.31-42)
     * Upward revaluation goes to revaluation surplus (OCI)
     * Downward revaluation to P&L unless reversing previous surplus
     */
    static postRevaluation(client: PoolClient, params: RevaluationPostingParams, userId?: string): Promise<{
        journal_entry_id: string;
        entry_number: string;
        surplus_or_deficit: number;
    }>;
    /**
     * Create journal entry for impairment loss (IAS 36)
     */
    static postImpairment(client: PoolClient, params: ImpairmentPostingParams, userId?: string): Promise<{
        journal_entry_id: string;
        entry_number: string;
    }>;
    /**
     * Generate sequential entry number with prefix
     */
    private static generateEntryNumber;
}
export default AssetGLPostingService;
//# sourceMappingURL=asset-gl-posting.service.d.ts.map