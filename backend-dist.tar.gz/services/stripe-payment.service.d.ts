interface StripePaymentRequest {
    tenantId: string;
    userId: string;
    amount: number;
    plan: string;
    billingCycle: 'monthly' | 'annual';
    customerEmail: string;
    customerName: string;
    currency?: string;
}
interface StripePaymentResponse {
    sessionId: string;
    url: string;
    transactionReference: string;
}
export declare class StripePaymentService {
    /**
     * Create Stripe Checkout Session
     */
    static createCheckoutSession(data: StripePaymentRequest): Promise<StripePaymentResponse>;
    /**
     * Handle Stripe webhook events
     */
    static handleWebhook(body: string, signature: string): Promise<void>;
    /**
     * Handle successful checkout session
     */
    private static handleCheckoutCompleted;
    /**
     * Handle successful invoice payment (renewal)
     */
    private static handleInvoicePaymentSucceeded;
    /**
     * Handle failed invoice payment
     */
    private static handleInvoicePaymentFailed;
    /**
     * Handle subscription updated
     */
    private static handleSubscriptionUpdated;
    /**
     * Handle subscription deleted (cancelled)
     */
    private static handleSubscriptionDeleted;
    /**
     * Get or create Stripe customer
     */
    private static getOrCreateStripeCustomer;
    /**
     * Activate subscription after successful payment
     */
    private static activateSubscription;
    /**
     * Cancel Stripe subscription
     */
    static cancelSubscription(tenantId: string): Promise<void>;
    /**
     * Generate transaction reference
     */
    private static generateTransactionReference;
    /**
     * Get plan display name
     */
    private static getPlanDisplayName;
    /**
     * Check if Stripe is configured
     */
    static isConfigured(): boolean;
    /**
     * Get pricing for plan (USD)
     */
    static getPlanPricing(plan: string, billingCycle: string): number;
}
export default StripePaymentService;
//# sourceMappingURL=stripe-payment.service.d.ts.map