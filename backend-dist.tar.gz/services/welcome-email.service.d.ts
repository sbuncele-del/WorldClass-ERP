/**
 * Welcome Email Service
 * Handles sending welcome emails to new users
 */
/**
 * Send welcome email after signup
 */
export declare function sendWelcomeEmail(email: string, userId: string): Promise<void>;
/**
 * Send onboarding complete email
 */
export declare function sendOnboardingCompleteEmail(email: string, userId: string): Promise<void>;
/**
 * Send getting started guide email
 */
export declare function sendGettingStartedEmail(email: string, userId: string): Promise<void>;
/**
 * Send welcome series (drip campaign)
 * Sends a series of emails over time to help users get started
 */
export declare function sendWelcomeSeries(email: string, userId: string): Promise<void>;
declare const _default: {
    sendWelcomeEmail: typeof sendWelcomeEmail;
    sendOnboardingCompleteEmail: typeof sendOnboardingCompleteEmail;
    sendGettingStartedEmail: typeof sendGettingStartedEmail;
    sendWelcomeSeries: typeof sendWelcomeSeries;
};
export default _default;
//# sourceMappingURL=welcome-email.service.d.ts.map