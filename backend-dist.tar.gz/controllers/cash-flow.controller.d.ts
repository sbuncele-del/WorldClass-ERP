import { Request, Response } from 'express';
export declare class CashFlowController {
    /**
     * Generate Cash Flow Statement (Indirect Method)
     * GET /api/financial/reports/cash-flow
     */
    static generateCashFlowStatement(req: Request, res: Response): Promise<void>;
    /**
     * Export Cash Flow Statement to PDF
     * POST /api/financial/reports/cash-flow/export
     */
    static exportToPDF(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=cash-flow.controller.d.ts.map