/**
 * Audit Ready Controller V2
 * Tenant-hardened API for audit management
 *
 * Features:
 * - Audit engagements
 * - Audit findings & corrective actions
 * - Evidence repository
 * - Audit checklists
 * - Permanent records
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get audit engagements
 */
export declare const getEngagements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get engagement by ID
 */
export declare const getEngagementById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create audit engagement
 */
export declare const createEngagement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update engagement status
 */
export declare const updateEngagementStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get audit findings
 */
export declare const getFindings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create audit finding
 */
export declare const createFinding: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update finding
 */
export declare const updateFinding: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get audit evidence
 */
export declare const getEvidence: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Add audit evidence
 */
export declare const addEvidence: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get checklist templates
 */
export declare const getChecklistTemplates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get checklist items
 */
export declare const getChecklistItems: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get permanent records
 */
export declare const getPermanentRecords: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Add permanent record
 */
export declare const addPermanentRecord: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getEngagements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEngagementById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createEngagement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateEngagementStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFindings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createFinding: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateFinding: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEvidence: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    addEvidence: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getChecklistTemplates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getChecklistItems: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPermanentRecords: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    addPermanentRecord: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=audit-ready.controller.v2.d.ts.map