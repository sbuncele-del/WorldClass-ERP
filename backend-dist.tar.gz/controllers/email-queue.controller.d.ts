import { Request, Response } from 'express';
/**
 * Email Queue Monitoring Controller
 *
 * Admin endpoints for monitoring and managing the email queue.
 */
/**
 * Get queue statistics
 *
 * GET /api/admin/email-queue/stats
 */
export declare function getStats(_req: Request, res: Response): Promise<void>;
/**
 * Get failed jobs (dead letter queue)
 *
 * GET /api/admin/email-queue/failed?limit=50
 */
export declare function getFailedJobsList(req: Request, res: Response): Promise<void>;
/**
 * Retry a failed job
 *
 * POST /api/admin/email-queue/retry/:jobId
 */
export declare function retryJob(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Clear completed jobs
 *
 * DELETE /api/admin/email-queue/completed
 */
export declare function clearCompleted(_req: Request, res: Response): Promise<void>;
/**
 * Clear failed jobs
 *
 * DELETE /api/admin/email-queue/failed
 */
export declare function clearFailed(_req: Request, res: Response): Promise<void>;
/**
 * Pause queue processing
 *
 * POST /api/admin/email-queue/pause
 */
export declare function pause(_req: Request, res: Response): Promise<void>;
/**
 * Resume queue processing
 *
 * POST /api/admin/email-queue/resume
 */
export declare function resume(_req: Request, res: Response): Promise<void>;
/**
 * Get job details by ID
 *
 * GET /api/admin/email-queue/jobs/:jobId
 */
export declare function getJobDetails(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Get queue health check
 *
 * GET /api/admin/email-queue/health
 */
export declare function healthCheck(_req: Request, res: Response): Promise<void>;
//# sourceMappingURL=email-queue.controller.d.ts.map