"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const super_admin_service_1 = __importDefault(require("../services/super-admin.service"));
/**
 * Super Admin Controller
 *
 * Handles HTTP requests for super admin functionality
 * All endpoints should be protected by superAdminAuth middleware
 */
class SuperAdminController {
    /**
     * Get list of all tenants
     * GET /api/admin/tenants
     */
    async getTenants(req, res) {
        try {
            const { status, plan, search, limit, offset } = req.query;
            const result = await super_admin_service_1.default.getTenants({
                status: status,
                plan: plan,
                search: search,
                limit: limit ? parseInt(limit) : undefined,
                offset: offset ? parseInt(offset) : undefined
            });
            res.status(200).json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Get tenants error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch tenants',
                error: error.message
            });
        }
    }
    /**
     * Get tenant details
     * GET /api/admin/tenants/:id
     */
    async getTenantDetails(req, res) {
        try {
            const { id } = req.params;
            const details = await super_admin_service_1.default.getTenantDetails(id);
            res.status(200).json({
                success: true,
                ...details
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Get tenant details error:', error);
            res.status(error.message === 'Tenant not found' ? 404 : 500).json({
                success: false,
                message: error.message
            });
        }
    }
    /**
     * Suspend tenant
     * POST /api/admin/tenants/:id/suspend
     */
    async suspendTenant(req, res) {
        try {
            const { id } = req.params;
            const { reason } = req.body;
            const adminEmail = req.user.email;
            if (!reason) {
                res.status(400).json({
                    success: false,
                    message: 'Suspension reason is required'
                });
                return;
            }
            const result = await super_admin_service_1.default.suspendTenant(id, reason, adminEmail);
            res.status(200).json(result);
        }
        catch (error) {
            console.error('[SuperAdmin] Suspend tenant error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to suspend tenant',
                error: error.message
            });
        }
    }
    /**
     * Activate tenant
     * POST /api/admin/tenants/:id/activate
     */
    async activateTenant(req, res) {
        try {
            const { id } = req.params;
            const adminEmail = req.user.email;
            const result = await super_admin_service_1.default.activateTenant(id, adminEmail);
            res.status(200).json(result);
        }
        catch (error) {
            console.error('[SuperAdmin] Activate tenant error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to activate tenant',
                error: error.message
            });
        }
    }
    /**
     * Delete tenant
     * DELETE /api/admin/tenants/:id
     */
    async deleteTenant(req, res) {
        try {
            const { id } = req.params;
            const adminEmail = req.user.email;
            const result = await super_admin_service_1.default.deleteTenant(id, adminEmail);
            res.status(200).json(result);
        }
        catch (error) {
            console.error('[SuperAdmin] Delete tenant error:', error);
            res.status(error.message === 'Cannot delete demo tenant' ? 403 : 500).json({
                success: false,
                message: error.message
            });
        }
    }
    /**
     * Generate impersonation token
     * POST /api/admin/impersonate
     */
    async impersonateUser(req, res) {
        try {
            const { userId } = req.body;
            const adminEmail = req.user.email;
            if (!userId) {
                res.status(400).json({
                    success: false,
                    message: 'User ID is required'
                });
                return;
            }
            const result = await super_admin_service_1.default.generateImpersonationToken(userId, adminEmail);
            res.status(200).json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Impersonate error:', error);
            res.status(error.message === 'User not found' ? 404 : 500).json({
                success: false,
                message: error.message
            });
        }
    }
    /**
     * Get system statistics
     * GET /api/admin/stats
     */
    async getSystemStats(_req, res) {
        try {
            const stats = await super_admin_service_1.default.getSystemStats();
            res.status(200).json({
                success: true,
                stats
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Get stats error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch system statistics',
                error: error.message
            });
        }
    }
    /**
     * Get system health
     * GET /api/admin/health
     */
    async getSystemHealth(_req, res) {
        try {
            const health = await super_admin_service_1.default.getSystemHealth();
            res.status(200).json({
                success: true,
                health
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Get health error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch system health',
                error: error.message
            });
        }
    }
    /**
     * Get feature flags
     * GET /api/admin/feature-flags
     */
    async getFeatureFlags(_req, res) {
        try {
            const flags = await super_admin_service_1.default.getFeatureFlags();
            res.status(200).json({
                success: true,
                flags
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Get feature flags error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch feature flags',
                error: error.message
            });
        }
    }
    /**
     * Update feature flag
     * PUT /api/admin/feature-flags/:name
     */
    async updateFeatureFlag(req, res) {
        try {
            const { name } = req.params;
            const { enabled, rolloutPercentage } = req.body;
            if (typeof enabled !== 'boolean') {
                res.status(400).json({
                    success: false,
                    message: 'enabled must be a boolean'
                });
                return;
            }
            const result = await super_admin_service_1.default.updateFeatureFlag(name, enabled, rolloutPercentage);
            res.status(200).json(result);
        }
        catch (error) {
            console.error('[SuperAdmin] Update feature flag error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to update feature flag',
                error: error.message
            });
        }
    }
    /**
     * Get audit logs
     * GET /api/admin/audit-logs
     */
    async getAuditLogs(req, res) {
        try {
            const { limit, offset } = req.query;
            const result = await super_admin_service_1.default.getAuditLogs(limit ? parseInt(limit) : undefined, offset ? parseInt(offset) : undefined);
            res.status(200).json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('[SuperAdmin] Get audit logs error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to fetch audit logs',
                error: error.message
            });
        }
    }
}
exports.default = new SuperAdminController();
//# sourceMappingURL=super-admin.controller.js.map