/**
 * Password Reset Controller
 * Handles HTTP requests for password reset
 */
import { Request, Response } from 'express';
/**
 * Request password reset
 * POST /api/auth/password/reset-request
 */
export declare function requestPasswordReset(req: Request, res: Response): Promise<void>;
/**
 * Verify reset token
 * POST /api/auth/password/verify-token
 */
export declare function verifyToken(req: Request, res: Response): Promise<void>;
/**
 * Reset password
 * POST /api/auth/password/reset
 */
export declare function resetPasswordHandler(req: Request, res: Response): Promise<void>;
/**
 * Validate password strength
 * POST /api/auth/password/validate
 */
export declare function validatePassword(req: Request, res: Response): Promise<void>;
declare const _default: {
    requestPasswordReset: typeof requestPasswordReset;
    verifyToken: typeof verifyToken;
    resetPasswordHandler: typeof resetPasswordHandler;
    validatePassword: typeof validatePassword;
};
export default _default;
//# sourceMappingURL=password-reset.controller.d.ts.map