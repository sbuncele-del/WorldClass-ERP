/**
 * AI Assistant Controller
 * Handle AI agent interactions
 */
import { Request, Response } from 'express';
/**
 * List all available AI agents
 */
export declare const getAgents: (req: Request, res: Response) => Promise<void>;
/**
 * Get specific agent details
 */
export declare const getAgent: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Chat with an AI agent
 */
export declare const chat: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Stream chat with an AI agent (SSE)
 */
export declare const streamChat: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get user's conversations
 */
export declare const getConversations: (req: Request, res: Response) => Promise<void>;
/**
 * Get conversation history
 */
export declare const getConversationHistory: (req: Request, res: Response) => Promise<void>;
/**
 * Archive a conversation
 */
export declare const archiveConversation: (req: Request, res: Response) => Promise<void>;
/**
 * Get AI suggestions for user
 */
export declare const getSuggestions: (req: Request, res: Response) => Promise<void>;
/**
 * Update suggestion status
 */
export declare const updateSuggestionStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get agent capabilities
 */
export declare const getAgentCapabilities: (req: Request, res: Response) => Promise<void>;
/**
 * Sales Assistant - Specific helper endpoints
 */
export declare const salesAssistant: {
    /**
     * Analyze customer for upsell opportunities
     */
    analyzeCustomer: (req: Request, res: Response) => Promise<void>;
    /**
     * Generate quotation with AI assistance
     */
    generateQuotation: (req: Request, res: Response) => Promise<void>;
    /**
     * Forecast sales
     */
    forecastSales: (req: Request, res: Response) => Promise<void>;
};
/**
 * Compliance Assistant - Specific helper endpoints
 */
export declare const complianceAssistant: {
    /**
     * Check compliance status
     */
    checkCompliance: (req: Request, res: Response) => Promise<void>;
    /**
     * Assess risk
     */
    assessRisk: (req: Request, res: Response) => Promise<void>;
};
/**
 * Finance Assistant - Specific helper endpoints
 */
export declare const financeAssistant: {
    /**
     * Explain variance
     */
    explainVariance: (req: Request, res: Response) => Promise<void>;
    /**
     * Reconcile account
     */
    reconcileAccount: (req: Request, res: Response) => Promise<void>;
};
//# sourceMappingURL=ai-assistant.controller.d.ts.map