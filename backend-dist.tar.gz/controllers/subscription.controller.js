"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SubscriptionController = void 0;
const subscription_service_1 = __importDefault(require("../services/subscription.service"));
class SubscriptionController {
    /**
     * GET /api/subscription
     * Get current subscription details
     */
    static async getCurrentSubscription(req, res) {
        try {
            const tenantId = req.tenant.id;
            const subscription = await subscription_service_1.default.getCurrentSubscription(tenantId);
            if (!subscription) {
                res.status(404).json({ error: 'Subscription not found' });
                return;
            }
            // Get usage statistics
            const usage = await subscription_service_1.default.getUsageStatistics(tenantId);
            // Check subscription status
            const status = await subscription_service_1.default.checkSubscriptionStatus(tenantId);
            res.json({
                subscription,
                usage,
                status
            });
        }
        catch (error) {
            console.error('[SubscriptionController] Get subscription error:', error);
            res.status(500).json({ error: 'Failed to retrieve subscription' });
        }
    }
    /**
     * POST /api/subscription/upgrade
     * Upgrade to a higher plan
     */
    static async upgradePlan(req, res) {
        try {
            const tenantId = req.tenant.id;
            const { plan, billingCycle = 'monthly' } = req.body;
            // Validate plan
            const validPlans = ['starter', 'professional', 'enterprise'];
            if (!validPlans.includes(plan)) {
                res.status(400).json({
                    error: 'Invalid plan',
                    validPlans
                });
                return;
            }
            // Validate billing cycle
            if (!['monthly', 'annual'].includes(billingCycle)) {
                res.status(400).json({
                    error: 'Invalid billing cycle',
                    validCycles: ['monthly', 'annual']
                });
                return;
            }
            const result = await subscription_service_1.default.upgradePlan(tenantId, plan, billingCycle);
            if (!result.success) {
                res.status(400).json({ error: result.message });
                return;
            }
            res.json({
                message: result.message,
                prorationAmount: result.prorationAmount,
                newPlan: plan,
                billingCycle
            });
        }
        catch (error) {
            console.error('[SubscriptionController] Upgrade error:', error);
            res.status(500).json({ error: 'Failed to upgrade subscription' });
        }
    }
    /**
     * POST /api/subscription/downgrade
     * Schedule downgrade to a lower plan
     */
    static async downgradePlan(req, res) {
        try {
            const tenantId = req.tenant.id;
            const { plan } = req.body;
            // Validate plan
            const validPlans = ['starter', 'professional'];
            if (!validPlans.includes(plan)) {
                res.status(400).json({
                    error: 'Invalid plan for downgrade',
                    validPlans
                });
                return;
            }
            const result = await subscription_service_1.default.downgradePlan(tenantId, plan);
            if (!result.success) {
                res.status(400).json({ error: result.message });
                return;
            }
            res.json({
                message: result.message,
                effectiveDate: result.effectiveDate,
                newPlan: plan
            });
        }
        catch (error) {
            console.error('[SubscriptionController] Downgrade error:', error);
            res.status(500).json({ error: 'Failed to downgrade subscription' });
        }
    }
    /**
     * POST /api/subscription/cancel
     * Cancel subscription (effective at period end)
     */
    static async cancelSubscription(req, res) {
        try {
            const tenantId = req.tenant.id;
            const { reason } = req.body;
            const result = await subscription_service_1.default.cancelSubscription(tenantId, reason);
            if (!result.success) {
                res.status(400).json({ error: result.message });
                return;
            }
            res.json({
                message: result.message,
                effectiveDate: result.effectiveDate
            });
        }
        catch (error) {
            console.error('[SubscriptionController] Cancel error:', error);
            res.status(500).json({ error: 'Failed to cancel subscription' });
        }
    }
    /**
     * POST /api/subscription/reactivate
     * Reactivate a cancelled subscription
     */
    static async reactivateSubscription(req, res) {
        try {
            const tenantId = req.tenant.id;
            const result = await subscription_service_1.default.reactivateSubscription(tenantId);
            if (!result.success) {
                res.status(400).json({ error: result.message });
                return;
            }
            res.json({ message: result.message });
        }
        catch (error) {
            console.error('[SubscriptionController] Reactivate error:', error);
            res.status(500).json({ error: 'Failed to reactivate subscription' });
        }
    }
    /**
     * PUT /api/subscription/payment-method
     * Update payment gateway
     */
    static async updatePaymentMethod(req, res) {
        try {
            const tenantId = req.tenant.id;
            const { gateway } = req.body;
            // Validate gateway
            if (!['ozow', 'stripe'].includes(gateway)) {
                res.status(400).json({
                    error: 'Invalid payment gateway',
                    validGateways: ['ozow', 'stripe']
                });
                return;
            }
            const result = await subscription_service_1.default.updatePaymentMethod(tenantId, gateway);
            if (!result.success) {
                res.status(400).json({ error: result.message });
                return;
            }
            res.json({ message: result.message });
        }
        catch (error) {
            console.error('[SubscriptionController] Update payment method error:', error);
            res.status(500).json({ error: 'Failed to update payment method' });
        }
    }
    /**
     * GET /api/subscription/usage
     * Get usage statistics
     */
    static async getUsageStatistics(req, res) {
        try {
            const tenantId = req.tenant.id;
            const usage = await subscription_service_1.default.getUsageStatistics(tenantId);
            res.json(usage);
        }
        catch (error) {
            console.error('[SubscriptionController] Get usage error:', error);
            res.status(500).json({ error: 'Failed to retrieve usage statistics' });
        }
    }
    /**
     * GET /api/subscription/status
     * Check subscription status
     */
    static async checkSubscriptionStatus(req, res) {
        try {
            const tenantId = req.tenant.id;
            const status = await subscription_service_1.default.checkSubscriptionStatus(tenantId);
            res.json(status);
        }
        catch (error) {
            console.error('[SubscriptionController] Check status error:', error);
            res.status(500).json({ error: 'Failed to check subscription status' });
        }
    }
}
exports.SubscriptionController = SubscriptionController;
exports.default = SubscriptionController;
//# sourceMappingURL=subscription.controller.js.map