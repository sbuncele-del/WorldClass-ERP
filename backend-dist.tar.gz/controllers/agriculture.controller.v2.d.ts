/**
 * Agriculture Controller V2
 * Tenant-hardened API for agriculture industry operations
 *
 * Features:
 * - Farm management
 * - Crop planning & tracking
 * - Livestock management
 * - Farm tasks & equipment
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getFarms: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getFarmById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createFarm: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateFarm: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getFarmFields: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createFarmField: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCrops: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createCrop: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateCrop: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getLivestock: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createLivestock: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateLivestock: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTasks: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFarms: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFarmById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createFarm: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateFarm: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFarmFields: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createFarmField: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getCrops: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createCrop: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateCrop: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getLivestock: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createLivestock: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateLivestock: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTasks: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=agriculture.controller.v2.d.ts.map