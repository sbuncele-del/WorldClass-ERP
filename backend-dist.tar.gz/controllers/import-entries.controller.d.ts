import { Request, Response } from 'express';
export declare class ImportEntriesController {
    /**
     * Parse and validate CSV/Excel file
     * POST /api/financial/import-entries/validate
     */
    static validateImport(req: Request, res: Response): Promise<void>;
    /**
     * Import validated journal entries
     * POST /api/financial/import-entries/import
     */
    static importEntries(req: Request, res: Response): Promise<void>;
    /**
     * Get import template
     * GET /api/financial/import-entries/template
     */
    static getTemplate(req: Request, res: Response): Promise<void>;
    /**
     * Get import history
     * GET /api/financial/import-entries/history
     */
    static getImportHistory(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=import-entries.controller.d.ts.map