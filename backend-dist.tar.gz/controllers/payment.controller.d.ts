import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class PaymentController {
    /**
     * POST /api/payment/create-session
     * Create payment session (Ozow or Stripe based on country)
     */
    static createPaymentSession(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/payment/status/:reference
     * Get payment transaction status
     */
    static getPaymentStatus(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/payment/history
     * Get tenant payment history
     */
    static getPaymentHistory(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/payment/cancel/:reference
     * Cancel pending payment
     */
    static cancelPayment(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/payment/pricing
     * Get pricing information for all plans
     */
    static getPricing(req: TenantRequest, res: Response): Promise<void>;
}
export default PaymentController;
//# sourceMappingURL=payment.controller.d.ts.map