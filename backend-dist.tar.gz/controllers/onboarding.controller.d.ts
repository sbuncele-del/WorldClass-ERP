import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class OnboardingController {
    /**
     * GET /api/onboarding/status
     * Get onboarding status for current tenant
     */
    static getStatus(req: TenantRequest, res: Response): Promise<void>;
    /**
     * PATCH /api/onboarding
     * Update onboarding data
     */
    static update(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/onboarding/complete
     * Mark onboarding as complete
     */
    static complete(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/onboarding/skip
     * Skip onboarding (use defaults)
     */
    static skip(req: TenantRequest, res: Response): Promise<void>;
}
export default OnboardingController;
//# sourceMappingURL=onboarding.controller.d.ts.map