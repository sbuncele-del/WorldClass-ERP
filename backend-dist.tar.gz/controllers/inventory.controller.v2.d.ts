/**
 * INVENTORY MANAGEMENT CONTROLLER (Repository Pattern)
 *
 * This controller demonstrates the proper multi-tenant pattern using repositories.
 * All data operations go through the repository which automatically handles tenant isolation.
 *
 * IMPORTANT: This uses TenantRequest to get tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getItemCategories: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getItemCategoryTree: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getItemCategory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createItemCategory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateItemCategory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteItemCategory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getItems: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getItem: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createItem: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateItem: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteItem: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getLowStockItems: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getWarehouses: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getWarehouse: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createWarehouse: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const setDefaultWarehouse: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getStockMovements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createStockReceipt: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createStockIssue: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createStockTransfer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMovementSummary: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockLevels: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createStockMovement: (req: TenantRequest, res: Response) => Promise<void>;
export declare const postStockMovement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockAdjustments: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getStockAdjustmentById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createStockAdjustment: (req: TenantRequest, res: Response) => Promise<void>;
export declare const postStockAdjustment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockTakes: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createStockTake: (req: TenantRequest, res: Response) => Promise<void>;
export declare const postStockTake: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockBatches: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getSerialNumbers: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getReorderSuggestions: (req: TenantRequest, res: Response) => Promise<void>;
export declare const generateReorderSuggestions: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getInventoryDashboard: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=inventory.controller.v2.d.ts.map