/**
 * Healthcare Operations Controller
 * Operational Intelligence for Healthcare Facilities
 * Focus: Proactive management, not just data storage
 */
import { Request, Response } from 'express';
/**
 * ================================================
 * OPERATIONS COMMAND CENTER
 * ================================================
 */
/**
 * Get Live Facility Status - Operations Command Center
 * Real-time operational state with actionable insights
 */
export declare const getFacilityOperationsStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Facility KPIs Dashboard
 */
export declare const getFacilityKPIs: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * PATIENT JOURNEY MANAGEMENT
 * ================================================
 */
/**
 * Get Today's Appointments - Live Schedule
 */
export declare const getTodayAppointments: (req: Request, res: Response) => Promise<void>;
/**
 * Get Active Patients in Facility - Real-time Patient Flow
 */
export declare const getActivePatientsInFacility: (req: Request, res: Response) => Promise<void>;
/**
 * Get Patient Flow Bottlenecks - AI-Detected Issues
 */
export declare const getPatientFlowBottlenecks: (req: Request, res: Response) => Promise<void>;
/**
 * Check-in Patient
 */
export declare const checkInPatient: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update Patient Journey Stage
 */
export declare const updatePatientJourneyStage: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * STAFF MANAGEMENT (Integrated with HR Module)
 * ================================================
 */
/**
 * Get Staff Schedule for Today - References HR Module
 */
export declare const getTodayStaffSchedule: (req: Request, res: Response) => Promise<void>;
/**
 * Get Staff Utilization (for operational insights)
 */
export declare const getStaffUtilization: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * EQUIPMENT MANAGEMENT (Integrated with Asset Management)
 * ================================================
 */
/**
 * Get Medical Equipment Status - References Asset Management
 */
export declare const getMedicalEquipmentStatus: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * FACILITY COMMUNICATIONS HUB
 * ================================================
 */
/**
 * Get Active Communications/Requests
 */
export declare const getFacilityCommunications: (req: Request, res: Response) => Promise<void>;
/**
 * Get Service Requests
 */
export declare const getServiceRequests: (req: Request, res: Response) => Promise<void>;
/**
 * Create Service Request
 */
export declare const createServiceRequest: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * GOODX INTEGRATION & REVENUE CAPTURE
 * ================================================
 */
/**
 * Get GoodX Revenue Transactions (Auto-captured from GoodX)
 */
export declare const getGoodXRevenue: (req: Request, res: Response) => Promise<void>;
/**
 * Get GoodX Sync Status
 */
export declare const getGoodXSyncStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * ================================================
 * MEDICAL INVENTORY INTELLIGENCE
 * ================================================
 */
/**
 * Get Inventory Status with Criticality
 */
export declare const getInventoryStatus: (req: Request, res: Response) => Promise<void>;
/**
 * Get Active Inventory Alerts
 */
export declare const getInventoryAlerts: (req: Request, res: Response) => Promise<void>;
/**
 * Get Pending Reorder Requests
 */
export declare const getPendingReorders: (req: Request, res: Response) => Promise<void>;
/**
 * Create Inventory Reorder Request
 */
export declare const createReorderRequest: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * ================================================
 * PATIENT MANAGEMENT (CRUD)
 * ================================================
 */
/**
 * Get All Patients
 */
export declare const getPatients: (req: Request, res: Response) => Promise<void>;
/**
 * Get Single Patient
 */
export declare const getPatient: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create Patient
 */
export declare const createPatient: (req: Request, res: Response) => Promise<void>;
/**
 * Update Patient
 */
export declare const updatePatient: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * ================================================
 * CLINICAL WORKFLOWS
 * ================================================
 */
/**
 * Record Patient Vitals
 */
export declare const recordVitals: (req: Request, res: Response) => Promise<void>;
/**
 * Create Triage Assessment
 */
export declare const createTriage: (req: Request, res: Response) => Promise<void>;
/**
 * Create Lab Order
 */
export declare const createLabOrder: (req: Request, res: Response) => Promise<void>;
/**
 * Update Lab Results
 */
export declare const updateLabResults: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create Prescription
 */
export declare const createPrescription: (req: Request, res: Response) => Promise<void>;
/**
 * Get Patient Lab Orders
 */
export declare const getPatientLabOrders: (req: Request, res: Response) => Promise<void>;
/**
 * Get Patient Prescriptions
 */
export declare const getPatientPrescriptions: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * BED MANAGEMENT
 * ================================================
 */
/**
 * Get Bed Status
 */
export declare const getBedStatus: (req: Request, res: Response) => Promise<void>;
/**
 * Assign Bed to Patient
 */
export declare const assignBed: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Release Bed
 */
export declare const releaseBed: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * ================================================
 * APPOINTMENTS
 * ================================================
 */
/**
 * Create Appointment
 */
export declare const createAppointment: (req: Request, res: Response) => Promise<void>;
/**
 * Update Appointment Status
 */
export declare const updateAppointmentStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * ================================================
 * FACILITY MANAGEMENT
 * ================================================
 */
/**
 * Get All Facilities
 */
export declare const getFacilities: (req: Request, res: Response) => Promise<void>;
/**
 * Get Facility Locations
 */
export declare const getFacilityLocations: (req: Request, res: Response) => Promise<void>;
/**
 * ================================================
 * DASHBOARD & WORKSPACE ENDPOINTS
 * ================================================
 */
/**
 * Get Complete Operations Command Center Dashboard
 * Comprehensive real-time data for main dashboard
 */
export declare const getOperationsCommandCenterDashboard: (req: Request, res: Response) => Promise<void>;
/**
 * Get Patient Workspace Data
 * All data needed for patient management workspace
 */
export declare const getPatientWorkspace: (req: Request, res: Response) => Promise<void>;
/**
 * Get Clinical Workspace Data
 * All data needed for clinical workflows workspace
 */
export declare const getClinicalWorkspace: (req: Request, res: Response) => Promise<void>;
/**
 * Get Resource Management Workspace Data
 * Beds, staff, equipment status
 */
export declare const getResourceWorkspace: (req: Request, res: Response) => Promise<void>;
/**
 * Get Analytics Workspace Data
 * Performance metrics and trends
 */
export declare const getAnalyticsWorkspace: (req: Request, res: Response) => Promise<void>;
/**
 * Get Quick Stats (for dashboard widgets)
 */
export declare const getQuickStats: (req: Request, res: Response) => Promise<void>;
declare const _default: {
    getFacilityOperationsStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFacilityKPIs: (req: Request, res: Response) => Promise<void>;
    getOperationsCommandCenterDashboard: (req: Request, res: Response) => Promise<void>;
    getPatientWorkspace: (req: Request, res: Response) => Promise<void>;
    getClinicalWorkspace: (req: Request, res: Response) => Promise<void>;
    getResourceWorkspace: (req: Request, res: Response) => Promise<void>;
    getAnalyticsWorkspace: (req: Request, res: Response) => Promise<void>;
    getQuickStats: (req: Request, res: Response) => Promise<void>;
    getTodayAppointments: (req: Request, res: Response) => Promise<void>;
    getActivePatientsInFacility: (req: Request, res: Response) => Promise<void>;
    getPatientFlowBottlenecks: (req: Request, res: Response) => Promise<void>;
    checkInPatient: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePatientJourneyStage: (req: Request, res: Response) => Promise<void>;
    getPatients: (req: Request, res: Response) => Promise<void>;
    getPatient: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createPatient: (req: Request, res: Response) => Promise<void>;
    updatePatient: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    recordVitals: (req: Request, res: Response) => Promise<void>;
    createTriage: (req: Request, res: Response) => Promise<void>;
    createLabOrder: (req: Request, res: Response) => Promise<void>;
    updateLabResults: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createPrescription: (req: Request, res: Response) => Promise<void>;
    getPatientLabOrders: (req: Request, res: Response) => Promise<void>;
    getPatientPrescriptions: (req: Request, res: Response) => Promise<void>;
    getBedStatus: (req: Request, res: Response) => Promise<void>;
    assignBed: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    releaseBed: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createAppointment: (req: Request, res: Response) => Promise<void>;
    updateAppointmentStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTodayStaffSchedule: (req: Request, res: Response) => Promise<void>;
    getStaffUtilization: (req: Request, res: Response) => Promise<void>;
    getMedicalEquipmentStatus: (req: Request, res: Response) => Promise<void>;
    getFacilityCommunications: (req: Request, res: Response) => Promise<void>;
    getServiceRequests: (req: Request, res: Response) => Promise<void>;
    createServiceRequest: (req: Request, res: Response) => Promise<void>;
    getGoodXRevenue: (req: Request, res: Response) => Promise<void>;
    getGoodXSyncStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getInventoryStatus: (req: Request, res: Response) => Promise<void>;
    getInventoryAlerts: (req: Request, res: Response) => Promise<void>;
    getPendingReorders: (req: Request, res: Response) => Promise<void>;
    createReorderRequest: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFacilities: (req: Request, res: Response) => Promise<void>;
    getFacilityLocations: (req: Request, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=healthcare.controller.d.ts.map