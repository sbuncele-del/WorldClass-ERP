import { Request, Response } from 'express';
/**
 * Demo Access Controller
 *
 * Provides instant demo access without signup:
 * - Generates pre-authenticated JWT token for demo user
 * - Returns token and redirect URL
 * - Tracks demo usage statistics
 */
declare class DemoAccessController {
    /**
     * Generate demo access token
     * POST /api/demo/access
     *
     * Returns JWT token for instant demo access
     * No authentication required - this is a public endpoint
     */
    generateDemoToken(req: Request, res: Response): Promise<void>;
    /**
     * Get demo information (for landing page)
     * GET /api/demo/info
     *
     * Returns demo credentials and features
     */
    getDemoInfo(_req: Request, res: Response): Promise<void>;
    /**
     * Get demo usage statistics (for admin)
     * GET /api/demo/statistics
     */
    getDemoStatistics(_req: Request, res: Response): Promise<void>;
}
declare const _default: DemoAccessController;
export default _default;
//# sourceMappingURL=demo-access.controller.d.ts.map