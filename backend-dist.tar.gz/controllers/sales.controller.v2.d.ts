/**
 * SALES MANAGEMENT CONTROLLER (Repository Pattern)
 *
 * This controller uses the Repository Pattern for automatic multi-tenant isolation.
 * All data operations go through repositories which handle tenant filtering.
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getCustomers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCustomerOrders: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCustomerInvoices: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getSalesOrders: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSalesOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createSalesOrder: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateSalesOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const confirmSalesOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const cancelSalesOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getInvoices: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createInvoice: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createInvoiceFromOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const voidInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getQuotations: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createQuotation: (req: TenantRequest, res: Response) => Promise<void>;
export declare const convertQuotationToOrder: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getSalesDashboard: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getSalesReport: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getLeads: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getLeadById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createLead: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const convertLeadToOpportunity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getOpportunities: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getOpportunityById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createOpportunity: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateOpportunity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteOpportunity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const acceptQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const shipOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deliverOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCreditNotes: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCreditNoteById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createCreditNote: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateCreditNote: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteCreditNote: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getReceipts: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getReceiptById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createReceipt: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCommissions: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCommissionById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createCommission: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateCommission: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteCommission: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPricingRules: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getPricingRuleById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createPricingRule: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updatePricingRule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deletePricingRule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Post a sales invoice to the General Ledger
 * Creates: DR Accounts Receivable, CR Revenue, CR VAT Output
 */
export declare const postInvoiceToGL: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get GL posting status for an invoice
 */
export declare const getInvoiceGLStatus: (req: TenantRequest, res: Response) => Promise<void>;
/**
 * Record a payment received and post to GL
 */
export declare const recordPaymentReceived: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=sales.controller.v2.d.ts.map