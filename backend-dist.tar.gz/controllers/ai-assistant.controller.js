"use strict";
/**
 * AI Assistant Controller
 * Handle AI agent interactions
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.financeAssistant = exports.complianceAssistant = exports.salesAssistant = exports.getAgentCapabilities = exports.updateSuggestionStatus = exports.getSuggestions = exports.archiveConversation = exports.getConversationHistory = exports.getConversations = exports.streamChat = exports.chat = exports.getAgent = exports.getAgents = void 0;
const ai_agent_service_1 = __importDefault(require("../services/ai-agent.service"));
/**
 * List all available AI agents
 */
const getAgents = async (req, res) => {
    try {
        const agents = await ai_agent_service_1.default.listAgents();
        res.json(agents);
    }
    catch (error) {
        console.error('Error fetching agents:', error);
        res.status(500).json({ error: 'Failed to fetch agents' });
    }
};
exports.getAgents = getAgents;
/**
 * Get specific agent details
 */
const getAgent = async (req, res) => {
    try {
        const { agentCode } = req.params;
        const agent = await ai_agent_service_1.default.getAgent(agentCode);
        if (!agent) {
            return res.status(404).json({ error: 'Agent not found' });
        }
        res.json(agent);
    }
    catch (error) {
        console.error('Error fetching agent:', error);
        res.status(500).json({ error: 'Failed to fetch agent' });
    }
};
exports.getAgent = getAgent;
/**
 * Chat with an AI agent
 */
const chat = async (req, res) => {
    try {
        const { agentCode } = req.params;
        const { message, contextData } = req.body;
        const tenantId = req.user.tenantId;
        const userId = req.user.userId;
        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }
        const result = await ai_agent_service_1.default.chatWithAgent(agentCode, tenantId, userId, message, contextData || {});
        res.json(result);
    }
    catch (error) {
        console.error('Error in chat:', error);
        res.status(500).json({ error: error.message || 'Failed to process chat' });
    }
};
exports.chat = chat;
/**
 * Stream chat with an AI agent (SSE)
 */
const streamChat = async (req, res) => {
    try {
        const { agentCode } = req.params;
        const { message, contextData } = req.body;
        const tenantId = req.user.tenantId;
        const userId = req.user.userId;
        if (!message) {
            return res.status(400).json({ error: 'Message is required' });
        }
        // Set headers for SSE
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        const stream = ai_agent_service_1.default.streamChatWithAgent(agentCode, tenantId, userId, message, contextData || {});
        for await (const chunk of stream) {
            res.write(`data: ${JSON.stringify({ content: chunk })}\n\n`);
        }
        res.write('data: [DONE]\n\n');
        res.end();
    }
    catch (error) {
        console.error('Error in stream chat:', error);
        res.status(500).json({ error: error.message || 'Failed to process chat' });
    }
};
exports.streamChat = streamChat;
/**
 * Get user's conversations
 */
const getConversations = async (req, res) => {
    try {
        const tenantId = req.user.tenantId;
        const userId = req.user.userId;
        const includeArchived = req.query.includeArchived === 'true';
        const conversations = await ai_agent_service_1.default.getUserConversations(tenantId, userId, includeArchived);
        res.json(conversations);
    }
    catch (error) {
        console.error('Error fetching conversations:', error);
        res.status(500).json({ error: 'Failed to fetch conversations' });
    }
};
exports.getConversations = getConversations;
/**
 * Get conversation history
 */
const getConversationHistory = async (req, res) => {
    try {
        const { conversationId } = req.params;
        const limit = parseInt(req.query.limit) || 50;
        const history = await ai_agent_service_1.default.getConversationHistory(conversationId, limit);
        res.json(history);
    }
    catch (error) {
        console.error('Error fetching conversation history:', error);
        res.status(500).json({ error: 'Failed to fetch conversation history' });
    }
};
exports.getConversationHistory = getConversationHistory;
/**
 * Archive a conversation
 */
const archiveConversation = async (req, res) => {
    try {
        const { conversationId } = req.params;
        await ai_agent_service_1.default.archiveConversation(conversationId);
        res.json({ message: 'Conversation archived successfully' });
    }
    catch (error) {
        console.error('Error archiving conversation:', error);
        res.status(500).json({ error: 'Failed to archive conversation' });
    }
};
exports.archiveConversation = archiveConversation;
/**
 * Get AI suggestions for user
 */
const getSuggestions = async (req, res) => {
    try {
        const tenantId = req.user.tenantId;
        const userId = req.user.userId;
        const suggestions = await ai_agent_service_1.default.getUserSuggestions(tenantId, userId);
        res.json(suggestions);
    }
    catch (error) {
        console.error('Error fetching suggestions:', error);
        res.status(500).json({ error: 'Failed to fetch suggestions' });
    }
};
exports.getSuggestions = getSuggestions;
/**
 * Update suggestion status
 */
const updateSuggestionStatus = async (req, res) => {
    try {
        const { suggestionId } = req.params;
        const { status } = req.body;
        if (!['VIEWED', 'ACTIONED', 'DISMISSED'].includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }
        const { Pool } = require('pg');
        const pool = new Pool();
        await pool.query('UPDATE ai_suggestions SET status = $1 WHERE suggestion_id = $2', [status, suggestionId]);
        res.json({ message: 'Suggestion status updated successfully' });
    }
    catch (error) {
        console.error('Error updating suggestion status:', error);
        res.status(500).json({ error: 'Failed to update suggestion status' });
    }
};
exports.updateSuggestionStatus = updateSuggestionStatus;
/**
 * Get agent capabilities
 */
const getAgentCapabilities = async (req, res) => {
    try {
        const { agentCode } = req.params;
        const capabilities = await ai_agent_service_1.default.getAgentCapabilities(agentCode);
        res.json({ capabilities });
    }
    catch (error) {
        console.error('Error fetching capabilities:', error);
        res.status(500).json({ error: 'Failed to fetch capabilities' });
    }
};
exports.getAgentCapabilities = getAgentCapabilities;
/**
 * Sales Assistant - Specific helper endpoints
 */
exports.salesAssistant = {
    /**
     * Analyze customer for upsell opportunities
     */
    analyzeCustomer: async (req, res) => {
        try {
            const { customerId } = req.params;
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const contextData = { customerId, action: 'analyze_customer' };
            const message = `Analyze customer ${customerId} and suggest upsell opportunities based on their purchase history.`;
            const result = await ai_agent_service_1.default.chatWithAgent('SALES_ASSISTANT', tenantId, userId, message, contextData);
            res.json(result);
        }
        catch (error) {
            console.error('Error analyzing customer:', error);
            res.status(500).json({ error: 'Failed to analyze customer' });
        }
    },
    /**
     * Generate quotation with AI assistance
     */
    generateQuotation: async (req, res) => {
        try {
            const { customerId, items } = req.body;
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const contextData = { customerId, items, action: 'generate_quotation' };
            const message = `Create a professional quotation for customer ${customerId} with these items: ${JSON.stringify(items)}`;
            const result = await ai_agent_service_1.default.chatWithAgent('SALES_ASSISTANT', tenantId, userId, message, contextData);
            res.json(result);
        }
        catch (error) {
            console.error('Error generating quotation:', error);
            res.status(500).json({ error: 'Failed to generate quotation' });
        }
    },
    /**
     * Forecast sales
     */
    forecastSales: async (req, res) => {
        try {
            const { period } = req.query; // 'month', 'quarter', 'year'
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const message = `Generate a sales forecast for the next ${period || 'month'} based on historical data and current trends.`;
            const result = await ai_agent_service_1.default.chatWithAgent('SALES_ASSISTANT', tenantId, userId, message, { action: 'forecast_sales', period });
            res.json(result);
        }
        catch (error) {
            console.error('Error forecasting sales:', error);
            res.status(500).json({ error: 'Failed to forecast sales' });
        }
    }
};
/**
 * Compliance Assistant - Specific helper endpoints
 */
exports.complianceAssistant = {
    /**
     * Check compliance status
     */
    checkCompliance: async (req, res) => {
        try {
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const message = 'Check current compliance status and highlight any overdue items or upcoming deadlines.';
            const result = await ai_agent_service_1.default.chatWithAgent('COMPLIANCE_ASSISTANT', tenantId, userId, message, { action: 'check_compliance' });
            res.json(result);
        }
        catch (error) {
            console.error('Error checking compliance:', error);
            res.status(500).json({ error: 'Failed to check compliance' });
        }
    },
    /**
     * Assess risk
     */
    assessRisk: async (req, res) => {
        try {
            const { area } = req.query; // 'financial', 'operational', 'regulatory'
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const message = `Perform a risk assessment for ${area || 'all areas'} and suggest mitigation strategies.`;
            const result = await ai_agent_service_1.default.chatWithAgent('COMPLIANCE_ASSISTANT', tenantId, userId, message, { action: 'assess_risk', area });
            res.json(result);
        }
        catch (error) {
            console.error('Error assessing risk:', error);
            res.status(500).json({ error: 'Failed to assess risk' });
        }
    }
};
/**
 * Finance Assistant - Specific helper endpoints
 */
exports.financeAssistant = {
    /**
     * Explain variance
     */
    explainVariance: async (req, res) => {
        try {
            const { accountCode, period } = req.query;
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const message = `Explain the variance in account ${accountCode} for ${period}. Analyze the contributing factors and suggest corrective actions if needed.`;
            const result = await ai_agent_service_1.default.chatWithAgent('FINANCE_ASSISTANT', tenantId, userId, message, { action: 'explain_variance', accountCode, period });
            res.json(result);
        }
        catch (error) {
            console.error('Error explaining variance:', error);
            res.status(500).json({ error: 'Failed to explain variance' });
        }
    },
    /**
     * Reconcile account
     */
    reconcileAccount: async (req, res) => {
        try {
            const { accountCode } = req.params;
            const tenantId = req.user.tenantId;
            const userId = req.user.userId;
            const message = `Help me reconcile account ${accountCode}. Identify any discrepancies and suggest how to resolve them.`;
            const result = await ai_agent_service_1.default.chatWithAgent('FINANCE_ASSISTANT', tenantId, userId, message, { action: 'reconcile_account', accountCode });
            res.json(result);
        }
        catch (error) {
            console.error('Error reconciling account:', error);
            res.status(500).json({ error: 'Failed to reconcile account' });
        }
    }
};
//# sourceMappingURL=ai-assistant.controller.js.map