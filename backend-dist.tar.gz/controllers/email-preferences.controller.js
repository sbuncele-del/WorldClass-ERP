"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailPreferencesController = void 0;
const email_preferences_service_1 = __importDefault(require("../services/email-preferences.service"));
class EmailPreferencesController {
    /**
     * GET /api/email-preferences
     * Get current user's email preferences
     */
    static async getPreferences(req, res) {
        try {
            if (!req.user || !req.tenant) {
                res.status(401).json({ error: 'Not authenticated' });
                return;
            }
            const preferences = await email_preferences_service_1.default.getUserEmailPreferences(parseInt(req.user.id) || 0, parseInt(req.tenant.id) || 0);
            const categories = email_preferences_service_1.default.getEmailCategories(preferences);
            res.status(200).json({
                success: true,
                data: {
                    preferences,
                    categories,
                },
            });
        }
        catch (error) {
            console.error('Error getting email preferences:', error);
            res.status(500).json({ error: 'Failed to get email preferences' });
        }
    }
    /**
     * PATCH /api/email-preferences
     * Update current user's email preferences
     */
    static async updatePreferences(req, res) {
        try {
            if (!req.user || !req.tenant) {
                res.status(401).json({ error: 'Not authenticated' });
                return;
            }
            const updates = req.body;
            // Validate updates
            const allowedFields = [
                'marketingEmails',
                'productUpdates',
                'paymentNotifications',
                'subscriptionNotifications',
                'inventoryAlerts',
                'teamNotifications',
                'systemNotifications',
                'digestFrequency',
            ];
            const invalidFields = Object.keys(updates).filter((key) => !allowedFields.includes(key));
            if (invalidFields.length > 0) {
                res.status(400).json({
                    error: 'Invalid fields',
                    invalidFields,
                    allowedFields,
                });
                return;
            }
            // Security alerts cannot be disabled
            if (updates.securityAlerts === false) {
                res.status(400).json({
                    error: 'Security alerts cannot be disabled for your safety',
                });
                return;
            }
            const preferences = await email_preferences_service_1.default.updateEmailPreferences(parseInt(req.user.id) || 0, parseInt(req.tenant.id) || 0, updates);
            res.status(200).json({
                success: true,
                message: 'Email preferences updated successfully',
                data: preferences,
            });
        }
        catch (error) {
            console.error('Error updating email preferences:', error);
            res.status(500).json({ error: 'Failed to update email preferences' });
        }
    }
    /**
     * POST /api/email-preferences/unsubscribe-all
     * Unsubscribe from all non-essential emails
     */
    static async unsubscribeAll(req, res) {
        try {
            if (!req.user || !req.tenant) {
                res.status(401).json({ error: 'Not authenticated' });
                return;
            }
            await email_preferences_service_1.default.updateEmailPreferences(parseInt(req.user.id) || 0, parseInt(req.tenant.id) || 0, { unsubscribedAll: true });
            res.status(200).json({
                success: true,
                message: 'Successfully unsubscribed from all non-essential emails',
            });
        }
        catch (error) {
            console.error('Error unsubscribing:', error);
            res.status(500).json({ error: 'Failed to unsubscribe' });
        }
    }
    /**
     * POST /api/email-preferences/resubscribe
     * Resubscribe to emails
     */
    static async resubscribe(req, res) {
        try {
            if (!req.user || !req.tenant) {
                res.status(401).json({ error: 'Not authenticated' });
                return;
            }
            await email_preferences_service_1.default.updateEmailPreferences(parseInt(req.user.id) || 0, parseInt(req.tenant.id) || 0, { unsubscribedAll: false });
            res.status(200).json({
                success: true,
                message: 'Successfully resubscribed to emails',
            });
        }
        catch (error) {
            console.error('Error resubscribing:', error);
            res.status(500).json({ error: 'Failed to resubscribe' });
        }
    }
    /**
     * GET /api/email-preferences/unsubscribe/:token
     * One-click unsubscribe via token (public, no auth required)
     */
    static async unsubscribeViaToken(req, res) {
        try {
            const { token } = req.params;
            if (!token) {
                res.status(400).json({ error: 'Token is required' });
                return;
            }
            const result = await email_preferences_service_1.default.processUnsubscribe(token);
            if (!result.success) {
                res.status(400).json({
                    error: 'Invalid or expired unsubscribe link',
                });
                return;
            }
            res.status(200).json({
                success: true,
                message: result.category
                    ? `Successfully unsubscribed from ${result.category} emails`
                    : 'Successfully unsubscribed from all non-essential emails',
                data: {
                    category: result.category,
                    email: result.email,
                },
            });
        }
        catch (error) {
            console.error('Error processing unsubscribe:', error);
            res.status(500).json({ error: 'Failed to process unsubscribe' });
        }
    }
    /**
     * GET /api/email-preferences/categories
     * Get all available email categories with descriptions
     */
    static async getCategories(req, res) {
        try {
            if (!req.user || !req.tenant) {
                res.status(401).json({ error: 'Not authenticated' });
                return;
            }
            const preferences = await email_preferences_service_1.default.getUserEmailPreferences(parseInt(req.user.id) || 0, parseInt(req.tenant.id) || 0);
            const categories = email_preferences_service_1.default.getEmailCategories(preferences);
            res.status(200).json({
                success: true,
                data: categories,
            });
        }
        catch (error) {
            console.error('Error getting email categories:', error);
            res.status(500).json({ error: 'Failed to get email categories' });
        }
    }
}
exports.EmailPreferencesController = EmailPreferencesController;
exports.default = EmailPreferencesController;
//# sourceMappingURL=email-preferences.controller.js.map