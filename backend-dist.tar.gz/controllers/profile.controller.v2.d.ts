/**
 * Profile Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure user profile management.
 * Personal settings, preferences, and account management.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class ProfileControllerV2 {
    /**
     * Get current user profile
     * GET /api/v2/profile
     */
    static getProfile(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update profile
     * PUT /api/v2/profile
     */
    static updateProfile(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Change password
     * PUT /api/v2/profile/password
     */
    static changePassword(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update avatar
     * PUT /api/v2/profile/avatar
     */
    static updateAvatar(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get user preferences
     * GET /api/v2/profile/preferences
     */
    static getPreferences(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update user preferences
     * PUT /api/v2/profile/preferences
     */
    static updatePreferences(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get notification settings
     * GET /api/v2/profile/notifications
     */
    static getNotificationSettings(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update notification settings
     * PUT /api/v2/profile/notifications
     */
    static updateNotificationSettings(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get active sessions
     * GET /api/v2/profile/sessions
     */
    static getSessions(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Terminate a session
     * DELETE /api/v2/profile/sessions/:sessionId
     */
    static terminateSession(req: TenantRequest, res: Response): Promise<void>;
}
export default ProfileControllerV2;
//# sourceMappingURL=profile.controller.v2.d.ts.map