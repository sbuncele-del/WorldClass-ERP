/**
 * Import Entries Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure journal entry import from CSV/Excel.
 * Validation, mapping, and batch creation.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class ImportEntriesControllerV2 {
    /**
     * Validate import file
     * POST /api/v2/financial/import-entries/validate
     */
    static validateImport(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Execute import (create journal entries)
     * POST /api/v2/financial/import-entries/execute
     */
    static executeImport(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get import templates
     * GET /api/v2/financial/import-entries/templates
     */
    static getImportTemplates(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Save import template
     * POST /api/v2/financial/import-entries/templates
     */
    static saveImportTemplate(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get import history
     * GET /api/v2/financial/import-entries/history
     */
    static getImportHistory(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Download sample CSV template
     * GET /api/v2/financial/import-entries/sample
     */
    static downloadSample(req: TenantRequest, res: Response): Promise<void>;
}
export default ImportEntriesControllerV2;
//# sourceMappingURL=import-entries.controller.v2.d.ts.map