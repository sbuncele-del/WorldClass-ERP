import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getAllTimeEntries: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getTimeEntryById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const approveTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const rejectTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTimesheet: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPendingApprovals: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=practice-time-tracking.controller.v2.d.ts.map