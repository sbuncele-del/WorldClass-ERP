import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getAllTasks: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getTaskById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMyTasks: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=practice-tasks.controller.v2.d.ts.map