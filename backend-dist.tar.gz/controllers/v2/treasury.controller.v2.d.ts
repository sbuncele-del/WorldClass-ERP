/**
 * Treasury Management Controller V2
 *
 * Cash management and treasury operations:
 * - Treasury accounts & cash position
 * - Cash forecasting
 * - Investments & returns tracking
 * - FX rates
 * - Payment orders
 * - Liquidity metrics
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
/**
 * Get treasury accounts
 * GET /api/v2/treasury/accounts
 */
export declare function getTreasuryAccounts(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get cash position
 * GET /api/v2/treasury/cash-position
 */
export declare function getCashPosition(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get cash forecasts
 * GET /api/v2/treasury/forecasts
 */
export declare function getCashForecasts(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create cash forecast
 * POST /api/v2/treasury/forecasts
 */
export declare function createCashForecast(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get investments
 * GET /api/v2/treasury/investments
 */
export declare function getInvestments(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create investment
 * POST /api/v2/treasury/investments
 */
export declare function createInvestment(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get treasury transactions
 * GET /api/v2/treasury/transactions
 */
export declare function getTreasuryTransactions(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get FX rates
 * GET /api/v2/treasury/fx-rates
 */
export declare function getFXRates(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get payment orders
 * GET /api/v2/treasury/payment-orders
 */
export declare function getPaymentOrders(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create payment order
 * POST /api/v2/treasury/payment-orders
 */
export declare function createPaymentOrder(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get liquidity metrics
 * GET /api/v2/treasury/liquidity-metrics
 */
export declare function getLiquidityMetrics(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get treasury dashboard summary
 * GET /api/v2/treasury/dashboard
 */
export declare function getTreasuryDashboard(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=treasury.controller.v2.d.ts.map