import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getAllProjects: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getProjectById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectTeam: (req: TenantRequest, res: Response) => Promise<void>;
export declare const addTeamMember: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const removeTeamMember: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectHealth: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=practice-projects.controller.v2.d.ts.map