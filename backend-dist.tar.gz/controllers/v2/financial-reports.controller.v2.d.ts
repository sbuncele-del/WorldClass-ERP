/**
 * Financial Reports Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure financial reporting including:
 * - Income Statement
 * - Balance Sheet
 * - Cash Flow Statement
 *
 * CRITICAL: All queries include tenant_id filtering to prevent data breach
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare function generateIncomeStatement(req: TenantRequest, res: Response): Promise<void>;
export declare function getIncomeStatementAccountDetails(req: TenantRequest, res: Response): Promise<void>;
export declare function generateBalanceSheet(req: TenantRequest, res: Response): Promise<void>;
export declare function getBalanceSheetAccountDetails(req: TenantRequest, res: Response): Promise<void>;
export declare function getFinancialRatios(req: TenantRequest, res: Response): Promise<void>;
export declare function generateCashFlowStatement(req: TenantRequest, res: Response): Promise<void>;
export declare function exportIncomeStatementToPDF(req: TenantRequest, res: Response): Promise<void>;
export declare function exportBalanceSheetToPDF(req: TenantRequest, res: Response): Promise<void>;
export declare function exportCashFlowToPDF(req: TenantRequest, res: Response): Promise<void>;
//# sourceMappingURL=financial-reports.controller.v2.d.ts.map