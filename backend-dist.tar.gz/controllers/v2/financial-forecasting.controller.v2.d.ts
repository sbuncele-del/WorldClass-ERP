/**
 * Financial Forecasting Controller v2 - Tenant-Hardened
 *
 * Budget and forecasting management with full multi-tenant isolation.
 *
 * Features:
 * - Budget scenarios management
 * - Budget CRUD with line items
 * - Budget vs Actual analysis
 * - Variance reporting
 * - Forecast generation (linear regression)
 * - Dashboard analytics
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenantId?: string;
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
    };
}
/**
 * GET /api/v2/financial/forecasting/scenarios
 * Get all budget scenarios for tenant
 */
export declare function getBudgetScenarios(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/financial/forecasting/scenarios
 * Create a new budget scenario
 */
export declare function createBudgetScenario(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/financial/forecasting/scenarios/:id
 * Get a specific budget scenario
 */
export declare function getBudgetScenario(req: TenantRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/financial/forecasting/scenarios/:id
 * Update a budget scenario
 */
export declare function updateBudgetScenario(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/financial/forecasting/scenarios/:id
 * Delete a budget scenario
 */
export declare function deleteBudgetScenario(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/financial/forecasting/budgets
 * Get all budgets with optional filters
 */
export declare function getBudgets(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/financial/forecasting/budgets/:id
 * Get a single budget by ID with all its lines
 */
export declare function getBudgetById(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/financial/forecasting/budgets
 * Create a new budget with lines
 */
export declare function createBudget(req: TenantRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/financial/forecasting/budgets/:id
 * Update an existing budget
 */
export declare function updateBudget(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/financial/forecasting/budgets/:id
 * Delete a budget
 */
export declare function deleteBudget(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/financial/forecasting/budgets/:budget_id/vs-actual
 * Get budget vs actual comparison
 */
export declare function getBudgetVsActual(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/financial/forecasting/variance-analysis
 * Get variance analysis
 */
export declare function getVarianceAnalysis(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/financial/forecasting/generate
 * Generate forecast for an account using linear regression
 */
export declare function generateForecast(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/financial/forecasting/dashboard
 * Get dashboard summary for budget performance
 */
export declare function getBudgetDashboard(req: TenantRequest, res: Response): Promise<void>;
declare const _default: {
    getBudgetScenarios: typeof getBudgetScenarios;
    createBudgetScenario: typeof createBudgetScenario;
    getBudgetScenario: typeof getBudgetScenario;
    updateBudgetScenario: typeof updateBudgetScenario;
    deleteBudgetScenario: typeof deleteBudgetScenario;
    getBudgets: typeof getBudgets;
    getBudgetById: typeof getBudgetById;
    createBudget: typeof createBudget;
    updateBudget: typeof updateBudget;
    deleteBudget: typeof deleteBudget;
    getBudgetVsActual: typeof getBudgetVsActual;
    getVarianceAnalysis: typeof getVarianceAnalysis;
    generateForecast: typeof generateForecast;
    getBudgetDashboard: typeof getBudgetDashboard;
};
export default _default;
//# sourceMappingURL=financial-forecasting.controller.v2.d.ts.map