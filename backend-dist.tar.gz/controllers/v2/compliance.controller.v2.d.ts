/**
 * Compliance & Governance Controller V2
 *
 * Tenant-hardened compliance management including:
 * - Regulatory frameworks & requirements
 * - Risk management & register
 * - Policy management & acknowledgments
 * - Incident tracking
 * - Training management
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
/**
 * Get regulatory frameworks
 * GET /api/v2/compliance/frameworks
 */
export declare function getRegulatoryFrameworks(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get compliance requirements
 * GET /api/v2/compliance/requirements
 */
export declare function getComplianceRequirements(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get compliance status records
 * GET /api/v2/compliance/status
 */
export declare function getComplianceStatus(req: TenantRequest, res: Response): Promise<void>;
/**
 * Update compliance status
 * PUT /api/v2/compliance/status/:id
 */
export declare function updateComplianceStatus(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get risk register
 * GET /api/v2/compliance/risks
 */
export declare function getRisks(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create risk
 * POST /api/v2/compliance/risks
 */
export declare function createRisk(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get risk categories
 * GET /api/v2/compliance/risk-categories
 */
export declare function getRiskCategories(_req: TenantRequest, res: Response): Promise<void>;
/**
 * Get policies
 * GET /api/v2/compliance/policies
 */
export declare function getPolicies(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create policy
 * POST /api/v2/compliance/policies
 */
export declare function createPolicy(req: TenantRequest, res: Response): Promise<void>;
/**
 * Acknowledge policy
 * POST /api/v2/compliance/policies/:id/acknowledge
 */
export declare function acknowledgePolicy(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get policy categories
 * GET /api/v2/compliance/policy-categories
 */
export declare function getPolicyCategories(_req: TenantRequest, res: Response): Promise<void>;
/**
 * Get incidents
 * GET /api/v2/compliance/incidents
 */
export declare function getIncidents(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create incident
 * POST /api/v2/compliance/incidents
 */
export declare function createIncident(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get incident types
 * GET /api/v2/compliance/incident-types
 */
export declare function getIncidentTypes(_req: TenantRequest, res: Response): Promise<void>;
/**
 * Get training courses
 * GET /api/v2/compliance/training/courses
 */
export declare function getTrainingCourses(req: TenantRequest, res: Response): Promise<void>;
/**
 * Record training completion
 * POST /api/v2/compliance/training/completions
 */
export declare function recordTrainingCompletion(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get user training history
 * GET /api/v2/compliance/training/history/:userId
 */
export declare function getUserTrainingHistory(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=compliance.controller.v2.d.ts.map