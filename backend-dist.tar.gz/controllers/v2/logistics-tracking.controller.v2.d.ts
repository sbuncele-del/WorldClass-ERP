/**
 * Vehicle Tracking Controller V2
 *
 * Tenant-hardened vehicle tracking and GPS provider management
 * Handles real-time positions, provider configuration, and alerts
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
    };
}
/**
 * GET /api/v2/logistics/tracking/positions
 * Get all current vehicle positions (tenant-scoped)
 */
export declare function getAllPositions(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/tracking/positions/:vehicleId
 * Get position for specific vehicle (tenant-scoped)
 */
export declare function getVehiclePosition(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/tracking/history/:vehicleId
 * Get position history for a vehicle (tenant-scoped)
 */
export declare function getPositionHistory(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/tracking/refresh
 * Force refresh positions from all providers (tenant-scoped)
 */
export declare function refreshPositions(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/tracking/providers
 * Get all configured tracking providers (tenant-scoped)
 */
export declare function listProviders(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/tracking/providers
 * Add or update tracking provider (tenant-scoped)
 */
export declare function upsertProvider(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/logistics/tracking/providers/:providerId
 * Delete a tracking provider (tenant-scoped)
 */
export declare function deleteProvider(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/tracking/alerts
 * Get tracking alerts (tenant-scoped)
 */
export declare function getAlerts(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/tracking/alerts/:alertId/resolve
 * Resolve a tracking alert (tenant-scoped)
 */
export declare function resolveAlert(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/tracking/stats
 * Get tracking statistics (tenant-scoped)
 */
export declare function getTrackingStats(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=logistics-tracking.controller.v2.d.ts.map