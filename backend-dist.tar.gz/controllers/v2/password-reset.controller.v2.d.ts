/**
 * Password Reset Controller V2
 *
 * Handles password reset flows:
 * - Request password reset
 * - Verify reset token
 * - Reset password with token
 * - Validate password strength
 *
 * Note: Password reset flows are typically pre-auth and don't require tenant context.
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
/**
 * Request password reset
 * POST /api/v2/auth/password/reset-request
 */
export declare function requestPasswordReset(req: TenantRequest, res: Response): Promise<void>;
/**
 * Verify reset token
 * POST /api/v2/auth/password/verify-token
 */
export declare function verifyToken(req: TenantRequest, res: Response): Promise<void>;
/**
 * Reset password
 * POST /api/v2/auth/password/reset
 */
export declare function resetPasswordHandler(req: TenantRequest, res: Response): Promise<void>;
/**
 * Validate password strength
 * POST /api/v2/auth/password/validate
 */
export declare function validatePassword(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=password-reset.controller.v2.d.ts.map