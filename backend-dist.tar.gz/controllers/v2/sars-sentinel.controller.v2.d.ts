/**
 * SARS Sentinel Controller V2
 *
 * South African Revenue Service (SARS) compliance management:
 * - Correspondence tracking with deadlines
 * - Workflow automation
 * - Submission history
 * - Deadline calendar
 *
 * Multi-tenant support for accounting practices managing multiple clients.
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
/**
 * Get all SARS correspondence
 * GET /api/v2/sars-sentinel/correspondence
 */
export declare function getCorrespondence(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get correspondence by ID
 * GET /api/v2/sars-sentinel/correspondence/:id
 */
export declare function getCorrespondenceById(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create SARS correspondence
 * POST /api/v2/sars-sentinel/correspondence
 */
export declare function createCorrespondence(req: TenantRequest, res: Response): Promise<void>;
/**
 * Update correspondence
 * PUT /api/v2/sars-sentinel/correspondence/:id
 */
export declare function updateCorrespondence(req: TenantRequest, res: Response): Promise<void>;
/**
 * Add comment to correspondence
 * POST /api/v2/sars-sentinel/correspondence/:id/comments
 */
export declare function addComment(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get dashboard statistics
 * GET /api/v2/sars-sentinel/dashboard/stats
 */
export declare function getDashboardStats(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create workflow for correspondence
 * POST /api/v2/sars-sentinel/correspondence/:id/workflows
 */
export declare function createWorkflow(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get workflow steps
 * GET /api/v2/sars-sentinel/workflows/:workflowId/steps
 */
export declare function getWorkflowSteps(req: TenantRequest, res: Response): Promise<void>;
/**
 * Complete workflow step
 * POST /api/v2/sars-sentinel/workflows/steps/:stepId/complete
 */
export declare function completeWorkflowStep(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get submission history
 * GET /api/v2/sars-sentinel/submissions
 */
export declare function getSubmissionHistory(req: TenantRequest, res: Response): Promise<void>;
/**
 * Record submission
 * POST /api/v2/sars-sentinel/submissions
 */
export declare function recordSubmission(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get correspondence types
 * GET /api/v2/sars-sentinel/correspondence-types
 */
export declare function getCorrespondenceTypes(_req: TenantRequest, res: Response): Promise<void>;
/**
 * Get deadline calendar
 * GET /api/v2/sars-sentinel/deadline-calendar
 */
export declare function getDeadlineCalendar(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=sars-sentinel.controller.v2.d.ts.map