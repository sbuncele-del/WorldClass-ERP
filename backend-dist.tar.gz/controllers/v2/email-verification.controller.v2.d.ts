/**
 * Email Verification Controller V2
 *
 * Handles email verification flows:
 * - Send verification email
 * - Verify email token
 * - Resend verification
 * - Check verification status
 *
 * Note: Email verification is typically tenant-aware but some operations
 * can happen before tenant context is established (during signup).
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
/**
 * Send verification email
 * POST /api/v2/email/verify/send
 */
export declare function sendVerification(req: TenantRequest, res: Response): Promise<void>;
/**
 * Verify email token
 * POST /api/v2/email/verify
 */
export declare function verifyEmail(req: TenantRequest, res: Response): Promise<void>;
/**
 * Resend verification email
 * POST /api/v2/email/verify/resend
 */
export declare function resendVerification(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get verification status
 * GET /api/v2/email/verify/status/:userId
 */
export declare function getStatus(req: TenantRequest, res: Response): Promise<void>;
/**
 * Check if email is verified
 * GET /api/v2/email/verify/check/:userId
 */
export declare function checkVerified(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=email-verification.controller.v2.d.ts.map