/**
 * Logistics Trips Controller V2
 *
 * Tenant-hardened trip management for logistics module
 * Handles trip CRUD, status updates, and dashboard statistics
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
    };
}
/**
 * GET /api/v2/logistics/trips
 * Get all trips with optional filters (tenant-scoped)
 */
export declare function listTrips(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/trips/:id
 * Get single trip details (tenant-scoped)
 */
export declare function getTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/trips
 * Create new trip (tenant-scoped)
 */
export declare function createTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/logistics/trips/:id
 * Update trip (tenant-scoped)
 */
export declare function updateTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/logistics/trips/:id
 * Delete trip (tenant-scoped)
 */
export declare function deleteTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/trips/:id/start
 * Start a trip (tenant-scoped)
 */
export declare function startTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/trips/:id/complete
 * Complete a trip (tenant-scoped)
 */
export declare function completeTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/trips/:id/cancel
 * Cancel a trip (tenant-scoped)
 */
export declare function cancelTrip(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/trips/stats/dashboard
 * Get trip statistics for dashboard (tenant-scoped)
 */
export declare function getDashboardStats(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/trips/recent
 * Get recent trips for quick view (tenant-scoped)
 */
export declare function getRecentTrips(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=logistics-trips.controller.v2.d.ts.map