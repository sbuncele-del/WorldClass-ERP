/**
 * Routes, Incidents & Geofences Controller V2
 *
 * Tenant-hardened logistics management:
 * - Routes CRUD
 * - Incidents tracking
 * - Geofence management & events
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
/**
 * Get routes with pagination
 * GET /api/v2/logistics/routes
 */
export declare function getRoutes(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get route by ID
 * GET /api/v2/logistics/routes/:id
 */
export declare function getRouteById(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create route
 * POST /api/v2/logistics/routes
 */
export declare function createRoute(req: TenantRequest, res: Response): Promise<void>;
/**
 * Update route
 * PUT /api/v2/logistics/routes/:id
 */
export declare function updateRoute(req: TenantRequest, res: Response): Promise<void>;
/**
 * Delete route
 * DELETE /api/v2/logistics/routes/:id
 */
export declare function deleteRoute(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get logistics incidents
 * GET /api/v2/logistics/incidents
 */
export declare function getIncidents(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get incident by ID
 * GET /api/v2/logistics/incidents/:id
 */
export declare function getIncidentById(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create incident
 * POST /api/v2/logistics/incidents
 */
export declare function createIncident(req: TenantRequest, res: Response): Promise<void>;
/**
 * Update incident
 * PUT /api/v2/logistics/incidents/:id
 */
export declare function updateIncident(req: TenantRequest, res: Response): Promise<void>;
/**
 * Delete incident
 * DELETE /api/v2/logistics/incidents/:id
 */
export declare function deleteIncident(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get geofences
 * GET /api/v2/logistics/geofences
 */
export declare function getGeofences(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get geofence by ID
 * GET /api/v2/logistics/geofences/:id
 */
export declare function getGeofenceById(req: TenantRequest, res: Response): Promise<void>;
/**
 * Create geofence
 * POST /api/v2/logistics/geofences
 */
export declare function createGeofence(req: TenantRequest, res: Response): Promise<void>;
/**
 * Update geofence
 * PUT /api/v2/logistics/geofences/:id
 */
export declare function updateGeofence(req: TenantRequest, res: Response): Promise<void>;
/**
 * Delete geofence
 * DELETE /api/v2/logistics/geofences/:id
 */
export declare function deleteGeofence(req: TenantRequest, res: Response): Promise<void>;
/**
 * Get geofence events
 * GET /api/v2/logistics/geofences/events
 */
export declare function getGeofenceEvents(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=routes-incidents-geofences.controller.v2.d.ts.map