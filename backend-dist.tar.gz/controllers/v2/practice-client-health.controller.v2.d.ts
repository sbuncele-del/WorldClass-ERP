import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getClient360: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getAllClientHealth: (req: TenantRequest, res: Response) => Promise<void>;
export declare const calculateHealthScore: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const logInteraction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getInteractions: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getHealthHistory: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=practice-client-health.controller.v2.d.ts.map