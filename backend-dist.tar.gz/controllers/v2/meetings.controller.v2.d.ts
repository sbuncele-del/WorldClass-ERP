/**
 * Meetings Controller V2
 *
 * Tenant-hardened video conferencing API using Daily.co
 * Used by the Communications Hub for video meeting features.
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
        name?: string;
    };
}
/**
 * GET /api/v2/meetings/status
 * Check if video conferencing is configured
 */
export declare function getMeetingStatus(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/meetings/instant
 * Create an instant meeting (start immediately)
 */
export declare function createInstantMeeting(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/meetings/schedule
 * Schedule a meeting for a future time
 */
export declare function scheduleMeeting(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/meetings/room
 * Create a custom meeting room
 */
export declare function createRoom(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/meetings/rooms
 * List all meeting rooms for tenant
 */
export declare function listRooms(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/meetings/room/:name
 * Get a specific room by name
 */
export declare function getRoom(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/meetings/room/:name
 * Delete a meeting room
 */
export declare function deleteRoom(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/meetings/token
 * Create a meeting token for joining a room
 */
export declare function createToken(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/meetings/invite
 * Create a guest invitation link
 */
export declare function createInvite(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/meetings/logs/:roomName
 * Get meeting logs/analytics for a room
 */
export declare function getMeetingLogs(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/meetings/usage
 * Get tenant's meeting usage statistics
 */
export declare function getUsageStats(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=meetings.controller.v2.d.ts.map