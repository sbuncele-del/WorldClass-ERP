/**
 * AI Chat Controller V2
 *
 * Tenant-hardened AI assistant API
 * Handles chat, conversations, sessions, and suggestions
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        name?: string;
    };
}
/**
 * POST /api/v2/ai/chat
 * Send a message to the AI assistant (tenant-scoped)
 */
export declare function chat(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/ai/confirm
 * Confirm a pending AI action (tenant-scoped)
 */
export declare function confirmAction(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/ai/cancel
 * Cancel a pending AI action (tenant-scoped)
 */
export declare function cancelAction(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/ai/conversation/:sessionId
 * Get conversation history (tenant-scoped)
 */
export declare function getConversation(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/ai/conversation/:sessionId
 * Clear conversation history (tenant-scoped)
 */
export declare function clearConversation(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/ai/conversations
 * List all conversations for user (tenant-scoped)
 */
export declare function listConversations(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/ai/usage/:sessionId
 * Get token usage for billing (tenant-scoped)
 */
export declare function getUsage(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/ai/suggestions
 * Get AI-generated suggestions (tenant-scoped by module context)
 */
export declare function getSuggestions(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/ai/status
 * Check AI service status (tenant-scoped)
 */
export declare function getStatus(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=ai-chat.controller.v2.d.ts.map