/**
 * Delivery Controller v2 - Tenant-Hardened
 *
 * Proof of Delivery (POD) verification system with SMS-based customer verification,
 * file uploads, and delivery completion workflow.
 *
 * Features:
 * - SMS verification codes sent to customers
 * - POD file upload management
 * - Delivery completion with invoice generation
 * - Full audit trail via delivery_events
 */
import { Request, Response } from 'express';
import { Pool } from 'pg';
interface AuthenticatedRequest extends Request {
    tenantId?: string;
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
    };
    pool?: Pool;
    tenantPool?: Pool;
}
/**
 * POST /api/v2/delivery/initiate-verification
 * Initiates delivery verification by sending SMS code to customer
 */
export declare function initiateVerification(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/delivery/verify-code
 * Customer enters the code to verify delivery
 */
export declare function verifyCode(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/delivery/resend-code
 * Resend verification code if customer didn't receive it
 */
export declare function resendCode(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/delivery/upload-pod
 * Upload proof of delivery documents/photos
 */
export declare function uploadPOD(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/delivery/complete
 * Final delivery confirmation after verification and POD upload
 */
export declare function completeDelivery(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/delivery/status/:tripId
 * Get current delivery verification status
 */
export declare function getDeliveryStatus(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/delivery/events/:tripId
 * Get delivery event history/audit trail
 */
export declare function getDeliveryEvents(req: AuthenticatedRequest, res: Response): Promise<void>;
declare const _default: {
    initiateVerification: typeof initiateVerification;
    verifyCode: typeof verifyCode;
    resendCode: typeof resendCode;
    uploadPOD: typeof uploadPOD;
    completeDelivery: typeof completeDelivery;
    getDeliveryStatus: typeof getDeliveryStatus;
    getDeliveryEvents: typeof getDeliveryEvents;
};
export default _default;
//# sourceMappingURL=delivery.controller.v2.d.ts.map