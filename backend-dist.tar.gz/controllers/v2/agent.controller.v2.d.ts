/**
 * AI Agent Controller v2 - Tenant-Hardened
 *
 * API endpoints for the Actionable AI Agent that can execute business actions.
 *
 * Features:
 * - Main chat interface for authenticated users
 * - Demo chat for landing page (no auth)
 * - Conversation history management
 * - Available actions discovery
 * - Session management
 */
import { Request, Response } from 'express';
interface AuthenticatedRequest extends Request {
    tenantId?: string;
    tenant?: {
        id: string;
    };
}
/**
 * POST /api/v2/agent/chat
 * Main chat endpoint for the AI agent
 */
export declare function chat(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/agent/demo
 * Demo chat endpoint (no auth required for landing page)
 */
export declare function demoChat(req: Request, res: Response): Promise<void>;
/**
 * GET /api/v2/agent/conversation/:sessionId
 * Get conversation history for a session
 */
export declare function getConversation(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/agent/conversation/:sessionId
 * Clear conversation history
 */
export declare function clearConversation(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/agent/actions
 * Get list of available actions the agent can perform
 */
export declare function getAvailableActions(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/agent/execute
 * Execute a specific action directly (bypasses NLP)
 */
export declare function executeAction(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/agent/sessions
 * Get all active sessions for current user
 * Note: The current ActionableAIAgent doesn't expose session listing,
 * so this returns an empty array. Future implementation could add this.
 */
export declare function getSessions(req: AuthenticatedRequest, res: Response): Promise<void>;
declare const _default: {
    chat: typeof chat;
    demoChat: typeof demoChat;
    getConversation: typeof getConversation;
    clearConversation: typeof clearConversation;
    getAvailableActions: typeof getAvailableActions;
    executeAction: typeof executeAction;
    getSessions: typeof getSessions;
};
export default _default;
//# sourceMappingURL=agent.controller.v2.d.ts.map