/**
 * Projects Controller v2 - Tenant-Hardened
 *
 * Project and task management with full multi-tenant isolation.
 *
 * Features:
 * - Project CRUD with status tracking
 * - Task management per project
 * - Progress tracking and reporting
 * - Workspace dashboard with KPIs
 */
import { Request, Response } from 'express';
interface AuthenticatedRequest extends Request {
    tenantId?: string;
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
    };
}
/**
 * GET /api/v2/projects/workspace
 * Get project workspace dashboard with KPIs
 */
export declare function getWorkspace(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/projects
 * List all projects with filtering and pagination
 */
export declare function listProjects(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/projects/:id
 * Get single project with tasks
 */
export declare function getProject(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/projects
 * Create a new project
 */
export declare function createProject(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/projects/:id
 * Update an existing project
 */
export declare function updateProject(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/projects/:id
 * Soft delete a project
 */
export declare function deleteProject(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/projects/:projectId/tasks
 * List tasks for a project
 */
export declare function listTasks(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/projects/:projectId/tasks
 * Create a new task
 */
export declare function createTask(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/projects/tasks/:taskId
 * Update a task
 */
export declare function updateTask(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/projects/tasks/:taskId
 * Delete a task
 */
export declare function deleteTask(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/projects/tasks/:taskId
 * Get single task details
 */
export declare function getTask(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/projects/reports/summary
 * Get project portfolio summary report
 */
export declare function getProjectSummary(req: AuthenticatedRequest, res: Response): Promise<void>;
declare const _default: {
    getWorkspace: typeof getWorkspace;
    listProjects: typeof listProjects;
    getProject: typeof getProject;
    createProject: typeof createProject;
    updateProject: typeof updateProject;
    deleteProject: typeof deleteProject;
    listTasks: typeof listTasks;
    createTask: typeof createTask;
    updateTask: typeof updateTask;
    deleteTask: typeof deleteTask;
    getTask: typeof getTask;
    getProjectSummary: typeof getProjectSummary;
};
export default _default;
//# sourceMappingURL=projects.controller.v2.d.ts.map