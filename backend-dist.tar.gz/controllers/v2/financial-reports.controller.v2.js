"use strict";
/**
 * Financial Reports Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure financial reporting including:
 * - Income Statement
 * - Balance Sheet
 * - Cash Flow Statement
 *
 * CRITICAL: All queries include tenant_id filtering to prevent data breach
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateIncomeStatement = generateIncomeStatement;
exports.getIncomeStatementAccountDetails = getIncomeStatementAccountDetails;
exports.generateBalanceSheet = generateBalanceSheet;
exports.getBalanceSheetAccountDetails = getBalanceSheetAccountDetails;
exports.getFinancialRatios = getFinancialRatios;
exports.generateCashFlowStatement = generateCashFlowStatement;
exports.exportIncomeStatementToPDF = exportIncomeStatementToPDF;
exports.exportBalanceSheetToPDF = exportBalanceSheetToPDF;
exports.exportCashFlowToPDF = exportCashFlowToPDF;
const database_1 = __importDefault(require("../../config/database"));
// Helper to extract tenant context
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: req.user?.id };
}
// ============================================================================
// INCOME STATEMENT (V2 - Tenant Isolated)
// ============================================================================
async function generateIncomeStatement(req, res) {
    try {
        const { tenantId } = getTenantContext(req);
        const { start_date, end_date, period = 'monthly', compare_prior = false } = req.query;
        // Calculate date range
        const dateRange = calculateDateRange(period, start_date, end_date);
        // Fetch accounts with tenant filtering
        const [revenueAccounts, cogsAccounts, expenseAccounts, otherIncomeAccounts, otherExpenseAccounts, taxAccounts] = await Promise.all([
            fetchAccountBalances(tenantId, dateRange.start_date, dateRange.end_date, '4000', '4999'),
            fetchAccountBalances(tenantId, dateRange.start_date, dateRange.end_date, '5000', '5999'),
            fetchAccountBalances(tenantId, dateRange.start_date, dateRange.end_date, '6000', '6999'),
            fetchAccountBalances(tenantId, dateRange.start_date, dateRange.end_date, '7000', '7499'),
            fetchAccountBalances(tenantId, dateRange.start_date, dateRange.end_date, '7500', '7999'),
            fetchAccountBalances(tenantId, dateRange.start_date, dateRange.end_date, '8000', '8999')
        ]);
        // Calculate totals
        const revenueTotalAmount = revenueAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const cogsTotalAmount = cogsAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const grossProfit = revenueTotalAmount - cogsTotalAmount;
        const expenseTotalAmount = expenseAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const operatingProfit = grossProfit - expenseTotalAmount;
        const otherIncomeTotalAmount = otherIncomeAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const otherExpenseTotalAmount = otherExpenseAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const netProfitBeforeTax = operatingProfit + otherIncomeTotalAmount - otherExpenseTotalAmount;
        const taxExpense = taxAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const netProfitAfterTax = netProfitBeforeTax - taxExpense;
        const incomeStatement = {
            period: dateRange,
            revenue: { title: 'Revenue', accounts: revenueAccounts, subtotal: revenueTotalAmount },
            cost_of_sales: { title: 'Cost of Sales', accounts: cogsAccounts, subtotal: cogsTotalAmount },
            gross_profit: grossProfit,
            operating_expenses: { title: 'Operating Expenses', accounts: expenseAccounts, subtotal: expenseTotalAmount },
            operating_profit: operatingProfit,
            other_income: { title: 'Other Income', accounts: otherIncomeAccounts, subtotal: otherIncomeTotalAmount },
            other_expenses: { title: 'Other Expenses', accounts: otherExpenseAccounts, subtotal: otherExpenseTotalAmount },
            net_profit_before_tax: netProfitBeforeTax,
            tax_expense: taxExpense,
            net_profit_after_tax: netProfitAfterTax
        };
        // Add comparison if requested
        let comparison = undefined;
        if (compare_prior === 'true') {
            const priorRange = calculatePriorPeriod(dateRange);
            comparison = await generateIncomeStatementComparison(tenantId, priorRange);
        }
        res.json({
            success: true,
            data: { ...incomeStatement, comparison }
        });
    }
    catch (error) {
        console.error('Error generating income statement:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate income statement',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}
async function getIncomeStatementAccountDetails(req, res) {
    try {
        const { tenantId } = getTenantContext(req);
        const { accountCode } = req.params;
        const { start_date, end_date } = req.query;
        const query = `
      SELECT 
        jel.journal_entry_id,
        je.journal_date,
        je.description as entry_description,
        jel.description as line_description,
        jel.debit_amount,
        jel.credit_amount,
        (jel.debit_amount - jel.credit_amount) as net_amount
      FROM accounting.journal_entry_lines jel
      INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
      WHERE jel.tenant_id = $1
        AND jel.account_code = $2
        AND je.journal_date BETWEEN $3 AND $4
        AND je.is_posted = true
      ORDER BY je.journal_date, je.entry_id
    `;
        const result = await database_1.default.query(query, [tenantId, accountCode, start_date, end_date]);
        res.json({
            success: true,
            data: {
                account_code: accountCode,
                transactions: result.rows,
                total: result.rows.reduce((sum, row) => sum + parseFloat(row.net_amount || 0), 0)
            }
        });
    }
    catch (error) {
        console.error('Error fetching account details:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch account details' });
    }
}
// ============================================================================
// BALANCE SHEET (V2 - Tenant Isolated)
// ============================================================================
async function generateBalanceSheet(req, res) {
    try {
        const { tenantId } = getTenantContext(req);
        const { as_of_date, compare_prior = false } = req.query;
        const asOfDate = as_of_date || new Date().toISOString().split('T')[0];
        const label = `As of ${new Date(asOfDate).toLocaleDateString('en-ZA', {
            day: 'numeric', month: 'long', year: 'numeric'
        })}`;
        // Fetch all account categories with tenant filtering
        const [currentAssets, nonCurrentAssets, currentLiabilities, nonCurrentLiabilities, equityAccounts] = await Promise.all([
            fetchBalanceSheetAccounts(tenantId, asOfDate, '1000', '1499'),
            fetchBalanceSheetAccounts(tenantId, asOfDate, '1500', '1999'),
            fetchBalanceSheetAccounts(tenantId, asOfDate, '2000', '2499'),
            fetchBalanceSheetAccounts(tenantId, asOfDate, '2500', '2999'),
            fetchBalanceSheetAccounts(tenantId, asOfDate, '3000', '3999')
        ]);
        // Calculate retained earnings
        const retainedEarnings = await calculateRetainedEarnings(tenantId, asOfDate);
        if (retainedEarnings !== 0) {
            equityAccounts.push({
                account_code: '3900',
                account_name: 'Retained Earnings (Current Year)',
                amount: retainedEarnings
            });
        }
        // Calculate totals
        const currentAssetsTotal = currentAssets.reduce((sum, acc) => sum + acc.amount, 0);
        const nonCurrentAssetsTotal = nonCurrentAssets.reduce((sum, acc) => sum + acc.amount, 0);
        const totalAssets = currentAssetsTotal + nonCurrentAssetsTotal;
        const currentLiabilitiesTotal = currentLiabilities.reduce((sum, acc) => sum + acc.amount, 0);
        const nonCurrentLiabilitiesTotal = nonCurrentLiabilities.reduce((sum, acc) => sum + acc.amount, 0);
        const totalLiabilities = currentLiabilitiesTotal + nonCurrentLiabilitiesTotal;
        const totalEquity = equityAccounts.reduce((sum, acc) => sum + acc.amount, 0);
        const totalLiabilitiesEquity = totalLiabilities + totalEquity;
        const variance = totalAssets - totalLiabilitiesEquity;
        const isBalanced = Math.abs(variance) < 0.01;
        const balanceSheet = {
            as_of_date: asOfDate,
            label,
            current_assets: { title: 'Current Assets', accounts: currentAssets, subtotal: currentAssetsTotal },
            non_current_assets: { title: 'Non-Current Assets', accounts: nonCurrentAssets, subtotal: nonCurrentAssetsTotal },
            total_assets: totalAssets,
            current_liabilities: { title: 'Current Liabilities', accounts: currentLiabilities, subtotal: currentLiabilitiesTotal },
            non_current_liabilities: { title: 'Non-Current Liabilities', accounts: nonCurrentLiabilities, subtotal: nonCurrentLiabilitiesTotal },
            total_liabilities: totalLiabilities,
            equity: { title: 'Equity', accounts: equityAccounts, subtotal: totalEquity },
            total_equity: totalEquity,
            total_liabilities_equity: totalLiabilitiesEquity,
            is_balanced: isBalanced,
            variance
        };
        res.json({ success: true, data: balanceSheet });
    }
    catch (error) {
        console.error('Error generating balance sheet:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate balance sheet',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}
async function getBalanceSheetAccountDetails(req, res) {
    try {
        const { tenantId } = getTenantContext(req);
        const { accountCode } = req.params;
        const { as_of_date } = req.query;
        const query = `
      SELECT 
        jel.journal_entry_id,
        je.journal_date,
        je.description as entry_description,
        jel.description as line_description,
        jel.debit_amount,
        jel.credit_amount,
        (jel.debit_amount - jel.credit_amount) as net_amount
      FROM accounting.journal_entry_lines jel
      INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
      WHERE jel.tenant_id = $1
        AND jel.account_code = $2
        AND je.journal_date <= $3
        AND je.is_posted = true
      ORDER BY je.journal_date DESC, je.entry_id DESC
      LIMIT 100
    `;
        const result = await database_1.default.query(query, [tenantId, accountCode, as_of_date]);
        res.json({
            success: true,
            data: {
                account_code: accountCode,
                transactions: result.rows,
                balance: result.rows.reduce((sum, row) => sum + parseFloat(row.net_amount || 0), 0)
            }
        });
    }
    catch (error) {
        console.error('Error fetching balance sheet account details:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch account details' });
    }
}
async function getFinancialRatios(req, res) {
    try {
        const { tenantId } = getTenantContext(req);
        const { as_of_date } = req.query;
        const asOfDate = as_of_date || new Date().toISOString().split('T')[0];
        // Fetch balances for ratio calculations
        const [currentAssets, currentLiabilities, totalAssets, totalLiabilities, inventory, revenue, netIncome] = await Promise.all([
            getAccountRangeBalance(tenantId, asOfDate, '1000', '1499'),
            getAccountRangeBalance(tenantId, asOfDate, '2000', '2499'),
            getAccountRangeBalance(tenantId, asOfDate, '1000', '1999'),
            getAccountRangeBalance(tenantId, asOfDate, '2000', '2999'),
            getAccountRangeBalance(tenantId, asOfDate, '1300', '1399'),
            getYTDAccountBalance(tenantId, asOfDate, '4000', '4999'),
            calculateRetainedEarnings(tenantId, asOfDate)
        ]);
        const equity = totalAssets - totalLiabilities;
        const quickAssets = currentAssets - inventory;
        const ratios = {
            liquidity: {
                current_ratio: currentLiabilities !== 0 ? currentAssets / currentLiabilities : 0,
                quick_ratio: currentLiabilities !== 0 ? quickAssets / currentLiabilities : 0,
                working_capital: currentAssets - currentLiabilities
            },
            leverage: {
                debt_to_equity: equity !== 0 ? totalLiabilities / equity : 0,
                debt_to_assets: totalAssets !== 0 ? totalLiabilities / totalAssets : 0,
                equity_ratio: totalAssets !== 0 ? equity / totalAssets : 0
            },
            profitability: {
                return_on_assets: totalAssets !== 0 ? (netIncome / totalAssets) * 100 : 0,
                return_on_equity: equity !== 0 ? (netIncome / equity) * 100 : 0,
                profit_margin: revenue !== 0 ? (netIncome / revenue) * 100 : 0
            }
        };
        res.json({ success: true, data: ratios });
    }
    catch (error) {
        console.error('Error calculating financial ratios:', error);
        res.status(500).json({ success: false, message: 'Failed to calculate financial ratios' });
    }
}
// ============================================================================
// CASH FLOW STATEMENT (V2 - Tenant Isolated)
// ============================================================================
async function generateCashFlowStatement(req, res) {
    try {
        const { tenantId } = getTenantContext(req);
        const { start_date, end_date, period = 'monthly', method = 'indirect' } = req.query;
        const dateRange = calculateDateRange(period, start_date, end_date);
        // Get net income for the period
        const netIncome = await calculateNetIncome(tenantId, dateRange.start_date, dateRange.end_date);
        // Operating Activities (Indirect Method)
        const operatingItems = [
            { description: 'Net Income', amount: netIncome }
        ];
        // Add back non-cash expenses
        const depreciation = await getDepreciation(tenantId, dateRange.start_date, dateRange.end_date);
        if (depreciation !== 0) {
            operatingItems.push({ description: 'Add: Depreciation and Amortization', amount: depreciation });
        }
        // Changes in working capital
        const arChange = await getAccountChange(tenantId, dateRange.start_date, dateRange.end_date, '1200', '1299');
        if (arChange !== 0) {
            operatingItems.push({
                description: arChange > 0 ? 'Decrease in Accounts Receivable' : 'Increase in Accounts Receivable',
                amount: -arChange
            });
        }
        const inventoryChange = await getAccountChange(tenantId, dateRange.start_date, dateRange.end_date, '1300', '1399');
        if (inventoryChange !== 0) {
            operatingItems.push({
                description: inventoryChange > 0 ? 'Decrease in Inventory' : 'Increase in Inventory',
                amount: -inventoryChange
            });
        }
        const apChange = await getAccountChange(tenantId, dateRange.start_date, dateRange.end_date, '2100', '2199');
        if (apChange !== 0) {
            operatingItems.push({
                description: apChange > 0 ? 'Increase in Accounts Payable' : 'Decrease in Accounts Payable',
                amount: apChange
            });
        }
        const operatingSubtotal = operatingItems.reduce((sum, item) => sum + item.amount, 0);
        // Investing Activities
        const investingItems = [];
        const ppeChange = await getAccountChange(tenantId, dateRange.start_date, dateRange.end_date, '1500', '1599');
        if (ppeChange !== 0) {
            investingItems.push({
                description: ppeChange > 0 ? 'Purchase of Property, Plant & Equipment' : 'Sale of Property, Plant & Equipment',
                amount: -ppeChange
            });
        }
        const investingSubtotal = investingItems.reduce((sum, item) => sum + item.amount, 0);
        // Financing Activities
        const financingItems = [];
        const debtChange = await getAccountChange(tenantId, dateRange.start_date, dateRange.end_date, '2500', '2999');
        if (debtChange !== 0) {
            financingItems.push({
                description: debtChange > 0 ? 'Proceeds from Long-term Debt' : 'Repayment of Long-term Debt',
                amount: debtChange
            });
        }
        const financingSubtotal = financingItems.reduce((sum, item) => sum + item.amount, 0);
        // Cash balances
        const beginningCash = await getAccountRangeBalance(tenantId, dateRange.start_date, '1000', '1099');
        const endingCash = await getAccountRangeBalance(tenantId, dateRange.end_date, '1000', '1099');
        const netCashFlow = operatingSubtotal + investingSubtotal + financingSubtotal;
        const cashFlowStatement = {
            period: dateRange,
            method: method,
            operating_activities: { title: 'Operating Activities', items: operatingItems, subtotal: operatingSubtotal },
            investing_activities: { title: 'Investing Activities', items: investingItems, subtotal: investingSubtotal },
            financing_activities: { title: 'Financing Activities', items: financingItems, subtotal: financingSubtotal },
            net_cash_flow: netCashFlow,
            beginning_cash: beginningCash,
            ending_cash: endingCash,
            cash_reconciliation: {
                calculated_ending: beginningCash + netCashFlow,
                actual_ending: endingCash,
                is_reconciled: Math.abs((beginningCash + netCashFlow) - endingCash) < 0.01,
                variance: endingCash - (beginningCash + netCashFlow)
            }
        };
        res.json({ success: true, data: cashFlowStatement });
    }
    catch (error) {
        console.error('Error generating cash flow statement:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to generate cash flow statement',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
}
// ============================================================================
// PDF EXPORT PLACEHOLDERS
// ============================================================================
async function exportIncomeStatementToPDF(req, res) {
    res.json({ success: true, message: 'PDF export will be implemented in Phase 2', download_url: null });
}
async function exportBalanceSheetToPDF(req, res) {
    res.json({ success: true, message: 'PDF export will be implemented in Phase 2', download_url: null });
}
async function exportCashFlowToPDF(req, res) {
    res.json({ success: true, message: 'PDF export will be implemented in Phase 2', download_url: null });
}
// ============================================================================
// HELPER FUNCTIONS (All include tenant_id)
// ============================================================================
function calculateDateRange(period, start_date, end_date) {
    const now = new Date();
    if (start_date && end_date) {
        return { start_date, end_date, label: `${start_date} to ${end_date}` };
    }
    switch (period) {
        case 'monthly': {
            const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
            return {
                start_date: startOfMonth.toISOString().split('T')[0],
                end_date: endOfMonth.toISOString().split('T')[0],
                label: startOfMonth.toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' })
            };
        }
        case 'quarterly': {
            const quarter = Math.floor(now.getMonth() / 3);
            const startOfQuarter = new Date(now.getFullYear(), quarter * 3, 1);
            const endOfQuarter = new Date(now.getFullYear(), quarter * 3 + 3, 0);
            return {
                start_date: startOfQuarter.toISOString().split('T')[0],
                end_date: endOfQuarter.toISOString().split('T')[0],
                label: `Q${quarter + 1} ${now.getFullYear()}`
            };
        }
        case 'annual':
        default: {
            const startOfYear = new Date(now.getFullYear(), 0, 1);
            const endOfYear = new Date(now.getFullYear(), 11, 31);
            return {
                start_date: startOfYear.toISOString().split('T')[0],
                end_date: endOfYear.toISOString().split('T')[0],
                label: `FY ${now.getFullYear()}`
            };
        }
    }
}
function calculatePriorPeriod(currentRange) {
    const startDate = new Date(currentRange.start_date);
    const endDate = new Date(currentRange.end_date);
    const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    const priorEnd = new Date(startDate);
    priorEnd.setDate(priorEnd.getDate() - 1);
    const priorStart = new Date(priorEnd);
    priorStart.setDate(priorStart.getDate() - daysDiff);
    return {
        start_date: priorStart.toISOString().split('T')[0],
        end_date: priorEnd.toISOString().split('T')[0],
        label: `Prior Period`
    };
}
async function fetchAccountBalances(tenantId, startDate, endDate, startCode, endCode) {
    const query = `
    SELECT 
      coa.account_code,
      coa.account_name,
      coa.parent_account_code as parent_code,
      COALESCE(SUM(
        CASE 
          WHEN coa.normal_balance = 'CREDIT' THEN jel.credit_amount - jel.debit_amount
          ELSE jel.debit_amount - jel.credit_amount
        END
      ), 0) as amount
    FROM accounting.chart_of_accounts coa
    LEFT JOIN accounting.journal_entry_lines jel ON coa.account_code = jel.account_code AND jel.tenant_id = coa.tenant_id
    LEFT JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
      AND je.journal_date BETWEEN $2 AND $3
      AND je.is_posted = true
    WHERE coa.tenant_id = $1
      AND coa.account_code >= $4
      AND coa.account_code <= $5
      AND coa.is_active = true
    GROUP BY coa.account_code, coa.account_name, coa.parent_account_code
    HAVING COALESCE(SUM(
      CASE 
        WHEN coa.normal_balance = 'CREDIT' THEN jel.credit_amount - jel.debit_amount
        ELSE jel.debit_amount - jel.credit_amount
      END
    ), 0) != 0
    ORDER BY coa.account_code
  `;
    const result = await database_1.default.query(query, [tenantId, startDate, endDate, startCode, endCode]);
    return result.rows.map(row => ({
        account_code: row.account_code,
        account_name: row.account_name,
        amount: parseFloat(row.amount) || 0,
        parent_code: row.parent_code
    }));
}
async function fetchBalanceSheetAccounts(tenantId, asOfDate, startCode, endCode) {
    const query = `
    SELECT 
      coa.account_code,
      coa.account_name,
      coa.parent_account_code as parent_code,
      COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as amount
    FROM accounting.chart_of_accounts coa
    LEFT JOIN accounting.journal_entry_lines jel ON coa.account_code = jel.account_code AND jel.tenant_id = coa.tenant_id
    LEFT JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
      AND je.journal_date <= $2
      AND je.is_posted = true
    WHERE coa.tenant_id = $1
      AND coa.account_code >= $3
      AND coa.account_code <= $4
      AND coa.is_active = true
    GROUP BY coa.account_code, coa.account_name, coa.parent_account_code
    HAVING COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) != 0
    ORDER BY coa.account_code
  `;
    const result = await database_1.default.query(query, [tenantId, asOfDate, startCode, endCode]);
    return result.rows.map(row => ({
        account_code: row.account_code,
        account_name: row.account_name,
        amount: parseFloat(row.amount) || 0,
        parent_code: row.parent_code
    }));
}
async function calculateRetainedEarnings(tenantId, asOfDate) {
    const year = new Date(asOfDate).getFullYear();
    const startOfYear = `${year}-01-01`;
    const query = `
    SELECT 
      COALESCE(SUM(
        CASE 
          WHEN coa.account_code >= '4000' AND coa.account_code <= '4999' THEN jel.credit_amount - jel.debit_amount
          WHEN coa.account_code >= '5000' AND coa.account_code <= '8999' THEN jel.debit_amount - jel.credit_amount
          ELSE 0
        END
      ), 0) as net_income
    FROM accounting.journal_entry_lines jel
    INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
    INNER JOIN accounting.chart_of_accounts coa ON jel.account_code = coa.account_code AND coa.tenant_id = jel.tenant_id
    WHERE jel.tenant_id = $1
      AND je.journal_date BETWEEN $2 AND $3
      AND je.is_posted = true
      AND coa.account_code >= '4000'
  `;
    const result = await database_1.default.query(query, [tenantId, startOfYear, asOfDate]);
    return parseFloat(result.rows[0]?.net_income) || 0;
}
async function calculateNetIncome(tenantId, startDate, endDate) {
    const query = `
    SELECT 
      COALESCE(SUM(
        CASE 
          WHEN coa.account_code >= '4000' AND coa.account_code <= '4999' THEN jel.credit_amount - jel.debit_amount
          WHEN coa.account_code >= '5000' AND coa.account_code <= '8999' THEN -(jel.debit_amount - jel.credit_amount)
          ELSE 0
        END
      ), 0) as net_income
    FROM accounting.journal_entry_lines jel
    INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
    INNER JOIN accounting.chart_of_accounts coa ON jel.account_code = coa.account_code AND coa.tenant_id = jel.tenant_id
    WHERE jel.tenant_id = $1
      AND je.journal_date BETWEEN $2 AND $3
      AND je.is_posted = true
  `;
    const result = await database_1.default.query(query, [tenantId, startDate, endDate]);
    return parseFloat(result.rows[0]?.net_income) || 0;
}
async function getAccountRangeBalance(tenantId, asOfDate, startCode, endCode) {
    const query = `
    SELECT COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as balance
    FROM accounting.journal_entry_lines jel
    INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
    WHERE jel.tenant_id = $1
      AND jel.account_code >= $3
      AND jel.account_code <= $4
      AND je.journal_date <= $2
      AND je.is_posted = true
  `;
    const result = await database_1.default.query(query, [tenantId, asOfDate, startCode, endCode]);
    return parseFloat(result.rows[0]?.balance) || 0;
}
async function getYTDAccountBalance(tenantId, asOfDate, startCode, endCode) {
    const year = new Date(asOfDate).getFullYear();
    const startOfYear = `${year}-01-01`;
    const query = `
    SELECT COALESCE(SUM(jel.credit_amount - jel.debit_amount), 0) as balance
    FROM accounting.journal_entry_lines jel
    INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
    WHERE jel.tenant_id = $1
      AND jel.account_code >= $3
      AND jel.account_code <= $4
      AND je.journal_date BETWEEN $2 AND $5
      AND je.is_posted = true
  `;
    const result = await database_1.default.query(query, [tenantId, startOfYear, startCode, endCode, asOfDate]);
    return parseFloat(result.rows[0]?.balance) || 0;
}
async function getAccountChange(tenantId, startDate, endDate, startCode, endCode) {
    const beginningBalance = await getAccountRangeBalance(tenantId, startDate, startCode, endCode);
    const endingBalance = await getAccountRangeBalance(tenantId, endDate, startCode, endCode);
    return endingBalance - beginningBalance;
}
async function getDepreciation(tenantId, startDate, endDate) {
    // Depreciation is typically account 6100-6199 or similar
    const query = `
    SELECT COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as depreciation
    FROM accounting.journal_entry_lines jel
    INNER JOIN accounting.journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = jel.tenant_id
    WHERE jel.tenant_id = $1
      AND jel.account_code LIKE '61%'
      AND je.journal_date BETWEEN $2 AND $3
      AND je.is_posted = true
  `;
    const result = await database_1.default.query(query, [tenantId, startDate, endDate]);
    return parseFloat(result.rows[0]?.depreciation) || 0;
}
async function generateIncomeStatementComparison(tenantId, priorRange) {
    const [revenue, cogs, expenses] = await Promise.all([
        fetchAccountBalances(tenantId, priorRange.start_date, priorRange.end_date, '4000', '4999'),
        fetchAccountBalances(tenantId, priorRange.start_date, priorRange.end_date, '5000', '5999'),
        fetchAccountBalances(tenantId, priorRange.start_date, priorRange.end_date, '6000', '6999')
    ]);
    const revenueTotal = revenue.reduce((sum, acc) => sum + acc.amount, 0);
    const cogsTotal = cogs.reduce((sum, acc) => sum + acc.amount, 0);
    const expensesTotal = expenses.reduce((sum, acc) => sum + acc.amount, 0);
    const grossProfit = revenueTotal - cogsTotal;
    const operatingProfit = grossProfit - expensesTotal;
    return {
        period: priorRange,
        revenue_total: revenueTotal,
        cogs_total: cogsTotal,
        gross_profit: grossProfit,
        operating_expenses_total: expensesTotal,
        operating_profit: operatingProfit,
        net_profit: operatingProfit
    };
}
//# sourceMappingURL=financial-reports.controller.v2.js.map