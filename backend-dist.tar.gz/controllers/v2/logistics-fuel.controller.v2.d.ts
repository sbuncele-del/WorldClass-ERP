/**
 * Logistics Fuel Controller V2
 *
 * Tenant-hardened fuel transaction management with automatic GL integration
 * Creates double-entry accounting records for fuel purchases
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
    };
}
/**
 * POST /api/v2/logistics/fuel/transactions
 * Log a fuel transaction and create journal entry (tenant-scoped)
 */
export declare function createFuelTransaction(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/fuel/transactions
 * Get all fuel transactions (tenant-scoped)
 */
export declare function listFuelTransactions(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/fuel/transactions/:id
 * Get single fuel transaction (tenant-scoped)
 */
export declare function getFuelTransaction(req: TenantRequest, res: Response): Promise<void>;
/**
 * DELETE /api/v2/logistics/fuel/transactions/:id
 * Delete fuel transaction and reverse journal entry (tenant-scoped)
 */
export declare function deleteFuelTransaction(req: TenantRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/logistics/fuel/stats
 * Get fuel consumption statistics (tenant-scoped)
 */
export declare function getFuelStats(req: TenantRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/logistics/fuel/reconcile
 * Reconcile fuel transactions with card statements (tenant-scoped)
 */
export declare function reconcileFuelTransactions(req: TenantRequest, res: Response): Promise<void>;
export {};
//# sourceMappingURL=logistics-fuel.controller.v2.d.ts.map