"use strict";
/**
 * Password Reset Controller V2
 *
 * Handles password reset flows:
 * - Request password reset
 * - Verify reset token
 * - Reset password with token
 * - Validate password strength
 *
 * Note: Password reset flows are typically pre-auth and don't require tenant context.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestPasswordReset = requestPasswordReset;
exports.verifyToken = verifyToken;
exports.resetPasswordHandler = resetPasswordHandler;
exports.validatePassword = validatePassword;
const password_reset_service_1 = require("../../services/password-reset.service");
/**
 * Request password reset
 * POST /api/v2/auth/password/reset-request
 */
async function requestPasswordReset(req, res) {
    try {
        const { email } = req.body;
        if (!email) {
            res.status(400).json({
                success: false,
                error: 'Email is required'
            });
            return;
        }
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            res.status(400).json({
                success: false,
                error: 'Invalid email format'
            });
            return;
        }
        try {
            await (0, password_reset_service_1.sendPasswordResetEmail)(email);
        }
        catch (err) {
            // Log but don't expose errors to prevent email enumeration
            console.error('[PasswordReset V2] Error sending reset email:', err);
        }
        // Always return success to prevent email enumeration
        res.json({
            success: true,
            data: {
                message: 'If an account exists with that email, a password reset link has been sent.'
            }
        });
    }
    catch (error) {
        console.error('[PasswordReset V2] Request password reset error:', error);
        // Still return success to prevent email enumeration
        res.json({
            success: true,
            data: {
                message: 'If an account exists with that email, a password reset link has been sent.'
            }
        });
    }
}
/**
 * Verify reset token
 * POST /api/v2/auth/password/verify-token
 */
async function verifyToken(req, res) {
    try {
        const { token } = req.body;
        if (!token) {
            res.status(400).json({
                success: false,
                error: 'Token is required'
            });
            return;
        }
        const result = await (0, password_reset_service_1.verifyResetToken)(token);
        if (result.success) {
            res.json({
                success: true,
                data: { message: result.message }
            });
        }
        else {
            res.status(400).json({
                success: false,
                error: result.message
            });
        }
    }
    catch (error) {
        console.error('[PasswordReset V2] Verify token error:', error);
        res.status(500).json({ success: false, error: 'Failed to verify token' });
    }
}
/**
 * Reset password
 * POST /api/v2/auth/password/reset
 */
async function resetPasswordHandler(req, res) {
    try {
        const { token, password, confirmPassword } = req.body;
        if (!token || !password || !confirmPassword) {
            res.status(400).json({
                success: false,
                error: 'Token, password, and confirm password are required'
            });
            return;
        }
        // Check passwords match
        if (password !== confirmPassword) {
            res.status(400).json({
                success: false,
                error: 'Passwords do not match'
            });
            return;
        }
        // Validate password strength
        const validation = (0, password_reset_service_1.validatePasswordStrength)(password);
        if (!validation.valid) {
            res.status(400).json({
                success: false,
                error: 'Password does not meet requirements',
                data: {
                    errors: validation.errors,
                    strength: validation.strength
                }
            });
            return;
        }
        // Reset password
        const result = await (0, password_reset_service_1.resetPassword)(token, password);
        if (result.success) {
            res.json({
                success: true,
                data: { message: result.message }
            });
        }
        else {
            res.status(400).json({
                success: false,
                error: result.message
            });
        }
    }
    catch (error) {
        console.error('[PasswordReset V2] Reset password error:', error);
        res.status(500).json({ success: false, error: 'Failed to reset password' });
    }
}
/**
 * Validate password strength
 * POST /api/v2/auth/password/validate
 */
async function validatePassword(req, res) {
    try {
        const { password } = req.body;
        if (!password) {
            res.status(400).json({
                success: false,
                error: 'Password is required'
            });
            return;
        }
        const validation = (0, password_reset_service_1.validatePasswordStrength)(password);
        res.json({
            success: true,
            data: {
                valid: validation.valid,
                strength: validation.strength,
                errors: validation.errors
            }
        });
    }
    catch (error) {
        console.error('[PasswordReset V2] Validate password error:', error);
        res.status(500).json({ success: false, error: 'Failed to validate password' });
    }
}
//# sourceMappingURL=password-reset.controller.v2.js.map