/**
 * Messages Controller v2 - Tenant-Hardened
 *
 * Internal messaging system for driver-dispatch communication.
 *
 * Features:
 * - Conversation management
 * - Message sending/receiving
 * - Read receipts and unread counts
 * - Emergency/SOS alerts
 * - Attachments support
 */
import { Request, Response } from 'express';
interface AuthenticatedRequest extends Request {
    tenantId?: string;
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        first_name?: string;
        last_name?: string;
    };
}
/**
 * GET /api/v2/messages/conversations
 * Get all conversations for current user
 */
export declare function getConversations(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/messages/conversation/:conversationId
 * Get messages in a conversation
 */
export declare function getConversationMessages(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/messages
 * Send a new message
 */
export declare function sendMessage(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/messages/emergency
 * Send an emergency/SOS message
 */
export declare function sendEmergency(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/messages/:id/read
 * Mark a message as read
 */
export declare function markAsRead(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/messages/unread/count
 * Get unread message count
 */
export declare function getUnreadCount(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * POST /api/v2/messages/driver/check-in
 * Driver check-in/status update
 */
export declare function driverCheckIn(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/messages/driver/status
 * Get current driver status
 */
export declare function getDriverStatus(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * GET /api/v2/messages/dispatch/active-alerts
 * Get active emergency alerts for dispatch
 */
export declare function getActiveAlerts(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/messages/dispatch/alerts/:alertId/acknowledge
 * Acknowledge an emergency alert
 */
export declare function acknowledgeAlert(req: AuthenticatedRequest, res: Response): Promise<void>;
/**
 * PUT /api/v2/messages/dispatch/alerts/:alertId/resolve
 * Resolve an emergency alert
 */
export declare function resolveAlert(req: AuthenticatedRequest, res: Response): Promise<void>;
declare const _default: {
    getConversations: typeof getConversations;
    getConversationMessages: typeof getConversationMessages;
    sendMessage: typeof sendMessage;
    sendEmergency: typeof sendEmergency;
    markAsRead: typeof markAsRead;
    getUnreadCount: typeof getUnreadCount;
    driverCheckIn: typeof driverCheckIn;
    getDriverStatus: typeof getDriverStatus;
    getActiveAlerts: typeof getActiveAlerts;
    acknowledgeAlert: typeof acknowledgeAlert;
    resolveAlert: typeof resolveAlert;
};
export default _default;
//# sourceMappingURL=messages.controller.v2.d.ts.map