import { Request, Response } from 'express';
/**
 * Approval Workflows Controller
 * Handles multi-level approval processes for journal entries
 */
export declare const submitForApproval: (req: Request, res: Response) => Promise<void>;
export declare const approveEntry: (req: Request, res: Response) => Promise<void>;
export declare const rejectEntry: (req: Request, res: Response) => Promise<void>;
export declare const recallEntry: (req: Request, res: Response) => Promise<void>;
export declare const getPendingApprovals: (req: Request, res: Response) => Promise<void>;
export declare const getApprovalHistory: (req: Request, res: Response) => Promise<void>;
export declare const getApprovalStats: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=approval.controller.d.ts.map