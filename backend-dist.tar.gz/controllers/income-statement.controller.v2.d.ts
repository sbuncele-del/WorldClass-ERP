/**
 * Income Statement Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure income statement (P&L) generation.
 * All queries filtered by tenant_id.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class IncomeStatementControllerV2 {
    /**
     * Generate Income Statement (P&L)
     * GET /api/v2/financial/reports/income-statement
     */
    static generateIncomeStatement(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get revenue breakdown
     * GET /api/v2/financial/reports/revenue-breakdown
     */
    static getRevenueBreakdown(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get expense breakdown
     * GET /api/v2/financial/reports/expense-breakdown
     */
    static getExpenseBreakdown(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Export income statement to PDF
     * POST /api/v2/financial/reports/income-statement/export
     */
    static exportToPDF(req: TenantRequest, res: Response): Promise<void>;
}
export default IncomeStatementControllerV2;
//# sourceMappingURL=income-statement.controller.v2.d.ts.map