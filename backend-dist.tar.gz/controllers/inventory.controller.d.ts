/**
 * INVENTORY MANAGEMENT CONTROLLER
 *
 * Handles all inventory operations:
 * - Item master data management
 * - Stock level tracking
 * - Stock movements (receipts, issues, transfers, adjustments)
 * - Inventory valuation (FIFO/LIFO/Weighted Average)
 * - Reorder suggestions
 * - Integration with Purchase and Sales modules
 */
import { Request, Response } from 'express';
export declare const getItemCategories: (req: Request, res: Response) => Promise<void>;
export declare const createItemCategory: (req: Request, res: Response) => Promise<void>;
export declare const updateItemCategory: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getWarehouses: (req: Request, res: Response) => Promise<void>;
export declare const createWarehouse: (req: Request, res: Response) => Promise<void>;
export declare const updateWarehouse: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getItems: (req: Request, res: Response) => Promise<void>;
export declare const getItemById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createItem: (req: Request, res: Response) => Promise<void>;
export declare const updateItem: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockLevels: (req: Request, res: Response) => Promise<void>;
export declare const getStockByItem: (req: Request, res: Response) => Promise<void>;
export declare const getStockMovements: (req: Request, res: Response) => Promise<void>;
export declare const createStockMovement: (req: Request, res: Response) => Promise<void>;
export declare const postStockMovement: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockAdjustments: (req: Request, res: Response) => Promise<void>;
export declare const getStockAdjustmentById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createStockAdjustment: (req: Request, res: Response) => Promise<void>;
export declare const postStockAdjustment: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getReorderSuggestions: (req: Request, res: Response) => Promise<void>;
export declare const generateReorderSuggestions: (req: Request, res: Response) => Promise<void>;
export declare const getStockTakes: (_req: Request, res: Response) => Promise<void>;
export declare const createStockTake: (req: Request, res: Response) => Promise<void>;
export declare const postStockTake: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getStockBatches: (req: Request, res: Response) => Promise<void>;
export declare const getSerialNumbers: (req: Request, res: Response) => Promise<void>;
export declare const getInventoryDashboard: (_req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=inventory.controller.d.ts.map