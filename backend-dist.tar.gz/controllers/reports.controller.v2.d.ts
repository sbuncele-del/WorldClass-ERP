/**
 * Reports Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure report definitions, execution, and scheduling.
 * All queries filtered by tenant_id.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class ReportsControllerV2 {
    /**
     * Get all report definitions
     * GET /api/v2/reports/definitions
     */
    static getReportDefinitions(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get report definition by ID
     * GET /api/v2/reports/definitions/:id
     */
    static getReportDefinitionById(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Create a new report definition
     * POST /api/v2/reports/definitions
     */
    static createReportDefinition(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Execute a report
     * POST /api/v2/reports/execute/:id
     */
    static executeReport(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get report execution history
     * GET /api/v2/reports/history
     */
    static getExecutionHistory(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Schedule a report
     * POST /api/v2/reports/schedule
     */
    static scheduleReport(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get scheduled reports
     * GET /api/v2/reports/schedules
     */
    static getScheduledReports(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Delete a schedule
     * DELETE /api/v2/reports/schedules/:id
     */
    static deleteSchedule(req: TenantRequest, res: Response): Promise<void>;
}
export default ReportsControllerV2;
//# sourceMappingURL=reports.controller.v2.d.ts.map