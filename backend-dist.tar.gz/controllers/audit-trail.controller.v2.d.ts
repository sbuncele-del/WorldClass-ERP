/**
 * Audit Trail Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure audit logging and compliance tracking.
 * Complete audit trail for all data changes.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class AuditTrailControllerV2 {
    /**
     * Get audit trail entries
     * GET /api/v2/audit/trail
     */
    static getAuditTrail(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get entity history (all changes to a specific record)
     * GET /api/v2/audit/entity/:type/:id
     */
    static getEntityHistory(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get user activity
     * GET /api/v2/audit/user-activity/:userId
     */
    static getUserActivity(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get audit summary/statistics
     * GET /api/v2/audit/summary
     */
    static getAuditSummary(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Export audit trail
     * POST /api/v2/audit/export
     */
    static exportAuditTrail(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Log a manual audit entry
     * POST /api/v2/audit/log
     */
    static logAuditEntry(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get data changes comparison
     * GET /api/v2/audit/compare/:id
     */
    static getChangeComparison(req: TenantRequest, res: Response): Promise<void>;
}
export default AuditTrailControllerV2;
//# sourceMappingURL=audit-trail.controller.v2.d.ts.map