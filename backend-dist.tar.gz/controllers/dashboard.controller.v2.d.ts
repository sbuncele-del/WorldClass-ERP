/**
 * Dashboard Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure dashboard with financial KPIs,
 * metrics, and real-time data visualization.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class DashboardControllerV2 {
    /**
     * Get dashboard statistics
     * GET /api/v2/dashboard/stats
     */
    static getDashboardStats(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get revenue trend
     * GET /api/v2/dashboard/revenue-trend
     */
    static getRevenueTrend(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get expense breakdown
     * GET /api/v2/dashboard/expense-breakdown
     */
    static getExpenseBreakdown(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get recent journal entries
     * GET /api/v2/dashboard/recent-entries
     */
    static getRecentEntries(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get cash position
     * GET /api/v2/dashboard/cash-position
     */
    static getCashPosition(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get AR/AP aging summary
     * GET /api/v2/dashboard/aging-summary
     */
    static getAgingSummary(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get KPI metrics
     * GET /api/v2/dashboard/kpis
     */
    static getKPIs(req: TenantRequest, res: Response): Promise<void>;
}
export default DashboardControllerV2;
//# sourceMappingURL=dashboard.controller.v2.d.ts.map