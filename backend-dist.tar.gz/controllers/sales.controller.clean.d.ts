import { Request, Response } from 'express';
export declare const getLeads: (req: Request, res: Response) => Promise<void>;
export declare const getLeadById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createLead: (req: Request, res: Response) => Promise<void>;
export declare const updateLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const convertLeadToOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getOpportunities: (req: Request, res: Response) => Promise<void>;
declare const _default: {
    getLeads: (req: Request, res: Response) => Promise<void>;
    getLeadById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createLead: (req: Request, res: Response) => Promise<void>;
    updateLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    convertLeadToOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getOpportunities: (req: Request, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=sales.controller.clean.d.ts.map