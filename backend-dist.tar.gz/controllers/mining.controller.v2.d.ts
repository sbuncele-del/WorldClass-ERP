/**
 * Mining Controller V2
 * Tenant-hardened API for mining industry operations
 *
 * Features:
 * - Mining site management
 * - Production tracking
 * - Safety incident reporting
 * - Equipment management
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSites: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSiteById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createSite: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateSite: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProduction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const recordProduction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProduction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSafetyIncidents: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const reportSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getEquipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const registerEquipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateEquipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSites: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSiteById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createSite: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateSite: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProduction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    recordProduction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateProduction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSafetyIncidents: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    reportSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEquipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    registerEquipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateEquipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=mining.controller.v2.d.ts.map