import { Request, Response } from 'express';
export declare const getLeads: (req: Request, res: Response) => Promise<void>;
export declare const getLeadById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const convertLeadToOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getOpportunities: (req: Request, res: Response) => Promise<void>;
export declare const getOpportunityById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getLeads: (req: Request, res: Response) => Promise<void>;
    getLeadById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteLead: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    convertLeadToOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getOpportunities: (req: Request, res: Response) => Promise<void>;
    getOpportunityById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteOpportunity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=sales.controller.complete.d.ts.map