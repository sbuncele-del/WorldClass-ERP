/**
 * Routes, Incidents, and Geofences Controller
 * Full CRUD operations for logistics management
 */
import { Request, Response } from 'express';
export declare function getRoutes(req: Request, res: Response): Promise<void>;
export declare function getRouteById(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createRoute(req: Request, res: Response): Promise<void>;
export declare function updateRoute(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function deleteRoute(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getIncidents(req: Request, res: Response): Promise<void>;
export declare function getIncidentById(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createIncident(req: Request, res: Response): Promise<void>;
export declare function updateIncident(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function deleteIncident(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getGeofences(req: Request, res: Response): Promise<void>;
export declare function getGeofenceById(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createGeofence(req: Request, res: Response): Promise<void>;
export declare function updateGeofence(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function deleteGeofence(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getGeofenceEvents(req: Request, res: Response): Promise<void>;
//# sourceMappingURL=routes-incidents-geofences.controller.d.ts.map