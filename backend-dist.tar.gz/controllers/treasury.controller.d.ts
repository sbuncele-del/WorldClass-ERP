import { Request, Response } from 'express';
/**
 * Treasury Management Controller
 *
 * Cash management, investments, and treasury operations
 */
declare class TreasuryController {
    getTreasuryAccounts(req: Request, res: Response): Promise<void>;
    getCashPosition(req: Request, res: Response): Promise<void>;
    getCashForecasts(req: Request, res: Response): Promise<void>;
    createCashForecast(req: Request, res: Response): Promise<void>;
    getInvestments(req: Request, res: Response): Promise<void>;
    createInvestment(req: Request, res: Response): Promise<void>;
    getTreasuryTransactions(req: Request, res: Response): Promise<void>;
    getFXRates(req: Request, res: Response): Promise<void>;
    getPaymentOrders(req: Request, res: Response): Promise<void>;
    createPaymentOrder(req: Request, res: Response): Promise<void>;
    getLiquidityMetrics(req: Request, res: Response): Promise<void>;
}
declare const _default: TreasuryController;
export default _default;
//# sourceMappingURL=treasury.controller.d.ts.map