/**
 * Approval Workflows Controller V2
 * Tenant-aware handlers for multi-level approval processes
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const submitForApproval: (req: TenantRequest, res: Response) => Promise<void>;
export declare const approveEntry: (req: TenantRequest, res: Response) => Promise<void>;
export declare const rejectEntry: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getPendingApprovals: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getApprovalHistory: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getWorkflows: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createWorkflow: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getWorkflowLevels: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createWorkflowLevel: (req: TenantRequest, res: Response) => Promise<void>;
declare const _default: {
    submitForApproval: (req: TenantRequest, res: Response) => Promise<void>;
    approveEntry: (req: TenantRequest, res: Response) => Promise<void>;
    rejectEntry: (req: TenantRequest, res: Response) => Promise<void>;
    getPendingApprovals: (req: TenantRequest, res: Response) => Promise<void>;
    getApprovalHistory: (req: TenantRequest, res: Response) => Promise<void>;
    getWorkflows: (req: TenantRequest, res: Response) => Promise<void>;
    createWorkflow: (req: TenantRequest, res: Response) => Promise<void>;
    getWorkflowLevels: (req: TenantRequest, res: Response) => Promise<void>;
    createWorkflowLevel: (req: TenantRequest, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=approval.controller.v2.d.ts.map