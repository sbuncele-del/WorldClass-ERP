/**
 * Recurring Entries Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure recurring journal entry management.
 * Automated entry generation and scheduling.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class RecurringEntriesControllerV2 {
    /**
     * Get all recurring entries
     * GET /api/v2/financial/recurring-entries
     */
    static getRecurringEntries(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get recurring entry by ID
     * GET /api/v2/financial/recurring-entries/:id
     */
    static getRecurringEntryById(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Create recurring entry
     * POST /api/v2/financial/recurring-entries
     */
    static createRecurringEntry(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update recurring entry
     * PUT /api/v2/financial/recurring-entries/:id
     */
    static updateRecurringEntry(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Delete recurring entry
     * DELETE /api/v2/financial/recurring-entries/:id
     */
    static deleteRecurringEntry(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Generate entries manually
     * POST /api/v2/financial/recurring-entries/:id/generate
     */
    static generateEntry(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get pending entries (due for generation)
     * GET /api/v2/financial/recurring-entries/pending
     */
    static getPendingEntries(req: TenantRequest, res: Response): Promise<void>;
}
export default RecurringEntriesControllerV2;
//# sourceMappingURL=recurring-entries.controller.v2.d.ts.map