/**
 * Onboarding Controller V2
 * Tenant-hardened API for tenant onboarding workflow
 *
 * Features:
 * - Onboarding status tracking
 * - Step-by-step progress
 * - Complete/skip onboarding
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get onboarding status for current tenant
 */
export declare const getStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update onboarding progress
 */
export declare const update: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Mark onboarding as complete
 */
export declare const complete: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Skip onboarding (use defaults)
 */
export declare const skip: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Reset onboarding (admin function)
 */
export declare const reset: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get onboarding checklist items
 */
export declare const getChecklist: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    update: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    complete: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    skip: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    reset: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getChecklist: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=onboarding.controller.v2.d.ts.map