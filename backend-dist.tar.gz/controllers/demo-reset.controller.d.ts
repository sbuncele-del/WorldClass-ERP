import { Request, Response } from 'express';
/**
 * Demo Reset Controller
 *
 * Provides API endpoints for:
 * - Manual demo tenant reset (for testing/emergency)
 * - Reset status/statistics
 * - Health check
 */
declare class DemoResetController {
    /**
     * Manually trigger demo tenant reset
     * POST /api/demo/reset
     *
     * Security: Should be protected by super admin auth in production
     */
    triggerReset(_req: Request, res: Response): Promise<void>;
    /**
     * Get reset statistics and status
     * GET /api/demo/reset/status
     */
    getResetStatus(_req: Request, res: Response): Promise<void>;
    /**
     * Health check for demo reset service
     * GET /api/demo/reset/health
     */
    healthCheck(_req: Request, res: Response): Promise<void>;
}
declare const _default: DemoResetController;
export default _default;
//# sourceMappingURL=demo-reset.controller.d.ts.map