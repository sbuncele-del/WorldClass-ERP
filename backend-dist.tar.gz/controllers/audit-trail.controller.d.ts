import { Request, Response } from 'express';
/**
 * Audit Trail Controller
 * Tracks and retrieves all system activity for compliance
 */
export declare class AuditTrailController {
    /**
     * Get audit logs with filtering
     */
    getAuditLogs(req: Request, res: Response): Promise<void>;
    /**
     * Get audit log by ID
     */
    getAuditLogById(req: Request, res: Response): Promise<void>;
    /**
     * Get entity history (all changes to a specific entity)
     */
    getEntityHistory(req: Request, res: Response): Promise<void>;
    /**
     * Get user activity
     */
    getUserActivity(req: Request, res: Response): Promise<void>;
    /**
     * Get audit summary statistics
     */
    getAuditSummary(req: Request, res: Response): Promise<void>;
    /**
     * Manual audit log creation (for application-level events)
     */
    createAuditLog(req: Request, res: Response): Promise<void>;
    /**
     * Export audit logs to CSV
     */
    exportAuditLogs(req: Request, res: Response): Promise<void>;
}
declare const _default: AuditTrailController;
export default _default;
//# sourceMappingURL=audit-trail.controller.d.ts.map