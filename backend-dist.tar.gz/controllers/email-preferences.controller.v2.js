"use strict";
/**
 * Email Preferences Controller V2
 * Tenant-hardened API for email preference management
 *
 * Features:
 * - User email preferences
 * - Category management
 * - Unsubscribe/resubscribe
 * - Token-based unsubscribe
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCategories = exports.unsubscribeViaToken = exports.resubscribe = exports.unsubscribeAll = exports.updatePreferences = exports.getPreferences = void 0;
const email_preferences_service_1 = __importDefault(require("../services/email-preferences.service"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    const userEmail = req.user?.email;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '', userEmail: userEmail || '' };
}
/**
 * Get current user's email preferences
 */
const getPreferences = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const preferences = await email_preferences_service_1.default.getUserEmailPreferences(parseInt(userId) || 0, parseInt(tenantId) || 0);
        const categories = email_preferences_service_1.default.getEmailCategories(preferences);
        res.json({
            success: true,
            data: {
                preferences,
                categories
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get email preferences error:', error);
        res.status(500).json({ success: false, error: 'Failed to get email preferences' });
    }
};
exports.getPreferences = getPreferences;
/**
 * Update current user's email preferences
 */
const updatePreferences = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const updates = req.body;
        // Validate updates
        const allowedFields = [
            'marketingEmails',
            'productUpdates',
            'paymentNotifications',
            'subscriptionNotifications',
            'inventoryAlerts',
            'teamNotifications',
            'systemNotifications',
            'digestFrequency'
        ];
        const invalidFields = Object.keys(updates).filter(key => !allowedFields.includes(key));
        if (invalidFields.length > 0) {
            return res.status(400).json({
                success: false,
                error: 'Invalid fields',
                invalidFields,
                allowedFields
            });
        }
        // Security alerts cannot be disabled
        if (updates.securityAlerts === false) {
            return res.status(400).json({
                success: false,
                error: 'Security alerts cannot be disabled for your safety'
            });
        }
        const preferences = await email_preferences_service_1.default.updateEmailPreferences(parseInt(userId) || 0, parseInt(tenantId) || 0, updates);
        res.json({
            success: true,
            message: 'Email preferences updated successfully',
            data: preferences
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update email preferences error:', error);
        res.status(500).json({ success: false, error: 'Failed to update email preferences' });
    }
};
exports.updatePreferences = updatePreferences;
/**
 * Unsubscribe from all non-essential emails
 */
const unsubscribeAll = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        await email_preferences_service_1.default.updateEmailPreferences(parseInt(userId) || 0, parseInt(tenantId) || 0, { unsubscribedAll: true });
        res.json({
            success: true,
            message: 'Successfully unsubscribed from all non-essential emails'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Unsubscribe all error:', error);
        res.status(500).json({ success: false, error: 'Failed to unsubscribe' });
    }
};
exports.unsubscribeAll = unsubscribeAll;
/**
 * Resubscribe to emails
 */
const resubscribe = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        await email_preferences_service_1.default.updateEmailPreferences(parseInt(userId) || 0, parseInt(tenantId) || 0, { unsubscribedAll: false });
        res.json({
            success: true,
            message: 'Successfully resubscribed to emails'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Resubscribe error:', error);
        res.status(500).json({ success: false, error: 'Failed to resubscribe' });
    }
};
exports.resubscribe = resubscribe;
/**
 * One-click unsubscribe via token (public, no auth required)
 * Note: This endpoint doesn't require tenant context as it uses token
 */
const unsubscribeViaToken = async (req, res) => {
    try {
        const { token } = req.params;
        if (!token) {
            return res.status(400).json({ success: false, error: 'Token is required' });
        }
        const result = await email_preferences_service_1.default.processUnsubscribe(token);
        if (!result.success) {
            return res.status(400).json({
                success: false,
                error: 'Invalid or expired unsubscribe link'
            });
        }
        res.json({
            success: true,
            message: result.category
                ? `Successfully unsubscribed from ${result.category} emails`
                : 'Successfully unsubscribed from all non-essential emails',
            data: {
                category: result.category,
                email: result.email
            }
        });
    }
    catch (error) {
        console.error('Unsubscribe via token error:', error);
        res.status(500).json({ success: false, error: 'Failed to process unsubscribe' });
    }
};
exports.unsubscribeViaToken = unsubscribeViaToken;
/**
 * Get all available email categories with descriptions
 */
const getCategories = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const preferences = await email_preferences_service_1.default.getUserEmailPreferences(parseInt(userId) || 0, parseInt(tenantId) || 0);
        const categories = email_preferences_service_1.default.getEmailCategories(preferences);
        res.json({
            success: true,
            data: categories
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get categories error:', error);
        res.status(500).json({ success: false, error: 'Failed to get email categories' });
    }
};
exports.getCategories = getCategories;
exports.default = {
    getPreferences: exports.getPreferences,
    updatePreferences: exports.updatePreferences,
    unsubscribeAll: exports.unsubscribeAll,
    resubscribe: exports.resubscribe,
    unsubscribeViaToken: exports.unsubscribeViaToken,
    getCategories: exports.getCategories
};
//# sourceMappingURL=email-preferences.controller.v2.js.map