/**
 * Email Preferences Controller V2
 * Tenant-hardened API for email preference management
 *
 * Features:
 * - User email preferences
 * - Category management
 * - Unsubscribe/resubscribe
 * - Token-based unsubscribe
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get current user's email preferences
 */
export declare const getPreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update current user's email preferences
 */
export declare const updatePreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Unsubscribe from all non-essential emails
 */
export declare const unsubscribeAll: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Resubscribe to emails
 */
export declare const resubscribe: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * One-click unsubscribe via token (public, no auth required)
 * Note: This endpoint doesn't require tenant context as it uses token
 */
export declare const unsubscribeViaToken: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get all available email categories with descriptions
 */
export declare const getCategories: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getPreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    unsubscribeAll: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    resubscribe: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    unsubscribeViaToken: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getCategories: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=email-preferences.controller.v2.d.ts.map