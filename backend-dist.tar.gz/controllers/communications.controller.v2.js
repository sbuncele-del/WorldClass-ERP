"use strict";
/**
 * Communications Controller V2
 * Tenant-hardened API for internal communications
 *
 * Features:
 * - Announcements
 * - Chat channels & messages
 * - Direct messages
 * - Notifications
 * - Video meetings
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCampaign = exports.getCampaigns = exports.createTemplate = exports.getTemplates = exports.getContacts = exports.sendMessage = exports.getMessages = exports.cancelMeeting = exports.updateMeeting = exports.createMeeting = exports.getMeetings = exports.getMessageUnreadCount = exports.getNotificationUnreadCount = exports.markAllNotificationsRead = exports.markNotificationRead = exports.getNotifications = exports.sendDirectMessage = exports.getDirectMessages = exports.getDirectConversations = exports.sendChannelMessage = exports.getChannelMessages = exports.createChannel = exports.getChannels = exports.deleteAnnouncement = exports.updateAnnouncement = exports.createAnnouncement = exports.getAnnouncements = exports.getWorkspace = void 0;
const database_1 = __importDefault(require("../config/database"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '' };
}
// ============================================================================
// WORKSPACE
// ============================================================================
const getWorkspace = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const [announcementsResult, channelsResult, unreadResult, meetingsResult] = await Promise.all([
            database_1.default.query(`SELECT COUNT(*) as active_announcements
        FROM announcements WHERE tenant_id = $1 AND is_active = true 
        AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)`, [tenantId]),
            database_1.default.query(`SELECT COUNT(*) as total_channels
        FROM chat_channels WHERE tenant_id = $1 AND is_active = true`, [tenantId]),
            database_1.default.query(`SELECT COUNT(*) as unread_notifications
        FROM user_notifications WHERE tenant_id = $1 AND user_id = $2 AND is_read = false`, [tenantId, userId]),
            database_1.default.query(`SELECT COUNT(*) as upcoming_meetings
        FROM video_meetings WHERE tenant_id = $1 
        AND scheduled_start > CURRENT_TIMESTAMP 
        AND scheduled_start < CURRENT_TIMESTAMP + INTERVAL '7 days'`, [tenantId])
        ]);
        res.json({
            success: true,
            data: {
                summary: {
                    activeAnnouncements: parseInt(announcementsResult.rows[0]?.active_announcements || '0'),
                    totalChannels: parseInt(channelsResult.rows[0]?.total_channels || '0'),
                    unreadNotifications: parseInt(unreadResult.rows[0]?.unread_notifications || '0'),
                    upcomingMeetings: parseInt(meetingsResult.rows[0]?.upcoming_meetings || '0')
                }
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Communications workspace error:', error);
        res.status(500).json({ success: false, error: 'Failed to load workspace' });
    }
};
exports.getWorkspace = getWorkspace;
// ============================================================================
// ANNOUNCEMENTS
// ============================================================================
const getAnnouncements = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { priority, includeExpired } = req.query;
        let queryStr = `
      SELECT a.*, u.full_name as author_name
      FROM announcements a
      LEFT JOIN users u ON a.created_by_user_id = u.id
      WHERE a.tenant_id = $1 AND a.is_active = true
    `;
        const params = [tenantId];
        if (includeExpired !== 'true') {
            queryStr += ' AND (a.expires_at IS NULL OR a.expires_at > CURRENT_TIMESTAMP)';
        }
        if (priority) {
            params.push(priority);
            queryStr += ` AND a.priority = $${params.length}`;
        }
        queryStr += ' ORDER BY a.is_pinned DESC, a.created_at DESC';
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get announcements error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch announcements' });
    }
};
exports.getAnnouncements = getAnnouncements;
const createAnnouncement = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { title, content, priority, targetAudience, expiresAt, isPinned } = req.body;
        const result = await database_1.default.query(`INSERT INTO announcements (tenant_id, created_by_user_id, title, content, priority,
        target_audience, expires_at, is_pinned)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *`, [tenantId, userId, title, content, priority || 'normal', targetAudience || 'all',
            expiresAt, isPinned || false]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Announcement posted' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Create announcement error:', error);
        res.status(500).json({ success: false, error: 'Failed to create announcement' });
    }
};
exports.createAnnouncement = createAnnouncement;
const updateAnnouncement = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const { title, content, priority, expiresAt, isPinned, isActive } = req.body;
        const result = await database_1.default.query(`UPDATE announcements SET
        title = COALESCE($3, title),
        content = COALESCE($4, content),
        priority = COALESCE($5, priority),
        expires_at = COALESCE($6, expires_at),
        is_pinned = COALESCE($7, is_pinned),
        is_active = COALESCE($8, is_active),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId, title, content, priority, expiresAt, isPinned, isActive]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Announcement not found' });
        }
        res.json({ success: true, data: result.rows[0], message: 'Announcement updated' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update announcement error:', error);
        res.status(500).json({ success: false, error: 'Failed to update announcement' });
    }
};
exports.updateAnnouncement = updateAnnouncement;
const deleteAnnouncement = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const result = await database_1.default.query(`UPDATE announcements SET is_active = false WHERE id = $1 AND tenant_id = $2 RETURNING id`, [id, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Announcement not found' });
        }
        res.json({ success: true, message: 'Announcement deleted' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Delete announcement error:', error);
        res.status(500).json({ success: false, error: 'Failed to delete announcement' });
    }
};
exports.deleteAnnouncement = deleteAnnouncement;
// ============================================================================
// CHAT CHANNELS
// ============================================================================
const getChannels = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { type } = req.query;
        let queryStr = `
      SELECT c.*, 
        (SELECT COUNT(*) FROM chat_messages m WHERE m.channel_id = c.id) as message_count,
        (SELECT MAX(created_at) FROM chat_messages m WHERE m.channel_id = c.id) as last_message_at
      FROM chat_channels c
      WHERE c.tenant_id = $1 AND c.is_active = true
      AND (c.is_private = false OR EXISTS (
        SELECT 1 FROM chat_channel_members cm WHERE cm.channel_id = c.id AND cm.user_id = $2
      ))
    `;
        const params = [tenantId, userId];
        if (type) {
            params.push(type);
            queryStr += ` AND c.channel_type = $${params.length}`;
        }
        queryStr += ' ORDER BY last_message_at DESC NULLS LAST, c.name ASC';
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get channels error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch channels' });
    }
};
exports.getChannels = getChannels;
const createChannel = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { name, description, channelType, isPrivate, memberUserIds } = req.body;
        const channelResult = await database_1.default.query(`INSERT INTO chat_channels (tenant_id, created_by_user_id, name, description, 
        channel_type, is_private)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *`, [tenantId, userId, name, description, channelType || 'general', isPrivate || false]);
        const channel = channelResult.rows[0];
        // Add creator as member
        await database_1.default.query(`INSERT INTO chat_channel_members (tenant_id, channel_id, user_id, role)
      VALUES ($1, $2, $3, 'admin')`, [tenantId, channel.id, userId]);
        // Add other members
        if (memberUserIds && memberUserIds.length > 0) {
            for (const memberId of memberUserIds) {
                if (memberId !== userId) {
                    await database_1.default.query(`INSERT INTO chat_channel_members (tenant_id, channel_id, user_id, role)
            VALUES ($1, $2, $3, 'member')`, [tenantId, channel.id, memberId]);
                }
            }
        }
        res.status(201).json({ success: true, data: channel, message: 'Channel created' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Create channel error:', error);
        res.status(500).json({ success: false, error: 'Failed to create channel' });
    }
};
exports.createChannel = createChannel;
// ============================================================================
// CHANNEL MESSAGES
// ============================================================================
const getChannelMessages = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { channelId } = req.params;
        const { limit = 50, before } = req.query;
        let queryStr = `
      SELECT m.*, u.full_name as author_name, u.email as author_email
      FROM chat_messages m
      LEFT JOIN users u ON m.user_id = u.id
      WHERE m.tenant_id = $1 AND m.channel_id = $2
    `;
        const params = [tenantId, channelId];
        if (before) {
            params.push(before);
            queryStr += ` AND m.created_at < $${params.length}`;
        }
        params.push(limit);
        queryStr += ` ORDER BY m.created_at DESC LIMIT $${params.length}`;
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows.reverse() });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get messages error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch messages' });
    }
};
exports.getChannelMessages = getChannelMessages;
const sendChannelMessage = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { channelId } = req.params;
        const { content, messageType, attachments } = req.body;
        const result = await database_1.default.query(`INSERT INTO chat_messages (tenant_id, channel_id, user_id, content, message_type, attachments)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *`, [tenantId, channelId, userId, content, messageType || 'text', attachments]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Message sent' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Send message error:', error);
        res.status(500).json({ success: false, error: 'Failed to send message' });
    }
};
exports.sendChannelMessage = sendChannelMessage;
// ============================================================================
// DIRECT MESSAGES
// ============================================================================
const getDirectConversations = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const result = await database_1.default.query(`SELECT DISTINCT ON (other_user_id)
        CASE WHEN sender_id = $2 THEN recipient_id ELSE sender_id END as other_user_id,
        u.full_name as other_user_name,
        dm.content as last_message,
        dm.created_at as last_message_at
      FROM direct_messages dm
      LEFT JOIN users u ON (CASE WHEN dm.sender_id = $2 THEN dm.recipient_id ELSE dm.sender_id END) = u.id
      WHERE dm.tenant_id = $1 AND (dm.sender_id = $2 OR dm.recipient_id = $2)
      ORDER BY other_user_id, dm.created_at DESC`, [tenantId, userId]);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get DM conversations error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch conversations' });
    }
};
exports.getDirectConversations = getDirectConversations;
const getDirectMessages = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { otherUserId } = req.params;
        const { limit = 50 } = req.query;
        const result = await database_1.default.query(`SELECT dm.*, 
        s.name as sender_name, 
        r.name as recipient_name
      FROM direct_messages dm
      LEFT JOIN users s ON dm.sender_id = s.id
      LEFT JOIN users r ON dm.recipient_id = r.id
      WHERE dm.tenant_id = $1 
      AND ((dm.sender_id = $2 AND dm.recipient_id = $3) 
           OR (dm.sender_id = $3 AND dm.recipient_id = $2))
      ORDER BY dm.created_at DESC
      LIMIT $4`, [tenantId, userId, otherUserId, limit]);
        // Mark as read
        await database_1.default.query(`UPDATE direct_messages SET is_read = true 
      WHERE tenant_id = $1 AND recipient_id = $2 AND sender_id = $3 AND is_read = false`, [tenantId, userId, otherUserId]);
        res.json({ success: true, data: result.rows.reverse() });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get DMs error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch messages' });
    }
};
exports.getDirectMessages = getDirectMessages;
const sendDirectMessage = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { recipientId, content, attachments } = req.body;
        const result = await database_1.default.query(`INSERT INTO direct_messages (tenant_id, sender_id, recipient_id, content, attachments)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *`, [tenantId, userId, recipientId, content, attachments]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Message sent' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Send DM error:', error);
        res.status(500).json({ success: false, error: 'Failed to send message' });
    }
};
exports.sendDirectMessage = sendDirectMessage;
// ============================================================================
// NOTIFICATIONS
// ============================================================================
const getNotifications = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { unreadOnly, limit = 50 } = req.query;
        let queryStr = `
      SELECT * FROM user_notifications
      WHERE tenant_id = $1 AND user_id = $2
    `;
        const params = [tenantId, userId];
        if (unreadOnly === 'true') {
            queryStr += ' AND is_read = false';
        }
        params.push(limit);
        queryStr += ` ORDER BY created_at DESC LIMIT $${params.length}`;
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get notifications error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch notifications' });
    }
};
exports.getNotifications = getNotifications;
const markNotificationRead = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { id } = req.params;
        const result = await database_1.default.query(`UPDATE user_notifications SET is_read = true, read_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND tenant_id = $2 AND user_id = $3
      RETURNING *`, [id, tenantId, userId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Notification not found' });
        }
        res.json({ success: true, data: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Mark notification error:', error);
        res.status(500).json({ success: false, error: 'Failed to mark notification' });
    }
};
exports.markNotificationRead = markNotificationRead;
const markAllNotificationsRead = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        await database_1.default.query(`UPDATE user_notifications SET is_read = true, read_at = CURRENT_TIMESTAMP
      WHERE tenant_id = $1 AND user_id = $2 AND is_read = false`, [tenantId, userId]);
        res.json({ success: true, message: 'All notifications marked as read' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Mark all notifications error:', error);
        res.status(500).json({ success: false, error: 'Failed to mark notifications' });
    }
};
exports.markAllNotificationsRead = markAllNotificationsRead;
// Get unread notification count
const getNotificationUnreadCount = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const result = await database_1.default.query(`SELECT COUNT(*) as count FROM user_notifications
      WHERE tenant_id = $1 AND user_id = $2 AND is_read = false`, [tenantId, userId]);
        res.json({ success: true, data: { count: parseInt(result.rows[0]?.count || '0') } });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get notification count error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch notification count' });
    }
};
exports.getNotificationUnreadCount = getNotificationUnreadCount;
// Get unread messages count (direct messages)
const getMessageUnreadCount = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const result = await database_1.default.query(`SELECT COUNT(*) as count FROM direct_messages
      WHERE tenant_id = $1 AND recipient_id = $2 AND is_read = false`, [tenantId, userId]);
        res.json({ success: true, data: { count: parseInt(result.rows[0]?.count || '0') } });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get message count error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch message count' });
    }
};
exports.getMessageUnreadCount = getMessageUnreadCount;
// ============================================================================
// VIDEO MEETINGS
// ============================================================================
const getMeetings = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { upcoming, past } = req.query;
        let queryStr = `
      SELECT m.*, u.full_name as organizer_name
      FROM video_meetings m
      LEFT JOIN users u ON m.organizer_user_id = u.id
      WHERE m.tenant_id = $1
      AND (m.organizer_user_id = $2 OR EXISTS (
        SELECT 1 FROM video_meeting_participants p WHERE p.meeting_id = m.id AND p.user_id = $2
      ))
    `;
        const params = [tenantId, userId];
        if (upcoming === 'true') {
            queryStr += ' AND m.scheduled_start > CURRENT_TIMESTAMP';
        }
        if (past === 'true') {
            queryStr += ' AND m.scheduled_end < CURRENT_TIMESTAMP';
        }
        queryStr += ' ORDER BY m.scheduled_start ASC';
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get meetings error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch meetings' });
    }
};
exports.getMeetings = getMeetings;
const createMeeting = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { title, description, scheduledStart, scheduledEnd, meetingType, participantUserIds, isRecurring, recurringPattern } = req.body;
        // Generate meeting link
        const meetingCode = `mtg-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 9)}`;
        const meetingLink = `/meetings/${meetingCode}`;
        const meetingResult = await database_1.default.query(`INSERT INTO video_meetings (tenant_id, organizer_user_id, title, description,
        scheduled_start, scheduled_end, meeting_type, meeting_link, meeting_code,
        is_recurring, recurring_pattern, status)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'scheduled')
      RETURNING *`, [tenantId, userId, title, description, scheduledStart, scheduledEnd,
            meetingType || 'video', meetingLink, meetingCode, isRecurring || false, recurringPattern]);
        const meeting = meetingResult.rows[0];
        // Add organizer as participant
        await database_1.default.query(`INSERT INTO video_meeting_participants (tenant_id, meeting_id, user_id, role, status)
      VALUES ($1, $2, $3, 'organizer', 'accepted')`, [tenantId, meeting.id, userId]);
        // Add other participants
        if (participantUserIds && participantUserIds.length > 0) {
            for (const participantId of participantUserIds) {
                if (participantId !== userId) {
                    await database_1.default.query(`INSERT INTO video_meeting_participants (tenant_id, meeting_id, user_id, role, status)
            VALUES ($1, $2, $3, 'participant', 'pending')`, [tenantId, meeting.id, participantId]);
                }
            }
        }
        res.status(201).json({ success: true, data: meeting, message: 'Meeting scheduled' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Create meeting error:', error);
        res.status(500).json({ success: false, error: 'Failed to create meeting' });
    }
};
exports.createMeeting = createMeeting;
const updateMeeting = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const { title, description, scheduledStart, scheduledEnd, status } = req.body;
        const result = await database_1.default.query(`UPDATE video_meetings SET
        title = COALESCE($3, title),
        description = COALESCE($4, description),
        scheduled_start = COALESCE($5, scheduled_start),
        scheduled_end = COALESCE($6, scheduled_end),
        status = COALESCE($7, status),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId, title, description, scheduledStart, scheduledEnd, status]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Meeting not found' });
        }
        res.json({ success: true, data: result.rows[0], message: 'Meeting updated' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update meeting error:', error);
        res.status(500).json({ success: false, error: 'Failed to update meeting' });
    }
};
exports.updateMeeting = updateMeeting;
const cancelMeeting = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const result = await database_1.default.query(`UPDATE video_meetings SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Meeting not found' });
        }
        res.json({ success: true, message: 'Meeting cancelled' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Cancel meeting error:', error);
        res.status(500).json({ success: false, error: 'Failed to cancel meeting' });
    }
};
exports.cancelMeeting = cancelMeeting;
// ============================================================================
// MESSAGES (Inbox-style messages - email, internal, etc.)
// ============================================================================
const getMessages = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { folder = 'inbox', type } = req.query;
        // Try to get messages from messages table if it exists, otherwise return sample data
        try {
            let queryStr = `
        SELECT m.*, u.full_name as sender_name
        FROM messages m
        LEFT JOIN users u ON m.sender_id = u.id
        WHERE m.tenant_id = $1
      `;
            const params = [tenantId];
            if (folder === 'inbox') {
                queryStr += ` AND m.recipient_id = $${params.length + 1}`;
                params.push(userId);
            }
            else if (folder === 'sent') {
                queryStr += ` AND m.sender_id = $${params.length + 1}`;
                params.push(userId);
            }
            else if (folder === 'drafts') {
                queryStr += ` AND m.sender_id = $${params.length + 1} AND m.status = 'draft'`;
                params.push(userId);
            }
            if (type) {
                queryStr += ` AND m.type = $${params.length + 1}`;
                params.push(type);
            }
            queryStr += ' ORDER BY m.created_at DESC LIMIT 100';
            const result = await database_1.default.query(queryStr, params);
            res.json({ success: true, data: result.rows });
        }
        catch (dbError) {
            // Table might not exist, return empty array
            res.json({ success: true, data: [] });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get messages error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch messages' });
    }
};
exports.getMessages = getMessages;
const sendMessage = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { recipientId, subject, content, type = 'internal', priority = 'normal' } = req.body;
        try {
            const result = await database_1.default.query(`INSERT INTO messages (tenant_id, sender_id, recipient_id, subject, content, type, priority, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, 'sent')
        RETURNING *`, [tenantId, userId, recipientId, subject, content, type, priority]);
            res.status(201).json({ success: true, data: result.rows[0], message: 'Message sent' });
        }
        catch (dbError) {
            res.status(400).json({ success: false, error: 'Message sending not configured' });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Send message error:', error);
        res.status(500).json({ success: false, error: 'Failed to send message' });
    }
};
exports.sendMessage = sendMessage;
// ============================================================================
// CONTACTS
// ============================================================================
const getContacts = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { type } = req.query;
        // Get contacts from customers, suppliers, and employees
        let contacts = [];
        // Get customers
        const customersResult = await database_1.default.query(`SELECT id, name, email, phone, 'customer' as type, true as opt_in_email
      FROM customers WHERE tenant_id = $1 AND status = 'active' LIMIT 50`, [tenantId]);
        contacts = contacts.concat(customersResult.rows.map(c => ({
            ...c, groups: ['customers'], optInEmail: true, optInSMS: true, optInWhatsApp: false
        })));
        // Get suppliers
        const suppliersResult = await database_1.default.query(`SELECT id, name, email, phone, 'supplier' as type
      FROM suppliers WHERE tenant_id = $1 AND status = 'active' LIMIT 50`, [tenantId]);
        contacts = contacts.concat(suppliersResult.rows.map(s => ({
            ...s, groups: ['suppliers'], optInEmail: true, optInSMS: false, optInWhatsApp: false
        })));
        // Get employees
        const employeesResult = await database_1.default.query(`SELECT e.id, CONCAT(e.first_name, ' ', e.last_name) as name, e.email, e.phone, 'employee' as type
      FROM employees e WHERE e.tenant_id = $1 AND e.status = 'active' LIMIT 50`, [tenantId]);
        contacts = contacts.concat(employeesResult.rows.map(e => ({
            ...e, groups: ['employees'], optInEmail: true, optInSMS: true, optInWhatsApp: true
        })));
        // Filter by type if specified
        if (type) {
            contacts = contacts.filter(c => c.type === type);
        }
        res.json({ success: true, data: contacts });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get contacts error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch contacts' });
    }
};
exports.getContacts = getContacts;
// ============================================================================
// MESSAGE TEMPLATES
// ============================================================================
const getTemplates = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { type, category } = req.query;
        try {
            let queryStr = `
        SELECT * FROM message_templates
        WHERE tenant_id = $1 AND is_active = true
      `;
            const params = [tenantId];
            if (type) {
                queryStr += ` AND type = $${params.length + 1}`;
                params.push(type);
            }
            if (category) {
                queryStr += ` AND category = $${params.length + 1}`;
                params.push(category);
            }
            queryStr += ' ORDER BY usage_count DESC, name ASC';
            const result = await database_1.default.query(queryStr, params);
            res.json({ success: true, data: result.rows });
        }
        catch (dbError) {
            // Return default templates if table doesn't exist
            const defaultTemplates = [
                { id: '1', name: 'Welcome Email', type: 'email', category: 'onboarding', subject: 'Welcome to {company}', content: 'Dear {name},\n\nWelcome to {company}!', variables: ['company', 'name'], usageCount: 0 },
                { id: '2', name: 'Invoice Reminder', type: 'email', category: 'billing', subject: 'Invoice #{invoice_number} Reminder', content: 'Dear {name},\n\nThis is a reminder for invoice #{invoice_number}.', variables: ['name', 'invoice_number', 'amount'], usageCount: 0 },
                { id: '3', name: 'Meeting Invite', type: 'email', category: 'meetings', subject: 'Meeting: {meeting_title}', content: 'You are invited to {meeting_title} on {date} at {time}.', variables: ['meeting_title', 'date', 'time'], usageCount: 0 },
                { id: '4', name: 'SMS Appointment Reminder', type: 'sms', category: 'reminders', content: 'Reminder: Your appointment is on {date} at {time}. Reply CONFIRM to confirm.', variables: ['date', 'time'], usageCount: 0 },
            ];
            res.json({ success: true, data: defaultTemplates });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get templates error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch templates' });
    }
};
exports.getTemplates = getTemplates;
const createTemplate = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { name, type, category, subject, content, variables } = req.body;
        try {
            const result = await database_1.default.query(`INSERT INTO message_templates (tenant_id, created_by, name, type, category, subject, content, variables)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *`, [tenantId, userId, name, type, category, subject, content, JSON.stringify(variables || [])]);
            res.status(201).json({ success: true, data: result.rows[0], message: 'Template created' });
        }
        catch (dbError) {
            res.status(400).json({ success: false, error: 'Templates not configured' });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Create template error:', error);
        res.status(500).json({ success: false, error: 'Failed to create template' });
    }
};
exports.createTemplate = createTemplate;
// ============================================================================
// CAMPAIGNS
// ============================================================================
const getCampaigns = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, type } = req.query;
        try {
            let queryStr = `
        SELECT * FROM communication_campaigns
        WHERE tenant_id = $1
      `;
            const params = [tenantId];
            if (status) {
                queryStr += ` AND status = $${params.length + 1}`;
                params.push(status);
            }
            if (type) {
                queryStr += ` AND type = $${params.length + 1}`;
                params.push(type);
            }
            queryStr += ' ORDER BY created_at DESC';
            const result = await database_1.default.query(queryStr, params);
            res.json({ success: true, data: result.rows });
        }
        catch (dbError) {
            // Return empty if table doesn't exist
            res.json({ success: true, data: [] });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get campaigns error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch campaigns' });
    }
};
exports.getCampaigns = getCampaigns;
const createCampaign = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { name, type, templateId, targetAudience, scheduledDate } = req.body;
        try {
            const result = await database_1.default.query(`INSERT INTO communication_campaigns (tenant_id, created_by, name, type, template_id, target_audience, scheduled_date, status)
        VALUES ($1, $2, $3, $4, $5, $6, $7, 'draft')
        RETURNING *`, [tenantId, userId, name, type, templateId, JSON.stringify(targetAudience || []), scheduledDate]);
            res.status(201).json({ success: true, data: result.rows[0], message: 'Campaign created' });
        }
        catch (dbError) {
            res.status(400).json({ success: false, error: 'Campaigns not configured' });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Create campaign error:', error);
        res.status(500).json({ success: false, error: 'Failed to create campaign' });
    }
};
exports.createCampaign = createCampaign;
exports.default = {
    getWorkspace: exports.getWorkspace,
    getAnnouncements: exports.getAnnouncements,
    createAnnouncement: exports.createAnnouncement,
    updateAnnouncement: exports.updateAnnouncement,
    deleteAnnouncement: exports.deleteAnnouncement,
    getChannels: exports.getChannels,
    createChannel: exports.createChannel,
    getChannelMessages: exports.getChannelMessages,
    sendChannelMessage: exports.sendChannelMessage,
    getDirectConversations: exports.getDirectConversations,
    getDirectMessages: exports.getDirectMessages,
    sendDirectMessage: exports.sendDirectMessage,
    getNotifications: exports.getNotifications,
    markNotificationRead: exports.markNotificationRead,
    markAllNotificationsRead: exports.markAllNotificationsRead,
    getNotificationUnreadCount: exports.getNotificationUnreadCount,
    getMessageUnreadCount: exports.getMessageUnreadCount,
    getMeetings: exports.getMeetings,
    createMeeting: exports.createMeeting,
    updateMeeting: exports.updateMeeting,
    cancelMeeting: exports.cancelMeeting,
    // New endpoints
    getMessages: exports.getMessages,
    sendMessage: exports.sendMessage,
    getContacts: exports.getContacts,
    getTemplates: exports.getTemplates,
    createTemplate: exports.createTemplate,
    getCampaigns: exports.getCampaigns,
    createCampaign: exports.createCampaign
};
//# sourceMappingURL=communications.controller.v2.js.map