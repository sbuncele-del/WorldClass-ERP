/**
 * Payment Controller V2
 * Tenant-hardened API for payment processing
 *
 * Features:
 * - Payment session creation (Ozow/Stripe)
 * - Payment status tracking
 * - Payment history
 * - Pricing information
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Create payment session (Ozow or Stripe based on country)
 */
export declare const createPaymentSession: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get payment transaction status
 */
export declare const getPaymentStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get tenant payment history
 */
export declare const getPaymentHistory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Cancel pending payment
 */
export declare const cancelPayment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get pricing information for all plans
 */
export declare const getPricing: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    createPaymentSession: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPaymentStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPaymentHistory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    cancelPayment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPricing: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=payment.controller.v2.d.ts.map