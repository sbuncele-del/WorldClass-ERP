"use strict";
/**
 * Balance Sheet Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure balance sheet generation and reporting.
 * All queries filtered by tenant_id.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BalanceSheetControllerV2 = void 0;
const database_1 = __importDefault(require("../config/database"));
// Helper to extract tenant context
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: req.user?.id };
}
class BalanceSheetControllerV2 {
    /**
     * Generate Balance Sheet
     * GET /api/v2/financial/reports/balance-sheet
     */
    static async generateBalanceSheet(req, res) {
        try {
            const { tenantId } = getTenantContext(req);
            const { as_of_date, compare_prior = false } = req.query;
            const asOfDate = as_of_date || new Date().toISOString().split('T')[0];
            const label = `As of ${new Date(asOfDate).toLocaleDateString('en-ZA', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            })}`;
            // Fetch account sections with tenant filter
            const currentAssets = await fetchBalanceSheetAccounts(tenantId, asOfDate, '1000', '1499');
            const nonCurrentAssets = await fetchBalanceSheetAccounts(tenantId, asOfDate, '1500', '1999');
            const currentLiabilities = await fetchBalanceSheetAccounts(tenantId, asOfDate, '2000', '2499');
            const nonCurrentLiabilities = await fetchBalanceSheetAccounts(tenantId, asOfDate, '2500', '2999');
            const equityAccounts = await fetchBalanceSheetAccounts(tenantId, asOfDate, '3000', '3999');
            // Calculate retained earnings
            const retainedEarnings = await calculateRetainedEarnings(tenantId, asOfDate);
            if (retainedEarnings !== 0) {
                equityAccounts.push({
                    account_code: '3900',
                    account_name: 'Retained Earnings (Current Year)',
                    amount: retainedEarnings
                });
            }
            // Calculate totals
            const currentAssetsTotal = currentAssets.reduce((sum, acc) => sum + acc.amount, 0);
            const nonCurrentAssetsTotal = nonCurrentAssets.reduce((sum, acc) => sum + acc.amount, 0);
            const totalAssets = currentAssetsTotal + nonCurrentAssetsTotal;
            const currentLiabilitiesTotal = currentLiabilities.reduce((sum, acc) => sum + acc.amount, 0);
            const nonCurrentLiabilitiesTotal = nonCurrentLiabilities.reduce((sum, acc) => sum + acc.amount, 0);
            const totalLiabilities = currentLiabilitiesTotal + nonCurrentLiabilitiesTotal;
            const totalEquity = equityAccounts.reduce((sum, acc) => sum + acc.amount, 0);
            const totalLiabilitiesEquity = totalLiabilities + totalEquity;
            const balanceSheetData = {
                as_of_date: asOfDate,
                label,
                current_assets: {
                    title: 'Current Assets',
                    accounts: currentAssets,
                    subtotal: currentAssetsTotal
                },
                non_current_assets: {
                    title: 'Non-Current Assets',
                    accounts: nonCurrentAssets,
                    subtotal: nonCurrentAssetsTotal
                },
                total_assets: totalAssets,
                current_liabilities: {
                    title: 'Current Liabilities',
                    accounts: currentLiabilities,
                    subtotal: currentLiabilitiesTotal
                },
                non_current_liabilities: {
                    title: 'Non-Current Liabilities',
                    accounts: nonCurrentLiabilities,
                    subtotal: nonCurrentLiabilitiesTotal
                },
                total_liabilities: totalLiabilities,
                equity: {
                    title: 'Equity',
                    accounts: equityAccounts,
                    subtotal: totalEquity
                },
                total_equity: totalEquity,
                total_liabilities_equity: totalLiabilitiesEquity,
                is_balanced: Math.abs(totalAssets - totalLiabilitiesEquity) < 0.01,
                variance: totalAssets - totalLiabilitiesEquity
            };
            res.json({
                success: true,
                data: balanceSheetData
            });
        }
        catch (error) {
            if (error.message === 'Tenant context required') {
                res.status(401).json({ success: false, message: 'Unauthorized: Tenant context required' });
                return;
            }
            console.error('[BalanceSheet] Error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to generate balance sheet',
                error: error.message
            });
        }
    }
    /**
     * Get trial balance
     * GET /api/v2/financial/reports/trial-balance
     */
    static async getTrialBalance(req, res) {
        try {
            const { tenantId } = getTenantContext(req);
            const { as_of_date } = req.query;
            const asOfDate = as_of_date || new Date().toISOString().split('T')[0];
            const query = `
        SELECT 
          coa.account_code,
          coa.account_name,
          coa.account_type,
          COALESCE(SUM(jel.debit_amount), 0) as total_debits,
          COALESCE(SUM(jel.credit_amount), 0) as total_credits,
          CASE 
            WHEN coa.account_type IN ('ASSET', 'EXPENSE') 
            THEN COALESCE(SUM(jel.debit_amount), 0) - COALESCE(SUM(jel.credit_amount), 0)
            ELSE COALESCE(SUM(jel.credit_amount), 0) - COALESCE(SUM(jel.debit_amount), 0)
          END as balance
        FROM chart_of_accounts coa
        LEFT JOIN journal_entry_lines jel ON coa.id = jel.account_id
          AND jel.tenant_id = $1
        LEFT JOIN journal_entries je ON jel.journal_entry_id = je.entry_id
          AND je.tenant_id = $1
          AND je.status = 'POSTED'
          AND je.journal_date <= $2
        WHERE coa.tenant_id = $1
          AND coa.is_active = true
        GROUP BY coa.account_code, coa.account_name, coa.account_type
        HAVING COALESCE(SUM(jel.debit_amount), 0) != 0 
           OR COALESCE(SUM(jel.credit_amount), 0) != 0
        ORDER BY coa.account_code
      `;
            const result = await database_1.default.query(query, [tenantId, asOfDate]);
            const totalDebits = result.rows.reduce((sum, row) => sum + parseFloat(row.total_debits), 0);
            const totalCredits = result.rows.reduce((sum, row) => sum + parseFloat(row.total_credits), 0);
            res.json({
                success: true,
                data: {
                    as_of_date: asOfDate,
                    accounts: result.rows,
                    totals: {
                        total_debits: totalDebits,
                        total_credits: totalCredits,
                        is_balanced: Math.abs(totalDebits - totalCredits) < 0.01,
                        variance: totalDebits - totalCredits
                    }
                }
            });
        }
        catch (error) {
            if (error.message === 'Tenant context required') {
                res.status(401).json({ success: false, message: 'Unauthorized: Tenant context required' });
                return;
            }
            console.error('[TrialBalance] Error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to generate trial balance',
                error: error.message
            });
        }
    }
    /**
     * Export balance sheet to PDF
     * POST /api/v2/financial/reports/balance-sheet/export
     */
    static async exportToPDF(req, res) {
        try {
            const { tenantId } = getTenantContext(req);
            // For now, return a placeholder
            res.json({
                success: true,
                message: 'PDF export will be implemented with reporting service',
                tenant_id: tenantId
            });
        }
        catch (error) {
            if (error.message === 'Tenant context required') {
                res.status(401).json({ success: false, message: 'Unauthorized: Tenant context required' });
                return;
            }
            res.status(500).json({ success: false, message: 'Export failed' });
        }
    }
}
exports.BalanceSheetControllerV2 = BalanceSheetControllerV2;
// Helper functions with tenant filter
async function fetchBalanceSheetAccounts(tenantId, asOfDate, codeStart, codeEnd) {
    const query = `
    SELECT 
      coa.account_code,
      coa.account_name,
      coa.parent_account_code as parent_code,
      COALESCE(SUM(
        CASE 
          WHEN coa.account_type IN ('ASSET') 
          THEN jel.debit_amount - jel.credit_amount
          ELSE jel.credit_amount - jel.debit_amount
        END
      ), 0) as amount
    FROM chart_of_accounts coa
    LEFT JOIN journal_entry_lines jel ON coa.id = jel.account_id
      AND jel.tenant_id = $1
    LEFT JOIN journal_entries je ON jel.journal_entry_id = je.entry_id
      AND je.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date <= $2
    WHERE coa.tenant_id = $1
      AND coa.account_code >= $3
      AND coa.account_code < $4
      AND coa.is_active = true
    GROUP BY coa.account_code, coa.account_name, coa.parent_account_code
    HAVING COALESCE(SUM(jel.debit_amount), 0) != 0 
       OR COALESCE(SUM(jel.credit_amount), 0) != 0
    ORDER BY coa.account_code
  `;
    const result = await database_1.default.query(query, [tenantId, asOfDate, codeStart, codeEnd]);
    return result.rows.map(row => ({
        account_code: row.account_code,
        account_name: row.account_name,
        amount: parseFloat(row.amount),
        parent_code: row.parent_code
    }));
}
async function calculateRetainedEarnings(tenantId, asOfDate) {
    // Calculate net income for the current fiscal year
    const fiscalYearStart = `${asOfDate.substring(0, 4)}-01-01`;
    const query = `
    SELECT 
      COALESCE(SUM(
        CASE 
          WHEN coa.account_type = 'REVENUE' 
          THEN jel.credit_amount - jel.debit_amount
          WHEN coa.account_type = 'EXPENSE' 
          THEN -(jel.debit_amount - jel.credit_amount)
          ELSE 0
        END
      ), 0) as net_income
    FROM journal_entry_lines jel
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id
      AND coa.tenant_id = $1
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id
      AND je.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2
      AND je.journal_date <= $3
      AND coa.account_type IN ('REVENUE', 'EXPENSE')
  `;
    const result = await database_1.default.query(query, [tenantId, fiscalYearStart, asOfDate]);
    return parseFloat(result.rows[0]?.net_income || '0');
}
exports.default = BalanceSheetControllerV2;
//# sourceMappingURL=balance-sheet.controller.v2.js.map