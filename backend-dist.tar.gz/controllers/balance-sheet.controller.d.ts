import { Request, Response } from 'express';
export declare class BalanceSheetController {
    /**
     * Generate Balance Sheet
     * GET /api/financial/reports/balance-sheet
     */
    static generateBalanceSheet(req: Request, res: Response): Promise<void>;
    /**
     * Export Balance Sheet to PDF
     * POST /api/financial/reports/balance-sheet/export
     */
    static exportToPDF(req: Request, res: Response): Promise<void>;
    /**
     * Get account drill-down details
     * GET /api/financial/reports/balance-sheet/account/:accountCode
     */
    static getAccountDetails(req: Request, res: Response): Promise<void>;
    /**
     * Get financial ratios
     * GET /api/financial/reports/balance-sheet/ratios
     */
    static getFinancialRatios(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=balance-sheet.controller.d.ts.map