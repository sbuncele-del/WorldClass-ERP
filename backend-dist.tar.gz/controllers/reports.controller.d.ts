import { Request, Response } from 'express';
/**
 * Reports & Analytics Controller
 *
 * Handles comprehensive reporting and analytics:
 * - Custom report execution
 * - Report scheduling
 * - Dashboard management
 * - KPI tracking
 * - Data exports
 */
declare class ReportsController {
    /**
     * Get all report definitions
     * GET /api/reports/definitions
     */
    getReportDefinitions(req: Request, res: Response): Promise<void>;
    /**
     * Get report definition by ID
     * GET /api/reports/definitions/:id
     */
    getReportDefinitionById(req: Request, res: Response): Promise<void>;
    /**
     * Execute a report
     * POST /api/reports/execute
     */
    executeReport(req: Request, res: Response): Promise<void>;
    /**
     * Get report execution history
     * GET /api/reports/executions
     */
    getExecutionHistory(req: Request, res: Response): Promise<void>;
    /**
     * Get all dashboards
     * GET /api/reports/dashboards
     */
    getDashboards(req: Request, res: Response): Promise<void>;
    /**
     * Get dashboard by ID with widgets
     * GET /api/reports/dashboards/:id
     */
    getDashboardById(req: Request, res: Response): Promise<void>;
    /**
     * Execute widget query
     * POST /api/reports/widgets/execute
     */
    executeWidget(req: Request, res: Response): Promise<void>;
    /**
     * Get all KPI definitions
     * GET /api/reports/kpis
     */
    getKPIs(req: Request, res: Response): Promise<void>;
    /**
     * Calculate KPI value
     * POST /api/reports/kpis/calculate
     */
    calculateKPI(req: Request, res: Response): Promise<void>;
    /**
     * Get KPI history
     * GET /api/reports/kpis/:id/history
     */
    getKPIHistory(req: Request, res: Response): Promise<void>;
    /**
     * Export data
     * POST /api/reports/export
     */
    exportData(req: Request, res: Response): Promise<void>;
    /**
     * Get export history
     * GET /api/reports/exports
     */
    getExportHistory(req: Request, res: Response): Promise<void>;
}
declare const _default: ReportsController;
export default _default;
//# sourceMappingURL=reports.controller.d.ts.map