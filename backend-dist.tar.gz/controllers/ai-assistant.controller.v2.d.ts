/**
 * AI Assistant Controller V2
 * Tenant-hardened API for AI agent interactions
 *
 * Features:
 * - List AI agents
 * - Chat with agents (sync and streaming)
 * - Conversation management
 * - AI suggestions
 * - Specialized assistants (Sales, Compliance, Finance)
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * List all available AI agents
 */
export declare const getAgents: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get specific agent details
 */
export declare const getAgent: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get agent capabilities
 */
export declare const getAgentCapabilities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Chat with an AI agent
 */
export declare const chat: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Stream chat with an AI agent (SSE)
 */
export declare const streamChat: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get user's conversations
 */
export declare const getConversations: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get conversation history
 */
export declare const getConversationHistory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Archive a conversation
 */
export declare const archiveConversation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get AI suggestions for user
 */
export declare const getSuggestions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update suggestion status
 */
export declare const updateSuggestionStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Sales Assistant - Analyze customer
 */
export declare const salesAnalyzeCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Sales Assistant - Generate quotation
 */
export declare const salesGenerateQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Sales Assistant - Forecast sales
 */
export declare const salesForecast: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Compliance Assistant - Check compliance
 */
export declare const complianceCheck: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Compliance Assistant - Risk assessment
 */
export declare const complianceRiskAssess: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Finance Assistant - Explain variance
 */
export declare const financeExplainVariance: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Finance Assistant - Reconcile account
 */
export declare const financeReconcile: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Execute a natural language command
 * Converts text to actual ERP transactions
 */
export declare const executeCommand: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Record feedback on an AI response
 */
export declare const recordFeedback: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get FAQs - frequently asked questions learned from conversations
 */
export declare const getFAQs: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get AI analytics for admin dashboard
 */
export declare const getAIAnalytics: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get ERP knowledge base for help center
 */
export declare const getKnowledgeBase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Search the knowledge base
 */
export declare const searchKnowledgeBase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getAgents: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAgent: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAgentCapabilities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    chat: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    streamChat: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getConversations: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getConversationHistory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    archiveConversation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSuggestions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateSuggestionStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    salesAnalyzeCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    salesGenerateQuotation: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    salesForecast: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    complianceCheck: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    complianceRiskAssess: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    financeExplainVariance: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    financeReconcile: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    executeCommand: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    recordFeedback: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFAQs: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAIAnalytics: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getKnowledgeBase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    searchKnowledgeBase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=ai-assistant.controller.v2.d.ts.map