import { Request, Response } from 'express';
/**
 * Audit-Ready Suite Controller
 *
 * Handles comprehensive audit management:
 * - Audit engagements
 * - Audit findings & corrective actions
 * - Evidence repository
 * - Audit checklists
 * - Permanent records
 */
declare class AuditReadyController {
    /**
     * Get audit engagements
     * GET /api/audit/engagements
     */
    getEngagements(req: Request, res: Response): Promise<void>;
    /**
     * Get engagement by ID
     * GET /api/audit/engagements/:id
     */
    getEngagementById(req: Request, res: Response): Promise<void>;
    /**
     * Create audit engagement
     * POST /api/audit/engagements
     */
    createEngagement(req: Request, res: Response): Promise<void>;
    /**
     * Update engagement status
     * PUT /api/audit/engagements/:id/status
     */
    updateEngagementStatus(req: Request, res: Response): Promise<void>;
    /**
     * Get audit findings
     * GET /api/audit/findings
     */
    getFindings(req: Request, res: Response): Promise<void>;
    /**
     * Create audit finding
     * POST /api/audit/findings
     */
    createFinding(req: Request, res: Response): Promise<void>;
    /**
     * Update finding
     * PUT /api/audit/findings/:id
     */
    updateFinding(req: Request, res: Response): Promise<void>;
    /**
     * Get audit evidence
     * GET /api/audit/evidence
     */
    getEvidence(req: Request, res: Response): Promise<void>;
    /**
     * Add audit evidence
     * POST /api/audit/evidence
     */
    addEvidence(req: Request, res: Response): Promise<void>;
    /**
     * Get checklist templates
     * GET /api/audit/checklist-templates
     */
    getChecklistTemplates(req: Request, res: Response): Promise<void>;
    /**
     * Get checklist items
     * GET /api/audit/checklist-items/:templateId
     */
    getChecklistItems(req: Request, res: Response): Promise<void>;
    /**
     * Get permanent records
     * GET /api/audit/permanent-records
     */
    getPermanentRecords(req: Request, res: Response): Promise<void>;
    /**
     * Add permanent record
     * POST /api/audit/permanent-records
     */
    addPermanentRecord(req: Request, res: Response): Promise<void>;
}
declare const _default: AuditReadyController;
export default _default;
//# sourceMappingURL=audit-ready.controller.d.ts.map