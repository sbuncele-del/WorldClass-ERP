"use strict";
/**
 * Construction Controller V2
 * Tenant-hardened API for construction industry operations
 *
 * Features:
 * - Project management
 * - Phase tracking
 * - Safety incident reporting
 * - Materials management
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateMaterial = exports.addMaterial = exports.getMaterials = exports.updateSafetyIncident = exports.reportSafetyIncident = exports.getSafetyIncidents = exports.updatePhase = exports.createPhase = exports.getProjectPhases = exports.updateProject = exports.createProject = exports.getProjectById = exports.getProjects = exports.getWorkspace = void 0;
const database_1 = __importDefault(require("../config/database"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '' };
}
// ============================================================================
// WORKSPACE
// ============================================================================
const getWorkspace = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const [projectsResult, activeResult, safetyResult, materialsResult] = await Promise.all([
            database_1.default.query(`SELECT COUNT(*) as total_projects, COALESCE(SUM(contract_value), 0) as total_value
        FROM construction_projects WHERE tenant_id = $1 AND is_active = true`, [tenantId]),
            database_1.default.query(`SELECT COUNT(*) as active_projects
        FROM construction_projects WHERE tenant_id = $1 AND status IN ('in_progress', 'on_hold')`, [tenantId]),
            database_1.default.query(`SELECT COUNT(*) as open_incidents
        FROM construction_safety_incidents WHERE tenant_id = $1 AND status IN ('reported', 'investigating')`, [tenantId]),
            database_1.default.query(`SELECT COUNT(*) as low_stock_items
        FROM construction_materials WHERE tenant_id = $1 AND current_quantity <= reorder_level`, [tenantId])
        ]);
        res.json({
            success: true,
            data: {
                summary: {
                    totalProjects: parseInt(projectsResult.rows[0]?.total_projects || '0'),
                    totalContractValue: parseFloat(projectsResult.rows[0]?.total_value || '0'),
                    activeProjects: parseInt(activeResult.rows[0]?.active_projects || '0'),
                    openSafetyIncidents: parseInt(safetyResult.rows[0]?.open_incidents || '0'),
                    lowStockMaterials: parseInt(materialsResult.rows[0]?.low_stock_items || '0')
                }
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Construction workspace error:', error);
        res.status(500).json({ success: false, error: 'Failed to load workspace' });
    }
};
exports.getWorkspace = getWorkspace;
// ============================================================================
// PROJECTS
// ============================================================================
const getProjects = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, projectType } = req.query;
        let queryStr = `
      SELECT id, code, name, client_name, project_type, status, start_date, 
        expected_end_date, contract_value, completion_percentage, site_address, 
        project_manager, created_at
      FROM construction_projects WHERE tenant_id = $1 AND is_active = true
    `;
        const params = [tenantId];
        if (status) {
            params.push(status);
            queryStr += ` AND status = $${params.length}`;
        }
        if (projectType) {
            params.push(projectType);
            queryStr += ` AND project_type = $${params.length}`;
        }
        queryStr += ' ORDER BY start_date DESC';
        const result = await database_1.default.query(queryStr, params);
        res.json({
            success: true,
            data: result.rows.map(p => ({
                id: p.id,
                code: p.code,
                name: p.name,
                client: p.client_name,
                type: p.project_type,
                status: p.status,
                dates: { start: p.start_date, expectedEnd: p.expected_end_date },
                contractValue: parseFloat(p.contract_value),
                completion: parseFloat(p.completion_percentage),
                siteAddress: p.site_address,
                manager: p.project_manager
            }))
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get projects error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch projects' });
    }
};
exports.getProjects = getProjects;
const getProjectById = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const result = await database_1.default.query('SELECT * FROM construction_projects WHERE id = $1 AND tenant_id = $2', [id, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Project not found' });
        }
        res.json({ success: true, data: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get project error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch project' });
    }
};
exports.getProjectById = getProjectById;
const createProject = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { code, name, clientName, projectType, startDate, expectedEndDate, contractValue, siteAddress, projectManager, description } = req.body;
        const result = await database_1.default.query(`INSERT INTO construction_projects (tenant_id, code, name, client_name, project_type,
        start_date, expected_end_date, contract_value, site_address, project_manager, 
        description, status, completion_percentage)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'planning', 0)
      RETURNING *`, [tenantId, code, name, clientName, projectType, startDate, expectedEndDate,
            contractValue, siteAddress, projectManager, description]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Project created' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        if (error.code === '23505') {
            return res.status(400).json({ success: false, error: 'Project code already exists' });
        }
        console.error('Create project error:', error);
        res.status(500).json({ success: false, error: 'Failed to create project' });
    }
};
exports.createProject = createProject;
const updateProject = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const updates = req.body;
        const result = await database_1.default.query(`UPDATE construction_projects SET
        name = COALESCE($3, name),
        status = COALESCE($4, status),
        completion_percentage = COALESCE($5, completion_percentage),
        expected_end_date = COALESCE($6, expected_end_date),
        actual_end_date = COALESCE($7, actual_end_date),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId, updates.name, updates.status, updates.completionPercentage,
            updates.expectedEndDate, updates.actualEndDate]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Project not found' });
        }
        res.json({ success: true, data: result.rows[0], message: 'Project updated' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update project error:', error);
        res.status(500).json({ success: false, error: 'Failed to update project' });
    }
};
exports.updateProject = updateProject;
// ============================================================================
// PROJECT PHASES
// ============================================================================
const getProjectPhases = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { projectId } = req.params;
        const result = await database_1.default.query(`SELECT * FROM construction_phases 
      WHERE project_id = $1 AND tenant_id = $2 
      ORDER BY sequence_number`, [projectId, tenantId]);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get phases error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch phases' });
    }
};
exports.getProjectPhases = getProjectPhases;
const createPhase = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { projectId } = req.params;
        const { sequenceNumber, name, description, startDate, expectedEndDate, budget } = req.body;
        const result = await database_1.default.query(`INSERT INTO construction_phases (tenant_id, project_id, sequence_number, name, 
        description, start_date, expected_end_date, budget, status, completion_percentage)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'not_started', 0)
      RETURNING *`, [tenantId, projectId, sequenceNumber, name, description, startDate, expectedEndDate, budget]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Phase added' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Add phase error:', error);
        res.status(500).json({ success: false, error: 'Failed to add phase' });
    }
};
exports.createPhase = createPhase;
const updatePhase = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const { status, completionPercentage, actualEndDate, notes } = req.body;
        const result = await database_1.default.query(`UPDATE construction_phases SET
        status = COALESCE($3, status),
        completion_percentage = COALESCE($4, completion_percentage),
        actual_end_date = COALESCE($5, actual_end_date),
        notes = COALESCE($6, notes)
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId, status, completionPercentage, actualEndDate, notes]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Phase not found' });
        }
        res.json({ success: true, data: result.rows[0], message: 'Phase updated' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update phase error:', error);
        res.status(500).json({ success: false, error: 'Failed to update phase' });
    }
};
exports.updatePhase = updatePhase;
// ============================================================================
// SAFETY INCIDENTS
// ============================================================================
const getSafetyIncidents = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { projectId, status, severity } = req.query;
        let queryStr = `
      SELECT i.*, p.name as project_name
      FROM construction_safety_incidents i
      LEFT JOIN construction_projects p ON i.project_id = p.id
      WHERE i.tenant_id = $1
    `;
        const params = [tenantId];
        if (projectId) {
            params.push(projectId);
            queryStr += ` AND i.project_id = $${params.length}`;
        }
        if (status) {
            params.push(status);
            queryStr += ` AND i.status = $${params.length}`;
        }
        if (severity) {
            params.push(severity);
            queryStr += ` AND i.severity = $${params.length}`;
        }
        queryStr += ' ORDER BY i.incident_date DESC';
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get incidents error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch incidents' });
    }
};
exports.getSafetyIncidents = getSafetyIncidents;
const reportSafetyIncident = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { projectId, incidentDate, incidentType, severity, location, description, injuriesCount, fatalitiesCount, rootCause, correctiveActions } = req.body;
        const result = await database_1.default.query(`INSERT INTO construction_safety_incidents (tenant_id, project_id, incident_date, 
        incident_type, severity, location, description, injuries_count, fatalities_count, 
        root_cause, corrective_actions, status, reported_by_user_id)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'reported', $12)
      RETURNING *`, [tenantId, projectId, incidentDate, incidentType, severity, location, description,
            injuriesCount || 0, fatalitiesCount || 0, rootCause, correctiveActions, userId]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Incident reported' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Report incident error:', error);
        res.status(500).json({ success: false, error: 'Failed to report incident' });
    }
};
exports.reportSafetyIncident = reportSafetyIncident;
const updateSafetyIncident = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const { status, rootCause, correctiveActions, resolutionDate } = req.body;
        const result = await database_1.default.query(`UPDATE construction_safety_incidents SET
        status = COALESCE($3, status),
        root_cause = COALESCE($4, root_cause),
        corrective_actions = COALESCE($5, corrective_actions),
        resolution_date = COALESCE($6, resolution_date)
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId, status, rootCause, correctiveActions, resolutionDate]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Incident not found' });
        }
        res.json({ success: true, data: result.rows[0], message: 'Incident updated' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update incident error:', error);
        res.status(500).json({ success: false, error: 'Failed to update incident' });
    }
};
exports.updateSafetyIncident = updateSafetyIncident;
// ============================================================================
// MATERIALS
// ============================================================================
const getMaterials = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { projectId, category, lowStock } = req.query;
        let queryStr = `
      SELECT m.*, p.name as project_name
      FROM construction_materials m
      LEFT JOIN construction_projects p ON m.project_id = p.id
      WHERE m.tenant_id = $1
    `;
        const params = [tenantId];
        if (projectId) {
            params.push(projectId);
            queryStr += ` AND m.project_id = $${params.length}`;
        }
        if (category) {
            params.push(category);
            queryStr += ` AND m.category = $${params.length}`;
        }
        if (lowStock === 'true') {
            queryStr += ' AND m.current_quantity <= m.reorder_level';
        }
        queryStr += ' ORDER BY m.name';
        const result = await database_1.default.query(queryStr, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get materials error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch materials' });
    }
};
exports.getMaterials = getMaterials;
const addMaterial = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { projectId, code, name, category, unit, unitPrice, currentQuantity, reorderLevel, supplierName } = req.body;
        const result = await database_1.default.query(`INSERT INTO construction_materials (tenant_id, project_id, code, name, category, unit,
        unit_price, current_quantity, reorder_level, supplier_name)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING *`, [tenantId, projectId, code, name, category, unit, unitPrice, currentQuantity,
            reorderLevel, supplierName]);
        res.status(201).json({ success: true, data: result.rows[0], message: 'Material added' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        if (error.code === '23505') {
            return res.status(400).json({ success: false, error: 'Material code already exists' });
        }
        console.error('Add material error:', error);
        res.status(500).json({ success: false, error: 'Failed to add material' });
    }
};
exports.addMaterial = addMaterial;
const updateMaterial = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const { currentQuantity, unitPrice, reorderLevel, notes } = req.body;
        const result = await database_1.default.query(`UPDATE construction_materials SET
        current_quantity = COALESCE($3, current_quantity),
        unit_price = COALESCE($4, unit_price),
        reorder_level = COALESCE($5, reorder_level),
        notes = COALESCE($6, notes)
      WHERE id = $1 AND tenant_id = $2
      RETURNING *`, [id, tenantId, currentQuantity, unitPrice, reorderLevel, notes]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Material not found' });
        }
        res.json({ success: true, data: result.rows[0], message: 'Material updated' });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update material error:', error);
        res.status(500).json({ success: false, error: 'Failed to update material' });
    }
};
exports.updateMaterial = updateMaterial;
exports.default = {
    getWorkspace: exports.getWorkspace,
    getProjects: exports.getProjects,
    getProjectById: exports.getProjectById,
    createProject: exports.createProject,
    updateProject: exports.updateProject,
    getProjectPhases: exports.getProjectPhases,
    createPhase: exports.createPhase,
    updatePhase: exports.updatePhase,
    getSafetyIncidents: exports.getSafetyIncidents,
    reportSafetyIncident: exports.reportSafetyIncident,
    updateSafetyIncident: exports.updateSafetyIncident,
    getMaterials: exports.getMaterials,
    addMaterial: exports.addMaterial,
    updateMaterial: exports.updateMaterial
};
//# sourceMappingURL=construction.controller.v2.js.map