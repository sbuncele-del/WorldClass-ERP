/**
 * Tax Settings Controller V2
 * Tenant-hardened API for tax configuration
 *
 * Features:
 * - Tax settings CRUD
 * - VAT/GST configuration
 * - PAYE settings
 * - Income tax brackets
 * - eFiling integration
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get tax settings for tenant
 */
export declare const getTaxSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update tax settings
 */
export declare const updateTaxSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get tax accounts (GL accounts for tax)
 */
export declare const getTaxAccounts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update tax account mapping
 */
export declare const updateTaxAccount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get VAT configuration
 */
export declare const getVatConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update VAT configuration
 */
export declare const updateVatConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get PAYE settings
 */
export declare const getPayeSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update PAYE settings
 */
export declare const updatePayeSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get income tax brackets
 */
export declare const getIncomeTaxBrackets: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update income tax brackets
 */
export declare const updateIncomeTaxBrackets: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get eFiling configuration
 */
export declare const getEfilingConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update eFiling configuration
 */
export declare const updateEfilingConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getTaxSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTaxSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTaxAccounts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTaxAccount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getVatConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateVatConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPayeSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePayeSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getIncomeTaxBrackets: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateIncomeTaxBrackets: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEfilingConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateEfilingConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=tax-settings.controller.v2.d.ts.map