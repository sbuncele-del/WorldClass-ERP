import { Request, Response } from 'express';
/**
 * Super Admin Controller
 * Purpose: Centralized admin portal for monitoring and supporting ALL client tenants
 * Security: Platform admin and support agent roles only
 * Features: Tenant monitoring, impersonation, support tickets, health metrics
 */
/**
 * Get all tenants with health metrics
 * Used by: Super Admin Dashboard
 */
export declare const getAllTenants: (req: Request, res: Response) => Promise<void>;
/**
 * Get detailed information for a single tenant
 * Includes: metrics, users, activity, system health
 */
export declare const getTenantDetails: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Impersonate a tenant - generates temporary access token
 * Security: Creates audit trail, time-limited token
 */
export declare const impersonateTenant: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update tenant subscription or status
 */
export declare const updateTenantStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get system-wide health overview
 * Used by: Super Admin Dashboard home page
 */
export declare const getSystemHealth: (req: Request, res: Response) => Promise<void>;
/**
 * Get system-wide metrics trends
 */
export declare const getSystemMetricsTrends: (req: Request, res: Response) => Promise<void>;
/**
 * Get support tickets with filtering
 */
export declare const getSupportTickets: (req: Request, res: Response) => Promise<void>;
/**
 * Get single ticket with full details and comments
 */
export declare const getSupportTicket: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create support ticket
 */
export declare const createSupportTicket: (req: Request, res: Response) => Promise<void>;
/**
 * Update ticket status or assignment
 */
export declare const updateSupportTicket: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Add comment to ticket
 */
export declare const addTicketComment: (req: Request, res: Response) => Promise<void>;
/**
 * Get ticket statistics
 */
export declare const getTicketStatistics: (req: Request, res: Response) => Promise<void>;
/**
 * Get feature flags for a tenant
 */
export declare const getTenantFeatureFlags: (req: Request, res: Response) => Promise<void>;
/**
 * Update or create feature flag
 */
export declare const updateFeatureFlag: (req: Request, res: Response) => Promise<void>;
/**
 * Bulk update feature flags across multiple tenants
 */
export declare const bulkUpdateFeatureFlags: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get active alerts across all tenants
 */
export declare const getActiveAlerts: (req: Request, res: Response) => Promise<void>;
/**
 * Resolve or dismiss an alert
 */
export declare const resolveAlert: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get admin access logs with filtering
 */
export declare const getAdminAccessLogs: (req: Request, res: Response) => Promise<void>;
declare const _default: {
    getAllTenants: (req: Request, res: Response) => Promise<void>;
    getTenantDetails: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    impersonateTenant: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTenantStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSystemHealth: (req: Request, res: Response) => Promise<void>;
    getSystemMetricsTrends: (req: Request, res: Response) => Promise<void>;
    getSupportTickets: (req: Request, res: Response) => Promise<void>;
    getSupportTicket: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createSupportTicket: (req: Request, res: Response) => Promise<void>;
    updateSupportTicket: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    addTicketComment: (req: Request, res: Response) => Promise<void>;
    getTicketStatistics: (req: Request, res: Response) => Promise<void>;
    getTenantFeatureFlags: (req: Request, res: Response) => Promise<void>;
    updateFeatureFlag: (req: Request, res: Response) => Promise<void>;
    bulkUpdateFeatureFlags: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getActiveAlerts: (req: Request, res: Response) => Promise<void>;
    resolveAlert: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAdminAccessLogs: (req: Request, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=superadmin.controller.d.ts.map