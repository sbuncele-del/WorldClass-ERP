"use strict";
/**
 * Cash Flow Statement Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure cash flow statement generation.
 * Supports both indirect and direct methods.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CashFlowControllerV2 = void 0;
const database_1 = __importDefault(require("../config/database"));
// Helper to extract tenant context
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: req.user?.id };
}
class CashFlowControllerV2 {
    /**
     * Generate Cash Flow Statement
     * GET /api/v2/financial/reports/cash-flow
     */
    static async generateCashFlowStatement(req, res) {
        try {
            const { tenantId } = getTenantContext(req);
            const { start_date, end_date, period = 'monthly', method = 'indirect' } = req.query;
            const dateRange = calculateDateRange(period, start_date, end_date);
            let cashFlowData;
            if (method === 'indirect') {
                cashFlowData = await generateIndirectMethod(tenantId, dateRange);
            }
            else {
                cashFlowData = await generateDirectMethod(tenantId, dateRange);
            }
            res.json({
                success: true,
                data: cashFlowData
            });
        }
        catch (error) {
            if (error.message === 'Tenant context required') {
                res.status(401).json({ success: false, message: 'Unauthorized: Tenant context required' });
                return;
            }
            console.error('[CashFlow] Error:', error);
            res.status(500).json({
                success: false,
                message: 'Failed to generate cash flow statement',
                error: error.message
            });
        }
    }
    /**
     * Get cash position over time
     * GET /api/v2/financial/reports/cash-position
     */
    static async getCashPosition(req, res) {
        try {
            const { tenantId } = getTenantContext(req);
            const { start_date, end_date, interval = 'daily' } = req.query;
            const dateRange = calculateDateRange('custom', start_date, end_date);
            let truncInterval = 'day';
            if (interval === 'weekly')
                truncInterval = 'week';
            if (interval === 'monthly')
                truncInterval = 'month';
            const query = `
        WITH cash_movements AS (
          SELECT 
            DATE_TRUNC('${truncInterval}', je.journal_date) as period,
            SUM(
              CASE 
                WHEN jel.debit_amount > 0 THEN jel.debit_amount
                ELSE -jel.credit_amount
              END
            ) as net_movement
          FROM journal_entry_lines jel
          JOIN journal_entries je ON jel.journal_entry_id = je.entry_id
            AND je.tenant_id = $1
          JOIN chart_of_accounts coa ON jel.account_id = coa.account_id
            AND coa.tenant_id = $1
          WHERE jel.tenant_id = $1
            AND je.status = 'POSTED'
            AND je.journal_date >= $2
            AND je.journal_date <= $3
            AND coa.account_code LIKE '1%'
            AND coa.account_name ILIKE '%cash%'
          GROUP BY DATE_TRUNC('${truncInterval}', je.journal_date)
        )
        SELECT 
          period,
          net_movement,
          SUM(net_movement) OVER (ORDER BY period) as running_balance
        FROM cash_movements
        ORDER BY period
      `;
            const result = await database_1.default.query(query, [tenantId, dateRange.start_date, dateRange.end_date]);
            // Get opening balance
            const openingQuery = `
        SELECT COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as opening_balance
        FROM journal_entry_lines jel
        JOIN journal_entries je ON jel.journal_entry_id = je.entry_id
          AND je.tenant_id = $1
        JOIN chart_of_accounts coa ON jel.account_id = coa.account_id
          AND coa.tenant_id = $1
        WHERE jel.tenant_id = $1
          AND je.status = 'POSTED'
          AND je.journal_date < $2
          AND coa.account_code LIKE '1%'
          AND coa.account_name ILIKE '%cash%'
      `;
            const openingResult = await database_1.default.query(openingQuery, [tenantId, dateRange.start_date]);
            const openingBalance = parseFloat(openingResult.rows[0]?.opening_balance || '0');
            res.json({
                success: true,
                data: {
                    period: dateRange,
                    interval,
                    opening_balance: openingBalance,
                    positions: result.rows.map(row => ({
                        date: row.period,
                        movement: parseFloat(row.net_movement),
                        balance: openingBalance + parseFloat(row.running_balance)
                    }))
                }
            });
        }
        catch (error) {
            if (error.message === 'Tenant context required') {
                res.status(401).json({ success: false, message: 'Unauthorized: Tenant context required' });
                return;
            }
            console.error('[CashPosition] Error:', error);
            res.status(500).json({ success: false, message: 'Failed to get cash position' });
        }
    }
    /**
     * Export cash flow to PDF
     * POST /api/v2/financial/reports/cash-flow/export
     */
    static async exportToPDF(req, res) {
        try {
            const { tenantId } = getTenantContext(req);
            res.json({
                success: true,
                message: 'PDF export will be implemented with reporting service',
                tenant_id: tenantId
            });
        }
        catch (error) {
            if (error.message === 'Tenant context required') {
                res.status(401).json({ success: false, message: 'Unauthorized: Tenant context required' });
                return;
            }
            res.status(500).json({ success: false, message: 'Export failed' });
        }
    }
}
exports.CashFlowControllerV2 = CashFlowControllerV2;
// Helper functions
function calculateDateRange(period, startDate, endDate) {
    const now = new Date();
    let start;
    let end;
    let label;
    if (startDate && endDate) {
        return {
            start_date: startDate,
            end_date: endDate,
            label: `${startDate} to ${endDate}`
        };
    }
    switch (period) {
        case 'monthly':
            start = new Date(now.getFullYear(), now.getMonth(), 1);
            end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
            label = start.toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' });
            break;
        case 'quarterly':
            const quarter = Math.floor(now.getMonth() / 3);
            start = new Date(now.getFullYear(), quarter * 3, 1);
            end = new Date(now.getFullYear(), quarter * 3 + 3, 0);
            label = `Q${quarter + 1} ${now.getFullYear()}`;
            break;
        case 'annual':
            start = new Date(now.getFullYear(), 0, 1);
            end = new Date(now.getFullYear(), 11, 31);
            label = `FY ${now.getFullYear()}`;
            break;
        default:
            start = new Date(now.getFullYear(), now.getMonth(), 1);
            end = new Date(now.getFullYear(), now.getMonth() + 1, 0);
            label = start.toLocaleDateString('en-ZA', { month: 'long', year: 'numeric' });
    }
    return {
        start_date: start.toISOString().split('T')[0],
        end_date: end.toISOString().split('T')[0],
        label
    };
}
async function generateIndirectMethod(tenantId, dateRange) {
    // 1. Get Net Income for the period
    const netIncome = await calculateNetIncome(tenantId, dateRange.start_date, dateRange.end_date);
    // 2. Operating Activities adjustments
    const operatingItems = [
        { description: 'Net Income', amount: netIncome }
    ];
    // Add non-cash adjustments (depreciation, amortization)
    const depreciationQuery = `
    SELECT COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2 AND je.journal_date <= $3
      AND coa.account_name ILIKE '%depreciation%'
  `;
    const depResult = await database_1.default.query(depreciationQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    const depreciation = parseFloat(depResult.rows[0]?.amount || '0');
    if (depreciation !== 0) {
        operatingItems.push({ description: 'Add: Depreciation & Amortization', amount: depreciation });
    }
    // Working capital changes
    const workingCapitalChanges = await calculateWorkingCapitalChanges(tenantId, dateRange);
    operatingItems.push(...workingCapitalChanges);
    const operatingSubtotal = operatingItems.reduce((sum, item) => sum + item.amount, 0);
    // 3. Investing Activities
    const investingItems = await calculateInvestingActivities(tenantId, dateRange);
    const investingSubtotal = investingItems.reduce((sum, item) => sum + item.amount, 0);
    // 4. Financing Activities
    const financingItems = await calculateFinancingActivities(tenantId, dateRange);
    const financingSubtotal = financingItems.reduce((sum, item) => sum + item.amount, 0);
    // 5. Cash balances
    const beginningCash = await getCashBalance(tenantId, dateRange.start_date, true);
    const endingCash = await getCashBalance(tenantId, dateRange.end_date, false);
    const netCashFlow = operatingSubtotal + investingSubtotal + financingSubtotal;
    return {
        period: {
            start_date: dateRange.start_date,
            end_date: dateRange.end_date,
            label: dateRange.label
        },
        method: 'indirect',
        operating_activities: {
            title: 'Cash Flows from Operating Activities',
            items: operatingItems,
            subtotal: operatingSubtotal
        },
        investing_activities: {
            title: 'Cash Flows from Investing Activities',
            items: investingItems,
            subtotal: investingSubtotal
        },
        financing_activities: {
            title: 'Cash Flows from Financing Activities',
            items: financingItems,
            subtotal: financingSubtotal
        },
        net_cash_flow: netCashFlow,
        beginning_cash: beginningCash,
        ending_cash: endingCash,
        cash_reconciliation: {
            balance_sheet_cash_beginning: beginningCash,
            balance_sheet_cash_ending: endingCash,
            is_reconciled: Math.abs((beginningCash + netCashFlow) - endingCash) < 0.01,
            variance: (beginningCash + netCashFlow) - endingCash
        }
    };
}
async function generateDirectMethod(tenantId, dateRange) {
    // Direct method - show actual cash receipts and payments
    const operatingItems = [];
    // Cash received from customers
    const customerReceiptsQuery = `
    SELECT COALESCE(SUM(jel.debit_amount), 0) as amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2 AND je.journal_date <= $3
      AND coa.account_code LIKE '1%'
      AND coa.account_name ILIKE '%cash%'
      AND je.source_type = 'SALES'
  `;
    const receiptsResult = await database_1.default.query(customerReceiptsQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    operatingItems.push({
        description: 'Cash received from customers',
        amount: parseFloat(receiptsResult.rows[0]?.amount || '0')
    });
    // Cash paid to suppliers
    const supplierPaymentsQuery = `
    SELECT COALESCE(SUM(jel.credit_amount), 0) as amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2 AND je.journal_date <= $3
      AND coa.account_code LIKE '1%'
      AND coa.account_name ILIKE '%cash%'
      AND je.source_type = 'PURCHASE'
  `;
    const paymentsResult = await database_1.default.query(supplierPaymentsQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    operatingItems.push({
        description: 'Cash paid to suppliers',
        amount: -parseFloat(paymentsResult.rows[0]?.amount || '0')
    });
    const operatingSubtotal = operatingItems.reduce((sum, item) => sum + item.amount, 0);
    // Use same investing and financing calculations
    const investingItems = await calculateInvestingActivities(tenantId, dateRange);
    const financingItems = await calculateFinancingActivities(tenantId, dateRange);
    const investingSubtotal = investingItems.reduce((sum, item) => sum + item.amount, 0);
    const financingSubtotal = financingItems.reduce((sum, item) => sum + item.amount, 0);
    const beginningCash = await getCashBalance(tenantId, dateRange.start_date, true);
    const endingCash = await getCashBalance(tenantId, dateRange.end_date, false);
    const netCashFlow = operatingSubtotal + investingSubtotal + financingSubtotal;
    return {
        period: {
            start_date: dateRange.start_date,
            end_date: dateRange.end_date,
            label: dateRange.label
        },
        method: 'direct',
        operating_activities: {
            title: 'Cash Flows from Operating Activities (Direct)',
            items: operatingItems,
            subtotal: operatingSubtotal
        },
        investing_activities: {
            title: 'Cash Flows from Investing Activities',
            items: investingItems,
            subtotal: investingSubtotal
        },
        financing_activities: {
            title: 'Cash Flows from Financing Activities',
            items: financingItems,
            subtotal: financingSubtotal
        },
        net_cash_flow: netCashFlow,
        beginning_cash: beginningCash,
        ending_cash: endingCash,
        cash_reconciliation: {
            balance_sheet_cash_beginning: beginningCash,
            balance_sheet_cash_ending: endingCash,
            is_reconciled: Math.abs((beginningCash + netCashFlow) - endingCash) < 0.01,
            variance: (beginningCash + netCashFlow) - endingCash
        }
    };
}
async function calculateNetIncome(tenantId, startDate, endDate) {
    const query = `
    SELECT 
      COALESCE(SUM(
        CASE 
          WHEN coa.account_type = 'REVENUE' THEN jel.credit_amount - jel.debit_amount
          WHEN coa.account_type = 'EXPENSE' THEN -(jel.debit_amount - jel.credit_amount)
          ELSE 0
        END
      ), 0) as net_income
    FROM journal_entry_lines jel
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2 AND je.journal_date <= $3
      AND coa.account_type IN ('REVENUE', 'EXPENSE')
  `;
    const result = await database_1.default.query(query, [tenantId, startDate, endDate]);
    return parseFloat(result.rows[0]?.net_income || '0');
}
async function calculateWorkingCapitalChanges(tenantId, dateRange) {
    const items = [];
    // Change in accounts receivable
    const arQuery = `
    SELECT 
      COALESCE(SUM(CASE WHEN je.journal_date < $2 THEN jel.debit_amount - jel.credit_amount ELSE 0 END), 0) as beginning,
      COALESCE(SUM(CASE WHEN je.journal_date <= $3 THEN jel.debit_amount - jel.credit_amount ELSE 0 END), 0) as ending
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND coa.account_name ILIKE '%receivable%'
  `;
    const arResult = await database_1.default.query(arQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    const arChange = parseFloat(arResult.rows[0]?.ending || '0') - parseFloat(arResult.rows[0]?.beginning || '0');
    if (arChange !== 0) {
        items.push({ description: 'Change in Accounts Receivable', amount: -arChange });
    }
    // Change in accounts payable
    const apQuery = `
    SELECT 
      COALESCE(SUM(CASE WHEN je.journal_date < $2 THEN jel.credit_amount - jel.debit_amount ELSE 0 END), 0) as beginning,
      COALESCE(SUM(CASE WHEN je.journal_date <= $3 THEN jel.credit_amount - jel.debit_amount ELSE 0 END), 0) as ending
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND coa.account_name ILIKE '%payable%'
  `;
    const apResult = await database_1.default.query(apQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    const apChange = parseFloat(apResult.rows[0]?.ending || '0') - parseFloat(apResult.rows[0]?.beginning || '0');
    if (apChange !== 0) {
        items.push({ description: 'Change in Accounts Payable', amount: apChange });
    }
    return items;
}
async function calculateInvestingActivities(tenantId, dateRange) {
    const items = [];
    // Purchase of fixed assets
    const assetPurchaseQuery = `
    SELECT COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2 AND je.journal_date <= $3
      AND coa.account_code >= '1500' AND coa.account_code < '2000'
  `;
    const assetResult = await database_1.default.query(assetPurchaseQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    const assetPurchase = parseFloat(assetResult.rows[0]?.amount || '0');
    if (assetPurchase !== 0) {
        items.push({ description: 'Purchase of Fixed Assets', amount: -assetPurchase });
    }
    return items.length > 0 ? items : [{ description: 'No investing activities', amount: 0 }];
}
async function calculateFinancingActivities(tenantId, dateRange) {
    const items = [];
    // Long-term debt changes
    const debtQuery = `
    SELECT COALESCE(SUM(jel.credit_amount - jel.debit_amount), 0) as amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date >= $2 AND je.journal_date <= $3
      AND coa.account_code >= '2500' AND coa.account_code < '3000'
  `;
    const debtResult = await database_1.default.query(debtQuery, [tenantId, dateRange.start_date, dateRange.end_date]);
    const debtChange = parseFloat(debtResult.rows[0]?.amount || '0');
    if (debtChange !== 0) {
        items.push({ description: debtChange > 0 ? 'Proceeds from Long-term Debt' : 'Repayment of Long-term Debt', amount: debtChange });
    }
    return items.length > 0 ? items : [{ description: 'No financing activities', amount: 0 }];
}
async function getCashBalance(tenantId, asOfDate, beforeDate) {
    const operator = beforeDate ? '<' : '<=';
    const query = `
    SELECT COALESCE(SUM(jel.debit_amount - jel.credit_amount), 0) as balance
    FROM journal_entry_lines jel
    JOIN journal_entries je ON jel.journal_entry_id = je.entry_id AND je.tenant_id = $1
    JOIN chart_of_accounts coa ON jel.account_id = coa.account_id AND coa.tenant_id = $1
    WHERE jel.tenant_id = $1
      AND je.status = 'POSTED'
      AND je.journal_date ${operator} $2
      AND coa.account_code LIKE '1%'
      AND coa.account_name ILIKE '%cash%'
  `;
    const result = await database_1.default.query(query, [tenantId, asOfDate]);
    return parseFloat(result.rows[0]?.balance || '0');
}
exports.default = CashFlowControllerV2;
//# sourceMappingURL=cash-flow.controller.v2.js.map