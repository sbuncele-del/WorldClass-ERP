import { Request, Response } from 'express';
/**
 * Dashboard Controller
 * Provides aggregated financial data for the executive dashboard
 */
export declare const getDashboardStats: (_req: Request, res: Response) => Promise<void>;
export declare const getDimensionBreakdown: (req: Request, res: Response) => Promise<void>;
export declare const getRecentEntries: (req: Request, res: Response) => Promise<void>;
export declare const getDashboardMetrics: (req: Request, res: Response) => Promise<void>;
export declare const getRecentActivity: (req: Request, res: Response) => Promise<void>;
export declare const getInventoryAlerts: (req: Request, res: Response) => Promise<void>;
export declare const getTopProducts: (req: Request, res: Response) => Promise<void>;
export declare class DashboardController {
    /**
     * GET /api/dashboard/metrics
     * Get dashboard overview metrics for Enterprise Dashboard
     */
    static getMetrics(req: any, res: Response): Promise<void>;
    /**
     * GET /api/dashboard/tasks
     * Get pending tasks for the user
     */
    static getTasks(req: any, res: Response): Promise<void>;
    /**
     * GET /api/dashboard/alerts
     * Get system alerts and notifications
     */
    static getAlerts(req: any, res: Response): Promise<void>;
    /**
     * GET /api/dashboard/executive
     * Get executive dashboard data with KPIs, charts, AI insights
     */
    static getExecutiveDashboard(req: any, res: Response): Promise<void>;
}
export default DashboardController;
//# sourceMappingURL=dashboard.controller.d.ts.map