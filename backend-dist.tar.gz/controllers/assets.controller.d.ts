/**
 * Fixed Assets Controller
 * Handles CRUD operations for fixed assets, depreciation, disposals, transfers, and maintenance
 */
import { Request, Response } from 'express';
/**
 * GET /api/assets
 * Get all fixed assets with filtering, pagination, and sorting
 */
export declare function getAllAssets(req: Request, res: Response): Promise<void>;
/**
 * GET /api/assets/:id
 * Get single asset with full details including depreciation schedule
 */
export declare function getAssetById(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/assets
 * Create new fixed asset
 */
export declare function createAsset(req: Request, res: Response): Promise<void>;
/**
 * PUT /api/assets/:id
 * Update fixed asset
 */
export declare function updateAsset(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/assets/:id/depreciation/calculate
 * Calculate and save depreciation for a specific period
 */
export declare function calculateDepreciation(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/assets/depreciation/batch
 * Calculate depreciation for all active assets for a given period
 */
export declare function batchCalculateDepreciation(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Dispose of an asset - sale, scrapping, or write-off
 * IAS 16.67-72 compliant disposal workflow
 */
declare function disposeAsset(req: Request, res: Response): Promise<void>;
/**
 * Record asset revaluation - IAS 16.31-42
 * Revaluation model for property, plant and equipment
 */
declare function createRevaluation(req: Request, res: Response): Promise<void>;
/**
 * Record asset impairment - IAS 36
 * Impairment testing and loss recognition
 */
declare function createImpairment(req: Request, res: Response): Promise<void>;
/**
 * Get revaluation history for an asset
 */
declare function getRevaluations(req: Request, res: Response): Promise<void>;
/**
 * Classify expenditure as capital or expense
 * IAS 16.7-14 recognition and subsequent expenditure
 */
declare function classifyExpenditure(req: Request, res: Response): Promise<void>;
/**
 * Post depreciation batch to GL
 */
declare function postDepreciationToGL(req: Request, res: Response): Promise<void>;
/**
 * Get depreciation schedule projection
 */
declare function getDepreciationSchedule(req: Request, res: Response): Promise<void>;
declare const _default: {
    getAllAssets: typeof getAllAssets;
    getAssetById: typeof getAssetById;
    createAsset: typeof createAsset;
    updateAsset: typeof updateAsset;
    calculateDepreciation: typeof calculateDepreciation;
    batchCalculateDepreciation: typeof batchCalculateDepreciation;
    disposeAsset: typeof disposeAsset;
    createRevaluation: typeof createRevaluation;
    createImpairment: typeof createImpairment;
    getRevaluations: typeof getRevaluations;
    classifyExpenditure: typeof classifyExpenditure;
    postDepreciationToGL: typeof postDepreciationToGL;
    getDepreciationSchedule: typeof getDepreciationSchedule;
};
export default _default;
//# sourceMappingURL=assets.controller.d.ts.map