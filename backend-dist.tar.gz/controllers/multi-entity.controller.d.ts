/**
 * Multi-Entity Controller
 * Manage legal entities within a tenant
 */
import { Request, Response } from 'express';
/**
 * Get all entities for tenant
 */
export declare const getEntities: (req: Request, res: Response) => Promise<void>;
/**
 * Get entity by ID
 */
export declare const getEntityById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create new entity
 */
export declare const createEntity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update entity
 */
export declare const updateEntity: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get entity hierarchy (ancestors)
 */
export declare const getEntityAncestors: (req: Request, res: Response) => Promise<void>;
/**
 * Get entity descendants (children)
 */
export declare const getEntityDescendants: (req: Request, res: Response) => Promise<void>;
/**
 * Get user's accessible entities
 */
export declare const getUserEntities: (req: Request, res: Response) => Promise<void>;
/**
 * Grant entity permission to user
 */
export declare const grantEntityPermission: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get inter-entity transactions
 */
export declare const getInterEntityTransactions: (req: Request, res: Response) => Promise<void>;
/**
 * Create inter-entity transaction
 */
export declare const createInterEntityTransaction: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get consolidated financial data
 */
export declare const getConsolidatedData: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=multi-entity.controller.d.ts.map