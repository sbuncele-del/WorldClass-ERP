"use strict";
/**
 * Password Reset Controller
 * Handles HTTP requests for password reset
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestPasswordReset = requestPasswordReset;
exports.verifyToken = verifyToken;
exports.resetPasswordHandler = resetPasswordHandler;
exports.validatePassword = validatePassword;
const password_reset_service_1 = require("../services/password-reset.service");
const errorHandler_1 = require("../middleware/errorHandler");
/**
 * Request password reset
 * POST /api/auth/password/reset-request
 */
async function requestPasswordReset(req, res) {
    try {
        const { email } = req.body;
        if (!email) {
            throw new errorHandler_1.AppError('Email is required', 400);
        }
        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            throw new errorHandler_1.AppError('Invalid email format', 400);
        }
        const result = await (0, password_reset_service_1.sendPasswordResetEmail)(email);
        // Always return success to prevent email enumeration
        res.status(200).json({
            success: true,
            message: result.message,
        });
    }
    catch (error) {
        console.error('Request password reset error:', error);
        // Still return success to prevent email enumeration
        res.status(200).json({
            success: true,
            message: 'If an account exists with that email, a password reset link has been sent.',
        });
    }
}
/**
 * Verify reset token
 * POST /api/auth/password/verify-token
 */
async function verifyToken(req, res) {
    try {
        const { token } = req.body;
        if (!token) {
            throw new errorHandler_1.AppError('Token is required', 400);
        }
        const result = await (0, password_reset_service_1.verifyResetToken)(token);
        if (result.success) {
            res.status(200).json({
                success: true,
                message: result.message,
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message,
            });
        }
    }
    catch (error) {
        console.error('Verify token error:', error);
        throw new errorHandler_1.AppError('Failed to verify token', 500);
    }
}
/**
 * Reset password
 * POST /api/auth/password/reset
 */
async function resetPasswordHandler(req, res) {
    try {
        const { token, password, confirmPassword } = req.body;
        if (!token || !password || !confirmPassword) {
            throw new errorHandler_1.AppError('Token, password, and confirm password are required', 400);
        }
        // Check passwords match
        if (password !== confirmPassword) {
            res.status(400).json({
                success: false,
                message: 'Passwords do not match',
            });
            return;
        }
        // Validate password strength
        const validation = (0, password_reset_service_1.validatePasswordStrength)(password);
        if (!validation.valid) {
            res.status(400).json({
                success: false,
                message: 'Password does not meet requirements',
                errors: validation.errors,
                strength: validation.strength,
            });
            return;
        }
        // Reset password
        const result = await (0, password_reset_service_1.resetPassword)(token, password);
        if (result.success) {
            res.status(200).json({
                success: true,
                message: result.message,
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message,
            });
        }
    }
    catch (error) {
        console.error('Reset password error:', error);
        throw new errorHandler_1.AppError('Failed to reset password', 500);
    }
}
/**
 * Validate password strength
 * POST /api/auth/password/validate
 */
async function validatePassword(req, res) {
    try {
        const { password } = req.body;
        if (!password) {
            throw new errorHandler_1.AppError('Password is required', 400);
        }
        const validation = (0, password_reset_service_1.validatePasswordStrength)(password);
        res.status(200).json({
            success: true,
            ...validation,
        });
    }
    catch (error) {
        console.error('Validate password error:', error);
        throw new errorHandler_1.AppError('Failed to validate password', 500);
    }
}
exports.default = {
    requestPasswordReset,
    verifyToken,
    resetPasswordHandler,
    validatePassword,
};
//# sourceMappingURL=password-reset.controller.js.map