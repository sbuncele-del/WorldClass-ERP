/**
 * Email Queue Controller V2
 * Tenant-hardened API for email queue monitoring and management
 *
 * Features:
 * - Queue statistics
 * - Failed job management
 * - Queue pause/resume
 * - Job retry and cleanup
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get queue statistics
 */
export declare const getStats: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get failed jobs (dead letter queue)
 */
export declare const getFailedJobsList: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Retry a failed job
 */
export declare const retryJob: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Clear completed jobs
 */
export declare const clearCompleted: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Clear failed jobs
 */
export declare const clearFailed: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Pause queue processing
 */
export declare const pause: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Resume queue processing
 */
export declare const resume: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get job details by ID
 */
export declare const getJobDetails: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get queue health check
 */
export declare const healthCheck: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getStats: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFailedJobsList: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    retryJob: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    clearCompleted: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    clearFailed: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    pause: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    resume: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getJobDetails: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    healthCheck: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=email-queue.controller.v2.d.ts.map