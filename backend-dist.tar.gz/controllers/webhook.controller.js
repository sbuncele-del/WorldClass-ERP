"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebhookController = void 0;
const ozow_payment_service_1 = __importDefault(require("../services/ozow-payment.service"));
const stripe_payment_service_1 = __importDefault(require("../services/stripe-payment.service"));
class WebhookController {
    /**
     * POST /api/webhooks/ozow
     * Handle Ozow payment notifications
     */
    static async handleOzowWebhook(req, res) {
        try {
            const notification = req.body;
            // Log webhook for debugging
            console.log('[Ozow Webhook] Received notification:', {
                TransactionReference: notification.TransactionReference,
                Status: notification.Status,
                Amount: notification.Amount
            });
            // Process notification
            await ozow_payment_service_1.default.handleNotification(notification);
            // Ozow expects a 200 OK response
            res.status(200).send('OK');
        }
        catch (error) {
            console.error('[Ozow Webhook] Error:', error);
            // Still return 200 to prevent Ozow from retrying
            // But log the error for investigation
            res.status(200).send('ERROR');
        }
    }
    /**
     * POST /api/webhooks/stripe
     * Handle Stripe webhook events
     */
    static async handleStripeWebhook(req, res) {
        try {
            const signature = req.headers['stripe-signature'];
            if (!signature) {
                res.status(400).json({ error: 'Missing stripe-signature header' });
                return;
            }
            // Get raw body (important for signature verification)
            const rawBody = req.body;
            // Log webhook for debugging
            console.log('[Stripe Webhook] Received event');
            // Process webhook
            await stripe_payment_service_1.default.handleWebhook(rawBody, signature);
            // Stripe expects a 200 response
            res.status(200).json({ received: true });
        }
        catch (error) {
            console.error('[Stripe Webhook] Error:', error);
            res.status(400).json({ error: error.message });
        }
    }
}
exports.WebhookController = WebhookController;
exports.default = WebhookController;
//# sourceMappingURL=webhook.controller.js.map