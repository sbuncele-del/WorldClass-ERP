/**
 * Multi-Entity Controller V2
 * Tenant-hardened API for multi-entity/subsidiary management
 *
 * Features:
 * - Legal entity CRUD
 * - Entity hierarchy management
 * - Inter-company transactions
 * - Entity permissions
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get all legal entities for tenant
 */
export declare const getEntities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get single entity by ID
 */
export declare const getEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create new legal entity
 */
export declare const createEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update legal entity
 */
export declare const updateEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Delete (deactivate) legal entity
 */
export declare const deleteEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get entity hierarchy (tree structure)
 */
export declare const getEntityHierarchy: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Move entity to new parent
 */
export declare const moveEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get entity ancestors
 */
export declare const getEntityAncestors: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get entity descendants
 */
export declare const getEntityDescendants: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get user entity permissions
 */
export declare const getUserEntityPermissions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update user entity permissions
 */
export declare const updateUserEntityPermissions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get entities accessible by current user
 */
export declare const getUserEntities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Grant entity permission to user
 */
export declare const grantEntityPermission: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get inter-entity transactions
 */
export declare const getInterEntityTransactions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create inter-entity transaction
 */
export declare const createInterEntityTransaction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get consolidated financial data across entities
 */
export declare const getConsolidatedData: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getEntities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEntityHierarchy: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    moveEntity: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEntityAncestors: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEntityDescendants: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getUserEntityPermissions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateUserEntityPermissions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getUserEntities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    grantEntityPermission: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getInterEntityTransactions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createInterEntityTransaction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getConsolidatedData: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=multi-entity.controller.v2.d.ts.map