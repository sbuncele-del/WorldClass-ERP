/**
 * Practice Management - Tasks Controller V2
 * Tenant-aware handlers for project tasks and workflows
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getAllTasks: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTaskById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTaskStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMyTasks: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getAllTasks: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTaskById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteTask: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTaskStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMyTasks: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=tasks.controller.v2.d.ts.map