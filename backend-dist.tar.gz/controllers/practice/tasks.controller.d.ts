import { Request, Response } from 'express';
/**
 * ============================================================================
 * PRACTICE MANAGEMENT - TASKS CONTROLLER
 * ============================================================================
 *
 * Handles project tasks, workflows, and task management
 *
 * Features:
 * - Task CRUD operations
 * - Task assignment and delegation
 * - Status tracking and workflows
 * - AI-powered completion predictions
 * - Bottleneck identification
 * - Dependencies management
 * ============================================================================
 */
export declare const getAllTasks: (req: Request, res: Response) => Promise<void>;
export declare const getTaskById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTask: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTask: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteTask: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMyTasks: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=tasks.controller.d.ts.map