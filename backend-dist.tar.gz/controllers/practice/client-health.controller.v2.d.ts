/**
 * Practice Management - Client Health Controller V2
 * Tenant-aware handlers for client health scoring and analytics
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getClient360: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getClientHealthScores: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateClientHealthScore: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const logClientInteraction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getClientInteractions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getAtRiskClients: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getClientHealthDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getClient360: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getClientHealthScores: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateClientHealthScore: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    logClientInteraction: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getClientInteractions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAtRiskClients: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getClientHealthDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=client-health.controller.v2.d.ts.map