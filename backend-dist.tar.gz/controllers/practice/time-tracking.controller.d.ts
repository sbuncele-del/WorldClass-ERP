import { Request, Response } from 'express';
/**
 * ============================================================================
 * PRACTICE MANAGEMENT - TIME TRACKING CONTROLLER
 * ============================================================================
 *
 * Handles time entry, approval workflows, and billable hours tracking
 *
 * Features:
 * - Time entry CRUD
 * - Approval workflows (Pending → Approved → Invoiced)
 * - AI-suggested time entries
 * - Billable vs non-billable tracking
 * - Timesheet reports
 * ============================================================================
 */
export declare const getAllTimeEntries: (req: Request, res: Response) => Promise<void>;
export declare const getTimeEntryById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTimeEntry: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTimeEntry: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteTimeEntry: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const approveTimeEntries: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const rejectTimeEntries: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTimesheet: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPendingApprovals: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=time-tracking.controller.d.ts.map