/**
 * Practice Management - Time Tracking Controller V2
 * Tenant-aware handlers for time entry and billable hours tracking
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getAllTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTimeEntryById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const approveTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const rejectTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMyTimesheet: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTimesheetSummary: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getAllTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTimeEntryById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteTimeEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    approveTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    rejectTimeEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMyTimesheet: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTimesheetSummary: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=time-tracking.controller.v2.d.ts.map