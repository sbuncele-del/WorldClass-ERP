/**
 * Practice Management - Projects Controller V2
 * Tenant-aware handlers for client projects, engagements, and project lifecycle
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getAllProjects: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const addTeamMember: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const removeTeamMember: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectsDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getAllProjects: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProjectById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    addTeamMember: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    removeTeamMember: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProjectsDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=projects.controller.v2.d.ts.map