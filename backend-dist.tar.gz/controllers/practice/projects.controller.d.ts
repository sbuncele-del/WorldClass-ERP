import { Request, Response } from 'express';
/**
 * ============================================================================
 * PRACTICE MANAGEMENT - PROJECTS CONTROLLER
 * ============================================================================
 *
 * Handles client projects, engagements, and project lifecycle management
 *
 * Features:
 * - Project CRUD operations
 * - Team assignment and resource allocation
 * - Budget tracking and profitability
 * - Project timeline and milestones
 * - Integration with client portal
 * ============================================================================
 */
export declare const getAllProjects: (req: Request, res: Response) => Promise<void>;
export declare const getProjectById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProject: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProject: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteProject: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectTeam: (req: Request, res: Response) => Promise<void>;
export declare const addTeamMember: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const removeTeamMember: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectHealth: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=projects.controller.d.ts.map