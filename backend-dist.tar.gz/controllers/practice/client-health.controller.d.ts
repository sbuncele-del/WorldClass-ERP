import { Request, Response } from 'express';
/**
 * ============================================================================
 * PRACTICE MANAGEMENT - CLIENT HEALTH & ANALYTICS CONTROLLER
 * ============================================================================
 *
 * Handles client health scoring, churn prediction, and client intelligence
 *
 * Features:
 * - Client 360° view (unified client intelligence)
 * - Health score tracking (0-100)
 * - Churn risk prediction
 * - Client interaction logging
 * - Engagement analytics
 * - Revenue insights
 * ============================================================================
 */
export declare const getClient360: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getAllClientHealth: (req: Request, res: Response) => Promise<void>;
export declare const calculateHealthScore: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const logInteraction: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getInteractions: (req: Request, res: Response) => Promise<void>;
export declare const getHealthHistory: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=client-health.controller.d.ts.map