"use strict";
/**
 * Practice Management - Projects Controller V2
 * Tenant-aware handlers for client projects, engagements, and project lifecycle
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getProjectsDashboard = exports.removeTeamMember = exports.addTeamMember = exports.updateProject = exports.createProject = exports.getProjectById = exports.getAllProjects = void 0;
const database_1 = __importDefault(require("../../config/database"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant ID not found');
    }
    return {
        tenantId,
        userId: req.user?.id
    };
}
// ============================================================================
// GET ALL PROJECTS
// ============================================================================
const getAllProjects = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, project_type, customer_id, manager_id, priority, search, page = '1', limit = '20', sort_by = 'created_at', sort_order = 'DESC' } = req.query;
        // Validate sort columns
        const allowedSortColumns = ['created_at', 'project_name', 'status', 'start_date', 'end_date', 'budget'];
        const safeSortBy = allowedSortColumns.includes(sort_by) ? sort_by : 'created_at';
        const safeSortOrder = sort_order === 'ASC' ? 'ASC' : 'DESC';
        let query = `
      SELECT 
        cp.*,
        c.customer_name,
        c.customer_code,
        em1.first_name || ' ' || em1.last_name as manager_name,
        em2.first_name || ' ' || em2.last_name as partner_name,
        COUNT(DISTINCT ptm.assignment_id) as team_size,
        COUNT(DISTINCT pt.task_id) as total_tasks,
        COUNT(DISTINCT CASE WHEN pt.status = 'Completed' THEN pt.task_id END) as completed_tasks,
        COALESCE(SUM(te.hours), 0) as total_hours_logged,
        COALESCE(SUM(CASE WHEN te.billable THEN te.hours ELSE 0 END), 0) as billable_hours_logged
      FROM client_projects cp
      LEFT JOIN customers c ON cp.customer_id = c.id
      LEFT JOIN employees em1 ON cp.project_manager_id = em1.employee_id
      LEFT JOIN employees em2 ON cp.project_partner_id = em2.employee_id
      LEFT JOIN project_team_members ptm ON cp.project_id = ptm.project_id AND ptm.is_active = true
      LEFT JOIN project_tasks pt ON cp.project_id = pt.project_id
      LEFT JOIN time_entries te ON cp.project_id = te.project_id AND te.status = 'Approved'
      WHERE cp.tenant_id = $1
    `;
        const params = [tenantId];
        let paramCount = 2;
        if (status) {
            query += ` AND cp.status = $${paramCount}`;
            params.push(status);
            paramCount++;
        }
        if (project_type) {
            query += ` AND cp.project_type = $${paramCount}`;
            params.push(project_type);
            paramCount++;
        }
        if (customer_id) {
            query += ` AND cp.customer_id = $${paramCount}`;
            params.push(customer_id);
            paramCount++;
        }
        if (manager_id) {
            query += ` AND cp.project_manager_id = $${paramCount}`;
            params.push(manager_id);
            paramCount++;
        }
        if (priority) {
            query += ` AND cp.priority = $${paramCount}`;
            params.push(priority);
            paramCount++;
        }
        if (search) {
            query += ` AND (cp.project_name ILIKE $${paramCount} OR cp.project_number ILIKE $${paramCount})`;
            params.push(`%${search}%`);
            paramCount++;
        }
        query += ` GROUP BY cp.project_id, c.customer_name, c.customer_code, 
               em1.first_name, em1.last_name, em2.first_name, em2.last_name`;
        query += ` ORDER BY cp.${safeSortBy} ${safeSortOrder}`;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        query += ` LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        params.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, params);
        // Get total count
        const countQuery = `SELECT COUNT(*) FROM client_projects WHERE tenant_id = $1`;
        const countResult = await database_1.default.query(countQuery, [tenantId]);
        res.json({
            success: true,
            data: result.rows,
            total: parseInt(countResult.rows[0].count),
            page: parseInt(page),
            totalPages: Math.ceil(parseInt(countResult.rows[0].count) / parseInt(limit))
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching projects:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch projects', error: error.message });
    }
};
exports.getAllProjects = getAllProjects;
// ============================================================================
// GET PROJECT BY ID
// ============================================================================
const getProjectById = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const result = await database_1.default.query(`
      SELECT 
        cp.*,
        c.customer_name,
        c.customer_code,
        em1.first_name || ' ' || em1.last_name as manager_name,
        em2.first_name || ' ' || em2.last_name as partner_name
      FROM client_projects cp
      LEFT JOIN customers c ON cp.customer_id = c.id
      LEFT JOIN employees em1 ON cp.project_manager_id = em1.employee_id
      LEFT JOIN employees em2 ON cp.project_partner_id = em2.employee_id
      WHERE cp.project_id = $1 AND cp.tenant_id = $2
    `, [id, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }
        // Get team members
        const teamResult = await database_1.default.query(`
      SELECT ptm.*, e.first_name, e.last_name, e.email
      FROM project_team_members ptm
      JOIN employees e ON ptm.employee_id = e.employee_id
      WHERE ptm.project_id = $1 AND ptm.tenant_id = $2 AND ptm.is_active = true
    `, [id, tenantId]);
        // Get tasks summary
        const tasksSummary = await database_1.default.query(`
      SELECT 
        status, 
        COUNT(*) as count
      FROM project_tasks
      WHERE project_id = $1 AND tenant_id = $2
      GROUP BY status
    `, [id, tenantId]);
        res.json({
            success: true,
            data: {
                ...result.rows[0],
                team_members: teamResult.rows,
                tasks_summary: tasksSummary.rows
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching project:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch project', error: error.message });
    }
};
exports.getProjectById = getProjectById;
// ============================================================================
// CREATE PROJECT
// ============================================================================
const createProject = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const projectData = req.body;
        // Generate project number
        const seqResult = await database_1.default.query(`
      SELECT COALESCE(MAX(CAST(SUBSTRING(project_number FROM 5) AS INTEGER)), 0) + 1 as next_seq
      FROM client_projects
      WHERE tenant_id = $1 AND project_number LIKE 'PRJ-%'
    `, [tenantId]);
        const projectNumber = `PRJ-${String(seqResult.rows[0].next_seq).padStart(5, '0')}`;
        const result = await database_1.default.query(`
      INSERT INTO client_projects (
        tenant_id, project_number, project_name, project_type, customer_id,
        project_manager_id, project_partner_id, status, priority,
        start_date, end_date, budget, estimated_hours, description,
        created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
      RETURNING *
    `, [
            tenantId,
            projectNumber,
            projectData.project_name,
            projectData.project_type,
            projectData.customer_id,
            projectData.project_manager_id,
            projectData.project_partner_id,
            projectData.status || 'Planning',
            projectData.priority || 'Medium',
            projectData.start_date,
            projectData.end_date,
            projectData.budget,
            projectData.estimated_hours,
            projectData.description,
            userId
        ]);
        res.status(201).json({
            success: true,
            message: 'Project created successfully',
            data: result.rows[0]
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error creating project:', error);
        res.status(500).json({ success: false, message: 'Failed to create project', error: error.message });
    }
};
exports.createProject = createProject;
// ============================================================================
// UPDATE PROJECT
// ============================================================================
const updateProject = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { id } = req.params;
        const updateData = req.body;
        const result = await database_1.default.query(`
      UPDATE client_projects SET
        project_name = COALESCE($1, project_name),
        project_type = COALESCE($2, project_type),
        status = COALESCE($3, status),
        priority = COALESCE($4, priority),
        project_manager_id = COALESCE($5, project_manager_id),
        project_partner_id = COALESCE($6, project_partner_id),
        start_date = COALESCE($7, start_date),
        end_date = COALESCE($8, end_date),
        budget = COALESCE($9, budget),
        estimated_hours = COALESCE($10, estimated_hours),
        description = COALESCE($11, description),
        updated_by = $12,
        updated_at = CURRENT_TIMESTAMP
      WHERE project_id = $13 AND tenant_id = $14
      RETURNING *
    `, [
            updateData.project_name,
            updateData.project_type,
            updateData.status,
            updateData.priority,
            updateData.project_manager_id,
            updateData.project_partner_id,
            updateData.start_date,
            updateData.end_date,
            updateData.budget,
            updateData.estimated_hours,
            updateData.description,
            userId,
            id,
            tenantId
        ]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }
        res.json({
            success: true,
            message: 'Project updated successfully',
            data: result.rows[0]
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error updating project:', error);
        res.status(500).json({ success: false, message: 'Failed to update project', error: error.message });
    }
};
exports.updateProject = updateProject;
// ============================================================================
// TEAM MANAGEMENT
// ============================================================================
const addTeamMember = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { id } = req.params;
        const memberData = req.body;
        // Verify project belongs to tenant
        const projectCheck = await database_1.default.query('SELECT project_id FROM client_projects WHERE project_id = $1 AND tenant_id = $2', [id, tenantId]);
        if (projectCheck.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }
        const result = await database_1.default.query(`
      INSERT INTO project_team_members (
        tenant_id, project_id, employee_id, role, hourly_billing_rate,
        hourly_cost_rate, allocation_percentage, start_date, is_active, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, true, $9)
      RETURNING *
    `, [
            tenantId,
            id,
            memberData.employee_id,
            memberData.role,
            memberData.hourly_billing_rate,
            memberData.hourly_cost_rate,
            memberData.allocation_percentage || 100,
            memberData.start_date || new Date(),
            userId
        ]);
        res.status(201).json({
            success: true,
            message: 'Team member added successfully',
            data: result.rows[0]
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error adding team member:', error);
        res.status(500).json({ success: false, message: 'Failed to add team member', error: error.message });
    }
};
exports.addTeamMember = addTeamMember;
const removeTeamMember = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { id, memberId } = req.params;
        const result = await database_1.default.query(`
      UPDATE project_team_members 
      SET is_active = false, end_date = CURRENT_DATE, updated_by = $1, updated_at = CURRENT_TIMESTAMP
      WHERE assignment_id = $2 AND project_id = $3 AND tenant_id = $4
      RETURNING *
    `, [userId, memberId, id, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Team member not found' });
        }
        res.json({
            success: true,
            message: 'Team member removed successfully',
            data: result.rows[0]
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error removing team member:', error);
        res.status(500).json({ success: false, message: 'Failed to remove team member', error: error.message });
    }
};
exports.removeTeamMember = removeTeamMember;
// ============================================================================
// DASHBOARD
// ============================================================================
const getProjectsDashboard = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        // Project status summary
        const statusSummary = await database_1.default.query(`
      SELECT status, COUNT(*) as count
      FROM client_projects
      WHERE tenant_id = $1
      GROUP BY status
    `, [tenantId]);
        // Budget summary
        const budgetSummary = await database_1.default.query(`
      SELECT 
        COUNT(*) as total_projects,
        COALESCE(SUM(budget), 0) as total_budget,
        COALESCE(SUM(estimated_hours), 0) as total_estimated_hours
      FROM client_projects
      WHERE tenant_id = $1 AND status IN ('Planning', 'Active')
    `, [tenantId]);
        // Upcoming deadlines
        const upcomingDeadlines = await database_1.default.query(`
      SELECT project_id, project_name, project_number, end_date, status
      FROM client_projects
      WHERE tenant_id = $1 
      AND status = 'Active'
      AND end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days'
      ORDER BY end_date ASC
      LIMIT 5
    `, [tenantId]);
        res.json({
            success: true,
            data: {
                statusSummary: statusSummary.rows,
                budgetSummary: budgetSummary.rows[0],
                upcomingDeadlines: upcomingDeadlines.rows
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching dashboard:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch dashboard', error: error.message });
    }
};
exports.getProjectsDashboard = getProjectsDashboard;
exports.default = {
    getAllProjects: exports.getAllProjects,
    getProjectById: exports.getProjectById,
    createProject: exports.createProject,
    updateProject: exports.updateProject,
    addTeamMember: exports.addTeamMember,
    removeTeamMember: exports.removeTeamMember,
    getProjectsDashboard: exports.getProjectsDashboard
};
//# sourceMappingURL=projects.controller.v2.js.map