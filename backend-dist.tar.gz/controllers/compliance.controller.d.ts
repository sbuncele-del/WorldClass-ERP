import { Request, Response } from 'express';
/**
 * Compliance & Governance Controller
 *
 * Handles all compliance-related operations including:
 * - Regulatory compliance tracking
 * - Risk management
 * - Policy management
 * - Incident tracking
 * - Training management
 * - SARS Sentinel (tax compliance)
 * - Audit-Ready Suite
 */
declare class ComplianceController {
    /**
     * Get regulatory frameworks
     * GET /api/compliance/frameworks
     */
    getRegulatoryFrameworks(req: Request, res: Response): Promise<void>;
    /**
     * Get compliance requirements
     * GET /api/compliance/requirements
     */
    getComplianceRequirements(req: Request, res: Response): Promise<void>;
    /**
     * Get compliance status
     * GET /api/compliance/status
     */
    getComplianceStatus(req: Request, res: Response): Promise<void>;
    /**
     * Update compliance status
     * PUT /api/compliance/status/:id
     */
    updateComplianceStatus(req: Request, res: Response): Promise<void>;
    /**
     * Get risk register
     * GET /api/compliance/risks
     */
    getRisks(req: Request, res: Response): Promise<void>;
    /**
     * Create risk
     * POST /api/compliance/risks
     */
    createRisk(req: Request, res: Response): Promise<void>;
    /**
     * Get risk categories
     * GET /api/compliance/risk-categories
     */
    getRiskCategories(_req: Request, res: Response): Promise<void>;
    /**
     * Get policies
     * GET /api/compliance/policies
     */
    getPolicies(req: Request, res: Response): Promise<void>;
    /**
     * Create policy
     * POST /api/compliance/policies
     */
    createPolicy(req: Request, res: Response): Promise<void>;
    /**
     * Acknowledge policy
     * POST /api/compliance/policies/:id/acknowledge
     */
    acknowledgePolicy(req: Request, res: Response): Promise<void>;
    /**
     * Get policy categories
     * GET /api/compliance/policy-categories
     */
    getPolicyCategories(_req: Request, res: Response): Promise<void>;
    /**
     * Get incidents
     * GET /api/compliance/incidents
     */
    getIncidents(req: Request, res: Response): Promise<void>;
    /**
     * Create incident
     * POST /api/compliance/incidents
     */
    createIncident(req: Request, res: Response): Promise<void>;
    /**
     * Get incident types
     * GET /api/compliance/incident-types
     */
    getIncidentTypes(_req: Request, res: Response): Promise<void>;
    /**
     * Get training courses
     * GET /api/compliance/training/courses
     */
    getTrainingCourses(req: Request, res: Response): Promise<void>;
    /**
     * Record training completion
     * POST /api/compliance/training/completions
     */
    recordTrainingCompletion(req: Request, res: Response): Promise<void>;
    /**
     * Get user training history
     * GET /api/compliance/training/history/:userId
     */
    getUserTrainingHistory(req: Request, res: Response): Promise<void>;
}
declare const _default: ComplianceController;
export default _default;
//# sourceMappingURL=compliance.controller.d.ts.map