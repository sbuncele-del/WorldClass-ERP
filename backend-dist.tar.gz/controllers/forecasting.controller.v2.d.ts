/**
 * Forecasting Controller V2
 * Tenant-hardened API for financial forecasting and budgeting
 *
 * Features:
 * - Budget scenarios
 * - Budgets with monthly line items
 * - Budget vs Actual variance
 * - Financial forecasting
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get all budget scenarios
 */
export declare const getBudgetScenarios: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create budget scenario
 */
export declare const createBudgetScenario: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update budget scenario
 */
export declare const updateBudgetScenario: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Delete budget scenario
 */
export declare const deleteBudgetScenario: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get budgets for a scenario
 */
export declare const getBudgets: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get budget by ID with monthly lines
 */
export declare const getBudgetById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create budget with monthly lines
 */
export declare const createBudget: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update budget
 */
export declare const updateBudget: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Delete budget
 */
export declare const deleteBudget: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get budget vs actual variance
 */
export declare const getBudgetVsActual: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get variance analysis by department
 */
export declare const getVarianceByDepartment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get monthly trend comparison
 */
export declare const getMonthlyTrend: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getBudgetScenarios: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createBudgetScenario: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateBudgetScenario: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteBudgetScenario: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBudgets: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBudgetById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createBudget: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateBudget: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteBudget: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBudgetVsActual: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getVarianceByDepartment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMonthlyTrend: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=forecasting.controller.v2.d.ts.map