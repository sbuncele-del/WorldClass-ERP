/**
 * Healthcare Controller V2
 * Tenant-hardened API for healthcare/medical facility operations
 *
 * Features:
 * - Facility operations & KPIs
 * - Patient management & journey tracking
 * - Staff management & scheduling
 * - Medical equipment tracking
 * - Inventory management
 * - GoodX integration
 * - Clinical workflows (vitals, triage, labs)
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get Facility Operations Status - Real-time overview
 */
export declare const getFacilityOperationsStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Facility KPIs
 */
export declare const getFacilityKPIs: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Today's Appointments
 */
export declare const getTodayAppointments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get All Patients
 */
export declare const getPatients: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Patient by ID
 */
export declare const getPatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create Patient
 */
export declare const createPatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update Patient
 */
export declare const updatePatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Active Patients in Facility (Real-time board)
 */
export declare const getActivePatientsInFacility: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Check In Patient
 */
export declare const checkInPatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update Patient Journey Stage
 */
export declare const updatePatientJourneyStage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Today's Staff Schedule
 */
export declare const getTodayStaffSchedule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Staff Utilization
 */
export declare const getStaffUtilization: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Medical Equipment Status
 */
export declare const getMedicalEquipmentStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Inventory Status
 */
export declare const getInventoryStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get Inventory Alerts
 */
export declare const getInventoryAlerts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create Reorder Request
 */
export declare const createReorderRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Record Patient Vitals
 */
export declare const recordVitals: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create Triage Assessment
 */
export declare const createTriage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create Lab Order
 */
export declare const createLabOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get GoodX Revenue Transactions
 */
export declare const getGoodXRevenue: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get GoodX Sync Status
 */
export declare const getGoodXSyncStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get all facilities
 */
export declare const getFacilities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getFacilityOperationsStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFacilityKPIs: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTodayAppointments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getFacilities: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPatients: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createPatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getActivePatientsInFacility: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    checkInPatient: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePatientJourneyStage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTodayStaffSchedule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getStaffUtilization: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMedicalEquipmentStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getInventoryStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getInventoryAlerts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createReorderRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    recordVitals: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createTriage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createLabOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getGoodXRevenue: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getGoodXSyncStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=healthcare.controller.v2.d.ts.map