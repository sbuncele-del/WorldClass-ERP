/**
 * PURCHASE MANAGEMENT CONTROLLER (Repository Pattern)
 *
 * Uses repository layer to enforce tenant isolation automatically.
 * Legacy endpoints remain in the old controller; routes are split accordingly.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getSuppliers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSupplier: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createSupplier: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateSupplier: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteSupplier: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPurchaseOrders: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPurchaseOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createPurchaseOrder: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updatePurchaseOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendPurchaseOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const acknowledgePurchaseOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const cancelPurchaseOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getVendorInvoices: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const approveVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const rejectVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const payVendorInvoice: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getRequisitions: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getRequisition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createRequisition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateRequisition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const approveRequisition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const rejectRequisition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteRequisition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getGoodsReceipts: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getGoodsReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createGoodsReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateGoodsReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const confirmGoodsReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteGoodsReceipt: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPurchaseDashboard: (req: TenantRequest, res: Response) => Promise<void>;
/**
 * Post a purchase bill/invoice to the General Ledger
 * Creates: DR Expense/Inventory, DR VAT Input, CR Accounts Payable
 */
export declare const postBillToGL: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get GL posting status for a bill
 */
export declare const getBillGLStatus: (req: TenantRequest, res: Response) => Promise<void>;
/**
 * Record a payment made to supplier and post to GL
 */
export declare const recordPaymentMade: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=purchase.controller.v2.d.ts.map