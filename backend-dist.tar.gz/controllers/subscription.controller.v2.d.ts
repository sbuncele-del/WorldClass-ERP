/**
 * Subscription Controller V2
 * Tenant-hardened API for subscription management
 *
 * Features:
 * - Current subscription info
 * - Plan upgrades/downgrades
 * - Subscription cancellation & reactivation
 * - Usage statistics
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get current subscription for tenant
 */
export declare const getCurrentSubscription: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Upgrade subscription plan
 */
export declare const upgradePlan: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Downgrade subscription plan
 */
export declare const downgradePlan: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Cancel subscription
 */
export declare const cancelSubscription: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Reactivate cancelled subscription
 */
export declare const reactivateSubscription: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get subscription status
 */
export declare const getSubscriptionStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get available plans and features
 */
export declare const getAvailablePlans: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get billing history
 */
export declare const getBillingHistory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update payment method
 */
export declare const updatePaymentMethod: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getCurrentSubscription: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    upgradePlan: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    downgradePlan: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    cancelSubscription: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    reactivateSubscription: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSubscriptionStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAvailablePlans: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBillingHistory: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePaymentMethod: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=subscription.controller.v2.d.ts.map