"use strict";
/**
 * Email Verification Controller
 * Handles HTTP requests for email verification
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.sendVerification = sendVerification;
exports.verifyEmail = verifyEmail;
exports.resendVerification = resendVerification;
exports.getStatus = getStatus;
exports.checkVerified = checkVerified;
const email_verification_service_1 = require("../services/email-verification.service");
const errorHandler_1 = require("../middleware/errorHandler");
/**
 * Send verification email
 * POST /api/email/verify/send
 */
async function sendVerification(req, res) {
    try {
        const { email, userId, tenantId } = req.body;
        if (!email || !userId) {
            throw new errorHandler_1.AppError('Email and userId are required', 400);
        }
        await (0, email_verification_service_1.sendVerificationEmail)(email, userId, tenantId);
        res.status(200).json({
            success: true,
            message: 'Verification email sent',
        });
    }
    catch (error) {
        console.error('Send verification error:', error);
        throw new errorHandler_1.AppError('Failed to send verification email', 500);
    }
}
/**
 * Verify email token
 * POST /api/email/verify
 */
async function verifyEmail(req, res) {
    try {
        const { token } = req.body;
        if (!token) {
            throw new errorHandler_1.AppError('Token is required', 400);
        }
        const result = await (0, email_verification_service_1.verifyEmailToken)(token);
        if (result.success) {
            res.status(200).json({
                success: true,
                message: result.message,
                userId: result.userId,
                tenantId: result.tenantId,
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message,
            });
        }
    }
    catch (error) {
        console.error('Verify email error:', error);
        throw new errorHandler_1.AppError('Failed to verify email', 500);
    }
}
/**
 * Resend verification email
 * POST /api/email/verify/resend
 */
async function resendVerification(req, res) {
    try {
        const { email } = req.body;
        if (!email) {
            throw new errorHandler_1.AppError('Email is required', 400);
        }
        const result = await (0, email_verification_service_1.resendVerificationEmail)(email);
        if (result.success) {
            res.status(200).json({
                success: true,
                message: result.message,
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message,
            });
        }
    }
    catch (error) {
        console.error('Resend verification error:', error);
        throw new errorHandler_1.AppError('Failed to resend verification email', 500);
    }
}
/**
 * Get verification status
 * GET /api/email/verify/status/:userId
 */
async function getStatus(req, res) {
    try {
        const { userId } = req.params;
        if (!userId) {
            throw new errorHandler_1.AppError('User ID is required', 400);
        }
        const status = await (0, email_verification_service_1.getVerificationStatus)(userId);
        res.status(200).json({
            success: true,
            ...status,
        });
    }
    catch (error) {
        console.error('Get verification status error:', error);
        throw new errorHandler_1.AppError('Failed to get verification status', 500);
    }
}
/**
 * Check if email is verified (middleware-compatible)
 * GET /api/email/verify/check/:userId
 */
async function checkVerified(req, res) {
    try {
        const { userId } = req.params;
        if (!userId) {
            throw new errorHandler_1.AppError('User ID is required', 400);
        }
        const status = await (0, email_verification_service_1.getVerificationStatus)(userId);
        res.status(200).json({
            success: true,
            verified: status.verified,
        });
    }
    catch (error) {
        console.error('Check verified error:', error);
        throw new errorHandler_1.AppError('Failed to check verification', 500);
    }
}
exports.default = {
    sendVerification,
    verifyEmail,
    resendVerification,
    getStatus,
    checkVerified,
};
//# sourceMappingURL=email-verification.controller.js.map