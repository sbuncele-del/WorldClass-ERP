"use strict";
/**
 * PURCHASE MANAGEMENT CONTROLLER (Repository Pattern)
 *
 * Uses repository layer to enforce tenant isolation automatically.
 * Legacy endpoints remain in the old controller; routes are split accordingly.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.recordPaymentMade = exports.getBillGLStatus = exports.postBillToGL = exports.getPurchaseDashboard = exports.deleteGoodsReceipt = exports.confirmGoodsReceipt = exports.updateGoodsReceipt = exports.createGoodsReceipt = exports.getGoodsReceipt = exports.getGoodsReceipts = exports.deleteRequisition = exports.rejectRequisition = exports.approveRequisition = exports.updateRequisition = exports.createRequisition = exports.getRequisition = exports.getRequisitions = exports.payVendorInvoice = exports.rejectVendorInvoice = exports.approveVendorInvoice = exports.deleteVendorInvoice = exports.updateVendorInvoice = exports.createVendorInvoice = exports.getVendorInvoice = exports.getVendorInvoices = exports.cancelPurchaseOrder = exports.acknowledgePurchaseOrder = exports.sendPurchaseOrder = exports.updatePurchaseOrder = exports.createPurchaseOrder = exports.getPurchaseOrder = exports.getPurchaseOrders = exports.deleteSupplier = exports.updateSupplier = exports.createSupplier = exports.getSupplier = exports.getSuppliers = void 0;
const purchase_1 = require("../repositories/purchase");
function getTenantContext(req) {
    if (!req.tenant)
        throw new Error('Tenant context not available');
    return { tenantId: req.tenant.id, userId: req.user?.id };
}
// ============================================================================
// SUPPLIERS
// ============================================================================
const getSuppliers = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { search, is_active, supplier_type, page, limit } = req.query;
        if (search) {
            const result = await purchase_1.supplierRepository.search(ctx, search, {
                page: Number(page) || 1,
                limit: Number(limit) || 50
            });
            return res.json({ success: true, data: result.data, pagination: result.pagination });
        }
        const filters = {};
        if (is_active !== undefined)
            filters.is_active = is_active === 'true';
        if (supplier_type)
            filters.supplier_type = supplier_type;
        const result = await purchase_1.supplierRepository.findAll(ctx, filters, {
            page: Number(page) || 1,
            limit: Number(limit) || 50,
            sortBy: 'name',
            sortOrder: 'ASC'
        });
        res.json({ success: true, data: result.data, pagination: result.pagination });
    }
    catch (error) {
        console.error('Error fetching suppliers:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch suppliers', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getSuppliers = getSuppliers;
const getSupplier = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const supplier = await purchase_1.supplierRepository.getSupplierWithBalance(ctx, id);
        if (!supplier)
            return res.status(404).json({ success: false, message: 'Supplier not found' });
        res.json({ success: true, data: supplier });
    }
    catch (error) {
        console.error('Error fetching supplier:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch supplier', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getSupplier = getSupplier;
const createSupplier = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const data = req.body;
        const isUnique = await purchase_1.supplierRepository.isCodeUnique(ctx, data.code);
        if (!isUnique)
            return res.status(400).json({ success: false, message: 'Supplier code already exists' });
        const supplier = await purchase_1.supplierRepository.create(ctx, data);
        res.status(201).json({ success: true, data: supplier, message: 'Supplier created successfully' });
    }
    catch (error) {
        console.error('Error creating supplier:', error);
        res.status(500).json({ success: false, message: 'Failed to create supplier', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.createSupplier = createSupplier;
const updateSupplier = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const data = req.body;
        if (data.code) {
            const isUnique = await purchase_1.supplierRepository.isCodeUnique(ctx, data.code, id);
            if (!isUnique)
                return res.status(400).json({ success: false, message: 'Supplier code already exists' });
        }
        const supplier = await purchase_1.supplierRepository.update(ctx, id, data);
        if (!supplier)
            return res.status(404).json({ success: false, message: 'Supplier not found' });
        res.json({ success: true, data: supplier, message: 'Supplier updated successfully' });
    }
    catch (error) {
        console.error('Error updating supplier:', error);
        res.status(500).json({ success: false, message: 'Failed to update supplier', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.updateSupplier = updateSupplier;
const deleteSupplier = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const deleted = await purchase_1.supplierRepository.delete(ctx, id);
        if (!deleted)
            return res.status(404).json({ success: false, message: 'Supplier not found' });
        res.json({ success: true, message: 'Supplier deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting supplier:', error);
        res.status(500).json({ success: false, message: 'Failed to delete supplier', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.deleteSupplier = deleteSupplier;
// ============================================================================
// PURCHASE ORDERS
// ============================================================================
const getPurchaseOrders = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { status, supplier_id, start_date, end_date, page, limit } = req.query;
        if (start_date && end_date) {
            const result = await purchase_1.purchaseOrderRepository.findAll(ctx, {
                order_date: { op: '>=', value: new Date(start_date) },
                // end date handled via raw where? simplest use findAll? Instead use rawQuery? we will filter below
            });
            // Fallback: use findAll then filter in memory for date range
            const filtered = result.data.filter(o => {
                const d = new Date(o.order_date);
                return d >= new Date(start_date) && d <= new Date(end_date);
            });
            return res.json({ success: true, data: filtered, pagination: result.pagination });
        }
        const filters = {};
        if (status)
            filters.status = status;
        if (supplier_id)
            filters.supplier_id = supplier_id;
        const result = await purchase_1.purchaseOrderRepository.findAll(ctx, filters, {
            page: Number(page) || 1,
            limit: Number(limit) || 50,
            sortBy: 'order_date',
            sortOrder: 'DESC'
        });
        res.json({ success: true, data: result.data, pagination: result.pagination });
    }
    catch (error) {
        console.error('Error fetching purchase orders:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch purchase orders', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getPurchaseOrders = getPurchaseOrders;
const getPurchaseOrder = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const order = await purchase_1.purchaseOrderRepository.getOrderWithLines(ctx, id);
        if (!order)
            return res.status(404).json({ success: false, message: 'Purchase order not found' });
        res.json({ success: true, data: order });
    }
    catch (error) {
        console.error('Error fetching purchase order:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch purchase order', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getPurchaseOrder = getPurchaseOrder;
const createPurchaseOrder = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const orderData = req.body;
        const order = await purchase_1.purchaseOrderRepository.createOrderWithLines(ctx, orderData, orderData.lines || []);
        res.status(201).json({ success: true, data: order, message: 'Purchase order created successfully' });
    }
    catch (error) {
        console.error('Error creating purchase order:', error);
        res.status(500).json({ success: false, message: 'Failed to create purchase order', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.createPurchaseOrder = createPurchaseOrder;
const updatePurchaseOrder = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const orderData = req.body;
        const existing = await purchase_1.purchaseOrderRepository.findById(ctx, id);
        if (!existing)
            return res.status(404).json({ success: false, message: 'Purchase order not found' });
        const updated = await purchase_1.purchaseOrderRepository.update(ctx, id, orderData);
        res.json({ success: true, data: updated, message: 'Purchase order updated successfully' });
    }
    catch (error) {
        console.error('Error updating purchase order:', error);
        res.status(500).json({ success: false, message: 'Failed to update purchase order', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.updatePurchaseOrder = updatePurchaseOrder;
const sendPurchaseOrder = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.purchaseOrderRepository.update(ctx, id, { status: 'sent' });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Purchase order not found' });
        res.json({ success: true, data: updated, message: 'Purchase order marked as sent' });
    }
    catch (error) {
        console.error('Error sending purchase order:', error);
        res.status(500).json({ success: false, message: 'Failed to send purchase order', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.sendPurchaseOrder = sendPurchaseOrder;
const acknowledgePurchaseOrder = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.purchaseOrderRepository.update(ctx, id, { status: 'pending_approval' });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Purchase order not found' });
        res.json({ success: true, data: updated, message: 'Purchase order acknowledged' });
    }
    catch (error) {
        console.error('Error acknowledging purchase order:', error);
        res.status(500).json({ success: false, message: 'Failed to acknowledge purchase order', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.acknowledgePurchaseOrder = acknowledgePurchaseOrder;
const cancelPurchaseOrder = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.purchaseOrderRepository.update(ctx, id, { status: 'cancelled' });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Purchase order not found' });
        res.json({ success: true, data: updated, message: 'Purchase order cancelled' });
    }
    catch (error) {
        console.error('Error cancelling purchase order:', error);
        res.status(500).json({ success: false, message: 'Failed to cancel purchase order', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.cancelPurchaseOrder = cancelPurchaseOrder;
// ============================================================================
// PURCHASE INVOICES
// ============================================================================
const getVendorInvoices = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { status, supplier_id, overdue, page, limit } = req.query;
        if (overdue === 'true') {
            const invoices = await purchase_1.purchaseInvoiceRepository.getOverdueInvoices(ctx);
            return res.json({ success: true, data: invoices, pagination: { page: 1, limit: invoices.length, total: invoices.length, totalPages: 1 } });
        }
        const filters = {};
        if (status)
            filters.status = status;
        if (supplier_id)
            filters.supplier_id = supplier_id;
        const result = await purchase_1.purchaseInvoiceRepository.findAll(ctx, filters, {
            page: Number(page) || 1,
            limit: Number(limit) || 50,
            sortBy: 'invoice_date',
            sortOrder: 'DESC'
        });
        res.json({ success: true, data: result.data, pagination: result.pagination });
    }
    catch (error) {
        console.error('Error fetching vendor invoices:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch vendor invoices', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getVendorInvoices = getVendorInvoices;
const getVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const invoice = await purchase_1.purchaseInvoiceRepository.findById(ctx, id);
        if (!invoice)
            return res.status(404).json({ success: false, message: 'Vendor invoice not found' });
        res.json({ success: true, data: invoice });
    }
    catch (error) {
        console.error('Error fetching vendor invoice:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch vendor invoice', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getVendorInvoice = getVendorInvoice;
const createVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const invoiceData = req.body;
        // If linked to order, use helper to copy amounts
        if (invoiceData.order_id) {
            const invoice = await purchase_1.purchaseInvoiceRepository.createFromOrder(ctx, invoiceData.order_id, invoiceData.supplier_invoice_number);
            return res.status(201).json({ success: true, data: invoice, message: 'Vendor invoice created from order' });
        }
        const invoice = await purchase_1.purchaseInvoiceRepository.create(ctx, {
            ...invoiceData,
            amount_paid: invoiceData.amount_paid || 0,
            balance_due: invoiceData.balance_due ?? invoiceData.total_amount
        });
        res.status(201).json({ success: true, data: invoice, message: 'Vendor invoice created successfully' });
    }
    catch (error) {
        console.error('Error creating vendor invoice:', error);
        res.status(500).json({ success: false, message: 'Failed to create vendor invoice', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.createVendorInvoice = createVendorInvoice;
const updateVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const data = req.body;
        const updated = await purchase_1.purchaseInvoiceRepository.update(ctx, id, data);
        if (!updated)
            return res.status(404).json({ success: false, message: 'Vendor invoice not found' });
        res.json({ success: true, data: updated, message: 'Vendor invoice updated successfully' });
    }
    catch (error) {
        console.error('Error updating vendor invoice:', error);
        res.status(500).json({ success: false, message: 'Failed to update vendor invoice', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.updateVendorInvoice = updateVendorInvoice;
const deleteVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const deleted = await purchase_1.purchaseInvoiceRepository.delete(ctx, id);
        if (!deleted)
            return res.status(404).json({ success: false, message: 'Vendor invoice not found' });
        res.json({ success: true, message: 'Vendor invoice deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting vendor invoice:', error);
        res.status(500).json({ success: false, message: 'Failed to delete vendor invoice', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.deleteVendorInvoice = deleteVendorInvoice;
const approveVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.purchaseInvoiceRepository.update(ctx, id, { status: 'received' });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Vendor invoice not found' });
        res.json({ success: true, data: updated, message: 'Vendor invoice approved' });
    }
    catch (error) {
        console.error('Error approving vendor invoice:', error);
        res.status(500).json({ success: false, message: 'Failed to approve vendor invoice', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.approveVendorInvoice = approveVendorInvoice;
const rejectVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.purchaseInvoiceRepository.update(ctx, id, { status: 'cancelled' });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Vendor invoice not found' });
        res.json({ success: true, data: updated, message: 'Vendor invoice rejected' });
    }
    catch (error) {
        console.error('Error rejecting vendor invoice:', error);
        res.status(500).json({ success: false, message: 'Failed to reject vendor invoice', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.rejectVendorInvoice = rejectVendorInvoice;
const payVendorInvoice = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const { amount, payment_method, reference } = req.body;
        const invoice = await purchase_1.purchaseInvoiceRepository.recordPayment(ctx, id, amount, payment_method, reference);
        if (!invoice)
            return res.status(404).json({ success: false, message: 'Vendor invoice not found' });
        res.json({ success: true, data: invoice, message: 'Payment recorded successfully' });
    }
    catch (error) {
        console.error('Error recording payment:', error);
        res.status(500).json({ success: false, message: 'Failed to record payment', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.payVendorInvoice = payVendorInvoice;
// ============================================================================
// REQUISITIONS
// ============================================================================
const getRequisitions = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { status, department, page, limit } = req.query;
        const filters = {};
        if (status)
            filters.status = status;
        if (department)
            filters.department = department;
        const result = await purchase_1.requisitionRepository.findAll(ctx, filters, {
            page: Number(page) || 1,
            limit: Number(limit) || 50,
            sortBy: 'requisition_date',
            sortOrder: 'DESC'
        });
        res.json({ success: true, data: result.data, pagination: result.pagination });
    }
    catch (error) {
        console.error('Error fetching requisitions:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch requisitions', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getRequisitions = getRequisitions;
const getRequisition = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const requisition = await purchase_1.requisitionRepository.getWithLines(ctx, id);
        if (!requisition)
            return res.status(404).json({ success: false, message: 'Requisition not found' });
        res.json({ success: true, data: requisition });
    }
    catch (error) {
        console.error('Error fetching requisition:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getRequisition = getRequisition;
const createRequisition = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { line_items = [], ...header } = req.body || {};
        if (!Array.isArray(line_items) || line_items.length === 0) {
            return res.status(400).json({ success: false, message: 'Line items are required' });
        }
        const requisition = await purchase_1.requisitionRepository.createWithLines(ctx, header, line_items);
        res.status(201).json({ success: true, data: requisition, message: 'Requisition created successfully' });
    }
    catch (error) {
        console.error('Error creating requisition:', error);
        res.status(500).json({ success: false, message: 'Failed to create requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.createRequisition = createRequisition;
const updateRequisition = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const data = req.body;
        const updated = await purchase_1.requisitionRepository.update(ctx, id, data);
        if (!updated)
            return res.status(404).json({ success: false, message: 'Requisition not found' });
        res.json({ success: true, data: updated, message: 'Requisition updated successfully' });
    }
    catch (error) {
        console.error('Error updating requisition:', error);
        res.status(500).json({ success: false, message: 'Failed to update requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.updateRequisition = updateRequisition;
const approveRequisition = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.requisitionRepository.updateStatus(ctx, id, 'approved', { approved_by: ctx.userId, approved_date: new Date() });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Requisition not found' });
        res.json({ success: true, data: updated, message: 'Requisition approved' });
    }
    catch (error) {
        console.error('Error approving requisition:', error);
        res.status(500).json({ success: false, message: 'Failed to approve requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.approveRequisition = approveRequisition;
const rejectRequisition = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const { rejection_reason } = req.body || {};
        if (!rejection_reason)
            return res.status(400).json({ success: false, message: 'Rejection reason is required' });
        const updated = await purchase_1.requisitionRepository.updateStatus(ctx, id, 'rejected', { rejection_reason });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Requisition not found' });
        res.json({ success: true, data: updated, message: 'Requisition rejected' });
    }
    catch (error) {
        console.error('Error rejecting requisition:', error);
        res.status(500).json({ success: false, message: 'Failed to reject requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.rejectRequisition = rejectRequisition;
const deleteRequisition = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const deleted = await purchase_1.requisitionRepository.deleteIfNoPurchaseOrder(ctx, id);
        if (!deleted)
            return res.status(400).json({ success: false, message: 'Requisition cannot be deleted (linked to purchase order or not found)' });
        res.json({ success: true, message: 'Requisition deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting requisition:', error);
        res.status(500).json({ success: false, message: 'Failed to delete requisition', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.deleteRequisition = deleteRequisition;
// ============================================================================
// GOODS RECEIPTS
// ============================================================================
const getGoodsReceipts = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { status, order_id, page, limit } = req.query;
        const filters = {};
        if (status)
            filters.status = status;
        if (order_id)
            filters.order_id = order_id;
        const result = await purchase_1.goodsReceiptRepository.findAll(ctx, filters, {
            page: Number(page) || 1,
            limit: Number(limit) || 50,
            sortBy: 'gr_date',
            sortOrder: 'DESC'
        });
        res.json({ success: true, data: result.data, pagination: result.pagination });
    }
    catch (error) {
        console.error('Error fetching goods receipts:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch goods receipts', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getGoodsReceipts = getGoodsReceipts;
const getGoodsReceipt = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const receipt = await purchase_1.goodsReceiptRepository.getWithLines(ctx, id);
        if (!receipt)
            return res.status(404).json({ success: false, message: 'Goods receipt not found' });
        res.json({ success: true, data: receipt });
    }
    catch (error) {
        console.error('Error fetching goods receipt:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch goods receipt', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getGoodsReceipt = getGoodsReceipt;
const createGoodsReceipt = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { line_items = [], ...header } = req.body || {};
        if (!Array.isArray(line_items) || line_items.length === 0) {
            return res.status(400).json({ success: false, message: 'Line items are required' });
        }
        const receipt = await purchase_1.goodsReceiptRepository.createWithLines(ctx, header, line_items);
        res.status(201).json({ success: true, data: receipt, message: 'Goods receipt created successfully' });
    }
    catch (error) {
        console.error('Error creating goods receipt:', error);
        res.status(500).json({ success: false, message: 'Failed to create goods receipt', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.createGoodsReceipt = createGoodsReceipt;
const updateGoodsReceipt = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const data = req.body;
        const updated = await purchase_1.goodsReceiptRepository.update(ctx, id, data);
        if (!updated)
            return res.status(404).json({ success: false, message: 'Goods receipt not found' });
        res.json({ success: true, data: updated, message: 'Goods receipt updated successfully' });
    }
    catch (error) {
        console.error('Error updating goods receipt:', error);
        res.status(500).json({ success: false, message: 'Failed to update goods receipt', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.updateGoodsReceipt = updateGoodsReceipt;
const confirmGoodsReceipt = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const updated = await purchase_1.goodsReceiptRepository.update(ctx, id, {
            status: 'confirmed',
            confirmed: true,
            confirmed_by: ctx.userId,
            confirmed_date: new Date()
        });
        if (!updated)
            return res.status(404).json({ success: false, message: 'Goods receipt not found' });
        res.json({ success: true, data: updated, message: 'Goods receipt confirmed' });
    }
    catch (error) {
        console.error('Error confirming goods receipt:', error);
        res.status(500).json({ success: false, message: 'Failed to confirm goods receipt', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.confirmGoodsReceipt = confirmGoodsReceipt;
const deleteGoodsReceipt = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const deleted = await purchase_1.goodsReceiptRepository.delete(ctx, id);
        if (!deleted)
            return res.status(404).json({ success: false, message: 'Goods receipt not found' });
        res.json({ success: true, message: 'Goods receipt deleted successfully' });
    }
    catch (error) {
        console.error('Error deleting goods receipt:', error);
        res.status(500).json({ success: false, message: 'Failed to delete goods receipt', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.deleteGoodsReceipt = deleteGoodsReceipt;
// ============================================================================
// DASHBOARD
// ============================================================================
const getPurchaseDashboard = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const [supplierCount, pendingOrders, unpaidInvoices, overdueInvoices] = await Promise.all([
            purchase_1.supplierRepository.count(ctx, { is_active: true }),
            purchase_1.purchaseOrderRepository.count(ctx, { status: 'pending_approval' }),
            purchase_1.purchaseInvoiceRepository.getUnpaidInvoices(ctx),
            purchase_1.purchaseInvoiceRepository.getOverdueInvoices(ctx)
        ]);
        const unpaidTotal = unpaidInvoices.reduce((sum, inv) => sum + (inv.amount_outstanding || 0), 0);
        const overdueTotal = overdueInvoices.reduce((sum, inv) => sum + (inv.amount_outstanding || 0), 0);
        res.json({
            success: true,
            data: {
                summary: {
                    suppliers: supplierCount,
                    pending_orders: pendingOrders,
                    unpaid_invoices: unpaidInvoices.length,
                    unpaid_amount: unpaidTotal,
                    overdue_invoices: overdueInvoices.length,
                    overdue_amount: overdueTotal
                }
            }
        });
    }
    catch (error) {
        console.error('Error fetching purchase dashboard:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch purchase dashboard', error: error instanceof Error ? error.message : 'Unknown error' });
    }
};
exports.getPurchaseDashboard = getPurchaseDashboard;
// ============================================================================
// GL POSTING - Integration with Financial Module
// ============================================================================
const integration_service_1 = require("../services/integration.service");
/**
 * Post a purchase bill/invoice to the General Ledger
 * Creates: DR Expense/Inventory, DR VAT Input, CR Accounts Payable
 */
const postBillToGL = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        // Get invoice - use findById from BaseRepository
        const invoice = await purchase_1.purchaseInvoiceRepository.findById(ctx, id);
        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: 'Bill/Invoice not found'
            });
        }
        // Check GL posting status from database (field may exist from migration)
        const invoiceData = invoice;
        if (invoiceData.gl_posted) {
            return res.status(400).json({
                success: false,
                message: 'Bill already posted to GL',
                journalEntryId: invoiceData.gl_journal_id
            });
        }
        if (invoice.status === 'draft') {
            return res.status(400).json({
                success: false,
                message: 'Cannot post draft bill. Please approve the bill first.'
            });
        }
        // Prepare bill data for posting
        const billForPosting = {
            id: String(invoice.invoice_id),
            bill_number: invoice.invoice_number,
            supplier_id: String(invoice.supplier_id || ''),
            supplier_name: invoice.supplier_name || 'Unknown Supplier',
            bill_date: invoice.invoice_date instanceof Date
                ? invoice.invoice_date.toISOString().split('T')[0]
                : String(invoice.invoice_date),
            subtotal: invoice.subtotal || invoice.total_amount,
            vat_amount: invoice.vat_amount || 0,
            total_amount: invoice.total_amount,
            lines: [] // Lines not available in this query - posting uses header amounts
        };
        // Post to GL
        const result = await integration_service_1.integrationService.postPurchaseBillToGL(ctx.tenantId, billForPosting, ctx.userId || 'system');
        if (result.success) {
            res.json({
                success: true,
                message: result.message,
                journalEntryId: result.journalEntryId
            });
        }
        else {
            res.status(400).json({
                success: false,
                message: result.message
            });
        }
    }
    catch (error) {
        console.error('Error posting bill to GL:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to post bill to GL',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
};
exports.postBillToGL = postBillToGL;
/**
 * Get GL posting status for a bill
 */
const getBillGLStatus = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const status = await integration_service_1.integrationService.getPostingStatus(ctx.tenantId, 'PURCHASE_BILL', id);
        res.json({
            success: true,
            data: status
        });
    }
    catch (error) {
        console.error('Error getting bill GL status:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to get GL status'
        });
    }
};
exports.getBillGLStatus = getBillGLStatus;
/**
 * Record a payment made to supplier and post to GL
 */
const recordPaymentMade = async (req, res) => {
    try {
        const ctx = getTenantContext(req);
        const { id } = req.params;
        const { amount, payment_date, payment_reference, bank_account_code } = req.body;
        // Get invoice
        const invoice = await purchase_1.purchaseInvoiceRepository.findById(ctx, id);
        if (!invoice) {
            return res.status(404).json({
                success: false,
                message: 'Bill not found'
            });
        }
        const balanceDue = invoice.amount_outstanding || (invoice.total_amount - (invoice.amount_paid || 0));
        if (amount > balanceDue) {
            return res.status(400).json({
                success: false,
                message: `Payment amount (${amount}) exceeds balance due (${balanceDue})`
            });
        }
        // Post payment to GL
        const glResult = await integration_service_1.integrationService.postPaymentMadeToGL(ctx.tenantId, {
            id: `PAY-${Date.now()}`,
            payment_date: payment_date || new Date().toISOString().split('T')[0],
            amount,
            bill_number: invoice.invoice_number,
            supplier_name: invoice.supplier_name || 'Supplier',
            bank_account_code,
            payment_reference: payment_reference || `Payment for ${invoice.invoice_number}`
        }, ctx.userId || 'system');
        // Update invoice payment status
        const newAmountPaid = (invoice.amount_paid || 0) + amount;
        const newBalance = invoice.total_amount - newAmountPaid;
        const newStatus = newBalance <= 0 ? 'paid' : 'partial';
        await purchase_1.purchaseInvoiceRepository.update(ctx, id, {
            amount_paid: newAmountPaid,
            amount_outstanding: newBalance,
            status: newStatus
        });
        res.json({
            success: true,
            message: 'Payment recorded successfully',
            data: {
                invoice_id: id,
                amount_paid: amount,
                new_balance: newBalance,
                status: newStatus,
                gl_journal_id: glResult.journalEntryId
            }
        });
    }
    catch (error) {
        console.error('Error recording payment:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to record payment',
            error: error instanceof Error ? error.message : 'Unknown error'
        });
    }
};
exports.recordPaymentMade = recordPaymentMade;
//# sourceMappingURL=purchase.controller.v2.js.map