/**
 * Sales Live Controller V2
 * Tenant-hardened API for live sales/POS operations
 *
 * Features:
 * - Customer management
 * - Lead management
 * - Real-time sales data
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get all customers
 */
export declare const getCustomers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get customer by ID
 */
export declare const getCustomerById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create customer
 */
export declare const createCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update customer
 */
export declare const updateCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Delete customer
 */
export declare const deleteCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get all leads
 */
export declare const getLeads: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get lead by ID
 */
export declare const getLeadById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Create lead
 */
export declare const createLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update lead
 */
export declare const updateLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Convert lead to customer
 */
export declare const convertLeadToCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Delete lead
 */
export declare const deleteLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get live sales summary
 */
export declare const getSalesSummary: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getCustomers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getCustomerById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getLeads: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getLeadById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    convertLeadToCustomer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteLead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSalesSummary: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=sales-live.controller.v2.d.ts.map