"use strict";
/**
 * Payment Controller V2
 * Tenant-hardened API for payment processing
 *
 * Features:
 * - Payment session creation (Ozow/Stripe)
 * - Payment status tracking
 * - Payment history
 * - Pricing information
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPricing = exports.cancelPayment = exports.getPaymentHistory = exports.getPaymentStatus = exports.createPaymentSession = void 0;
const ozow_payment_service_1 = __importDefault(require("../services/ozow-payment.service"));
const stripe_payment_service_1 = __importDefault(require("../services/stripe-payment.service"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '', tenant: req.tenant, user: req.user };
}
// ============================================================================
// PAYMENT SESSIONS
// ============================================================================
/**
 * Create payment session (Ozow or Stripe based on country)
 */
const createPaymentSession = async (req, res) => {
    try {
        const { tenantId, tenant, user } = getTenantContext(req);
        const { plan, billingCycle = 'monthly', paymentMethod = 'auto' } = req.body;
        // Validate plan
        const validPlans = ['starter', 'professional', 'enterprise'];
        if (!validPlans.includes(plan)) {
            return res.status(400).json({ success: false, error: 'Invalid plan', validPlans });
        }
        // Validate billing cycle
        if (!['monthly', 'annual'].includes(billingCycle)) {
            return res.status(400).json({ success: false, error: 'Invalid billing cycle', valid: ['monthly', 'annual'] });
        }
        // Determine payment gateway
        let gateway = paymentMethod;
        if (gateway === 'auto') {
            const tenantCountry = tenant?.settings?.country || 'ZA';
            gateway = tenantCountry === 'ZA' && ozow_payment_service_1.default.isConfigured() ? 'ozow' : 'stripe';
        }
        const paymentData = {
            tenantId,
            userId: user?.id,
            amount: 0,
            plan,
            billingCycle,
            customerEmail: user?.email,
            customerName: `${user?.first_name || ''} ${user?.last_name || ''}`.trim()
        };
        let amount;
        let currency;
        let paymentUrl;
        let transactionReference;
        if (gateway === 'ozow') {
            if (!ozow_payment_service_1.default.isConfigured()) {
                return res.status(503).json({ success: false, error: 'Ozow payment gateway not configured' });
            }
            amount = ozow_payment_service_1.default.getPlanPricing(plan, billingCycle);
            currency = 'ZAR';
            const ozowResponse = await ozow_payment_service_1.default.createPaymentRequest({
                ...paymentData,
                amount
            });
            paymentUrl = ozowResponse.url;
            transactionReference = ozowResponse.transactionReference;
        }
        else {
            if (!stripe_payment_service_1.default.isConfigured()) {
                return res.status(503).json({ success: false, error: 'Stripe payment gateway not configured' });
            }
            amount = stripe_payment_service_1.default.getPlanPricing(plan, billingCycle);
            currency = 'USD';
            const stripeResponse = await stripe_payment_service_1.default.createCheckoutSession({
                ...paymentData,
                amount,
                currency
            });
            paymentUrl = stripeResponse.url;
            transactionReference = stripeResponse.transactionReference;
        }
        res.json({
            success: true,
            data: {
                gateway,
                paymentUrl,
                transactionReference,
                amount,
                currency,
                plan,
                billingCycle
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Create payment session error:', error);
        res.status(500).json({ success: false, error: 'Failed to create payment session' });
    }
};
exports.createPaymentSession = createPaymentSession;
/**
 * Get payment transaction status
 */
const getPaymentStatus = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { reference } = req.params;
        const payment = await ozow_payment_service_1.default.getPaymentStatus(reference);
        if (!payment) {
            return res.status(404).json({ success: false, error: 'Payment not found' });
        }
        // Verify tenant ownership
        if (payment.tenant_id !== tenantId) {
            return res.status(403).json({ success: false, error: 'Access denied' });
        }
        res.json({
            success: true,
            data: {
                reference: payment.transaction_reference,
                status: payment.status,
                amount: payment.amount,
                currency: payment.currency,
                gateway: payment.payment_gateway,
                plan: payment.plan,
                billingCycle: payment.billing_cycle,
                paidAt: payment.paid_at,
                createdAt: payment.created_at
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get payment status error:', error);
        res.status(500).json({ success: false, error: 'Failed to get payment status' });
    }
};
exports.getPaymentStatus = getPaymentStatus;
/**
 * Get tenant payment history
 */
const getPaymentHistory = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const payments = await ozow_payment_service_1.default.getPaymentHistory(tenantId);
        res.json({
            success: true,
            data: payments
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get payment history error:', error);
        res.status(500).json({ success: false, error: 'Failed to get payment history' });
    }
};
exports.getPaymentHistory = getPaymentHistory;
/**
 * Cancel pending payment
 */
const cancelPayment = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { reference } = req.params;
        await ozow_payment_service_1.default.cancelPayment(reference, tenantId);
        res.json({
            success: true,
            message: 'Payment cancelled'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Cancel payment error:', error);
        res.status(500).json({ success: false, error: 'Failed to cancel payment' });
    }
};
exports.cancelPayment = cancelPayment;
/**
 * Get pricing information for all plans
 */
const getPricing = async (req, res) => {
    try {
        const { tenant } = getTenantContext(req);
        const { gateway = 'auto' } = req.query;
        let selectedGateway = gateway;
        if (selectedGateway === 'auto') {
            const tenantCountry = tenant?.settings?.country || 'ZA';
            selectedGateway = tenantCountry === 'ZA' ? 'ozow' : 'stripe';
        }
        const plans = ['starter', 'professional', 'enterprise'];
        const pricing = {};
        for (const plan of plans) {
            if (selectedGateway === 'ozow') {
                pricing[plan] = {
                    monthly: {
                        amount: ozow_payment_service_1.default.getPlanPricing(plan, 'monthly'),
                        currency: 'ZAR'
                    },
                    annual: {
                        amount: ozow_payment_service_1.default.getPlanPricing(plan, 'annual'),
                        currency: 'ZAR',
                        discount: '2 months free'
                    }
                };
            }
            else {
                pricing[plan] = {
                    monthly: {
                        amount: stripe_payment_service_1.default.getPlanPricing(plan, 'monthly'),
                        currency: 'USD'
                    },
                    annual: {
                        amount: stripe_payment_service_1.default.getPlanPricing(plan, 'annual'),
                        currency: 'USD',
                        discount: '2 months free'
                    }
                };
            }
        }
        res.json({
            success: true,
            data: {
                gateway: selectedGateway,
                pricing
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get pricing error:', error);
        res.status(500).json({ success: false, error: 'Failed to get pricing' });
    }
};
exports.getPricing = getPricing;
exports.default = {
    createPaymentSession: exports.createPaymentSession,
    getPaymentStatus: exports.getPaymentStatus,
    getPaymentHistory: exports.getPaymentHistory,
    cancelPayment: exports.cancelPayment,
    getPricing: exports.getPricing
};
//# sourceMappingURL=payment.controller.v2.js.map