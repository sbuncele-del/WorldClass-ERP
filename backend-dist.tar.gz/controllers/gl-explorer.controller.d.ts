import { Request, Response } from 'express';
/**
 * GL Explorer Controller
 * Advanced search and analysis for General Ledger
 */
export declare class GLExplorerController {
    /**
     * Advanced search with multiple filters
     */
    search(req: Request, res: Response): Promise<void>;
    /**
     * Get account tree/hierarchy
     */
    getAccountTree(req: Request, res: Response): Promise<void>;
    /**
     * Get account drill-down (all transactions for an account)
     */
    getAccountDrillDown(req: Request, res: Response): Promise<void>;
    /**
     * Get filter options (for dropdowns)
     */
    getFilterOptions(req: Request, res: Response): Promise<void>;
}
declare const _default: GLExplorerController;
export default _default;
//# sourceMappingURL=gl-explorer.controller.d.ts.map