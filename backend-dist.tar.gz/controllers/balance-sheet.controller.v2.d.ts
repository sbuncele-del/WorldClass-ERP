/**
 * Balance Sheet Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure balance sheet generation and reporting.
 * All queries filtered by tenant_id.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class BalanceSheetControllerV2 {
    /**
     * Generate Balance Sheet
     * GET /api/v2/financial/reports/balance-sheet
     */
    static generateBalanceSheet(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get trial balance
     * GET /api/v2/financial/reports/trial-balance
     */
    static getTrialBalance(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Export balance sheet to PDF
     * POST /api/v2/financial/reports/balance-sheet/export
     */
    static exportToPDF(req: TenantRequest, res: Response): Promise<void>;
}
export default BalanceSheetControllerV2;
//# sourceMappingURL=balance-sheet.controller.v2.d.ts.map