import { Request, Response } from 'express';
/**
 * Financial Forecasting Controller
 * Handles budgets, budget vs actual analysis, variance reporting, and forecasting models
 */
/**
 * Get all budget scenarios
 */
export declare function getBudgetScenarios(req: Request, res: Response): Promise<void>;
/**
 * Create a new budget scenario
 */
export declare function createBudgetScenario(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Get all budgets with optional filters
 */
export declare function getBudgets(req: Request, res: Response): Promise<void>;
/**
 * Get a single budget by ID with all its lines
 */
export declare function getBudgetById(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Create a new budget
 */
export declare function createBudget(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Update an existing budget
 */
export declare function updateBudget(req: Request, res: Response): Promise<void>;
/**
 * Delete a budget
 */
export declare function deleteBudget(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Get budget vs actual comparison
 */
export declare function getBudgetVsActual(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Get variance analysis (from view)
 */
export declare function getVarianceAnalysis(req: Request, res: Response): Promise<void>;
/**
 * Generate forecast for an account (simple linear projection)
 */
export declare function generateForecast(req: Request, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Get dashboard summary for budget performance
 */
export declare function getBudgetDashboard(req: Request, res: Response): Promise<void>;
//# sourceMappingURL=financial-forecasting.controller.d.ts.map