import { Request, Response } from 'express';
/**
 * Admin Controller
 *
 * Handles user management, roles, permissions, settings, and notifications
 * All endpoints should be protected by appropriate auth middleware
 */
declare class AdminController {
    /**
     * Get all users
     * GET /api/admin/users
     */
    getAllUsers(req: Request, res: Response): Promise<void>;
    /**
     * Get user by ID
     * GET /api/admin/users/:id
     */
    getUserById(req: Request, res: Response): Promise<void>;
    /**
     * Create user
     * POST /api/admin/users
     */
    createUser(req: Request, res: Response): Promise<void>;
    /**
     * Update user
     * PUT /api/admin/users/:id
     */
    updateUser(req: Request, res: Response): Promise<void>;
    /**
     * Delete user
     * DELETE /api/admin/users/:id
     */
    deleteUser(req: Request, res: Response): Promise<void>;
    /**
     * Reset user password
     * POST /api/admin/users/:id/reset-password
     */
    resetPassword(req: Request, res: Response): Promise<void>;
    /**
     * Get all roles
     * GET /api/admin/roles
     */
    getAllRoles(req: Request, res: Response): Promise<void>;
    /**
     * Get role by ID with permissions
     * GET /api/admin/roles/:id
     */
    getRoleById(req: Request, res: Response): Promise<void>;
    /**
     * Create role
     * POST /api/admin/roles
     */
    createRole(req: Request, res: Response): Promise<void>;
    /**
     * Update role permissions
     * POST /api/admin/roles/:id/permissions
     */
    updateRolePermissions(req: Request, res: Response): Promise<void>;
    /**
     * Get all permissions
     * GET /api/admin/permissions
     */
    getAllPermissions(req: Request, res: Response): Promise<void>;
    /**
     * Get all settings
     * GET /api/admin/settings
     */
    getAllSettings(req: Request, res: Response): Promise<void>;
    /**
     * Update setting
     * PUT /api/admin/settings/:key
     */
    updateSetting(req: Request, res: Response): Promise<void>;
    /**
     * Get user notifications
     * GET /api/admin/notifications
     */
    getNotifications(req: Request, res: Response): Promise<void>;
    /**
     * Mark notification as read
     * PUT /api/admin/notifications/:id/read
     */
    markNotificationRead(req: Request, res: Response): Promise<void>;
    /**
     * Get audit logs
     * GET /api/admin/audit-logs
     */
    getAuditLogs(req: Request, res: Response): Promise<void>;
}
declare const _default: AdminController;
export default _default;
//# sourceMappingURL=admin.controller.d.ts.map