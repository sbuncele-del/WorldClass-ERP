/**
 * Property Controller V2
 * Tenant-hardened API for property management operations
 *
 * Features:
 * - Property portfolio management
 * - Unit management
 * - Tenant (occupant) management
 * - Lease management
 * - Maintenance requests
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProperties: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPropertyById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProperty: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProperty: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getUnits: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createUnit: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateUnit: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getOccupants: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createOccupant: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateOccupant: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getLeases: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createLease: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateLease: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMaintenanceRequests: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createMaintenanceRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateMaintenanceRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProperties: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPropertyById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createProperty: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateProperty: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getUnits: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createUnit: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateUnit: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getOccupants: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createOccupant: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateOccupant: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getLeases: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createLease: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateLease: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMaintenanceRequests: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createMaintenanceRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateMaintenanceRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=property.controller.v2.d.ts.map