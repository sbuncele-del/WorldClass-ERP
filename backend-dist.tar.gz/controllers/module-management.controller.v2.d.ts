/**
 * Module Management Controller V2
 * Tenant-hardened API for ERP module management
 *
 * Features:
 * - Enable/disable modules
 * - Module configuration
 * - Module dependencies
 * - Usage tracking
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get all available modules with tenant status
 */
export declare const getModules: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get module by code
 */
export declare const getModuleByCode: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Enable a module
 */
export declare const enableModule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Disable a module
 */
export declare const disableModule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update module configuration
 */
export declare const updateModuleConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get module usage statistics
 */
export declare const getModuleUsage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get module dependencies
 */
export declare const getModuleDependencies: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getModules: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getModuleByCode: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    enableModule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    disableModule: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateModuleConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getModuleUsage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getModuleDependencies: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=module-management.controller.v2.d.ts.map