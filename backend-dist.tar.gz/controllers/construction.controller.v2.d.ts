/**
 * Construction Controller V2
 * Tenant-hardened API for construction industry operations
 *
 * Features:
 * - Project management
 * - Phase tracking
 * - Safety incident reporting
 * - Materials management
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjects: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProjectPhases: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createPhase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updatePhase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSafetyIncidents: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const reportSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMaterials: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const addMaterial: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateMaterial: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProjects: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProjectById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateProject: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProjectPhases: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createPhase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updatePhase: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSafetyIncidents: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    reportSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateSafetyIncident: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMaterials: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    addMaterial: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateMaterial: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=construction.controller.v2.d.ts.map