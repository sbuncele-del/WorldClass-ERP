import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
/**
 * Profile Controller
 *
 * Handles user profile management operations
 */
/**
 * Get user profile
 *
 * GET /api/auth/profile
 */
export declare function getProfile(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Update user profile
 *
 * PATCH /api/auth/profile
 */
export declare function updateProfile(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Change password
 *
 * POST /api/auth/change-password
 */
export declare function changePassword(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Upload avatar
 *
 * POST /api/auth/avatar
 */
export declare function uploadAvatar(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * Delete avatar
 *
 * DELETE /api/auth/avatar
 */
export declare function deleteAvatar(req: AuthRequest, res: Response): Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=profile.controller.d.ts.map