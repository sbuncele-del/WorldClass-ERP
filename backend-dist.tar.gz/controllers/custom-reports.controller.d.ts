import { Request, Response } from 'express';
export declare const getReportTemplates: (req: Request, res: Response) => Promise<void>;
export declare const getReportTemplateById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createReportTemplate: (req: Request, res: Response) => Promise<void>;
export declare const updateReportTemplate: (req: Request, res: Response) => Promise<void>;
export declare const deleteReportTemplate: (req: Request, res: Response) => Promise<void>;
export declare const cloneReportTemplate: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const executeReport: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getReportCategories: (req: Request, res: Response) => Promise<void>;
export declare const getPopularReports: (req: Request, res: Response) => Promise<void>;
export declare const getReportExecutions: (req: Request, res: Response) => Promise<void>;
export declare const toggleFavorite: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=custom-reports.controller.d.ts.map