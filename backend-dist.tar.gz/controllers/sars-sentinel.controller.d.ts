import { Request, Response } from 'express';
/**
 * SARS Sentinel Controller
 *
 * Handles South African Revenue Service (SARS) compliance:
 * - Correspondence tracking
 * - Deadline management
 * - Workflow automation
 * - Submission history
 * - AI-powered analysis
 */
declare class SARSSentinelController {
    /**
     * Get all SARS correspondence
     * GET /api/sars-sentinel/correspondence
     */
    getCorrespondence(req: Request, res: Response): Promise<void>;
    /**
     * Get correspondence by ID
     * GET /api/sars-sentinel/correspondence/:id
     */
    getCorrespondenceById(req: Request, res: Response): Promise<void>;
    /**
     * Create SARS correspondence
     * POST /api/sars-sentinel/correspondence
     */
    createCorrespondence(req: Request, res: Response): Promise<void>;
    /**
     * Update correspondence
     * PUT /api/sars-sentinel/correspondence/:id
     */
    updateCorrespondence(req: Request, res: Response): Promise<void>;
    /**
     * Add comment to correspondence
     * POST /api/sars-sentinel/correspondence/:id/comments
     */
    addComment(req: Request, res: Response): Promise<void>;
    /**
     * Get dashboard statistics
     * GET /api/sars-sentinel/dashboard/stats
     */
    getDashboardStats(req: Request, res: Response): Promise<void>;
    /**
     * Create workflow for correspondence
     * POST /api/sars-sentinel/correspondence/:id/workflows
     */
    createWorkflow(req: Request, res: Response): Promise<void>;
    /**
     * Get workflow steps
     * GET /api/sars-sentinel/workflows/:workflowId/steps
     */
    getWorkflowSteps(req: Request, res: Response): Promise<void>;
    /**
     * Complete workflow step
     * POST /api/sars-sentinel/workflows/steps/:stepId/complete
     */
    completeWorkflowStep(req: Request, res: Response): Promise<void>;
    /**
     * Get submission history
     * GET /api/sars-sentinel/submissions
     */
    getSubmissionHistory(req: Request, res: Response): Promise<void>;
    /**
     * Record submission
     * POST /api/sars-sentinel/submissions
     */
    recordSubmission(req: Request, res: Response): Promise<void>;
    /**
     * Get correspondence types
     * GET /api/sars-sentinel/correspondence-types
     */
    getCorrespondenceTypes(_req: Request, res: Response): Promise<void>;
    /**
     * Get deadline calendar
     * GET /api/sars-sentinel/deadline-calendar
     */
    getDeadlineCalendar(req: Request, res: Response): Promise<void>;
}
declare const _default: SARSSentinelController;
export default _default;
//# sourceMappingURL=sars-sentinel.controller.d.ts.map