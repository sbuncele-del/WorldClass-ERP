/**
 * Proposals Controller V2
 * Tenant-hardened API for proposal/quote management
 *
 * Features:
 * - Proposal CRUD operations
 * - Workspace summary
 * - Send/convert proposals
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProposals: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProposalById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const convertProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProposals: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProposalById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    sendProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    convertProposal: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=proposals.controller.v2.d.ts.map