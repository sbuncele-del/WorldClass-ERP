/**
 * Admin Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure administration for users, roles,
 * permissions, and tenant settings.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class AdminControllerV2 {
    /**
     * Get all users
     * GET /api/v2/admin/users
     */
    static getAllUsers(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get user by ID
     * GET /api/v2/admin/users/:id
     */
    static getUserById(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Create a new user
     * POST /api/v2/admin/users
     */
    static createUser(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update user
     * PUT /api/v2/admin/users/:id
     */
    static updateUser(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Delete/deactivate user
     * DELETE /api/v2/admin/users/:id
     */
    static deleteUser(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get all roles
     * GET /api/v2/admin/roles
     */
    static getRoles(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Create a role
     * POST /api/v2/admin/roles
     */
    static createRole(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get audit log
     * GET /api/v2/admin/audit-log
     */
    static getAuditLog(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get tenant settings
     * GET /api/v2/admin/settings
     */
    static getSettings(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update tenant settings
     * PUT /api/v2/admin/settings
     */
    static updateSettings(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Invite a new user via email
     * POST /api/v2/admin/users/invite
     */
    static inviteUser(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Accept invitation and set password
     * POST /api/v2/admin/users/accept-invite
     */
    static acceptInvitation(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Resend invitation email
     * POST /api/v2/admin/users/:id/resend-invite
     */
    static resendInvitation(req: TenantRequest, res: Response): Promise<void>;
}
export default AdminControllerV2;
//# sourceMappingURL=admin.controller.v2.d.ts.map