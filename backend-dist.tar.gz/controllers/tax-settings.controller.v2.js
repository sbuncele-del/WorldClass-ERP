"use strict";
/**
 * Tax Settings Controller V2
 * Tenant-hardened API for tax configuration
 *
 * Features:
 * - Tax settings CRUD
 * - VAT/GST configuration
 * - PAYE settings
 * - Income tax brackets
 * - eFiling integration
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateEfilingConfig = exports.getEfilingConfig = exports.updateIncomeTaxBrackets = exports.getIncomeTaxBrackets = exports.updatePayeSettings = exports.getPayeSettings = exports.updateVatConfig = exports.getVatConfig = exports.updateTaxAccount = exports.getTaxAccounts = exports.updateTaxSettings = exports.getTaxSettings = void 0;
const database_1 = require("../config/database");
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '' };
}
// ============================================================================
// TAX SETTINGS
// ============================================================================
/**
 * Get tax settings for tenant
 */
const getTaxSettings = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT * FROM tax_settings WHERE tenant_id = $1`, [tenantId]);
        if (result.rows.length === 0) {
            // Return default settings
            return res.json({
                success: true,
                data: {
                    vatEnabled: false,
                    vatRate: 15,
                    vatNumber: null,
                    payeEnabled: false,
                    incomeTaxEnabled: false,
                    taxYear: new Date().getFullYear(),
                    country: 'ZA',
                    currency: 'ZAR'
                }
            });
        }
        res.json({
            success: true,
            data: result.rows[0]
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get tax settings error:', error);
        res.status(500).json({ success: false, error: 'Failed to get tax settings' });
    }
};
exports.getTaxSettings = getTaxSettings;
/**
 * Update tax settings
 */
const updateTaxSettings = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { vatEnabled, vatRate, vatNumber, payeEnabled, incomeTaxEnabled, taxYear, country, currency } = req.body;
        // Upsert tax settings
        const result = await database_1.pool.query(`INSERT INTO tax_settings 
        (tenant_id, vat_enabled, vat_rate, vat_number, paye_enabled, 
         income_tax_enabled, tax_year, country, currency, updated_by, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, NOW())
       ON CONFLICT (tenant_id) DO UPDATE SET
         vat_enabled = COALESCE($2, tax_settings.vat_enabled),
         vat_rate = COALESCE($3, tax_settings.vat_rate),
         vat_number = COALESCE($4, tax_settings.vat_number),
         paye_enabled = COALESCE($5, tax_settings.paye_enabled),
         income_tax_enabled = COALESCE($6, tax_settings.income_tax_enabled),
         tax_year = COALESCE($7, tax_settings.tax_year),
         country = COALESCE($8, tax_settings.country),
         currency = COALESCE($9, tax_settings.currency),
         updated_by = $10,
         updated_at = NOW()
       RETURNING *`, [tenantId, vatEnabled, vatRate, vatNumber, payeEnabled, incomeTaxEnabled, taxYear, country, currency, userId]);
        res.json({
            success: true,
            data: result.rows[0],
            message: 'Tax settings updated'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update tax settings error:', error);
        res.status(500).json({ success: false, error: 'Failed to update tax settings' });
    }
};
exports.updateTaxSettings = updateTaxSettings;
// ============================================================================
// TAX ACCOUNTS
// ============================================================================
/**
 * Get tax accounts (GL accounts for tax)
 */
const getTaxAccounts = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT ta.*, a.account_name, a.account_number 
       FROM tax_accounts ta
       LEFT JOIN accounts a ON ta.account_id = a.id AND a.tenant_id = $1
       WHERE ta.tenant_id = $1
       ORDER BY ta.tax_type`, [tenantId]);
        res.json({
            success: true,
            data: result.rows
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get tax accounts error:', error);
        res.status(500).json({ success: false, error: 'Failed to get tax accounts' });
    }
};
exports.getTaxAccounts = getTaxAccounts;
/**
 * Update tax account mapping
 */
const updateTaxAccount = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { taxType, accountId, description } = req.body;
        // Validate tax type
        const validTaxTypes = ['vat_output', 'vat_input', 'paye', 'income_tax', 'uif', 'sdl'];
        if (!validTaxTypes.includes(taxType)) {
            return res.status(400).json({
                success: false,
                error: 'Invalid tax type',
                validTypes: validTaxTypes
            });
        }
        // Verify account belongs to tenant
        if (accountId) {
            const accountCheck = await database_1.pool.query(`SELECT id FROM accounts WHERE id = $1 AND tenant_id = $2`, [accountId, tenantId]);
            if (accountCheck.rows.length === 0) {
                return res.status(404).json({ success: false, error: 'Account not found' });
            }
        }
        const result = await database_1.pool.query(`INSERT INTO tax_accounts (tenant_id, tax_type, account_id, description, updated_by, updated_at)
       VALUES ($1, $2, $3, $4, $5, NOW())
       ON CONFLICT (tenant_id, tax_type) DO UPDATE SET
         account_id = $3,
         description = COALESCE($4, tax_accounts.description),
         updated_by = $5,
         updated_at = NOW()
       RETURNING *`, [tenantId, taxType, accountId, description, userId]);
        res.json({
            success: true,
            data: result.rows[0],
            message: 'Tax account mapping updated'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update tax account error:', error);
        res.status(500).json({ success: false, error: 'Failed to update tax account' });
    }
};
exports.updateTaxAccount = updateTaxAccount;
// ============================================================================
// VAT SETTINGS
// ============================================================================
/**
 * Get VAT configuration
 */
const getVatConfig = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT * FROM vat_config WHERE tenant_id = $1`, [tenantId]);
        res.json({
            success: true,
            data: result.rows[0] || {
                standardRate: 15,
                reducedRates: [],
                exemptions: [],
                registrationThreshold: 1000000
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get VAT config error:', error);
        res.status(500).json({ success: false, error: 'Failed to get VAT config' });
    }
};
exports.getVatConfig = getVatConfig;
/**
 * Update VAT configuration
 */
const updateVatConfig = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { standardRate, reducedRates, exemptions, registrationThreshold, vatPeriod } = req.body;
        const result = await database_1.pool.query(`INSERT INTO vat_config 
        (tenant_id, standard_rate, reduced_rates, exemptions, registration_threshold, vat_period, updated_by, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())
       ON CONFLICT (tenant_id) DO UPDATE SET
         standard_rate = COALESCE($2, vat_config.standard_rate),
         reduced_rates = COALESCE($3, vat_config.reduced_rates),
         exemptions = COALESCE($4, vat_config.exemptions),
         registration_threshold = COALESCE($5, vat_config.registration_threshold),
         vat_period = COALESCE($6, vat_config.vat_period),
         updated_by = $7,
         updated_at = NOW()
       RETURNING *`, [tenantId, standardRate, JSON.stringify(reducedRates), JSON.stringify(exemptions), registrationThreshold, vatPeriod, userId]);
        res.json({
            success: true,
            data: result.rows[0],
            message: 'VAT configuration updated'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update VAT config error:', error);
        res.status(500).json({ success: false, error: 'Failed to update VAT config' });
    }
};
exports.updateVatConfig = updateVatConfig;
// ============================================================================
// PAYE SETTINGS
// ============================================================================
/**
 * Get PAYE settings
 */
const getPayeSettings = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT * FROM paye_settings WHERE tenant_id = $1`, [tenantId]);
        res.json({
            success: true,
            data: result.rows[0] || {
                enabled: false,
                uifRate: 1,
                sdlRate: 1,
                payeReference: null,
                uifReference: null
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get PAYE settings error:', error);
        res.status(500).json({ success: false, error: 'Failed to get PAYE settings' });
    }
};
exports.getPayeSettings = getPayeSettings;
/**
 * Update PAYE settings
 */
const updatePayeSettings = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { enabled, uifRate, sdlRate, payeReference, uifReference, sdlReference } = req.body;
        const result = await database_1.pool.query(`INSERT INTO paye_settings 
        (tenant_id, enabled, uif_rate, sdl_rate, paye_reference, uif_reference, sdl_reference, updated_by, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
       ON CONFLICT (tenant_id) DO UPDATE SET
         enabled = COALESCE($2, paye_settings.enabled),
         uif_rate = COALESCE($3, paye_settings.uif_rate),
         sdl_rate = COALESCE($4, paye_settings.sdl_rate),
         paye_reference = COALESCE($5, paye_settings.paye_reference),
         uif_reference = COALESCE($6, paye_settings.uif_reference),
         sdl_reference = COALESCE($7, paye_settings.sdl_reference),
         updated_by = $8,
         updated_at = NOW()
       RETURNING *`, [tenantId, enabled, uifRate, sdlRate, payeReference, uifReference, sdlReference, userId]);
        res.json({
            success: true,
            data: result.rows[0],
            message: 'PAYE settings updated'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update PAYE settings error:', error);
        res.status(500).json({ success: false, error: 'Failed to update PAYE settings' });
    }
};
exports.updatePayeSettings = updatePayeSettings;
// ============================================================================
// INCOME TAX
// ============================================================================
/**
 * Get income tax brackets
 */
const getIncomeTaxBrackets = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { taxYear } = req.query;
        const year = taxYear || new Date().getFullYear();
        const result = await database_1.pool.query(`SELECT * FROM income_tax_brackets 
       WHERE tenant_id = $1 AND tax_year = $2
       ORDER BY min_income`, [tenantId, year]);
        res.json({
            success: true,
            data: result.rows
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get income tax brackets error:', error);
        res.status(500).json({ success: false, error: 'Failed to get income tax brackets' });
    }
};
exports.getIncomeTaxBrackets = getIncomeTaxBrackets;
/**
 * Update income tax brackets
 */
const updateIncomeTaxBrackets = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { taxYear, brackets } = req.body;
        if (!Array.isArray(brackets) || brackets.length === 0) {
            return res.status(400).json({ success: false, error: 'Brackets must be a non-empty array' });
        }
        const client = await database_1.pool.connect();
        try {
            await client.query('BEGIN');
            // Delete existing brackets for the tax year
            await client.query(`DELETE FROM income_tax_brackets WHERE tenant_id = $1 AND tax_year = $2`, [tenantId, taxYear]);
            // Insert new brackets
            for (const bracket of brackets) {
                await client.query(`INSERT INTO income_tax_brackets 
            (tenant_id, tax_year, min_income, max_income, rate, base_tax, updated_by)
           VALUES ($1, $2, $3, $4, $5, $6, $7)`, [tenantId, taxYear, bracket.minIncome, bracket.maxIncome, bracket.rate, bracket.baseTax || 0, userId]);
            }
            await client.query('COMMIT');
            res.json({
                success: true,
                message: `Income tax brackets updated for ${taxYear}`
            });
        }
        catch (e) {
            await client.query('ROLLBACK');
            throw e;
        }
        finally {
            client.release();
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update income tax brackets error:', error);
        res.status(500).json({ success: false, error: 'Failed to update income tax brackets' });
    }
};
exports.updateIncomeTaxBrackets = updateIncomeTaxBrackets;
// ============================================================================
// eFILING
// ============================================================================
/**
 * Get eFiling configuration
 */
const getEfilingConfig = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT * FROM efiling_config WHERE tenant_id = $1`, [tenantId]);
        // Mask sensitive fields
        const config = result.rows[0];
        if (config?.password) {
            config.password = '********';
        }
        res.json({
            success: true,
            data: config || {
                enabled: false,
                username: null,
                lastSync: null
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get eFiling config error:', error);
        res.status(500).json({ success: false, error: 'Failed to get eFiling config' });
    }
};
exports.getEfilingConfig = getEfilingConfig;
/**
 * Update eFiling configuration
 */
const updateEfilingConfig = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { enabled, username, password, taxPractitionerNumber } = req.body;
        const result = await database_1.pool.query(`INSERT INTO efiling_config 
        (tenant_id, enabled, username, password, tax_practitioner_number, updated_by, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, NOW())
       ON CONFLICT (tenant_id) DO UPDATE SET
         enabled = COALESCE($2, efiling_config.enabled),
         username = COALESCE($3, efiling_config.username),
         password = COALESCE($4, efiling_config.password),
         tax_practitioner_number = COALESCE($5, efiling_config.tax_practitioner_number),
         updated_by = $6,
         updated_at = NOW()
       RETURNING id, tenant_id, enabled, username, tax_practitioner_number, updated_at`, [tenantId, enabled, username, password, taxPractitionerNumber, userId]);
        res.json({
            success: true,
            data: result.rows[0],
            message: 'eFiling configuration updated'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update eFiling config error:', error);
        res.status(500).json({ success: false, error: 'Failed to update eFiling config' });
    }
};
exports.updateEfilingConfig = updateEfilingConfig;
exports.default = {
    getTaxSettings: exports.getTaxSettings,
    updateTaxSettings: exports.updateTaxSettings,
    getTaxAccounts: exports.getTaxAccounts,
    updateTaxAccount: exports.updateTaxAccount,
    getVatConfig: exports.getVatConfig,
    updateVatConfig: exports.updateVatConfig,
    getPayeSettings: exports.getPayeSettings,
    updatePayeSettings: exports.updatePayeSettings,
    getIncomeTaxBrackets: exports.getIncomeTaxBrackets,
    updateIncomeTaxBrackets: exports.updateIncomeTaxBrackets,
    getEfilingConfig: exports.getEfilingConfig,
    updateEfilingConfig: exports.updateEfilingConfig
};
//# sourceMappingURL=tax-settings.controller.v2.js.map