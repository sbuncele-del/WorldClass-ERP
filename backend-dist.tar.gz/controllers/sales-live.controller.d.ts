import { Request, Response } from 'express';
/**
 * GET /api/sales/customers
 * Fetch all customers from sales.customers table
 */
export declare const getCustomers: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/sales/customers/:id
 * Get a single customer by ID
 */
export declare const getCustomerById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/sales/customers
 * Create a new customer
 */
export declare const createCustomer: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * PUT /api/sales/customers/:id
 * Update an existing customer
 */
export declare const updateCustomer: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * DELETE /api/sales/customers/:id
 * Delete a customer
 */
export declare const deleteCustomer: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/sales/leads
 * Fetch all leads
 */
export declare const getLeads: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/sales/leads
 * Create a new lead (as customer)
 */
export declare const createLead: (req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=sales-live.controller.d.ts.map