import { Request, Response } from 'express';
/**
 * Super Admin Controller
 *
 * Handles HTTP requests for super admin functionality
 * All endpoints should be protected by superAdminAuth middleware
 */
declare class SuperAdminController {
    /**
     * Get list of all tenants
     * GET /api/admin/tenants
     */
    getTenants(req: Request, res: Response): Promise<void>;
    /**
     * Get tenant details
     * GET /api/admin/tenants/:id
     */
    getTenantDetails(req: Request, res: Response): Promise<void>;
    /**
     * Suspend tenant
     * POST /api/admin/tenants/:id/suspend
     */
    suspendTenant(req: Request, res: Response): Promise<void>;
    /**
     * Activate tenant
     * POST /api/admin/tenants/:id/activate
     */
    activateTenant(req: Request, res: Response): Promise<void>;
    /**
     * Delete tenant
     * DELETE /api/admin/tenants/:id
     */
    deleteTenant(req: Request, res: Response): Promise<void>;
    /**
     * Generate impersonation token
     * POST /api/admin/impersonate
     */
    impersonateUser(req: Request, res: Response): Promise<void>;
    /**
     * Get system statistics
     * GET /api/admin/stats
     */
    getSystemStats(_req: Request, res: Response): Promise<void>;
    /**
     * Get system health
     * GET /api/admin/health
     */
    getSystemHealth(_req: Request, res: Response): Promise<void>;
    /**
     * Get feature flags
     * GET /api/admin/feature-flags
     */
    getFeatureFlags(_req: Request, res: Response): Promise<void>;
    /**
     * Update feature flag
     * PUT /api/admin/feature-flags/:name
     */
    updateFeatureFlag(req: Request, res: Response): Promise<void>;
    /**
     * Get audit logs
     * GET /api/admin/audit-logs
     */
    getAuditLogs(req: Request, res: Response): Promise<void>;
}
declare const _default: SuperAdminController;
export default _default;
//# sourceMappingURL=super-admin.controller.d.ts.map