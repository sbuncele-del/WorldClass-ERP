/**
 * GL Explorer Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure General Ledger search and exploration.
 * Advanced filtering and analysis capabilities.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class GLExplorerControllerV2 {
    /**
     * Advanced GL search with multiple filters
     * GET /api/v2/financial/gl-explorer/search
     */
    static search(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get account balances summary
     * GET /api/v2/financial/gl-explorer/account-summary
     */
    static getAccountSummary(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get account ledger (all transactions for one account)
     * GET /api/v2/financial/gl-explorer/account-ledger/:accountCode
     */
    static getAccountLedger(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get available filter options
     * GET /api/v2/financial/gl-explorer/filter-options
     */
    static getFilterOptions(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Export search results
     * POST /api/v2/financial/gl-explorer/export
     */
    static exportResults(req: TenantRequest, res: Response): Promise<void>;
}
export default GLExplorerControllerV2;
//# sourceMappingURL=gl-explorer.controller.v2.d.ts.map