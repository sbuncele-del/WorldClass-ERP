/**
 * Tenant Settings Controller V2
 * Tenant-hardened API for tenant configuration
 *
 * Features:
 * - Tenant settings CRUD
 * - Module configuration
 * - Branding settings
 * - Business information
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * Get tenant settings
 */
export declare const getTenantSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update tenant settings
 */
export declare const updateTenantSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get branding settings
 */
export declare const getBrandingSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update branding settings
 */
export declare const updateBrandingSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get enabled modules for tenant
 */
export declare const getModuleConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update module configuration
 */
export declare const updateModuleConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get module settings
 */
export declare const getModuleSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Get notification preferences
 */
export declare const getNotificationPreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * Update notification preferences
 */
export declare const updateNotificationPreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getTenantSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateTenantSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBrandingSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateBrandingSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getModuleConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateModuleConfig: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getModuleSettings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getNotificationPreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateNotificationPreferences: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=tenant-settings.controller.v2.d.ts.map