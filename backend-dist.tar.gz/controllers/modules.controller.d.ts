/**
 * Modules Controller
 * Provides module discovery and availability information
 * Backend informs frontend which modules are available and active
 */
import { Request, Response } from 'express';
/**
 * GET /api/modules/available
 * Returns modules available to the current tenant based on their industry
 *
 * Query params:
 *   - industry: Filter by industry (optional, defaults to tenant's industry)
 *   - status: Filter by status (active, coming_soon, disabled)
 *   - category: Filter by category (core, industry, compliance, advanced, platform)
 */
export declare const getAvailableModules: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/modules/:moduleId
 * Get detailed information about a specific module
 */
export declare const getModuleDetails: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/modules/categories
 * Get list of all module categories
 */
export declare const getModuleCategories: (_req: Request, res: Response) => Promise<void>;
/**
 * GET /api/modules/industries
 * Get list of supported industries
 */
export declare const getSupportedIndustries: (_req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=modules.controller.d.ts.map