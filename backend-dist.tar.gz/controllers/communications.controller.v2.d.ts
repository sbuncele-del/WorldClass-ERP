/**
 * Communications Controller V2
 * Tenant-hardened API for internal communications
 *
 * Features:
 * - Announcements
 * - Chat channels & messages
 * - Direct messages
 * - Notifications
 * - Video meetings
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare const getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getAnnouncements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createAnnouncement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateAnnouncement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const deleteAnnouncement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getChannels: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createChannel: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getChannelMessages: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendChannelMessage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDirectConversations: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDirectMessages: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendDirectMessage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getNotifications: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const markNotificationRead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const markAllNotificationsRead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getNotificationUnreadCount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMessageUnreadCount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMeetings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createMeeting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateMeeting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const cancelMeeting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getMessages: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const sendMessage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getContacts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTemplates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTemplate: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCampaigns: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createCampaign: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getAnnouncements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createAnnouncement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateAnnouncement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteAnnouncement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getChannels: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createChannel: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getChannelMessages: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    sendChannelMessage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getDirectConversations: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getDirectMessages: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    sendDirectMessage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getNotifications: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    markNotificationRead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    markAllNotificationsRead: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getNotificationUnreadCount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMessageUnreadCount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMeetings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createMeeting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateMeeting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    cancelMeeting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getMessages: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    sendMessage: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getContacts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTemplates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createTemplate: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getCampaigns: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createCampaign: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=communications.controller.v2.d.ts.map