/**
 * Fixed Assets Controller V2
 * Tenant-aware handlers for fixed assets, depreciation, disposals, transfers, and maintenance
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
/**
 * GET /api/assets
 * Get all fixed assets with filtering, pagination, and sorting
 */
export declare function getAllAssets(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/assets/:id
 * Get single asset with full details including depreciation schedule
 */
export declare function getAssetById(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/assets
 * Create a new fixed asset
 */
export declare function createAsset(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * PUT /api/assets/:id
 * Update an existing asset
 */
export declare function updateAsset(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
/**
 * DELETE /api/assets/:id
 * Soft delete an asset (mark as disposed)
 */
export declare function deleteAsset(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getAssetCategories(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createAssetCategory(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getAssetDisposals(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createAssetDisposal(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getAssetTransfers(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createAssetTransfer(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getAssetMaintenance(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function createAssetMaintenance(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function runDepreciation(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
export declare function getAssetDashboard(req: TenantRequest, res: Response): Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getAllAssets: typeof getAllAssets;
    getAssetById: typeof getAssetById;
    createAsset: typeof createAsset;
    updateAsset: typeof updateAsset;
    deleteAsset: typeof deleteAsset;
    getAssetCategories: typeof getAssetCategories;
    createAssetCategory: typeof createAssetCategory;
    getAssetDisposals: typeof getAssetDisposals;
    createAssetDisposal: typeof createAssetDisposal;
    getAssetTransfers: typeof getAssetTransfers;
    createAssetTransfer: typeof createAssetTransfer;
    getAssetMaintenance: typeof getAssetMaintenance;
    createAssetMaintenance: typeof createAssetMaintenance;
    runDepreciation: typeof runDepreciation;
    getAssetDashboard: typeof getAssetDashboard;
};
export default _default;
//# sourceMappingURL=assets.controller.v2.d.ts.map