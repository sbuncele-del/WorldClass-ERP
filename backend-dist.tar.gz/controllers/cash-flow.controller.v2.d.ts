/**
 * Cash Flow Statement Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure cash flow statement generation.
 * Supports both indirect and direct methods.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class CashFlowControllerV2 {
    /**
     * Generate Cash Flow Statement
     * GET /api/v2/financial/reports/cash-flow
     */
    static generateCashFlowStatement(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get cash position over time
     * GET /api/v2/financial/reports/cash-position
     */
    static getCashPosition(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Export cash flow to PDF
     * POST /api/v2/financial/reports/cash-flow/export
     */
    static exportToPDF(req: TenantRequest, res: Response): Promise<void>;
}
export default CashFlowControllerV2;
//# sourceMappingURL=cash-flow.controller.v2.d.ts.map