/**
 * Custom Reports Controller V2 - Tenant-Hardened
 *
 * Multi-tenant secure custom report builder and execution.
 * Report templates, columns, filters, and scheduling.
 */
import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class CustomReportsControllerV2 {
    /**
     * Get all report templates
     * GET /api/v2/custom-reports/templates
     */
    static getReportTemplates(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get report template by ID
     * GET /api/v2/custom-reports/templates/:id
     */
    static getReportTemplateById(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Create a new report template
     * POST /api/v2/custom-reports/templates
     */
    static createReportTemplate(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Update a report template
     * PUT /api/v2/custom-reports/templates/:id
     */
    static updateReportTemplate(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Delete a report template
     * DELETE /api/v2/custom-reports/templates/:id
     */
    static deleteReportTemplate(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Run a custom report
     * POST /api/v2/custom-reports/run/:id
     */
    static runReport(req: TenantRequest, res: Response): Promise<void>;
    /**
     * Get report categories
     * GET /api/v2/custom-reports/categories
     */
    static getCategories(req: TenantRequest, res: Response): Promise<void>;
}
export default CustomReportsControllerV2;
//# sourceMappingURL=custom-reports.controller.v2.d.ts.map