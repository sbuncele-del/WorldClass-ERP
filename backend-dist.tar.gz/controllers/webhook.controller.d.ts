import { Request, Response } from 'express';
export declare class WebhookController {
    /**
     * POST /api/webhooks/ozow
     * Handle Ozow payment notifications
     */
    static handleOzowWebhook(req: Request, res: Response): Promise<void>;
    /**
     * POST /api/webhooks/stripe
     * Handle Stripe webhook events
     */
    static handleStripeWebhook(req: Request, res: Response): Promise<void>;
}
export default WebhookController;
//# sourceMappingURL=webhook.controller.d.ts.map