import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
export declare const getTenantSettings: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateTenantSettings: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getModuleConfig: (req: AuthRequest, res: Response) => Promise<void>;
export declare const updateModuleConfig: (req: AuthRequest, res: Response) => Promise<void>;
export declare const getTeamMembers: (req: AuthRequest, res: Response) => Promise<void>;
export declare const inviteTeamMember: (req: AuthRequest, res: Response) => Promise<void>;
export declare const removeTeamMember: (req: AuthRequest, res: Response) => Promise<void>;
//# sourceMappingURL=tenant-settings.controller.d.ts.map