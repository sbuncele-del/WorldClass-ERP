import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class EmailPreferencesController {
    /**
     * GET /api/email-preferences
     * Get current user's email preferences
     */
    static getPreferences(req: TenantRequest, res: Response): Promise<void>;
    /**
     * PATCH /api/email-preferences
     * Update current user's email preferences
     */
    static updatePreferences(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/email-preferences/unsubscribe-all
     * Unsubscribe from all non-essential emails
     */
    static unsubscribeAll(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/email-preferences/resubscribe
     * Resubscribe to emails
     */
    static resubscribe(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/email-preferences/unsubscribe/:token
     * One-click unsubscribe via token (public, no auth required)
     */
    static unsubscribeViaToken(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/email-preferences/categories
     * Get all available email categories with descriptions
     */
    static getCategories(req: TenantRequest, res: Response): Promise<void>;
}
export default EmailPreferencesController;
//# sourceMappingURL=email-preferences.controller.d.ts.map