import { Request, Response } from 'express';
export declare const getSuppliers: (req: Request, res: Response) => Promise<void>;
export declare const getSupplierById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createSupplier: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getSuppliers: (req: Request, res: Response) => Promise<void>;
    getSupplierById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createSupplier: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=purchase.controller.backup2.d.ts.map