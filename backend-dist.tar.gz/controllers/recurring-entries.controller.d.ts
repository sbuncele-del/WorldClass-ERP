import { Request, Response } from 'express';
export declare class RecurringEntriesController {
    /**
     * Get all recurring entries
     * GET /api/financial/recurring-entries
     */
    static getRecurringEntries(req: Request, res: Response): Promise<void>;
    /**
     * Get single recurring entry with lines
     * GET /api/financial/recurring-entries/:id
     */
    static getRecurringEntry(req: Request, res: Response): Promise<void>;
    /**
     * Create new recurring entry
     * POST /api/financial/recurring-entries
     */
    static createRecurringEntry(req: Request, res: Response): Promise<void>;
    /**
     * Update recurring entry
     * PUT /api/financial/recurring-entries/:id
     */
    static updateRecurringEntry(req: Request, res: Response): Promise<void>;
    /**
     * Delete recurring entry
     * DELETE /api/financial/recurring-entries/:id
     */
    static deleteRecurringEntry(req: Request, res: Response): Promise<void>;
    /**
     * Toggle active status
     * PATCH /api/financial/recurring-entries/:id/toggle
     */
    static toggleActive(req: Request, res: Response): Promise<void>;
    /**
     * Generate journal entry from recurring template
     * POST /api/financial/recurring-entries/:id/generate
     */
    static generateEntry(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=recurring-entries.controller.d.ts.map