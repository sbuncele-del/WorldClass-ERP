import { Response } from 'express';
import { TenantRequest } from '../types';
export declare class SubscriptionController {
    /**
     * GET /api/subscription
     * Get current subscription details
     */
    static getCurrentSubscription(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/subscription/upgrade
     * Upgrade to a higher plan
     */
    static upgradePlan(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/subscription/downgrade
     * Schedule downgrade to a lower plan
     */
    static downgradePlan(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/subscription/cancel
     * Cancel subscription (effective at period end)
     */
    static cancelSubscription(req: TenantRequest, res: Response): Promise<void>;
    /**
     * POST /api/subscription/reactivate
     * Reactivate a cancelled subscription
     */
    static reactivateSubscription(req: TenantRequest, res: Response): Promise<void>;
    /**
     * PUT /api/subscription/payment-method
     * Update payment gateway
     */
    static updatePaymentMethod(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/subscription/usage
     * Get usage statistics
     */
    static getUsageStatistics(req: TenantRequest, res: Response): Promise<void>;
    /**
     * GET /api/subscription/status
     * Check subscription status
     */
    static checkSubscriptionStatus(req: TenantRequest, res: Response): Promise<void>;
}
export default SubscriptionController;
//# sourceMappingURL=subscription.controller.d.ts.map