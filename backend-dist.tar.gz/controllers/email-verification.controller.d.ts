/**
 * Email Verification Controller
 * Handles HTTP requests for email verification
 */
import { Request, Response } from 'express';
/**
 * Send verification email
 * POST /api/email/verify/send
 */
export declare function sendVerification(req: Request, res: Response): Promise<void>;
/**
 * Verify email token
 * POST /api/email/verify
 */
export declare function verifyEmail(req: Request, res: Response): Promise<void>;
/**
 * Resend verification email
 * POST /api/email/verify/resend
 */
export declare function resendVerification(req: Request, res: Response): Promise<void>;
/**
 * Get verification status
 * GET /api/email/verify/status/:userId
 */
export declare function getStatus(req: Request, res: Response): Promise<void>;
/**
 * Check if email is verified (middleware-compatible)
 * GET /api/email/verify/check/:userId
 */
export declare function checkVerified(req: Request, res: Response): Promise<void>;
declare const _default: {
    sendVerification: typeof sendVerification;
    verifyEmail: typeof verifyEmail;
    resendVerification: typeof resendVerification;
    getStatus: typeof getStatus;
    checkVerified: typeof checkVerified;
};
export default _default;
//# sourceMappingURL=email-verification.controller.d.ts.map