"use strict";
/**
 * Email Queue Controller V2
 * Tenant-hardened API for email queue monitoring and management
 *
 * Features:
 * - Queue statistics
 * - Failed job management
 * - Queue pause/resume
 * - Job retry and cleanup
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.healthCheck = exports.getJobDetails = exports.resume = exports.pause = exports.clearFailed = exports.clearCompleted = exports.retryJob = exports.getFailedJobsList = exports.getStats = void 0;
const email_queue_1 = require("../queues/email.queue");
/**
 * Tenant context helper (admin-only operations)
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '' };
}
/**
 * Get queue statistics
 */
const getStats = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        const stats = await (0, email_queue_1.getQueueStats)();
        const isPaused = await email_queue_1.emailQueue.isPaused();
        res.json({
            success: true,
            data: {
                ...stats,
                isPaused
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get queue stats error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch queue statistics' });
    }
};
exports.getStats = getStats;
/**
 * Get failed jobs (dead letter queue)
 */
const getFailedJobsList = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        const limit = parseInt(req.query.limit) || 50;
        const failed = await (0, email_queue_1.getFailedJobs)(limit);
        res.json({
            success: true,
            data: {
                count: failed.length,
                jobs: failed
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get failed jobs error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch failed jobs' });
    }
};
exports.getFailedJobsList = getFailedJobsList;
/**
 * Retry a failed job
 */
const retryJob = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        const { jobId } = req.params;
        if (!jobId) {
            return res.status(400).json({ success: false, error: 'Job ID is required' });
        }
        const success = await (0, email_queue_1.retryFailedJob)(jobId);
        if (success) {
            res.json({
                success: true,
                message: `Job ${jobId} queued for retry`
            });
        }
        else {
            res.status(404).json({ success: false, error: 'Job not found' });
        }
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Retry job error:', error);
        res.status(500).json({ success: false, error: 'Failed to retry job' });
    }
};
exports.retryJob = retryJob;
/**
 * Clear completed jobs
 */
const clearCompleted = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        await (0, email_queue_1.clearCompletedJobs)();
        res.json({
            success: true,
            message: 'Completed jobs cleared'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Clear completed jobs error:', error);
        res.status(500).json({ success: false, error: 'Failed to clear completed jobs' });
    }
};
exports.clearCompleted = clearCompleted;
/**
 * Clear failed jobs
 */
const clearFailed = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        await (0, email_queue_1.clearFailedJobs)();
        res.json({
            success: true,
            message: 'Failed jobs cleared'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Clear failed jobs error:', error);
        res.status(500).json({ success: false, error: 'Failed to clear failed jobs' });
    }
};
exports.clearFailed = clearFailed;
/**
 * Pause queue processing
 */
const pause = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        await (0, email_queue_1.pauseQueue)();
        res.json({
            success: true,
            message: 'Queue paused'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Pause queue error:', error);
        res.status(500).json({ success: false, error: 'Failed to pause queue' });
    }
};
exports.pause = pause;
/**
 * Resume queue processing
 */
const resume = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        await (0, email_queue_1.resumeQueue)();
        res.json({
            success: true,
            message: 'Queue resumed'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Resume queue error:', error);
        res.status(500).json({ success: false, error: 'Failed to resume queue' });
    }
};
exports.resume = resume;
/**
 * Get job details by ID
 */
const getJobDetails = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        const { jobId } = req.params;
        if (!jobId) {
            return res.status(400).json({ success: false, error: 'Job ID is required' });
        }
        const job = await email_queue_1.emailQueue.getJob(jobId);
        if (!job) {
            return res.status(404).json({ success: false, error: 'Job not found' });
        }
        const state = await job.getState();
        res.json({
            success: true,
            data: {
                id: job.id,
                data: job.data,
                state,
                progress: job.progress(),
                attemptsMade: job.attemptsMade,
                failedReason: job.failedReason,
                stacktrace: job.stacktrace,
                timestamp: job.timestamp,
                processedOn: job.processedOn,
                finishedOn: job.finishedOn,
                returnvalue: job.returnvalue
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get job details error:', error);
        res.status(500).json({ success: false, error: 'Failed to fetch job details' });
    }
};
exports.getJobDetails = getJobDetails;
/**
 * Get queue health check
 */
const healthCheck = async (req, res) => {
    try {
        getTenantContext(req); // Verify tenant access
        const stats = await (0, email_queue_1.getQueueStats)();
        const isPaused = await email_queue_1.emailQueue.isPaused();
        // Determine health status
        const isHealthy = stats.failed < 100 && !isPaused && stats.active < 1000;
        res.json({
            success: true,
            data: {
                healthy: isHealthy,
                status: isPaused ? 'paused' : isHealthy ? 'healthy' : 'degraded',
                stats
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Health check error:', error);
        res.status(500).json({
            success: false,
            data: {
                healthy: false,
                status: 'error'
            },
            error: 'Failed to check queue health'
        });
    }
};
exports.healthCheck = healthCheck;
exports.default = {
    getStats: exports.getStats,
    getFailedJobsList: exports.getFailedJobsList,
    retryJob: exports.retryJob,
    clearCompleted: exports.clearCompleted,
    clearFailed: exports.clearFailed,
    pause: exports.pause,
    resume: exports.resume,
    getJobDetails: exports.getJobDetails,
    healthCheck: exports.healthCheck
};
//# sourceMappingURL=email-queue.controller.v2.js.map