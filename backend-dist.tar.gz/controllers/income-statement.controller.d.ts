import { Request, Response } from 'express';
export declare class IncomeStatementController {
    /**
     * Generate Income Statement
     * GET /api/financial/reports/income-statement
     */
    static generateIncomeStatement(req: Request, res: Response): Promise<void>;
    /**
     * Export Income Statement to PDF
     * POST /api/financial/reports/income-statement/export
     */
    static exportToPDF(req: Request, res: Response): Promise<void>;
    /**
     * Get account drill-down details
     * GET /api/financial/reports/income-statement/account/:accountCode
     */
    static getAccountDetails(req: Request, res: Response): Promise<void>;
}
//# sourceMappingURL=income-statement.controller.d.ts.map