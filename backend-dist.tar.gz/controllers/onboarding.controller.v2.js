"use strict";
/**
 * Onboarding Controller V2
 * Tenant-hardened API for tenant onboarding workflow
 *
 * Features:
 * - Onboarding status tracking
 * - Step-by-step progress
 * - Complete/skip onboarding
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getChecklist = exports.reset = exports.skip = exports.complete = exports.update = exports.getStatus = void 0;
const database_1 = require("../config/database");
const welcome_email_service_1 = __importDefault(require("../services/welcome-email.service"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    const userId = req.user?.id;
    const userEmail = req.user?.email;
    if (!tenantId) {
        throw new Error('Tenant context required');
    }
    return { tenantId, userId: userId || '', userEmail: userEmail || '' };
}
/**
 * Get onboarding status for current tenant
 */
const getStatus = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT onboarding_completed, onboarding_data, onboarding_step
       FROM tenants
       WHERE id = $1`, [tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, error: 'Tenant not found' });
        }
        const tenant = result.rows[0];
        res.json({
            success: true,
            data: {
                completed: tenant.onboarding_completed || false,
                currentStep: tenant.onboarding_step || 1,
                completedSteps: getCompletedSteps(tenant.onboarding_data),
                data: tenant.onboarding_data || {}
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get onboarding status error:', error);
        res.status(500).json({ success: false, error: 'Failed to get onboarding status' });
    }
};
exports.getStatus = getStatus;
/**
 * Update onboarding progress
 */
const update = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { step, data } = req.body;
        if (typeof step !== 'number' || step < 1) {
            return res.status(400).json({ success: false, error: 'Valid step number is required' });
        }
        // Get current onboarding data
        const currentResult = await database_1.pool.query(`SELECT onboarding_data FROM tenants WHERE id = $1`, [tenantId]);
        const currentData = currentResult.rows[0]?.onboarding_data || {};
        const updatedData = { ...currentData, ...data, [`step${step}Completed`]: true };
        // Update tenant with new data
        const result = await database_1.pool.query(`UPDATE tenants
       SET onboarding_data = $1,
           onboarding_step = $2,
           updated_at = NOW()
       WHERE id = $3
       RETURNING onboarding_completed, onboarding_data, onboarding_step`, [JSON.stringify(updatedData), step, tenantId]);
        res.json({
            success: true,
            data: {
                completed: result.rows[0].onboarding_completed || false,
                currentStep: step,
                completedSteps: getCompletedSteps(updatedData),
                data: updatedData
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Update onboarding error:', error);
        res.status(500).json({ success: false, error: 'Failed to update onboarding' });
    }
};
exports.update = update;
/**
 * Mark onboarding as complete
 */
const complete = async (req, res) => {
    try {
        const { tenantId, userEmail, userId } = getTenantContext(req);
        // Mark onboarding as complete
        await database_1.pool.query(`UPDATE tenants
       SET onboarding_completed = true,
           updated_at = NOW()
       WHERE id = $1`, [tenantId]);
        // Send onboarding complete email (non-blocking)
        if (userEmail) {
            welcome_email_service_1.default.sendOnboardingCompleteEmail(userEmail, userId)
                .catch(err => console.error('Failed to send onboarding complete email:', err));
        }
        res.json({
            success: true,
            message: 'Onboarding completed successfully'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Complete onboarding error:', error);
        res.status(500).json({ success: false, error: 'Failed to complete onboarding' });
    }
};
exports.complete = complete;
/**
 * Skip onboarding (use defaults)
 */
const skip = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        // Mark onboarding as complete with default settings
        await database_1.pool.query(`UPDATE tenants
       SET onboarding_completed = true,
           onboarding_data = $1,
           updated_at = NOW()
       WHERE id = $2`, [JSON.stringify({ skipped: true, skippedAt: new Date().toISOString() }), tenantId]);
        res.json({
            success: true,
            message: 'Onboarding skipped'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Skip onboarding error:', error);
        res.status(500).json({ success: false, error: 'Failed to skip onboarding' });
    }
};
exports.skip = skip;
/**
 * Reset onboarding (admin function)
 */
const reset = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        await database_1.pool.query(`UPDATE tenants
       SET onboarding_completed = false,
           onboarding_step = 1,
           onboarding_data = '{}',
           updated_at = NOW()
       WHERE id = $1`, [tenantId]);
        res.json({
            success: true,
            message: 'Onboarding reset successfully'
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Reset onboarding error:', error);
        res.status(500).json({ success: false, error: 'Failed to reset onboarding' });
    }
};
exports.reset = reset;
/**
 * Get onboarding checklist items
 */
const getChecklist = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const result = await database_1.pool.query(`SELECT onboarding_data FROM tenants WHERE id = $1`, [tenantId]);
        const data = result.rows[0]?.onboarding_data || {};
        const checklist = [
            { step: 1, title: 'Company Profile', description: 'Set up your company information', completed: !!data.step1Completed },
            { step: 2, title: 'Modules', description: 'Select active ERP modules', completed: !!data.step2Completed },
            { step: 3, title: 'Users', description: 'Invite team members', completed: !!data.step3Completed },
            { step: 4, title: 'Integrations', description: 'Connect external services', completed: !!data.step4Completed },
            { step: 5, title: 'Preferences', description: 'Configure system preferences', completed: !!data.step5Completed }
        ];
        res.json({
            success: true,
            data: {
                checklist,
                progress: Math.round((checklist.filter(c => c.completed).length / checklist.length) * 100)
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant context required') {
            return res.status(401).json({ success: false, error: 'Unauthorized - tenant not found' });
        }
        console.error('Get checklist error:', error);
        res.status(500).json({ success: false, error: 'Failed to get checklist' });
    }
};
exports.getChecklist = getChecklist;
/**
 * Helper: Extract completed steps from onboarding data
 */
function getCompletedSteps(data) {
    if (!data)
        return [];
    const completed = [];
    for (let i = 1; i <= 10; i++) {
        if (data[`step${i}Completed`]) {
            completed.push(i);
        }
    }
    return completed;
}
exports.default = {
    getStatus: exports.getStatus,
    update: exports.update,
    complete: exports.complete,
    skip: exports.skip,
    reset: exports.reset,
    getChecklist: exports.getChecklist
};
//# sourceMappingURL=onboarding.controller.v2.js.map