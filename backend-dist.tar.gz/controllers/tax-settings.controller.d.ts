import { Request, Response } from 'express';
/**
 * Tax Settings Controller
 * Manages SARS-compliant tax configuration
 * Supports VAT (15%), PAYE, Income Tax (27%), and eFiling
 */
export declare class TaxSettingsController {
    /**
     * Get current tax configuration
     */
    getTaxSettings(req: Request, res: Response): Promise<void>;
    /**
     * Update tax configuration
     */
    updateTaxSettings(req: Request, res: Response): Promise<void>;
    /**
     * Get all tax accounts with their mappings
     */
    getTaxAccounts(req: Request, res: Response): Promise<void>;
    /**
     * Update tax account mapping
     */
    updateTaxAccount(req: Request, res: Response): Promise<void>;
    /**
     * Validate tax setup completeness
     */
    validateTaxSetup(req: Request, res: Response): Promise<void>;
    /**
     * Test SARS eFiling connection (Phase 2)
     */
    testSarsConnection(req: Request, res: Response): Promise<void>;
    /**
     * Update SARS eFiling configuration
     */
    updateEfilingConfig(req: Request, res: Response): Promise<void>;
    /**
     * Helper: Calculate setup completion percentage
     */
    private calculateSetupCompletion;
}
declare const _default: TaxSettingsController;
export default _default;
//# sourceMappingURL=tax-settings.controller.d.ts.map