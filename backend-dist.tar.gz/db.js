"use strict";
// Database pool export for backward compatibility
// Re-exports pool from config/database
Object.defineProperty(exports, "__esModule", { value: true });
exports.pool = void 0;
var database_1 = require("./config/database");
Object.defineProperty(exports, "pool", { enumerable: true, get: function () { return database_1.pool; } });
//# sourceMappingURL=db.js.map