import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Assets Workspace Controller
 * Provides aggregated data for the Asset Management dashboard
 */
/**
 * GET /api/assets/workspace
 * Returns all data needed for the Asset Management workspace dashboard
 */
export declare const getAssetsWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=assets.workspace.controller.d.ts.map