/**
 * Asset Management Controller
 */
import { Request, Response } from 'express';
export declare class AssetsController {
    /**
     * Create a new fixed asset
     * POST /api/assets
     */
    createAsset(req: Request, res: Response): Promise<void>;
    /**
     * Get asset by ID
     * GET /api/assets/:id
     */
    getAsset(req: Request, res: Response): Promise<void>;
    /**
     * List assets with filters
     * GET /api/assets
     */
    listAssets(req: Request, res: Response): Promise<void>;
    /**
     * Calculate monthly depreciation
     * POST /api/assets/depreciation/calculate
     */
    calculateDepreciation(req: Request, res: Response): Promise<void>;
    /**
     * Create asset revaluation
     * POST /api/assets/:id/revaluations
     */
    createRevaluation(req: Request, res: Response): Promise<void>;
    /**
     * Approve revaluation
     * POST /api/assets/revaluations/:id/approve
     */
    approveRevaluation(req: Request, res: Response): Promise<void>;
    /**
     * Get asset depreciation schedule
     * GET /api/assets/:id/depreciation
     */
    getDepreciationSchedule(req: Request, res: Response): Promise<void>;
    /**
     * Get workspace summary - Demo data for dashboard
     * GET /api/asset-management/workspace
     */
    getWorkspaceSummary(_req: Request, res: Response): Promise<void>;
}
declare const _default: AssetsController;
export default _default;
//# sourceMappingURL=controller.d.ts.map