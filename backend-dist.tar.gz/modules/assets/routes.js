"use strict";
/**
 * Asset Management Routes
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = __importDefault(require("./controller"));
const router = (0, express_1.Router)();
// Workspace summary endpoint (no auth required for demo data)
router.get('/workspace', controller_1.default.getWorkspaceSummary.bind(controller_1.default));
// Asset CRUD
router.post('/', controller_1.default.createAsset.bind(controller_1.default));
router.get('/', controller_1.default.listAssets.bind(controller_1.default));
router.get('/:id', controller_1.default.getAsset.bind(controller_1.default));
// Depreciation
router.post('/depreciation/calculate', controller_1.default.calculateDepreciation.bind(controller_1.default));
router.get('/:id/depreciation', controller_1.default.getDepreciationSchedule.bind(controller_1.default));
// Revaluation
router.post('/:id/revaluations', controller_1.default.createRevaluation.bind(controller_1.default));
router.post('/revaluations/:id/approve', controller_1.default.approveRevaluation.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map