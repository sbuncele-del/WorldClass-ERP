"use strict";
/**
 * Asset Management Controller
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AssetsController = void 0;
const service_1 = __importDefault(require("./service"));
class AssetsController {
    /**
     * Create a new fixed asset
     * POST /api/assets
     */
    async createAsset(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const userId = req.user?.id || '00000000-0000-0000-0000-000000000000';
            const asset = await service_1.default.createAsset({
                ...req.body,
                tenant_id: tenantId
            }, userId);
            res.status(201).json({
                success: true,
                data: asset
            });
        }
        catch (error) {
            console.error('Error creating asset:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to create asset'
            });
        }
    }
    /**
     * Get asset by ID
     * GET /api/assets/:id
     */
    async getAsset(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const assetId = parseInt(req.params.id);
            const asset = await service_1.default.getAssetById(assetId, tenantId);
            if (!asset) {
                res.status(404).json({
                    success: false,
                    error: 'Asset not found'
                });
                return;
            }
            res.json({
                success: true,
                data: asset
            });
        }
        catch (error) {
            console.error('Error getting asset:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to get asset'
            });
        }
    }
    /**
     * List assets with filters
     * GET /api/assets
     */
    async listAssets(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const filters = {
                status: req.query.status,
                category_id: req.query.category_id ? parseInt(req.query.category_id) : undefined,
                location_id: req.query.location_id ? parseInt(req.query.location_id) : undefined,
                search: req.query.search
            };
            const page = req.query.page ? parseInt(req.query.page) : 1;
            const limit = req.query.limit ? parseInt(req.query.limit) : 50;
            const result = await service_1.default.listAssets(filters, tenantId, page, limit);
            res.json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('Error listing assets:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to list assets'
            });
        }
    }
    /**
     * Calculate monthly depreciation
     * POST /api/assets/depreciation/calculate
     */
    async calculateDepreciation(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const { month } = req.body;
            if (!month) {
                res.status(400).json({
                    success: false,
                    error: 'Month is required (YYYY-MM-DD format)'
                });
                return;
            }
            const result = await service_1.default.calculateDepreciation(tenantId, month);
            res.json({
                success: true,
                data: result
            });
        }
        catch (error) {
            console.error('Error calculating depreciation:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to calculate depreciation'
            });
        }
    }
    /**
     * Create asset revaluation
     * POST /api/assets/:id/revaluations
     */
    async createRevaluation(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const userId = req.user?.id || '00000000-0000-0000-0000-000000000000';
            const assetId = parseInt(req.params.id);
            const revaluation = await service_1.default.createRevaluation({
                ...req.body,
                asset_id: assetId,
                tenant_id: tenantId
            }, userId);
            res.status(201).json({
                success: true,
                data: revaluation
            });
        }
        catch (error) {
            console.error('Error creating revaluation:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to create revaluation'
            });
        }
    }
    /**
     * Approve revaluation
     * POST /api/assets/revaluations/:id/approve
     */
    async approveRevaluation(req, res) {
        try {
            const userId = req.user?.id || '00000000-0000-0000-0000-000000000000';
            const revaluationId = parseInt(req.params.id);
            const revaluation = await service_1.default.approveRevaluation(revaluationId, userId);
            res.json({
                success: true,
                data: revaluation,
                message: 'Revaluation approved and posted to GL'
            });
        }
        catch (error) {
            console.error('Error approving revaluation:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to approve revaluation'
            });
        }
    }
    /**
     * Get asset depreciation schedule
     * GET /api/assets/:id/depreciation
     */
    async getDepreciationSchedule(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const assetId = parseInt(req.params.id);
            const schedule = await service_1.default.getDepreciationSchedule(assetId, tenantId);
            res.json({
                success: true,
                data: schedule
            });
        }
        catch (error) {
            console.error('Error getting depreciation schedule:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to get depreciation schedule'
            });
        }
    }
    /**
     * Get workspace summary - Demo data for dashboard
     * GET /api/asset-management/workspace
     */
    async getWorkspaceSummary(_req, res) {
        try {
            res.json({
                success: true,
                data: {
                    summary: {
                        totalAssets: 847,
                        activeAssets: 792,
                        disposedAssets: 42,
                        underMaintenanceAssets: 13,
                        totalValue: 125000000,
                        totalDepreciation: 42500000,
                        netBookValue: 82500000,
                        assetsRequiringAttention: 8
                    },
                    assetsByCategory: [
                        { category: 'Property & Buildings', count: 45, value: 65000000 },
                        { category: 'Vehicles & Fleet', count: 156, value: 18500000 },
                        { category: 'IT Equipment', count: 342, value: 8750000 },
                        { category: 'Machinery & Equipment', count: 89, value: 22000000 },
                        { category: 'Office Furniture', count: 215, value: 10750000 }
                    ],
                    recentActivities: [
                        { date: '2025-12-11', action: 'Depreciation Run', description: 'Monthly depreciation calculated for Dec 2025' },
                        { date: '2025-12-10', action: 'Asset Acquisition', description: 'New delivery vehicle added - REG ABC 123 GP' },
                        { date: '2025-12-09', action: 'Revaluation', description: 'Property revaluation completed - Main Office Building' },
                        { date: '2025-12-08', action: 'Disposal', description: 'Old IT equipment disposed - batch #2025-12-001' }
                    ],
                    upcomingDepreciation: {
                        month: 'December 2025',
                        estimatedAmount: 3250000,
                        assetsAffected: 687
                    }
                }
            });
        }
        catch (error) {
            console.error('Error getting workspace summary:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to get workspace summary'
            });
        }
    }
}
exports.AssetsController = AssetsController;
exports.default = new AssetsController();
//# sourceMappingURL=controller.js.map