/**
 * Asset Management Service
 * Handles fixed assets, depreciation, and revaluation
 */
export interface CreateAssetDto {
    asset_number?: string;
    asset_name: string;
    category_id: number;
    location_id: number;
    acquisition_date: string;
    depreciation_start_date: string;
    purchase_price: number;
    initial_cost: number;
    residual_value: number;
    depreciation_method: 'STRAIGHT_LINE' | 'DECLINING_BALANCE' | 'UNITS_OF_PRODUCTION';
    useful_life_years: number;
    useful_life_months: number;
    asset_status?: string;
    acquisition_method: 'PURCHASE' | 'CASH' | 'DONATION' | 'TRANSFER' | 'LEASE' | 'CONSTRUCTION';
    supplier_id?: number;
    description?: string;
    serial_number?: string;
    tenant_id?: string;
}
export interface AssetRevaluationDto {
    asset_id: number;
    revaluation_date: string;
    previous_book_value: number;
    new_valuation: number;
    revaluation_surplus_deficit: number;
    valuation_method: string;
    valuer_name?: string;
    revaluation_reason: string;
    tenant_id?: string;
}
export interface AssetFilters {
    status?: string;
    category_id?: number;
    location_id?: number;
    search?: string;
}
export declare class AssetsService {
    /**
     * Create a new fixed asset
     */
    createAsset(dto: CreateAssetDto, userId?: string): Promise<any>;
    /**
     * Get asset by ID
     */
    getAssetById(assetId: number, tenantId: string): Promise<any>;
    /**
     * List assets with filters
     */
    listAssets(filters: AssetFilters, tenantId: string, page?: number, limit?: number): Promise<any>;
    /**
     * Calculate monthly depreciation
     */
    calculateDepreciation(tenantId: string, month: string): Promise<any>;
    /**
     * Create asset revaluation
     */
    createRevaluation(dto: AssetRevaluationDto, userId?: string): Promise<any>;
    /**
     * Approve revaluation (triggers GL posting)
     */
    approveRevaluation(revaluationId: number, userId: string): Promise<any>;
    /**
     * Get asset depreciation schedule
     */
    getDepreciationSchedule(assetId: number, tenantId: string): Promise<any>;
}
declare const _default: AssetsService;
export default _default;
//# sourceMappingURL=service.d.ts.map