/**
 * Manufacturing Controller
 * Handles BOMs, Work Centers, Production Orders, and Shop Floor Operations
 */
import { Request, Response } from 'express';
export declare const getWorkCenters: (req: Request, res: Response) => Promise<void>;
export declare const createWorkCenter: (req: Request, res: Response) => Promise<void>;
export declare const getBOMs: (req: Request, res: Response) => Promise<void>;
export declare const getBOMById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createBOM: (req: Request, res: Response) => Promise<void>;
export declare const getProductionOrders: (req: Request, res: Response) => Promise<void>;
export declare const createProductionOrder: (req: Request, res: Response) => Promise<void>;
export declare const updateProductionOrderStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDashboardStats: (req: Request, res: Response) => Promise<void>;
declare const _default: {
    getWorkCenters: (req: Request, res: Response) => Promise<void>;
    createWorkCenter: (req: Request, res: Response) => Promise<void>;
    getBOMs: (req: Request, res: Response) => Promise<void>;
    getBOMById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createBOM: (req: Request, res: Response) => Promise<void>;
    getProductionOrders: (req: Request, res: Response) => Promise<void>;
    createProductionOrder: (req: Request, res: Response) => Promise<void>;
    updateProductionOrderStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getDashboardStats: (req: Request, res: Response) => Promise<void>;
};
export default _default;
//# sourceMappingURL=manufacturing.controller.d.ts.map