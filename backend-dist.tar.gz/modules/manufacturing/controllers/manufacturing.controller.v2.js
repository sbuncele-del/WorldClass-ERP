"use strict";
/**
 * Manufacturing Controller V2
 * Tenant-aware handlers for BOMs, Work Centers, Production Orders, and Shop Floor Operations
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDashboardStats = exports.updateProductionOrderStatus = exports.createProductionOrder = exports.getProductionOrders = exports.createBOM = exports.getBOMById = exports.getBOMs = exports.createWorkCenter = exports.getWorkCenters = void 0;
const database_1 = require("../../../config/database");
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant ID not found');
    }
    return {
        tenantId,
        userId: req.user?.id
    };
}
// ============================================================================
// WORK CENTERS
// ============================================================================
const getWorkCenters = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status } = req.query;
        const params = [tenantId];
        let query = `SELECT * FROM manufacturing.work_centers WHERE tenant_id = $1`;
        if (status) {
            params.push(status);
            query += ` AND status = $${params.length}`;
        }
        query += ` ORDER BY work_center_code`;
        const result = await database_1.pool.query(query, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching work centers:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch work centers', error: error.message });
    }
};
exports.getWorkCenters = getWorkCenters;
const createWorkCenter = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const { work_center_code, work_center_name, description, warehouse_id, capacity_per_day_hours, efficiency_factor, hourly_cost_rate } = req.body;
        const result = await database_1.pool.query(`INSERT INTO manufacturing.work_centers (
        tenant_id, work_center_code, work_center_name, description, warehouse_id,
        capacity_per_day_hours, efficiency_factor, hourly_cost_rate, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *`, [tenantId, work_center_code, work_center_name, description, warehouse_id,
            capacity_per_day_hours, efficiency_factor, hourly_cost_rate, userId || 1]);
        res.status(201).json({ success: true, data: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error creating work center:', error);
        res.status(500).json({ success: false, message: 'Failed to create work center', error: error.message });
    }
};
exports.createWorkCenter = createWorkCenter;
// ============================================================================
// BILL OF MATERIALS (BOM)
// ============================================================================
const getBOMs = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { item_id } = req.query;
        const params = [tenantId];
        let query = `
      SELECT b.*, i.item_code, i.item_name 
      FROM manufacturing.bill_of_materials b
      JOIN items i ON b.item_id = i.item_id AND i.tenant_id = $1
      WHERE b.tenant_id = $1
    `;
        if (item_id) {
            params.push(item_id);
            query += ` AND b.item_id = $${params.length}`;
        }
        query += ` ORDER BY b.created_at DESC`;
        const result = await database_1.pool.query(query, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching BOMs:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch BOMs', error: error.message });
    }
};
exports.getBOMs = getBOMs;
const getBOMById = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const bomResult = await database_1.pool.query(`SELECT b.*, i.item_code, i.item_name 
       FROM manufacturing.bill_of_materials b
       JOIN items i ON b.item_id = i.item_id AND i.tenant_id = $1
       WHERE b.bom_id = $2 AND b.tenant_id = $1`, [tenantId, id]);
        if (bomResult.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'BOM not found' });
        }
        const componentsResult = await database_1.pool.query(`SELECT bc.*, i.item_code, i.item_name, u.uom_code
       FROM manufacturing.bom_components bc
       JOIN items i ON bc.item_id = i.item_id AND i.tenant_id = $1
       LEFT JOIN units_of_measure u ON bc.uom_id = u.uom_id
       WHERE bc.bom_id = $2`, [tenantId, id]);
        res.json({
            success: true,
            data: {
                ...bomResult.rows[0],
                components: componentsResult.rows
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching BOM details:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch BOM details', error: error.message });
    }
};
exports.getBOMById = getBOMById;
const createBOM = async (req, res) => {
    const client = await database_1.pool.connect();
    try {
        const { tenantId, userId } = getTenantContext(req);
        await client.query('BEGIN');
        const { item_id, bom_code, version, description, components } = req.body;
        const bomResult = await client.query(`INSERT INTO manufacturing.bill_of_materials (
        tenant_id, item_id, bom_code, version, description, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`, [tenantId, item_id, bom_code, version, description, userId || 1]);
        const bomId = bomResult.rows[0].bom_id;
        for (const comp of components || []) {
            await client.query(`INSERT INTO manufacturing.bom_components (
          bom_id, item_id, quantity, uom_id, scrap_percentage, notes
        ) VALUES ($1, $2, $3, $4, $5, $6)`, [bomId, comp.item_id, comp.quantity, comp.uom_id, comp.scrap_percentage || 0, comp.notes]);
        }
        await client.query('COMMIT');
        res.status(201).json({ success: true, data: bomResult.rows[0] });
    }
    catch (error) {
        await client.query('ROLLBACK');
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error creating BOM:', error);
        res.status(500).json({ success: false, message: 'Failed to create BOM', error: error.message });
    }
    finally {
        client.release();
    }
};
exports.createBOM = createBOM;
// ============================================================================
// PRODUCTION ORDERS
// ============================================================================
const getProductionOrders = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, item_id } = req.query;
        const params = [tenantId];
        let query = `
      SELECT po.*, i.item_code, i.item_name, w.warehouse_name
      FROM manufacturing.production_orders po
      JOIN items i ON po.item_id = i.item_id AND i.tenant_id = $1
      LEFT JOIN warehouses w ON po.warehouse_id = w.warehouse_id
      WHERE po.tenant_id = $1
    `;
        if (status) {
            params.push(status);
            query += ` AND po.status = $${params.length}`;
        }
        if (item_id) {
            params.push(item_id);
            query += ` AND po.item_id = $${params.length}`;
        }
        query += ` ORDER BY po.created_at DESC`;
        const result = await database_1.pool.query(query, params);
        res.json({ success: true, data: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching production orders:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch production orders', error: error.message });
    }
};
exports.getProductionOrders = getProductionOrders;
const createProductionOrder = async (req, res) => {
    const client = await database_1.pool.connect();
    try {
        const { tenantId, userId } = getTenantContext(req);
        await client.query('BEGIN');
        const { item_id, quantity_planned, start_date, due_date, warehouse_id, priority, notes, bom_id, routing_id } = req.body;
        // Generate Order Number (tenant-scoped)
        const numResult = await client.query(`SELECT COALESCE(MAX(CAST(SUBSTRING(order_number FROM 4) AS INTEGER)), 0) + 1 as next_num
       FROM manufacturing.production_orders 
       WHERE tenant_id = $1 AND order_number LIKE 'WO-%'`, [tenantId]);
        const orderNumber = `WO-${String(numResult.rows[0].next_num).padStart(6, '0')}`;
        // Use default BOM/Routing if not provided
        let finalBomId = bom_id;
        if (!finalBomId) {
            const bomRes = await client.query(`SELECT bom_id FROM manufacturing.bill_of_materials 
         WHERE tenant_id = $1 AND item_id = $2 AND is_default = true LIMIT 1`, [tenantId, item_id]);
            finalBomId = bomRes.rows[0]?.bom_id;
        }
        let finalRoutingId = routing_id;
        if (!finalRoutingId) {
            const routRes = await client.query(`SELECT routing_id FROM manufacturing.routings 
         WHERE tenant_id = $1 AND item_id = $2 AND is_default = true LIMIT 1`, [tenantId, item_id]);
            finalRoutingId = routRes.rows[0]?.routing_id;
        }
        const result = await client.query(`INSERT INTO manufacturing.production_orders (
        tenant_id, order_number, item_id, bom_id, routing_id, warehouse_id,
        quantity_planned, start_date, due_date, priority, notes,
        status, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'planned', $12)
      RETURNING *`, [tenantId, orderNumber, item_id, finalBomId, finalRoutingId, warehouse_id,
            quantity_planned, start_date, due_date, priority || 'medium', notes, userId || 1]);
        await client.query('COMMIT');
        res.status(201).json({ success: true, data: result.rows[0] });
    }
    catch (error) {
        await client.query('ROLLBACK');
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error creating production order:', error);
        res.status(500).json({ success: false, message: 'Failed to create production order', error: error.message });
    }
    finally {
        client.release();
    }
};
exports.createProductionOrder = createProductionOrder;
const updateProductionOrderStatus = async (req, res) => {
    const client = await database_1.pool.connect();
    try {
        const { tenantId } = getTenantContext(req);
        await client.query('BEGIN');
        const { id } = req.params;
        const { status } = req.body; // released, in_progress, completed, cancelled
        const orderRes = await client.query(`SELECT * FROM manufacturing.production_orders 
       WHERE production_order_id = $1 AND tenant_id = $2`, [id, tenantId]);
        if (orderRes.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ success: false, message: 'Order not found' });
        }
        const order = orderRes.rows[0];
        // Status transition logic
        let updateQuery = `UPDATE manufacturing.production_orders SET status = $1, updated_at = NOW()`;
        const params = [status];
        if (status === 'in_progress' && order.status !== 'in_progress') {
            updateQuery += `, actual_start_date = NOW()`;
        }
        else if (status === 'completed' && order.status !== 'completed') {
            updateQuery += `, actual_end_date = NOW(), quantity_produced = quantity_planned`;
        }
        updateQuery += ` WHERE production_order_id = $${params.length + 1} AND tenant_id = $${params.length + 2} RETURNING *`;
        params.push(id, tenantId);
        const result = await client.query(updateQuery, params);
        await client.query('COMMIT');
        res.json({ success: true, data: result.rows[0] });
    }
    catch (error) {
        await client.query('ROLLBACK');
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error updating order status:', error);
        res.status(500).json({ success: false, message: 'Failed to update order status', error: error.message });
    }
    finally {
        client.release();
    }
};
exports.updateProductionOrderStatus = updateProductionOrderStatus;
const getDashboardStats = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        // 1. Active Orders Count (tenant-scoped)
        const activeOrders = await database_1.pool.query(`SELECT COUNT(*) as count FROM manufacturing.production_orders 
       WHERE tenant_id = $1 AND status IN ('released', 'in_progress')`, [tenantId]);
        // 2. Work Center Utilization (tenant-scoped)
        const utilization = await database_1.pool.query(`SELECT AVG(efficiency_factor) * 100 as avg_efficiency 
       FROM manufacturing.work_centers 
       WHERE tenant_id = $1 AND status = 'active'`, [tenantId]);
        // 3. Orders by Status (tenant-scoped)
        const statusCounts = await database_1.pool.query(`SELECT status, COUNT(*) as count FROM manufacturing.production_orders 
       WHERE tenant_id = $1 GROUP BY status`, [tenantId]);
        // 4. Upcoming Due Dates (tenant-scoped)
        const upcoming = await database_1.pool.query(`SELECT order_number, due_date, status FROM manufacturing.production_orders 
       WHERE tenant_id = $1 AND status NOT IN ('completed', 'cancelled') 
       ORDER BY due_date ASC LIMIT 5`, [tenantId]);
        res.json({
            success: true,
            data: {
                active_orders: parseInt(activeOrders.rows[0].count),
                avg_efficiency: parseFloat(utilization.rows[0].avg_efficiency || 0).toFixed(1),
                status_breakdown: statusCounts.rows,
                upcoming_orders: upcoming.rows
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch dashboard stats', error: error.message });
    }
};
exports.getDashboardStats = getDashboardStats;
exports.default = {
    getWorkCenters: exports.getWorkCenters,
    createWorkCenter: exports.createWorkCenter,
    getBOMs: exports.getBOMs,
    getBOMById: exports.getBOMById,
    createBOM: exports.createBOM,
    getProductionOrders: exports.getProductionOrders,
    createProductionOrder: exports.createProductionOrder,
    updateProductionOrderStatus: exports.updateProductionOrderStatus,
    getDashboardStats: exports.getDashboardStats
};
//# sourceMappingURL=manufacturing.controller.v2.js.map