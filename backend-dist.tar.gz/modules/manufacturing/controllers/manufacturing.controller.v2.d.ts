/**
 * Manufacturing Controller V2
 * Tenant-aware handlers for BOMs, Work Centers, Production Orders, and Shop Floor Operations
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../../types';
export declare const getWorkCenters: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createWorkCenter: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getBOMs: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getBOMById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createBOM: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getProductionOrders: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createProductionOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateProductionOrderStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDashboardStats: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getWorkCenters: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createWorkCenter: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBOMs: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getBOMById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createBOM: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getProductionOrders: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createProductionOrder: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateProductionOrderStatus: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getDashboardStats: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=manufacturing.controller.v2.d.ts.map