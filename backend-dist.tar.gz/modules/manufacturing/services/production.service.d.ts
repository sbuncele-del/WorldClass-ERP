export declare class ProductionService {
    static createProductionOrder(params: {
        item_id: number;
        quantity: number;
        start_date: Date;
        due_date: Date;
        warehouse_id: number;
        created_by?: number;
    }): Promise<any>;
    static releaseOrder(orderId: number): Promise<any>;
    static completeOrder(orderId: number, quantityProduced: number, userId?: number): Promise<any>;
}
//# sourceMappingURL=production.service.d.ts.map