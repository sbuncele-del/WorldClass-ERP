export declare class MrpService {
    static runMrp(userId?: number): Promise<{
        runId: any;
        message: string;
    }>;
    private static processItem;
}
//# sourceMappingURL=mrp.service.d.ts.map