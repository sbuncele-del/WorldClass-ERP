/**
 * MRP Engine Service (Material Requirements Planning)
 * Calculates net requirements and generates planned orders
 */
export interface MrpRunParams {
    warehouse_id?: number;
    horizon_days?: number;
    include_safety_stock?: boolean;
}
export declare class MrpEngineService {
    /**
     * Run MRP Calculation
     */
    static runMrp(params: MrpRunParams, userId?: number): Promise<{
        success: boolean;
        runId: any;
        message: string;
    }>;
    /**
     * Get MRP Results
     */
    static getResults(runId?: number): Promise<any[]>;
}
//# sourceMappingURL=mrp-engine.service.d.ts.map