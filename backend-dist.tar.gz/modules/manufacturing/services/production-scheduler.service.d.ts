/**
 * Production Scheduler Service
 * Handles capacity planning and scheduling of production orders
 */
export declare class ProductionSchedulerService {
    /**
     * Schedule a Production Order
     * Finds the earliest available slots for all operations
     */
    static scheduleOrder(orderId: number): Promise<{
        success: boolean;
        message: string;
    }>;
    /**
     * Optimize Schedule using Vertex AI (Placeholder)
     */
    static optimizeSchedule(): Promise<{
        message: string;
    }>;
    /**
     * Get Work Center Load
     */
    static getWorkCenterLoad(startDate: string, endDate: string): Promise<any[]>;
}
//# sourceMappingURL=production-scheduler.service.d.ts.map