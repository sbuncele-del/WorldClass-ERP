export interface BomComponent {
    item_id: number;
    quantity: number;
    uom_id?: number;
    scrap_percentage?: number;
    notes?: string;
}
export interface CreateBomParams {
    item_id: number;
    bom_code: string;
    version: string;
    description?: string;
    components: BomComponent[];
    created_by?: number;
}
export declare class BomService {
    static createBom(params: CreateBomParams): Promise<any>;
    static getBom(bomId: number): Promise<any>;
    static calculateBomCost(bomId: number): Promise<number>;
    static getActiveBomForItem(itemId: number): Promise<any>;
}
//# sourceMappingURL=bom.service.d.ts.map