/**
 * Vertex AI Scheduling Optimization Service
 * Uses Google Cloud Vertex AI to optimize production schedules
 */
export declare class VertexSchedulingService {
    /**
     * Optimizes the production schedule based on constraints
     * @param productionOrders List of open production orders
     * @param workCenters List of available work centers and capacities
     */
    static optimizeSchedule(productionOrders: any[], workCenters: any[]): Promise<{
        success: boolean;
        schedule: {
            production_order_id: any;
            suggested_start_date: Date;
            suggested_end_date: Date;
            confidence_score: number;
            optimization_method: string;
        }[];
        metadata: {
            model_version: string;
            processing_time_ms: number;
        };
    }>;
}
//# sourceMappingURL=vertex-scheduling.service.d.ts.map