/**
 * Manufacturing Routes
 */
declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=manufacturing.routes.d.ts.map