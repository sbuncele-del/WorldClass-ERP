"use strict";
/**
 * Manufacturing Routes
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const manufacturingController = __importStar(require("../controllers/manufacturing.controller.v2"));
const tenant_1 = require("../../../middleware/tenant");
const mrp_engine_service_1 = require("../services/mrp-engine.service");
const production_scheduler_service_1 = require("../services/production-scheduler.service");
const router = (0, express_1.Router)();
// Enforce tenant context for all manufacturing routes
router.use(tenant_1.tenantMiddleware);
// ==================================================
// WORK CENTERS
// ==================================================
router.get('/work-centers', manufacturingController.getWorkCenters);
router.post('/work-centers', manufacturingController.createWorkCenter);
// ==================================================
// BILL OF MATERIALS (BOM)
// ==================================================
router.get('/boms', manufacturingController.getBOMs);
router.get('/boms/:id', manufacturingController.getBOMById);
router.post('/boms', manufacturingController.createBOM);
// ==================================================
// PRODUCTION ORDERS
// ==================================================
router.get('/orders', manufacturingController.getProductionOrders);
router.post('/orders', manufacturingController.createProductionOrder);
router.put('/orders/:id/status', manufacturingController.updateProductionOrderStatus);
// ==================================================
// MRP (Material Requirements Planning)
// ==================================================
router.post('/mrp/run', async (req, res) => {
    try {
        const userId = typeof req.user?.id === 'string' ? parseInt(req.user.id) : (req.user?.id || 1);
        const result = await mrp_engine_service_1.MrpEngineService.runMrp(req.body, userId);
        res.json(result);
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});
router.get('/mrp/results', async (req, res) => {
    try {
        const results = await mrp_engine_service_1.MrpEngineService.getResults(req.query.run_id ? Number(req.query.run_id) : undefined);
        res.json({ success: true, data: results });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});
// ==================================================
// SCHEDULING
// ==================================================
router.post('/schedule/:orderId', async (req, res) => {
    try {
        const result = await production_scheduler_service_1.ProductionSchedulerService.scheduleOrder(Number(req.params.orderId));
        res.json(result);
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});
router.get('/schedule/load', async (req, res) => {
    try {
        const { start_date, end_date } = req.query;
        const load = await production_scheduler_service_1.ProductionSchedulerService.getWorkCenterLoad(start_date, end_date);
        res.json({ success: true, data: load });
    }
    catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
});
// ==================================================
// DASHBOARD
// ==================================================
router.get('/dashboard', manufacturingController.getDashboardStats);
exports.default = router;
//# sourceMappingURL=manufacturing.routes.js.map