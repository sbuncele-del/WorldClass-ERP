/**
 * HR Compliance Controller
 * South African labor law compliance, statutory reporting, and audit endpoints
 */
import { Request, Response } from 'express';
type TenantRequest = Request & {
    tenant?: {
        id: string;
    };
    user?: {
        id?: number;
    };
};
/**
 * GET /api/hr/compliance/irp5/:employee_id/:tax_year
 * Generate IRP5 certificate data for an employee
 */
export declare const getIRP5: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/compliance/emp501/:tax_year
 * Generate EMP501 reconciliation data
 */
export declare const getEMP501: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/payslips/:employee_id/:run_id
 * Get payslip data
 */
export declare const getPayslip: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/payslips/:employee_id/:run_id/html
 * Get payslip as HTML (for printing/PDF)
 */
export declare const getPayslipHTML: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/hr/tax-calculator
 * Calculate tax for given income
 */
export declare const calculateTax: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/tax-brackets/:tax_year
 * Get SARS tax brackets
 */
export declare const getTaxBrackets: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/hr/employees/:employee_id/documents
 * Upload employee document
 */
export declare const uploadDocument: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/employees/:employee_id/documents
 * Get employee documents
 */
export declare const getEmployeeDocuments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * DELETE /api/hr/documents/:document_id
 * Delete employee document
 */
export declare const deleteDocument: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/documents/expiring
 * Get documents expiring soon
 */
export declare const getExpiringDocuments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/hr/employees/:employee_id/contracts
 * Create employee contract
 */
export declare const createContract: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/employees/:employee_id/contracts
 * Get employee contracts
 */
export declare const getEmployeeContracts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/hr/contracts/:contract_id/terminate
 * Terminate employee contract
 */
export declare const terminateContract: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/contracts/expiring
 * Get contracts expiring soon
 */
export declare const getExpiringContracts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/hr/leave/process-accruals
 * Process monthly leave accruals
 */
export declare const processLeaveAccruals: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/hr/leave/year-end-carryover
 * Process year-end leave carryover
 */
export declare const processYearEndCarryover: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/leave/calendar/:department_id
 * Get leave calendar for department
 */
export declare const getLeaveCalendar: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/compliance/bcea-check/:employee_id
 * Check BCEA (Basic Conditions of Employment Act) compliance
 */
export declare const checkBCEACompliance: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/hr/compliance/report
 * Get overall HR compliance report
 */
export declare const getComplianceReport: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getIRP5: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEMP501: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPayslip: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPayslipHTML: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    calculateTax: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTaxBrackets: (req: Request, res: Response) => Promise<void>;
    uploadDocument: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEmployeeDocuments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteDocument: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getExpiringDocuments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createContract: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getEmployeeContracts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    terminateContract: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getExpiringContracts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    processLeaveAccruals: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    processYearEndCarryover: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getLeaveCalendar: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    checkBCEACompliance: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getComplianceReport: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=hr.compliance.controller.d.ts.map