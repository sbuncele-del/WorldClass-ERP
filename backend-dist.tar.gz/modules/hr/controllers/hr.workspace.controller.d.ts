import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * HR Workspace Controller
 * Provides aggregated data for the HR & Payroll dashboard
 */
/**
 * GET /api/hr/workspace
 * Returns all data needed for the HR & Payroll workspace dashboard
 */
export declare const getHRWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=hr.workspace.controller.d.ts.map