/**
 * HR CONTROLLER (Repository Pattern)
 *
 * Tenant-aware HR endpoints backed by BaseRepository.
 * This v2 controller gradually replaces legacy hrController routes.
 */
import { Response } from 'express';
import { TenantRequest } from '../../../types';
export declare const getDepartments: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getDepartmentById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createDepartment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateDepartment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPositions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createPosition: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getEmployees: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getEmployeeById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createEmployee: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const updateEmployee: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getHRDashboard: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getPayrollPeriods: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createPayrollPeriod: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const processPayroll: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPayrollRunDetails: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const postPayrollToGL: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getLeaveRequests: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createLeaveRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const processLeaveRequest: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getLeaveBalances: (req: TenantRequest, res: Response) => Promise<void>;
export declare const recordAttendance: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getAttendanceRecords: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=hr.controller.v2.d.ts.map