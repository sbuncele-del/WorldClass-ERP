"use strict";
/**
 * HR Compliance Controller
 * South African labor law compliance, statutory reporting, and audit endpoints
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getComplianceReport = exports.checkBCEACompliance = exports.getLeaveCalendar = exports.processYearEndCarryover = exports.processLeaveAccruals = exports.getExpiringContracts = exports.terminateContract = exports.getEmployeeContracts = exports.createContract = exports.getExpiringDocuments = exports.deleteDocument = exports.getEmployeeDocuments = exports.uploadDocument = exports.getTaxBrackets = exports.calculateTax = exports.getPayslipHTML = exports.getPayslip = exports.getEMP501 = exports.getIRP5 = void 0;
const database_1 = __importDefault(require("../../../config/database"));
const taxService = __importStar(require("../services/tax-calculation.service"));
const payslipService = __importStar(require("../services/payslip.service"));
const documentService = __importStar(require("../services/employee-documents.service"));
const leaveService = __importStar(require("../services/leave-accrual.service"));
const getTenantId = (req) => req.tenant?.id;
/**
 * GET /api/hr/compliance/irp5/:employee_id/:tax_year
 * Generate IRP5 certificate data for an employee
 */
const getIRP5 = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id, tax_year } = req.params;
        const irp5Data = await taxService.generateIRP5Data(parseInt(employee_id), parseInt(tax_year), tenantId);
        res.json({
            success: true,
            data: irp5Data,
        });
    }
    catch (error) {
        console.error('Error generating IRP5:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate IRP5',
            details: error.message,
        });
    }
};
exports.getIRP5 = getIRP5;
/**
 * GET /api/hr/compliance/emp501/:tax_year
 * Generate EMP501 reconciliation data
 */
const getEMP501 = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { tax_year } = req.params;
        const emp501Data = await taxService.generateEMP501Data(parseInt(tax_year), tenantId);
        res.json({
            success: true,
            data: emp501Data,
        });
    }
    catch (error) {
        console.error('Error generating EMP501:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate EMP501',
            details: error.message,
        });
    }
};
exports.getEMP501 = getEMP501;
/**
 * GET /api/hr/payslips/:employee_id/:run_id
 * Get payslip data
 */
const getPayslip = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id, run_id } = req.params;
        const payslipData = await payslipService.getPayslipData(parseInt(employee_id), parseInt(run_id), tenantId);
        if (!payslipData) {
            return res.status(404).json({
                success: false,
                error: 'Payslip not found',
            });
        }
        res.json({
            success: true,
            data: payslipData,
        });
    }
    catch (error) {
        console.error('Error fetching payslip:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch payslip',
            details: error.message,
        });
    }
};
exports.getPayslip = getPayslip;
/**
 * GET /api/hr/payslips/:employee_id/:run_id/html
 * Get payslip as HTML (for printing/PDF)
 */
const getPayslipHTML = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id, run_id } = req.params;
        const payslipData = await payslipService.getPayslipData(parseInt(employee_id), parseInt(run_id), tenantId);
        if (!payslipData) {
            return res.status(404).json({
                success: false,
                error: 'Payslip not found',
            });
        }
        const html = payslipService.generatePayslipHTML(payslipData);
        res.setHeader('Content-Type', 'text/html');
        res.send(html);
    }
    catch (error) {
        console.error('Error generating payslip HTML:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate payslip',
            details: error.message,
        });
    }
};
exports.getPayslipHTML = getPayslipHTML;
/**
 * POST /api/hr/tax-calculator
 * Calculate tax for given income
 */
const calculateTax = async (req, res) => {
    try {
        const { annual_gross_income, employee_age, medical_aid_members, retirement_contributions, travel_allowance, } = req.body;
        if (!annual_gross_income || !employee_age) {
            return res.status(400).json({
                success: false,
                error: 'Annual gross income and employee age are required',
            });
        }
        const result = taxService.calculateFullTax({
            annualGrossIncome: annual_gross_income,
            employeeAge: employee_age,
            medicalAidMembers: medical_aid_members || 0,
            retirementContributions: retirement_contributions || 0,
            travelAllowance: travel_allowance || 0,
        });
        res.json({
            success: true,
            data: result,
        });
    }
    catch (error) {
        console.error('Error calculating tax:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to calculate tax',
            details: error.message,
        });
    }
};
exports.calculateTax = calculateTax;
/**
 * GET /api/hr/tax-brackets/:tax_year
 * Get SARS tax brackets
 */
const getTaxBrackets = async (req, res) => {
    try {
        res.json({
            success: true,
            data: {
                tax_brackets: taxService.SARS_TAX_BRACKETS_2024,
                rebates: taxService.TAX_REBATES_2024,
                thresholds: taxService.TAX_THRESHOLDS_2024,
                tax_year: '2024/2025',
            },
        });
    }
    catch (error) {
        console.error('Error fetching tax brackets:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch tax brackets',
            details: error.message,
        });
    }
};
exports.getTaxBrackets = getTaxBrackets;
/**
 * POST /api/hr/employees/:employee_id/documents
 * Upload employee document
 */
const uploadDocument = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id } = req.params;
        const documentData = req.body;
        const userId = req.user?.id || 1;
        const document = await documentService.createDocument(tenantId, parseInt(employee_id), {
            ...documentData,
            uploaded_by: userId,
        });
        res.status(201).json({
            success: true,
            message: 'Document uploaded successfully',
            data: document,
        });
    }
    catch (error) {
        console.error('Error uploading document:', error);
        res.status(400).json({
            success: false,
            error: 'Failed to upload document',
            details: error.message,
        });
    }
};
exports.uploadDocument = uploadDocument;
/**
 * GET /api/hr/employees/:employee_id/documents
 * Get employee documents
 */
const getEmployeeDocuments = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id } = req.params;
        const { document_type } = req.query;
        const documents = await documentService.getEmployeeDocuments(tenantId, parseInt(employee_id), document_type);
        res.json({
            success: true,
            data: documents,
            count: documents.length,
        });
    }
    catch (error) {
        console.error('Error fetching documents:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch documents',
            details: error.message,
        });
    }
};
exports.getEmployeeDocuments = getEmployeeDocuments;
/**
 * DELETE /api/hr/documents/:document_id
 * Delete employee document
 */
const deleteDocument = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { document_id } = req.params;
        await documentService.deleteDocument(tenantId, parseInt(document_id));
        res.json({
            success: true,
            message: 'Document deleted successfully',
        });
    }
    catch (error) {
        console.error('Error deleting document:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to delete document',
            details: error.message,
        });
    }
};
exports.deleteDocument = deleteDocument;
/**
 * GET /api/hr/documents/expiring
 * Get documents expiring soon
 */
const getExpiringDocuments = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { days } = req.query;
        const daysAhead = parseInt(days) || 30;
        const documents = await documentService.getExpiringDocuments(tenantId, daysAhead);
        res.json({
            success: true,
            data: documents,
            count: documents.length,
        });
    }
    catch (error) {
        console.error('Error fetching expiring documents:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch expiring documents',
            details: error.message,
        });
    }
};
exports.getExpiringDocuments = getExpiringDocuments;
/**
 * POST /api/hr/employees/:employee_id/contracts
 * Create employee contract
 */
const createContract = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id } = req.params;
        const contractData = req.body;
        const userId = req.user?.id || 1;
        const contract = await documentService.createContract(tenantId, parseInt(employee_id), {
            ...contractData,
            created_by: userId,
        });
        res.status(201).json({
            success: true,
            message: 'Contract created successfully',
            data: contract,
        });
    }
    catch (error) {
        console.error('Error creating contract:', error);
        res.status(400).json({
            success: false,
            error: 'Failed to create contract',
            details: error.message,
        });
    }
};
exports.createContract = createContract;
/**
 * GET /api/hr/employees/:employee_id/contracts
 * Get employee contracts
 */
const getEmployeeContracts = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id } = req.params;
        const { include_history } = req.query;
        const contracts = await documentService.getEmployeeContracts(tenantId, parseInt(employee_id), include_history === 'true');
        res.json({
            success: true,
            data: contracts,
            count: contracts.length,
        });
    }
    catch (error) {
        console.error('Error fetching contracts:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch contracts',
            details: error.message,
        });
    }
};
exports.getEmployeeContracts = getEmployeeContracts;
/**
 * POST /api/hr/contracts/:contract_id/terminate
 * Terminate employee contract
 */
const terminateContract = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { contract_id } = req.params;
        const { termination_date, termination_reason } = req.body;
        const userId = req.user?.id || 1;
        await documentService.terminateContract(tenantId, parseInt(contract_id), new Date(termination_date), termination_reason, userId);
        res.json({
            success: true,
            message: 'Contract terminated successfully',
        });
    }
    catch (error) {
        console.error('Error terminating contract:', error);
        res.status(400).json({
            success: false,
            error: 'Failed to terminate contract',
            details: error.message,
        });
    }
};
exports.terminateContract = terminateContract;
/**
 * GET /api/hr/contracts/expiring
 * Get contracts expiring soon
 */
const getExpiringContracts = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { days } = req.query;
        const daysAhead = parseInt(days) || 60;
        const contracts = await documentService.getExpiringContracts(tenantId, daysAhead);
        res.json({
            success: true,
            data: contracts,
            count: contracts.length,
        });
    }
    catch (error) {
        console.error('Error fetching expiring contracts:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch expiring contracts',
            details: error.message,
        });
    }
};
exports.getExpiringContracts = getExpiringContracts;
/**
 * POST /api/hr/leave/process-accruals
 * Process monthly leave accruals
 */
const processLeaveAccruals = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const result = await leaveService.processMonthlyAccruals(tenantId);
        res.json({
            success: true,
            message: `Processed ${result.processed} leave accruals`,
            data: result,
        });
    }
    catch (error) {
        console.error('Error processing leave accruals:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to process leave accruals',
            details: error.message,
        });
    }
};
exports.processLeaveAccruals = processLeaveAccruals;
/**
 * POST /api/hr/leave/year-end-carryover
 * Process year-end leave carryover
 */
const processYearEndCarryover = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { from_year, to_year } = req.body;
        if (!from_year || !to_year) {
            return res.status(400).json({
                success: false,
                error: 'from_year and to_year are required',
            });
        }
        const result = await leaveService.processYearEndCarryover(tenantId, parseInt(from_year), parseInt(to_year));
        res.json({
            success: true,
            message: `Processed ${result.processed} leave carryovers. ${result.forfeitedDays} days forfeited.`,
            data: result,
        });
    }
    catch (error) {
        console.error('Error processing year-end carryover:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to process year-end carryover',
            details: error.message,
        });
    }
};
exports.processYearEndCarryover = processYearEndCarryover;
/**
 * GET /api/hr/leave/calendar/:department_id
 * Get leave calendar for department
 */
const getLeaveCalendar = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { department_id } = req.params;
        const { start_date, end_date } = req.query;
        const startDate = start_date
            ? new Date(start_date)
            : new Date(new Date().setMonth(new Date().getMonth() - 1));
        const endDate = end_date
            ? new Date(end_date)
            : new Date(new Date().setMonth(new Date().getMonth() + 2));
        const calendar = await leaveService.getDepartmentLeaveCalendar(tenantId, parseInt(department_id), startDate, endDate);
        res.json({
            success: true,
            data: calendar,
            count: calendar.length,
        });
    }
    catch (error) {
        console.error('Error fetching leave calendar:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to fetch leave calendar',
            details: error.message,
        });
    }
};
exports.getLeaveCalendar = getLeaveCalendar;
/**
 * GET /api/hr/compliance/bcea-check/:employee_id
 * Check BCEA (Basic Conditions of Employment Act) compliance
 */
const checkBCEACompliance = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        const { employee_id } = req.params;
        // Get employee details
        const empResult = await database_1.default.query(`
      SELECT 
        e.*,
        c.working_hours_per_week,
        c.notice_period_days,
        c.contract_type,
        c.probation_period_months
      FROM hr.employees e
      LEFT JOIN hr.employee_contracts c ON e.employee_id = c.employee_id AND e.tenant_id = c.tenant_id AND c.status = 'ACTIVE'
      WHERE e.tenant_id = $1 AND e.employee_id = $2
    `, [tenantId, employee_id]);
        if (empResult.rows.length === 0) {
            return res.status(404).json({
                success: false,
                error: 'Employee not found',
            });
        }
        const employee = empResult.rows[0];
        const issues = [];
        const warnings = [];
        // Check working hours (max 45 per week)
        if (employee.working_hours_per_week > 45) {
            issues.push('Working hours exceed BCEA maximum of 45 hours per week');
        }
        else if (employee.working_hours_per_week > 40) {
            warnings.push('Working hours are above standard 40 hours but within BCEA limits');
        }
        // Check leave balances
        const leaveResult = await database_1.default.query(`
      SELECT lt.leave_name, b.closing_balance, lt.default_days
      FROM hr.employee_leave_balances b
      JOIN hr.leave_types lt ON b.leave_type_id = lt.leave_type_id AND lt.tenant_id = $1
      WHERE b.tenant_id = $1 AND b.employee_id = $2 AND b.year = EXTRACT(YEAR FROM CURRENT_DATE)
    `, [tenantId, employee_id]);
        const annualLeave = leaveResult.rows.find(l => l.leave_name === 'Annual Leave');
        if (annualLeave && annualLeave.closing_balance < 15) {
            warnings.push(`Annual leave balance (${annualLeave.closing_balance} days) below statutory minimum of 15 days`);
        }
        // Check notice period
        if (employee.notice_period_days && employee.notice_period_days < 7) {
            issues.push('Notice period below BCEA minimum (1-4 weeks depending on tenure)');
        }
        // Check probation period (max 3 months typically)
        if (employee.probation_period_months && employee.probation_period_months > 6) {
            warnings.push('Probation period exceeds common practice of 3-6 months');
        }
        // Calculate tenure
        const hireDate = new Date(employee.hire_date);
        const tenureMonths = Math.floor((Date.now() - hireDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
        res.json({
            success: true,
            data: {
                employee_id: parseInt(employee_id),
                employee_number: employee.employee_number,
                employee_name: `${employee.first_name} ${employee.last_name}`,
                compliance_status: issues.length === 0 ? 'COMPLIANT' : 'NON_COMPLIANT',
                tenure_months: tenureMonths,
                issues,
                warnings,
                leave_balances: leaveResult.rows,
                contract_type: employee.contract_type,
                working_hours_per_week: employee.working_hours_per_week,
                notice_period_days: employee.notice_period_days,
                checked_at: new Date().toISOString(),
            },
        });
    }
    catch (error) {
        console.error('Error checking BCEA compliance:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to check BCEA compliance',
            details: error.message,
        });
    }
};
exports.checkBCEACompliance = checkBCEACompliance;
/**
 * GET /api/hr/compliance/report
 * Get overall HR compliance report
 */
const getComplianceReport = async (req, res) => {
    try {
        const tenantId = getTenantId(req);
        if (!tenantId)
            return res.status(401).json({ success: false, error: 'Tenant context not found' });
        // Count employees by status
        const statusCount = await database_1.default.query(`
      SELECT employment_status, COUNT(*) as count
      FROM hr.employees
      WHERE tenant_id = $1
      GROUP BY employment_status
    `, [tenantId]);
        // Count expiring documents
        const expiringDocs = await database_1.default.query(`
      SELECT COUNT(*) as count
      FROM hr.employee_documents
      WHERE expiry_date IS NOT NULL
        AND expiry_date <= CURRENT_DATE + INTERVAL '30 days'
        AND expiry_date >= CURRENT_DATE
        AND is_deleted = false
        AND tenant_id = $1
    `, [tenantId]);
        // Count expiring contracts
        const expiringContracts = await database_1.default.query(`
      SELECT COUNT(*) as count
      FROM hr.employee_contracts
      WHERE end_date IS NOT NULL
        AND end_date <= CURRENT_DATE + INTERVAL '60 days'
        AND end_date >= CURRENT_DATE
        AND status = 'ACTIVE'
        AND tenant_id = $1
    `, [tenantId]);
        // Count pending leave requests
        const pendingLeave = await database_1.default.query(`
      SELECT COUNT(*) as count
      FROM hr.leave_requests
      WHERE status = 'Pending'
        AND tenant_id = $1
    `, [tenantId]);
        // Check for employees without contracts
        const noContract = await database_1.default.query(`
      SELECT COUNT(*) as count
      FROM hr.employees e
      WHERE e.employment_status = 'Active'
        AND NOT EXISTS (
          SELECT 1 FROM hr.employee_contracts c
          WHERE c.employee_id = e.employee_id AND c.tenant_id = $1 AND c.status = 'ACTIVE'
        )
        AND e.tenant_id = $1
    `, [tenantId]);
        // Check for employees without tax numbers
        const noTaxNumber = await database_1.default.query(`
      SELECT COUNT(*) as count
      FROM hr.employees
      WHERE employment_status = 'Active'
        AND (tax_number IS NULL OR tax_number = '')
        AND tenant_id = $1
    `, [tenantId]);
        res.json({
            success: true,
            data: {
                employee_status: statusCount.rows,
                alerts: {
                    expiring_documents: parseInt(expiringDocs.rows[0].count),
                    expiring_contracts: parseInt(expiringContracts.rows[0].count),
                    pending_leave_requests: parseInt(pendingLeave.rows[0].count),
                    employees_without_contracts: parseInt(noContract.rows[0].count),
                    employees_without_tax_numbers: parseInt(noTaxNumber.rows[0].count),
                },
                compliance_score: calculateComplianceScore({
                    expiringDocs: parseInt(expiringDocs.rows[0].count),
                    expiringContracts: parseInt(expiringContracts.rows[0].count),
                    noContract: parseInt(noContract.rows[0].count),
                    noTaxNumber: parseInt(noTaxNumber.rows[0].count),
                }),
                generated_at: new Date().toISOString(),
            },
        });
    }
    catch (error) {
        console.error('Error generating compliance report:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to generate compliance report',
            details: error.message,
        });
    }
};
exports.getComplianceReport = getComplianceReport;
function calculateComplianceScore(metrics) {
    let score = 100;
    // Deduct points for issues
    score -= metrics.expiringDocs * 2;
    score -= metrics.expiringContracts * 3;
    score -= metrics.noContract * 10;
    score -= metrics.noTaxNumber * 5;
    return Math.max(0, score);
}
exports.default = {
    getIRP5: exports.getIRP5,
    getEMP501: exports.getEMP501,
    getPayslip: exports.getPayslip,
    getPayslipHTML: exports.getPayslipHTML,
    calculateTax: exports.calculateTax,
    getTaxBrackets: exports.getTaxBrackets,
    uploadDocument: exports.uploadDocument,
    getEmployeeDocuments: exports.getEmployeeDocuments,
    deleteDocument: exports.deleteDocument,
    getExpiringDocuments: exports.getExpiringDocuments,
    createContract: exports.createContract,
    getEmployeeContracts: exports.getEmployeeContracts,
    terminateContract: exports.terminateContract,
    getExpiringContracts: exports.getExpiringContracts,
    processLeaveAccruals: exports.processLeaveAccruals,
    processYearEndCarryover: exports.processYearEndCarryover,
    getLeaveCalendar: exports.getLeaveCalendar,
    checkBCEACompliance: exports.checkBCEACompliance,
    getComplianceReport: exports.getComplianceReport,
};
//# sourceMappingURL=hr.compliance.controller.js.map