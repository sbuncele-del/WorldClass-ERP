/**
 * Payslip Service
 * Generates professional payslips for employees
 */
export interface PayslipData {
    employee: {
        employee_number: string;
        full_name: string;
        id_number: string;
        tax_number: string;
        department: string;
        position: string;
        bank_name: string;
        bank_account_number: string;
    };
    period: {
        period_name: string;
        start_date: string;
        end_date: string;
        payment_date: string;
    };
    earnings: Array<{
        description: string;
        amount: number;
    }>;
    deductions: Array<{
        description: string;
        amount: number;
    }>;
    totals: {
        gross_pay: number;
        total_deductions: number;
        net_pay: number;
    };
    ytd: {
        gross_pay: number;
        paye: number;
        uif: number;
        net_pay: number;
    };
    company: {
        name: string;
        registration_number: string;
        tax_number: string;
        address: string;
        uif_number: string;
        sdl_number: string;
    };
}
/**
 * Get payslip data for an employee and payroll run
 */
export declare function getPayslipData(employeeId: number, runId: number, tenantId: string): Promise<PayslipData | null>;
/**
 * Generate HTML payslip
 */
export declare function generatePayslipHTML(data: PayslipData): string;
declare const _default: {
    getPayslipData: typeof getPayslipData;
    generatePayslipHTML: typeof generatePayslipHTML;
};
export default _default;
//# sourceMappingURL=payslip.service.d.ts.map