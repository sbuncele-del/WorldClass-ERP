"use strict";
/**
 * Employee Documents Service
 * Manages employee contracts, documents, and file storage
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONTRACT_TYPES = exports.DOCUMENT_TYPES = void 0;
exports.createDocument = createDocument;
exports.getEmployeeDocuments = getEmployeeDocuments;
exports.deleteDocument = deleteDocument;
exports.getExpiringDocuments = getExpiringDocuments;
exports.createContract = createContract;
exports.getEmployeeContracts = getEmployeeContracts;
exports.terminateContract = terminateContract;
exports.getExpiringContracts = getExpiringContracts;
const database_1 = __importDefault(require("../../../config/database"));
const uuid_1 = require("uuid");
// Document types
exports.DOCUMENT_TYPES = [
    'ID_DOCUMENT',
    'PASSPORT',
    'DRIVERS_LICENSE',
    'WORK_PERMIT',
    'CONTRACT',
    'QUALIFICATION',
    'CERTIFICATE',
    'TAX_CERTIFICATE',
    'MEDICAL_CERTIFICATE',
    'BACKGROUND_CHECK',
    'REFERENCE_LETTER',
    'PERFORMANCE_REVIEW',
    'DISCIPLINARY_RECORD',
    'TRAINING_RECORD',
    'OTHER',
];
// Contract types
exports.CONTRACT_TYPES = [
    'PERMANENT',
    'FIXED_TERM',
    'PART_TIME',
    'TEMPORARY',
    'CASUAL',
    'INTERNSHIP',
    'LEARNERSHIP',
    'CONTRACTOR',
];
/**
 * Create employee document record
 */
async function createDocument(tenantId, employeeId, documentData) {
    const client = await database_1.default.connect();
    try {
        await client.query('BEGIN');
        // Validate document type
        if (!exports.DOCUMENT_TYPES.includes(documentData.document_type)) {
            throw new Error(`Invalid document type. Must be one of: ${exports.DOCUMENT_TYPES.join(', ')}`);
        }
        // Verify employee exists
        const empCheck = await client.query('SELECT employee_id FROM hr.employees WHERE tenant_id = $1 AND employee_id = $2', [tenantId, employeeId]);
        if (empCheck.rows.length === 0) {
            throw new Error('Employee not found');
        }
        const result = await client.query(`
      INSERT INTO hr.employee_documents (
        tenant_id,
        employee_id,
        document_type,
        document_name,
        file_name,
        file_path,
        file_size,
        mime_type,
        description,
        expiry_date,
        is_confidential,
        uploaded_by,
        created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, CURRENT_TIMESTAMP)
      RETURNING *
    `, [
            tenantId,
            employeeId,
            documentData.document_type,
            documentData.document_name,
            documentData.file_name,
            documentData.file_path,
            documentData.file_size,
            documentData.mime_type,
            documentData.description || null,
            documentData.expiry_date || null,
            documentData.is_confidential || false,
            documentData.uploaded_by,
        ]);
        await client.query('COMMIT');
        return result.rows[0];
    }
    catch (error) {
        await client.query('ROLLBACK');
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Get all documents for an employee
 */
async function getEmployeeDocuments(tenantId, employeeId, documentType) {
    let query = `
    SELECT 
      d.*,
      u.first_name || ' ' || u.last_name as uploaded_by_name
    FROM hr.employee_documents d
    LEFT JOIN users u ON d.uploaded_by = u.id
    WHERE d.tenant_id = $1 AND d.employee_id = $2 AND d.is_deleted = false
  `;
    const params = [tenantId, employeeId];
    if (documentType) {
        params.push(documentType);
        query += ` AND d.document_type = $${params.length}`;
    }
    query += ' ORDER BY d.created_at DESC';
    const result = await database_1.default.query(query, params);
    return result.rows;
}
/**
 * Delete document (soft delete)
 */
async function deleteDocument(tenantId, documentId) {
    await database_1.default.query(`
    UPDATE hr.employee_documents
    SET is_deleted = true, deleted_at = CURRENT_TIMESTAMP
    WHERE tenant_id = $1 AND document_id = $2
  `, [tenantId, documentId]);
}
/**
 * Get documents expiring soon
 */
async function getExpiringDocuments(tenantId, daysAhead = 30) {
    const result = await database_1.default.query(`
    SELECT 
      d.*,
      e.employee_number,
      e.first_name || ' ' || e.last_name as employee_name,
      dept.department_name
    FROM hr.employee_documents d
    JOIN hr.employees e ON d.employee_id = e.employee_id AND e.tenant_id = $2
    LEFT JOIN hr.departments dept ON e.department_id = dept.department_id
    WHERE d.expiry_date IS NOT NULL
      AND d.expiry_date <= CURRENT_DATE + INTERVAL '1 day' * $1
      AND d.expiry_date >= CURRENT_DATE
      AND d.is_deleted = false
      AND d.tenant_id = $2
    ORDER BY d.expiry_date ASC
  `, [daysAhead, tenantId]);
    return result.rows;
}
/**
 * Create employee contract
 */
async function createContract(tenantId, employeeId, contractData) {
    const client = await database_1.default.connect();
    try {
        await client.query('BEGIN');
        // Validate contract type
        if (!exports.CONTRACT_TYPES.includes(contractData.contract_type)) {
            throw new Error(`Invalid contract type. Must be one of: ${exports.CONTRACT_TYPES.join(', ')}`);
        }
        // Verify employee exists
        const empCheck = await client.query('SELECT employee_id FROM hr.employees WHERE tenant_id = $1 AND employee_id = $2', [tenantId, employeeId]);
        if (empCheck.rows.length === 0) {
            throw new Error('Employee not found');
        }
        // Generate contract number
        const contractNumber = `CTR-${new Date().getFullYear()}-${(0, uuid_1.v4)().substring(0, 8).toUpperCase()}`;
        // Expire any existing active contracts
        await client.query(`
      UPDATE hr.employee_contracts
      SET status = 'SUPERSEDED', updated_at = CURRENT_TIMESTAMP
      WHERE tenant_id = $1 AND employee_id = $2 AND status = 'ACTIVE'
    `, [tenantId, employeeId]);
        const result = await client.query(`
      INSERT INTO hr.employee_contracts (
        tenant_id,
        employee_id,
        contract_type,
        contract_number,
        start_date,
        end_date,
        job_title,
        department_id,
        reporting_to,
        basic_salary,
        salary_frequency,
        working_hours_per_week,
        probation_period_months,
        notice_period_days,
        benefits,
        special_conditions,
        status,
        document_id,
        created_by,
        created_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, 'ACTIVE', $17, $18, CURRENT_TIMESTAMP)
      RETURNING *
    `, [
            tenantId,
            employeeId,
            contractData.contract_type,
            contractNumber,
            contractData.start_date,
            contractData.end_date || null,
            contractData.job_title,
            contractData.department_id,
            contractData.reporting_to || null,
            contractData.basic_salary,
            contractData.salary_frequency || 'MONTHLY',
            contractData.working_hours_per_week || 40,
            contractData.probation_period_months || 3,
            contractData.notice_period_days || 30,
            JSON.stringify(contractData.benefits || {}),
            contractData.special_conditions || null,
            contractData.document_id || null,
            contractData.created_by,
        ]);
        // Update employee's basic salary if contract is active
        await client.query(`
      UPDATE hr.employees
      SET 
        basic_salary = $1,
        position_id = (SELECT position_id FROM hr.positions WHERE position_title = $2 LIMIT 1),
        department_id = $3,
        reports_to_employee_id = $4,
        updated_at = CURRENT_TIMESTAMP
      WHERE tenant_id = $5 AND employee_id = $6
    `, [
            contractData.basic_salary,
            contractData.job_title,
            contractData.department_id,
            contractData.reporting_to,
            tenantId,
            employeeId,
        ]);
        await client.query('COMMIT');
        return result.rows[0];
    }
    catch (error) {
        await client.query('ROLLBACK');
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Get all contracts for an employee
 */
async function getEmployeeContracts(tenantId, employeeId, includeHistory = false) {
    let query = `
    SELECT 
      c.*,
      d.department_name,
      m.first_name || ' ' || m.last_name as reporting_to_name
    FROM hr.employee_contracts c
    LEFT JOIN hr.departments d ON c.department_id = d.department_id AND d.tenant_id = $1
    LEFT JOIN hr.employees m ON c.reporting_to = m.employee_id AND m.tenant_id = $1
    WHERE c.tenant_id = $1 AND c.employee_id = $2
  `;
    if (!includeHistory) {
        query += ` AND c.status = 'ACTIVE'`;
    }
    query += ' ORDER BY c.start_date DESC';
    const result = await database_1.default.query(query, [tenantId, employeeId]);
    return result.rows;
}
/**
 * Terminate contract
 */
async function terminateContract(tenantId, contractId, terminationDate, terminationReason, terminatedBy) {
    const client = await database_1.default.connect();
    try {
        await client.query('BEGIN');
        // Update contract
        await client.query(`
      UPDATE hr.employee_contracts
      SET 
        status = 'TERMINATED',
        end_date = $1,
        termination_reason = $2,
        terminated_by = $3,
        terminated_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
      WHERE tenant_id = $4 AND contract_id = $5
    `, [terminationDate, terminationReason, terminatedBy, tenantId, contractId]);
        // Get employee ID
        const contractResult = await client.query('SELECT employee_id FROM hr.employee_contracts WHERE tenant_id = $1 AND contract_id = $2', [tenantId, contractId]);
        if (contractResult.rows.length > 0) {
            // Update employee status
            await client.query(`
        UPDATE hr.employees
        SET 
          employment_status = 'Terminated',
          termination_date = $1,
          updated_at = CURRENT_TIMESTAMP
        WHERE tenant_id = $2 AND employee_id = $3
      `, [terminationDate, tenantId, contractResult.rows[0].employee_id]);
        }
        await client.query('COMMIT');
    }
    catch (error) {
        await client.query('ROLLBACK');
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Get contracts expiring soon
 */
async function getExpiringContracts(tenantId, daysAhead = 60) {
    const result = await database_1.default.query(`
    SELECT 
      c.*,
      e.employee_number,
      e.first_name || ' ' || e.last_name as employee_name,
      d.department_name
    FROM hr.employee_contracts c
    JOIN hr.employees e ON c.employee_id = e.employee_id
    LEFT JOIN hr.departments d ON c.department_id = d.department_id
    WHERE c.end_date IS NOT NULL
      AND c.end_date <= CURRENT_DATE + INTERVAL '1 day' * $1
      AND c.end_date >= CURRENT_DATE
      AND c.status = 'ACTIVE'
      AND c.tenant_id = $2
      AND e.tenant_id = $2
    ORDER BY c.end_date ASC
  `, [daysAhead, tenantId]);
    return result.rows;
}
exports.default = {
    createDocument,
    getEmployeeDocuments,
    deleteDocument,
    getExpiringDocuments,
    createContract,
    getEmployeeContracts,
    terminateContract,
    getExpiringContracts,
    DOCUMENT_TYPES: exports.DOCUMENT_TYPES,
    CONTRACT_TYPES: exports.CONTRACT_TYPES,
};
//# sourceMappingURL=employee-documents.service.js.map