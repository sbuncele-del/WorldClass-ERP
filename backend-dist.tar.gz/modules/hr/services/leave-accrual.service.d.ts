/**
 * Leave Accrual Service
 * Automatic leave accrual calculations and processing
 */
export interface LeaveType {
    leave_type_id: number;
    leave_code: string;
    leave_name: string;
    default_days: number;
    accrual_method: 'NONE' | 'MONTHLY' | 'ANNUAL' | 'HOURLY';
    accrual_rate: number;
    max_carryover: number;
    max_balance: number;
    requires_approval: boolean;
    min_notice_days: number;
    is_paid: boolean;
    is_active: boolean;
}
export interface LeaveBalance {
    balance_id: number;
    employee_id: number;
    leave_type_id: number;
    year: number;
    opening_balance: number;
    accrued: number;
    taken: number;
    adjustment: number;
    pending: number;
    closing_balance: number;
}
export declare const STATUTORY_LEAVE_TYPES: {
    ANNUAL: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
    SICK: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
    FAMILY: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
    MATERNITY: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
    PATERNITY: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
    STUDY: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
    UNPAID: {
        leave_code: string;
        leave_name: string;
        default_days: number;
        accrual_method: string;
        accrual_rate: number;
        max_carryover: number;
        max_balance: number;
        requires_approval: boolean;
        min_notice_days: number;
        is_paid: boolean;
    };
};
/**
 * Initialize leave types for a new tenant
 */
export declare function initializeLeaveTypes(): Promise<void>;
/**
 * Initialize leave balances for a new employee
 */
export declare function initializeEmployeeLeaveBalances(employeeId: number, hireDate: Date): Promise<void>;
/**
 * Process monthly leave accruals for all active employees
 */
export declare function processMonthlyAccruals(tenantId: string): Promise<{
    processed: number;
    errors: string[];
}>;
/**
 * Process year-end leave carryover
 */
export declare function processYearEndCarryover(tenantId: string, fromYear: number, toYear: number): Promise<{
    processed: number;
    forfeitedDays: number;
    errors: string[];
}>;
/**
 * Get leave calendar for department
 */
export declare function getDepartmentLeaveCalendar(tenantId: string, departmentId: number, startDate: Date, endDate: Date): Promise<any[]>;
declare const _default: {
    initializeLeaveTypes: typeof initializeLeaveTypes;
    initializeEmployeeLeaveBalances: typeof initializeEmployeeLeaveBalances;
    processMonthlyAccruals: typeof processMonthlyAccruals;
    processYearEndCarryover: typeof processYearEndCarryover;
    getDepartmentLeaveCalendar: typeof getDepartmentLeaveCalendar;
    STATUTORY_LEAVE_TYPES: {
        ANNUAL: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
        SICK: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
        FAMILY: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
        MATERNITY: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
        PATERNITY: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
        STUDY: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
        UNPAID: {
            leave_code: string;
            leave_name: string;
            default_days: number;
            accrual_method: string;
            accrual_rate: number;
            max_carryover: number;
            max_balance: number;
            requires_approval: boolean;
            min_notice_days: number;
            is_paid: boolean;
        };
    };
};
export default _default;
//# sourceMappingURL=leave-accrual.service.d.ts.map