/**
 * Employee Documents Service
 * Manages employee contracts, documents, and file storage
 */
export interface EmployeeDocument {
    document_id: number;
    employee_id: number;
    document_type: string;
    document_name: string;
    file_name: string;
    file_path: string;
    file_size: number;
    mime_type: string;
    description?: string;
    expiry_date?: Date;
    is_confidential: boolean;
    uploaded_by: number;
    created_at: Date;
}
export interface EmployeeContract {
    contract_id: number;
    employee_id: number;
    contract_type: string;
    contract_number: string;
    start_date: Date;
    end_date?: Date;
    job_title: string;
    department_id: number;
    reporting_to: number;
    basic_salary: number;
    salary_frequency: string;
    working_hours_per_week: number;
    probation_period_months: number;
    notice_period_days: number;
    benefits: object;
    special_conditions?: string;
    status: string;
    document_id?: number;
    created_by: number;
    created_at: Date;
}
export declare const DOCUMENT_TYPES: string[];
export declare const CONTRACT_TYPES: string[];
/**
 * Create employee document record
 */
export declare function createDocument(tenantId: string, employeeId: number, documentData: {
    document_type: string;
    document_name: string;
    file_name: string;
    file_path: string;
    file_size: number;
    mime_type: string;
    description?: string;
    expiry_date?: Date;
    is_confidential?: boolean;
    uploaded_by: number;
}): Promise<EmployeeDocument>;
/**
 * Get all documents for an employee
 */
export declare function getEmployeeDocuments(tenantId: string, employeeId: number, documentType?: string): Promise<EmployeeDocument[]>;
/**
 * Delete document (soft delete)
 */
export declare function deleteDocument(tenantId: string, documentId: number): Promise<void>;
/**
 * Get documents expiring soon
 */
export declare function getExpiringDocuments(tenantId: string, daysAhead?: number): Promise<any[]>;
/**
 * Create employee contract
 */
export declare function createContract(tenantId: string, employeeId: number, contractData: {
    contract_type: string;
    start_date: Date;
    end_date?: Date;
    job_title: string;
    department_id: number;
    reporting_to?: number;
    basic_salary: number;
    salary_frequency: string;
    working_hours_per_week?: number;
    probation_period_months?: number;
    notice_period_days?: number;
    benefits?: object;
    special_conditions?: string;
    document_id?: number;
    created_by: number;
}): Promise<EmployeeContract>;
/**
 * Get all contracts for an employee
 */
export declare function getEmployeeContracts(tenantId: string, employeeId: number, includeHistory?: boolean): Promise<EmployeeContract[]>;
/**
 * Terminate contract
 */
export declare function terminateContract(tenantId: string, contractId: number, terminationDate: Date, terminationReason: string, terminatedBy: number): Promise<void>;
/**
 * Get contracts expiring soon
 */
export declare function getExpiringContracts(tenantId: string, daysAhead?: number): Promise<any[]>;
declare const _default: {
    createDocument: typeof createDocument;
    getEmployeeDocuments: typeof getEmployeeDocuments;
    deleteDocument: typeof deleteDocument;
    getExpiringDocuments: typeof getExpiringDocuments;
    createContract: typeof createContract;
    getEmployeeContracts: typeof getEmployeeContracts;
    terminateContract: typeof terminateContract;
    getExpiringContracts: typeof getExpiringContracts;
    DOCUMENT_TYPES: string[];
    CONTRACT_TYPES: string[];
};
export default _default;
//# sourceMappingURL=employee-documents.service.d.ts.map