/**
 * South African Tax Calculation Service
 * SARS-compliant PAYE, UIF, SDL calculations
 * Updated for 2024/2025 tax year
 */
export declare const SARS_TAX_BRACKETS_2024: {
    min: number;
    max: number;
    rate: number;
    base: number;
}[];
export declare const TAX_REBATES_2024: {
    primary: number;
    secondary: number;
    tertiary: number;
};
export declare const TAX_THRESHOLDS_2024: {
    under65: number;
    age65to74: number;
    age75plus: number;
};
export declare const UIF_RATE = 0.01;
export declare const UIF_CEILING_MONTHLY = 17712;
export declare const SDL_RATE = 0.01;
export interface TaxCalculationInput {
    annualGrossIncome: number;
    employeeAge: number;
    medicalAidMembers?: number;
    retirementContributions?: number;
    travelAllowance?: number;
    commissionsIncluded?: boolean;
}
export interface TaxCalculationResult {
    annualTax: number;
    monthlyPAYE: number;
    annualRebate: number;
    effectiveTaxRate: number;
    taxBracket: number;
    uifEmployee: number;
    uifEmployer: number;
    sdlEmployer: number;
    medicalCredits: number;
    taxableIncome: number;
    breakdown: {
        description: string;
        amount: number;
    }[];
}
/**
 * Calculate PAYE tax based on annual taxable income
 */
export declare function calculatePAYE(annualTaxableIncome: number): number;
/**
 * Get applicable tax rebate based on age
 */
export declare function getTaxRebate(age: number): number;
/**
 * Calculate medical tax credits
 * Main member + first dependent: R364/month each
 * Additional dependents: R246/month each
 */
export declare function calculateMedicalCredits(members: number): number;
/**
 * Calculate UIF (Unemployment Insurance Fund)
 */
export declare function calculateUIF(monthlyGross: number): {
    employee: number;
    employer: number;
};
/**
 * Calculate SDL (Skills Development Levy)
 */
export declare function calculateSDL(monthlyGross: number): number;
/**
 * Full tax calculation with all components
 */
export declare function calculateFullTax(input: TaxCalculationInput): TaxCalculationResult;
/**
 * Generate IRP5/IT3(a) data for an employee for the tax year
 */
export declare function generateIRP5Data(employeeId: number, taxYear: number, tenantId: string): Promise<{
    certificate_number: string;
    tax_year: string;
    employee: {
        employee_number: any;
        id_number: any;
        tax_number: any;
        first_name: any;
        last_name: any;
        date_of_birth: any;
        physical_address: string;
    };
    employer: {
        trading_name: string;
        paye_reference: string;
        sdl_reference: string;
        uif_reference: string;
        physical_address: string;
    };
    employment: {
        start_date: any;
        end_date: any;
        periods_paid: number;
        nature_of_person: string;
    };
    source_codes: {
        code: string;
        description: string;
        amount: number;
    }[];
    totals: {
        gross_remuneration: number;
        total_paye: number;
        total_uif: number;
        nett_remuneration: number;
    };
    generated_at: string;
}>;
/**
 * Generate EMP501 reconciliation data
 */
export declare function generateEMP501Data(taxYear: number, tenantId: string): Promise<{
    reconciliation_type: string;
    tax_year: string;
    submission_period: string;
    employer: {
        trading_name: string;
        paye_reference: string;
        sdl_reference: string;
        uif_reference: string;
    };
    summary: {
        total_employees: any;
        total_gross_remuneration: any;
        total_paye_deducted: any;
        total_uif_employee: any;
        total_uif_employer: any;
        total_sdl: any;
    };
    employees: {
        employee_number: any;
        id_number: any;
        name: string;
        gross_remuneration: number;
        paye_deducted: number;
        uif_contribution: number;
    }[];
    declaration: {
        certified_correct: boolean;
        signature_required: boolean;
        submission_deadline: string;
    };
    generated_at: string;
}>;
declare const _default: {
    calculatePAYE: typeof calculatePAYE;
    getTaxRebate: typeof getTaxRebate;
    calculateMedicalCredits: typeof calculateMedicalCredits;
    calculateUIF: typeof calculateUIF;
    calculateSDL: typeof calculateSDL;
    calculateFullTax: typeof calculateFullTax;
    generateIRP5Data: typeof generateIRP5Data;
    generateEMP501Data: typeof generateEMP501Data;
    SARS_TAX_BRACKETS_2024: {
        min: number;
        max: number;
        rate: number;
        base: number;
    }[];
    TAX_REBATES_2024: {
        primary: number;
        secondary: number;
        tertiary: number;
    };
    TAX_THRESHOLDS_2024: {
        under65: number;
        age65to74: number;
        age75plus: number;
    };
};
export default _default;
//# sourceMappingURL=tax-calculation.service.d.ts.map