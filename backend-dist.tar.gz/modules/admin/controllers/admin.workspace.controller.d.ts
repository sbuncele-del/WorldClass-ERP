import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Admin Portal Workspace Controller
 * Provides aggregated data for the Admin Portal dashboard
 */
/**
 * GET /api/admin/workspace
 * Returns all data needed for the Admin Portal workspace dashboard
 */
export declare const getAdminWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=admin.workspace.controller.d.ts.map