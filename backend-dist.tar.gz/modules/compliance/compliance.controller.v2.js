"use strict";
/**
 * Compliance Controller V2
 * Tenant-aware handlers for regulatory compliance management
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRegulatoryUpdates = exports.getComplianceDashboard = exports.getComplianceAudits = exports.createFiling = exports.getComplianceFilings = exports.createComplianceRequirement = exports.getComplianceRequirements = void 0;
const database_1 = __importDefault(require("../../config/database"));
/**
 * Tenant context helper
 */
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant ID not found');
    }
    return {
        tenantId,
        userId: req.user?.id
    };
}
// ============================================================================
// COMPLIANCE REQUIREMENTS
// ============================================================================
const getComplianceRequirements = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { category, status, jurisdiction, page = '1', limit = '50' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `
      SELECT * FROM compliance.requirements
      WHERE tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (category) {
            query += ` AND category = $${paramCount}`;
            values.push(category);
            paramCount++;
        }
        if (status) {
            query += ` AND status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        if (jurisdiction) {
            query += ` AND jurisdiction = $${paramCount}`;
            values.push(jurisdiction);
            paramCount++;
        }
        query += ` ORDER BY due_date ASC NULLS LAST, priority DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        // Get count
        const countQuery = `SELECT COUNT(*) FROM compliance.requirements WHERE tenant_id = $1`;
        const countResult = await database_1.default.query(countQuery, [tenantId]);
        res.json({
            success: true,
            requirements: result.rows,
            total: parseInt(countResult.rows[0].count),
            page: parseInt(page),
            totalPages: Math.ceil(parseInt(countResult.rows[0].count) / parseInt(limit))
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching compliance requirements:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch requirements', error: error.message });
    }
};
exports.getComplianceRequirements = getComplianceRequirements;
const createComplianceRequirement = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const reqData = req.body;
        const result = await database_1.default.query(`INSERT INTO compliance.requirements (
        tenant_id, name, description, category, jurisdiction, regulatory_body,
        due_date, frequency, priority, status, assigned_to, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
      RETURNING *`, [
            tenantId,
            reqData.name,
            reqData.description,
            reqData.category,
            reqData.jurisdiction,
            reqData.regulatory_body,
            reqData.due_date,
            reqData.frequency,
            reqData.priority || 'MEDIUM',
            reqData.status || 'PENDING',
            reqData.assigned_to,
            userId
        ]);
        res.status(201).json({ success: true, requirement: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to create requirement', error: error.message });
    }
};
exports.createComplianceRequirement = createComplianceRequirement;
// ============================================================================
// COMPLIANCE FILINGS
// ============================================================================
const getComplianceFilings = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { requirement_id, status, year, page = '1', limit = '50' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `
      SELECT f.*, r.name as requirement_name
      FROM compliance.filings f
      LEFT JOIN compliance.requirements r ON f.requirement_id = r.id
      WHERE f.tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (requirement_id) {
            query += ` AND f.requirement_id = $${paramCount}`;
            values.push(requirement_id);
            paramCount++;
        }
        if (status) {
            query += ` AND f.status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        if (year) {
            query += ` AND EXTRACT(YEAR FROM f.filing_date) = $${paramCount}`;
            values.push(year);
            paramCount++;
        }
        query += ` ORDER BY f.filing_date DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        res.json({ success: true, filings: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch filings', error: error.message });
    }
};
exports.getComplianceFilings = getComplianceFilings;
const createFiling = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const filingData = req.body;
        const result = await database_1.default.query(`INSERT INTO compliance.filings (
        tenant_id, requirement_id, filing_date, period_start, period_end,
        status, submission_reference, notes, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
      RETURNING *`, [
            tenantId,
            filingData.requirement_id,
            filingData.filing_date,
            filingData.period_start,
            filingData.period_end,
            filingData.status || 'DRAFT',
            filingData.submission_reference,
            filingData.notes,
            userId
        ]);
        res.status(201).json({ success: true, filing: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to create filing', error: error.message });
    }
};
exports.createFiling = createFiling;
// ============================================================================
// COMPLIANCE AUDITS
// ============================================================================
const getComplianceAudits = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { type, status, year, page = '1', limit = '50' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `
      SELECT * FROM compliance.audits
      WHERE tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (type) {
            query += ` AND audit_type = $${paramCount}`;
            values.push(type);
            paramCount++;
        }
        if (status) {
            query += ` AND status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        if (year) {
            query += ` AND EXTRACT(YEAR FROM audit_date) = $${paramCount}`;
            values.push(year);
            paramCount++;
        }
        query += ` ORDER BY audit_date DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        res.json({ success: true, audits: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch audits', error: error.message });
    }
};
exports.getComplianceAudits = getComplianceAudits;
// ============================================================================
// COMPLIANCE DASHBOARD
// ============================================================================
const getComplianceDashboard = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        // Get requirements by status
        const reqStats = await database_1.default.query(`SELECT 
        status,
        COUNT(*) as count
       FROM compliance.requirements
       WHERE tenant_id = $1
       GROUP BY status`, [tenantId]);
        // Get upcoming deadlines (next 30 days)
        const upcomingDeadlines = await database_1.default.query(`SELECT id, name, due_date, priority, status
       FROM compliance.requirements
       WHERE tenant_id = $1 
       AND due_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days'
       AND status NOT IN ('COMPLETED', 'CANCELLED')
       ORDER BY due_date ASC
       LIMIT 10`, [tenantId]);
        // Get recent filings
        const recentFilings = await database_1.default.query(`SELECT f.*, r.name as requirement_name
       FROM compliance.filings f
       LEFT JOIN compliance.requirements r ON f.requirement_id = r.id
       WHERE f.tenant_id = $1
       ORDER BY f.filing_date DESC
       LIMIT 5`, [tenantId]);
        res.json({
            success: true,
            dashboard: {
                requirementStats: reqStats.rows,
                upcomingDeadlines: upcomingDeadlines.rows,
                recentFilings: recentFilings.rows
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch dashboard', error: error.message });
    }
};
exports.getComplianceDashboard = getComplianceDashboard;
// ============================================================================
// REGULATORY UPDATES
// ============================================================================
const getRegulatoryUpdates = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { jurisdiction, category, page = '1', limit = '20' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `
      SELECT * FROM compliance.regulatory_updates
      WHERE tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (jurisdiction) {
            query += ` AND jurisdiction = $${paramCount}`;
            values.push(jurisdiction);
            paramCount++;
        }
        if (category) {
            query += ` AND category = $${paramCount}`;
            values.push(category);
            paramCount++;
        }
        query += ` ORDER BY effective_date DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        res.json({ success: true, updates: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch updates', error: error.message });
    }
};
exports.getRegulatoryUpdates = getRegulatoryUpdates;
exports.default = {
    getComplianceRequirements: exports.getComplianceRequirements,
    createComplianceRequirement: exports.createComplianceRequirement,
    getComplianceFilings: exports.getComplianceFilings,
    createFiling: exports.createFiling,
    getComplianceAudits: exports.getComplianceAudits,
    getComplianceDashboard: exports.getComplianceDashboard,
    getRegulatoryUpdates: exports.getRegulatoryUpdates
};
//# sourceMappingURL=compliance.controller.v2.js.map