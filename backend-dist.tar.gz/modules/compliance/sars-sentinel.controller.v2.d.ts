/**
 * SARS Sentinel Controller V2
 * Tenant-aware handlers for South African Revenue Service compliance
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getTaxReturns: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createTaxReturn: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getVATReturns: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createVATReturn: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getPAYESubmissions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createPAYESubmission: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTaxCertificates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getSARSDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getTaxReturns: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createTaxReturn: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getVATReturns: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createVATReturn: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getPAYESubmissions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createPAYESubmission: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTaxCertificates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getSARSDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=sars-sentinel.controller.v2.d.ts.map