/**
 * Compliance Controller V2
 * Tenant-aware handlers for regulatory compliance management
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getComplianceRequirements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createComplianceRequirement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getComplianceFilings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createFiling: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getComplianceAudits: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getComplianceDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getRegulatoryUpdates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getComplianceRequirements: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createComplianceRequirement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getComplianceFilings: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createFiling: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getComplianceAudits: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getComplianceDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getRegulatoryUpdates: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=compliance.controller.v2.d.ts.map