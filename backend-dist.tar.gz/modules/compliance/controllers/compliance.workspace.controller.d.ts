import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Compliance Workspace Controller
 * Provides aggregated data for the Compliance Framework dashboard
 */
/**
 * GET /api/compliance/workspace
 * Returns all data needed for the Compliance Framework workspace dashboard
 */
export declare const getComplianceWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=compliance.workspace.controller.d.ts.map