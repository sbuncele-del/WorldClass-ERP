import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * SARS Sentinel Workspace Controller
 * Provides aggregated data for the SARS Sentinel dashboard
 */
/**
 * GET /api/sars/workspace
 * Returns all data needed for the SARS Sentinel workspace dashboard
 */
export declare const getSARSWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=sars.workspace.controller.d.ts.map