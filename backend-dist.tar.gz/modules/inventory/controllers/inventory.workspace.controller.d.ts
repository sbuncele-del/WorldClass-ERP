import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Inventory Workspace Controller
 * Provides aggregated data for the Inventory Management dashboard
 */
/**
 * GET /api/inventory/workspace
 * Returns all data needed for the Inventory Management workspace dashboard
 */
export declare const getInventoryWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=inventory.workspace.controller.d.ts.map