import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Purchase Workspace Controller
 * Provides aggregated data for the Purchase Management dashboard
 */
/**
 * GET /api/purchase/workspace
 * Returns all data needed for the Purchase Management workspace dashboard
 */
export declare const getPurchaseWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=purchase.workspace.controller.d.ts.map