"use strict";
// ============================================================================
// ACCOUNTING AUTOMATION - API ROUTES
// ============================================================================
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const accounting_automation_controller_1 = __importDefault(require("./accounting.automation.controller"));
const auth_1 = require("../../middleware/auth");
const router = (0, express_1.Router)();
// Apply authentication to all routes
router.use(auth_1.authenticateToken);
// ---------------------------------------------------------------------------
// CHART OF ACCOUNTS
// ---------------------------------------------------------------------------
router.get('/chart-of-accounts', accounting_automation_controller_1.default.getChartOfAccounts);
// ---------------------------------------------------------------------------
// JOURNAL ENTRIES - AUTO DOUBLE-ENTRY
// ---------------------------------------------------------------------------
router.post('/journal-entries', accounting_automation_controller_1.default.createJournalEntry);
router.post('/journal-entries/:entryId/post', accounting_automation_controller_1.default.postJournalEntry);
router.post('/journal-entries/:entryId/reverse', accounting_automation_controller_1.default.reverseJournalEntry);
// ---------------------------------------------------------------------------
// ACCOUNTS RECEIVABLE AUTOMATION
// ---------------------------------------------------------------------------
router.post('/ar/auto-invoice', accounting_automation_controller_1.default.generateInvoiceFromDelivery);
router.post('/ar/smart-match', accounting_automation_controller_1.default.smartMatchPayment);
router.post('/ar/apply-payment', accounting_automation_controller_1.default.applyPayment);
// ---------------------------------------------------------------------------
// ACCOUNTS PAYABLE AUTOMATION
// ---------------------------------------------------------------------------
router.post('/ap/ocr-process', accounting_automation_controller_1.default.processInvoiceOCR);
router.get('/ap/payment-schedule', accounting_automation_controller_1.default.getPaymentSchedule);
// ---------------------------------------------------------------------------
// CASH MANAGEMENT
// ---------------------------------------------------------------------------
router.get('/cash/position', accounting_automation_controller_1.default.getCashPosition);
router.get('/cash/forecast', accounting_automation_controller_1.default.getCashForecast);
// ---------------------------------------------------------------------------
// FINANCIAL STATEMENTS (Real-time)
// ---------------------------------------------------------------------------
router.get('/statements/balance-sheet', accounting_automation_controller_1.default.getBalanceSheet);
router.get('/statements/income-statement', accounting_automation_controller_1.default.getIncomeStatement);
// ---------------------------------------------------------------------------
// LOGISTICS INTEGRATION WEBHOOK
// ---------------------------------------------------------------------------
router.post('/webhooks/logistics', accounting_automation_controller_1.default.handleLogisticsEvent);
exports.default = router;
//# sourceMappingURL=accounting.automation.routes.js.map