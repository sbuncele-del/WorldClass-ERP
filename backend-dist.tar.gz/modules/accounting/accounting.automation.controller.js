"use strict";
// ============================================================================
// ACCOUNTING AUTOMATION - REST API CONTROLLER
// ============================================================================
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.accountingAutomationController = void 0;
const accounting_automation_service_1 = __importDefault(require("./accounting.automation.service"));
class AccountingAutomationController {
    // ---------------------------------------------------------------------------
    // CHART OF ACCOUNTS
    // ---------------------------------------------------------------------------
    async getChartOfAccounts(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.query.tenantId || '');
            const entityId = req.query.entityId ? String(req.query.entityId) : undefined;
            const accounts = await accounting_automation_service_1.default.getChartOfAccounts(tenantId, entityId);
            res.json({ success: true, data: accounts });
        }
        catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
    // ---------------------------------------------------------------------------
    // JOURNAL ENTRIES
    // ---------------------------------------------------------------------------
    async createJournalEntry(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.body.tenantId || '');
            const entry = await accounting_automation_service_1.default.createJournalEntry({
                tenantId,
                ...req.body
            });
            res.status(201).json({
                success: true,
                data: entry,
                message: entry.aiExplanation ? `AI: ${entry.aiExplanation}` : undefined
            });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    async postJournalEntry(req, res) {
        try {
            const { entryId } = req.params;
            const userId = String(req.user?.id || 'system');
            const entry = await accounting_automation_service_1.default.postJournalEntry(String(entryId), userId);
            res.json({ success: true, data: entry });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    async reverseJournalEntry(req, res) {
        try {
            const { entryId } = req.params;
            const { reason } = req.body;
            const userId = String(req.user?.id || 'system');
            const reversal = await accounting_automation_service_1.default.reverseJournalEntry(String(entryId), reason, userId);
            res.json({ success: true, data: reversal });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    // ---------------------------------------------------------------------------
    // ACCOUNTS RECEIVABLE
    // ---------------------------------------------------------------------------
    async generateInvoiceFromDelivery(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.body.tenantId || '');
            const { deliveryId, deliveryData } = req.body;
            const invoice = await accounting_automation_service_1.default.generateInvoiceFromDelivery(tenantId, deliveryId, deliveryData);
            res.status(201).json({
                success: true,
                data: invoice,
                message: 'Invoice auto-generated with revenue recognition journal entry'
            });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    async smartMatchPayment(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.body.tenantId || '');
            const payment = req.body.payment;
            const matches = await accounting_automation_service_1.default.smartMatchPayment(tenantId, payment);
            res.json({
                success: true,
                data: matches,
                message: matches.length > 0
                    ? `Found ${matches.length} potential matches (best: ${matches[0].matchConfidence}% confidence)`
                    : 'No matching invoices found'
            });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    async applyPayment(req, res) {
        try {
            const { paymentId, invoiceId, amount, autoApplied } = req.body;
            await accounting_automation_service_1.default.applyPaymentToInvoice(paymentId, invoiceId, amount, autoApplied);
            res.json({ success: true, message: 'Payment applied successfully' });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    // ---------------------------------------------------------------------------
    // ACCOUNTS PAYABLE
    // ---------------------------------------------------------------------------
    async processInvoiceOCR(req, res) {
        try {
            const tenantId = req.user?.tenantId || req.body.tenantId;
            const { documentUrl } = req.body;
            const invoice = await accounting_automation_service_1.default.processAPInvoiceOCR(tenantId, documentUrl);
            res.status(201).json({
                success: true,
                data: invoice,
                message: `Invoice processed with ${invoice.ocrConfidence}% OCR confidence. Match status: ${invoice.matchStatus}`
            });
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
    async getPaymentSchedule(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.query.tenantId || '');
            const schedule = await accounting_automation_service_1.default.optimizePaymentSchedule(tenantId);
            const totalSavings = schedule.reduce((sum, s) => sum + s.savings, 0);
            res.json({
                success: true,
                data: schedule,
                summary: {
                    totalInvoices: schedule.length,
                    totalPayments: schedule.reduce((sum, s) => sum + s.paymentAmount, 0),
                    totalDiscountSavings: totalSavings
                },
                message: totalSavings > 0
                    ? `Optimized schedule saves $${totalSavings.toFixed(2)} in early payment discounts`
                    : 'Payment schedule optimized for cash flow'
            });
        }
        catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
    // ---------------------------------------------------------------------------
    // CASH MANAGEMENT
    // ---------------------------------------------------------------------------
    async getCashPosition(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.query.tenantId || '');
            const position = await accounting_automation_service_1.default.getCashPosition(tenantId);
            res.json({ success: true, data: position });
        }
        catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
    async getCashForecast(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.query.tenantId || '');
            const horizonDays = parseInt(req.query.days) || 30;
            const forecast = await accounting_automation_service_1.default.generateCashForecast(tenantId, horizonDays);
            res.json({
                success: true,
                data: forecast,
                message: `${horizonDays}-day forecast generated with ${forecast.accuracyScore}% model accuracy`
            });
        }
        catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
    // ---------------------------------------------------------------------------
    // FINANCIAL STATEMENTS
    // ---------------------------------------------------------------------------
    async getBalanceSheet(req, res) {
        try {
            const tenantId = String(req.user?.tenantId || req.query.tenantId || '');
            const asOfDate = req.query.asOfDate
                ? new Date(String(req.query.asOfDate))
                : new Date();
            const balanceSheet = await accounting_automation_service_1.default.getBalanceSheet(tenantId, asOfDate);
            res.json({ success: true, data: balanceSheet });
        }
        catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
    async getIncomeStatement(req, res) {
        try {
            const tenantId = req.user?.tenantId || req.query.tenantId;
            // Default to current month
            const now = new Date();
            const startDate = req.query.startDate
                ? new Date(req.query.startDate)
                : new Date(now.getFullYear(), now.getMonth(), 1);
            const endDate = req.query.endDate
                ? new Date(req.query.endDate)
                : new Date(now.getFullYear(), now.getMonth() + 1, 0);
            const incomeStatement = await accounting_automation_service_1.default.getIncomeStatement(String(tenantId), startDate, endDate);
            res.json({ success: true, data: incomeStatement });
        }
        catch (error) {
            res.status(500).json({ success: false, error: error.message });
        }
    }
    // ---------------------------------------------------------------------------
    // LOGISTICS INTEGRATION WEBHOOK
    // ---------------------------------------------------------------------------
    async handleLogisticsEvent(req, res) {
        try {
            const { eventType, tenantId, data } = req.body;
            switch (eventType) {
                case 'SHIPMENT_DELIVERED':
                    const invoice = await accounting_automation_service_1.default.generateInvoiceFromDelivery(tenantId, data.shipmentId, data);
                    res.json({
                        success: true,
                        action: 'invoice_created',
                        invoiceNumber: invoice.invoiceNumber,
                        amount: invoice.totalAmount
                    });
                    break;
                case 'FUEL_TRANSACTION':
                    // Create fuel expense accrual
                    // Implementation would create AP invoice or journal entry
                    res.json({ success: true, action: 'expense_recorded' });
                    break;
                default:
                    res.json({ success: true, action: 'no_action_required' });
            }
        }
        catch (error) {
            res.status(400).json({ success: false, error: error.message });
        }
    }
}
exports.accountingAutomationController = new AccountingAutomationController();
exports.default = exports.accountingAutomationController;
//# sourceMappingURL=accounting.automation.controller.js.map