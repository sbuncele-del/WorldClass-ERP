import { ChartOfAccount, JournalEntry, CreateJournalEntryRequest, ARInvoice, ARPayment, SmartMatchResult, APInvoice, ThreeWayMatchResult, BankTransaction, CashPosition, CashForecast, FraudAlert, AIJournalExplanation, AIPaymentPrediction, BalanceSheet, IncomeStatement } from './accounting.types';
declare class AccountingAutomationService {
    getChartOfAccounts(tenantId: string, entityId?: string): Promise<ChartOfAccount[]>;
    getAccountByCode(tenantId: string, accountCode: string): Promise<ChartOfAccount | null>;
    createJournalEntry(request: CreateJournalEntryRequest): Promise<JournalEntry>;
    postJournalEntry(entryId: string, userId: string): Promise<JournalEntry>;
    reverseJournalEntry(entryId: string, reason: string, userId: string): Promise<JournalEntry>;
    generateInvoiceFromDelivery(tenantId: string, deliveryId: string, deliveryData: any): Promise<ARInvoice>;
    smartMatchPayment(tenantId: string, payment: ARPayment): Promise<SmartMatchResult[]>;
    applyPaymentToInvoice(paymentId: string, invoiceId: string, amount: number, autoApplied?: boolean): Promise<void>;
    processAPInvoiceOCR(tenantId: string, documentUrl: string): Promise<APInvoice>;
    attemptThreeWayMatch(client: any, invoice: APInvoice): Promise<ThreeWayMatchResult>;
    optimizePaymentSchedule(tenantId: string): Promise<any[]>;
    getCashPosition(tenantId: string): Promise<CashPosition>;
    generateCashForecast(tenantId: string, horizonDays: number): Promise<CashForecast>;
    detectFraud(transaction: BankTransaction): Promise<FraudAlert | null>;
    getBalanceSheet(tenantId: string, asOfDate: Date): Promise<BalanceSheet>;
    getIncomeStatement(tenantId: string, startDate: Date, endDate: Date): Promise<IncomeStatement>;
    generateAIExplanation(entry: JournalEntry, lines: any[]): Promise<AIJournalExplanation>;
    predictPayment(tenantId: string, customerId: string, amount: number): Promise<AIPaymentPrediction | null>;
    private generateEntryNumber;
    private generateInvoiceNumber;
    private generateEntryHash;
    private getSystemAccountId;
    private getTaxRate;
    private getAccountById;
    private findOrCreateVendor;
    private performOCR;
    private refreshTrialBalance;
    private mapChartOfAccount;
    private mapJournalEntry;
    private mapARInvoice;
    private mapAPInvoice;
}
export declare const accountingAutomationService: AccountingAutomationService;
export default accountingAutomationService;
//# sourceMappingURL=accounting.automation.service.d.ts.map