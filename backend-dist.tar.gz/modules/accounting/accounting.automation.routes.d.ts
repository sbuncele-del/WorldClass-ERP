declare const router: import("express-serve-static-core").Router;
export default router;
//# sourceMappingURL=accounting.automation.routes.d.ts.map