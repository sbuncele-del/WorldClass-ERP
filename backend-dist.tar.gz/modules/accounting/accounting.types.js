"use strict";
// ============================================================================
// ACCOUNTING AUTOMATION - TYPE DEFINITIONS
// 100% automated double-entry with AI validation
// ============================================================================
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=accounting.types.js.map