import { Request, Response } from 'express';
declare class AccountingAutomationController {
    getChartOfAccounts(req: Request, res: Response): Promise<void>;
    createJournalEntry(req: Request, res: Response): Promise<void>;
    postJournalEntry(req: Request, res: Response): Promise<void>;
    reverseJournalEntry(req: Request, res: Response): Promise<void>;
    generateInvoiceFromDelivery(req: Request, res: Response): Promise<void>;
    smartMatchPayment(req: Request, res: Response): Promise<void>;
    applyPayment(req: Request, res: Response): Promise<void>;
    processInvoiceOCR(req: Request, res: Response): Promise<void>;
    getPaymentSchedule(req: Request, res: Response): Promise<void>;
    getCashPosition(req: Request, res: Response): Promise<void>;
    getCashForecast(req: Request, res: Response): Promise<void>;
    getBalanceSheet(req: Request, res: Response): Promise<void>;
    getIncomeStatement(req: Request, res: Response): Promise<void>;
    handleLogisticsEvent(req: Request, res: Response): Promise<void>;
}
export declare const accountingAutomationController: AccountingAutomationController;
export default accountingAutomationController;
//# sourceMappingURL=accounting.automation.controller.d.ts.map