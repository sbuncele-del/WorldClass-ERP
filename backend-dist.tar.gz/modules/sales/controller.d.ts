/**
 * Sales Invoice Controller
 */
import { Request, Response } from 'express';
export declare class SalesController {
    /**
     * Create a new sales invoice
     * POST /api/sales/invoices
     */
    createInvoice(req: Request, res: Response): Promise<void>;
    /**
     * Get invoice by ID
     * GET /api/sales/invoices/:id
     */
    getInvoice(req: Request, res: Response): Promise<void>;
    /**
     * List invoices with filters
     * GET /api/sales/invoices
     */
    listInvoices(req: Request, res: Response): Promise<void>;
    /**
     * Update invoice
     * PUT /api/sales/invoices/:id
     */
    updateInvoice(req: Request, res: Response): Promise<void>;
    /**
     * Post invoice to GL
     * PUT /api/sales/invoices/:id/post
     */
    postInvoice(req: Request, res: Response): Promise<void>;
    /**
     * Delete invoice (soft delete)
     * DELETE /api/sales/invoices/:id
     */
    deleteInvoice(req: Request, res: Response): Promise<void>;
}
declare const _default: SalesController;
export default _default;
//# sourceMappingURL=controller.d.ts.map