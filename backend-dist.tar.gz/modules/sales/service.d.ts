/**
 * Sales Invoice Service
 * Handles CRUD operations for sales invoices
 */
export interface SalesInvoiceLine {
    line_number: number;
    description: string;
    quantity: number;
    unit_price: number;
    line_total: number;
    vat_rate?: number;
    vat_amount?: number;
    revenue_account_id?: string;
}
export interface CreateInvoiceDto {
    customer_id: number;
    invoice_date: string;
    due_date: string;
    reference?: string;
    notes?: string;
    lines: SalesInvoiceLine[];
    tenant_id?: string;
}
export interface UpdateInvoiceDto {
    invoice_date?: string;
    due_date?: string;
    reference?: string;
    notes?: string;
    lines?: SalesInvoiceLine[];
}
export interface InvoiceFilters {
    status?: string;
    customer_id?: number;
    from_date?: string;
    to_date?: string;
    search?: string;
}
export declare class SalesService {
    /**
     * Create a new sales invoice (DRAFT status)
     */
    createInvoice(dto: CreateInvoiceDto, userId?: number): Promise<any>;
    /**
     * Get invoice by ID
     */
    getInvoiceById(invoiceId: number, tenantId: string): Promise<any>;
    /**
     * List invoices with filters
     */
    listInvoices(filters: InvoiceFilters, tenantId: string, page?: number, limit?: number): Promise<any>;
    /**
     * Update invoice (only DRAFT status can be updated)
     */
    updateInvoice(invoiceId: number, dto: UpdateInvoiceDto, tenantId: string, userId?: number): Promise<any>;
    /**
     * Post invoice to GL (change status from DRAFT to POSTED)
     */
    postInvoice(invoiceId: number, tenantId: string, userId?: number): Promise<any>;
    /**
     * Delete invoice (only DRAFT status can be deleted - soft delete)
     */
    deleteInvoice(invoiceId: number, tenantId: string, userId?: number): Promise<void>;
}
declare const _default: SalesService;
export default _default;
//# sourceMappingURL=service.d.ts.map