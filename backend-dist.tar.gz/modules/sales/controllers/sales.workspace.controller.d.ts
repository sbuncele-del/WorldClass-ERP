import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Sales Workspace Controller
 * Provides aggregated data for the Sales & CRM dashboard
 */
/**
 * GET /api/sales/workspace
 * Returns all data needed for the Sales & CRM workspace dashboard
 */
export declare const getSalesWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=sales.workspace.controller.d.ts.map