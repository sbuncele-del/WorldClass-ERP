"use strict";
/**
 * Sales Invoice Controller
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SalesController = void 0;
const service_1 = __importDefault(require("./service"));
class SalesController {
    /**
     * Create a new sales invoice
     * POST /api/sales/invoices
     */
    async createInvoice(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'];
            const userId = req.user?.id;
            const invoice = await service_1.default.createInvoice({
                ...req.body,
                tenant_id: tenantId
            }, userId);
            res.status(201).json({
                success: true,
                data: invoice
            });
        }
        catch (error) {
            console.error('Error creating invoice:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to create invoice'
            });
        }
    }
    /**
     * Get invoice by ID
     * GET /api/sales/invoices/:id
     */
    async getInvoice(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const invoiceId = parseInt(req.params.id);
            const invoice = await service_1.default.getInvoiceById(invoiceId, tenantId);
            if (!invoice) {
                res.status(404).json({
                    success: false,
                    error: 'Invoice not found'
                });
                return;
            }
            res.json({
                success: true,
                data: invoice
            });
        }
        catch (error) {
            console.error('Error getting invoice:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to get invoice'
            });
        }
    }
    /**
     * List invoices with filters
     * GET /api/sales/invoices
     */
    async listInvoices(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const filters = {
                status: req.query.status,
                customer_id: req.query.customer_id ? parseInt(req.query.customer_id) : undefined,
                from_date: req.query.from_date,
                to_date: req.query.to_date,
                search: req.query.search
            };
            const page = req.query.page ? parseInt(req.query.page) : 1;
            const limit = req.query.limit ? parseInt(req.query.limit) : 50;
            const result = await service_1.default.listInvoices(filters, tenantId, page, limit);
            res.json({
                success: true,
                ...result
            });
        }
        catch (error) {
            console.error('Error listing invoices:', error);
            res.status(500).json({
                success: false,
                error: error.message || 'Failed to list invoices'
            });
        }
    }
    /**
     * Update invoice
     * PUT /api/sales/invoices/:id
     */
    async updateInvoice(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const userId = req.user?.id;
            const invoiceId = parseInt(req.params.id);
            const invoice = await service_1.default.updateInvoice(invoiceId, req.body, tenantId, userId);
            res.json({
                success: true,
                data: invoice
            });
        }
        catch (error) {
            console.error('Error updating invoice:', error);
            res.status(400).json({
                success: false,
                error: error.message || 'Failed to update invoice'
            });
        }
    }
    /**
     * Post invoice to GL
     * PUT /api/sales/invoices/:id/post
     */
    async postInvoice(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const userId = req.user?.id;
            const invoiceId = parseInt(req.params.id);
            const invoice = await service_1.default.postInvoice(invoiceId, tenantId, userId);
            res.json({
                success: true,
                data: invoice,
                message: 'Invoice posted to GL successfully'
            });
        }
        catch (error) {
            console.error('Error posting invoice:', error);
            res.status(400).json({
                success: false,
                error: error.message || 'Failed to post invoice'
            });
        }
    }
    /**
     * Delete invoice (soft delete)
     * DELETE /api/sales/invoices/:id
     */
    async deleteInvoice(req, res) {
        try {
            const tenantId = req.headers['x-tenant-id'] || '00000000-0000-0000-0000-000000000001';
            const userId = req.user?.id;
            const invoiceId = parseInt(req.params.id);
            await service_1.default.deleteInvoice(invoiceId, tenantId, userId);
            res.json({
                success: true,
                message: 'Invoice deleted successfully'
            });
        }
        catch (error) {
            console.error('Error deleting invoice:', error);
            res.status(400).json({
                success: false,
                error: error.message || 'Failed to delete invoice'
            });
        }
    }
}
exports.SalesController = SalesController;
exports.default = new SalesController();
//# sourceMappingURL=controller.js.map