"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.processCartrackData = processCartrackData;
const database_1 = __importDefault(require("../../config/database"));
async function processCartrackData(data) {
    // In a real scenario, you would validate the data object here
    const { vehicle_id, timestamp, latitude, longitude, speed_kmh, engine_status } = data;
    // Here you would look up your internal vehicle ID based on the telematics provider's vehicle_id
    // For now, we'll assume a direct mapping is possible or the ID is already correct.
    try {
        await database_1.default.query(`INSERT INTO logistics_gps_tracking (vehicle_id, timestamp, latitude, longitude, speed_kmh, engine_status, provider)
       VALUES ($1, $2, $3, $4, $5, $6, 'Cartrack')`, [vehicle_id, timestamp, latitude, longitude, speed_kmh, engine_status]);
        console.log(`Logged GPS data for vehicle ${vehicle_id}`);
    }
    catch (error) {
        console.error('Error inserting GPS data into database:', error);
        throw error;
    }
}
//# sourceMappingURL=gps.service.js.map