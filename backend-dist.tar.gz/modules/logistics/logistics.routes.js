"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const logisticsController = __importStar(require("./logistics.controller"));
const logisticsWorkspaceController = __importStar(require("./controllers/logistics.workspace.controller"));
const routesIncidentsGeofencesController = __importStar(require("../../controllers/routes-incidents-geofences.controller"));
const documents_1 = __importDefault(require("../../routes/logistics/documents"));
const trips_1 = __importDefault(require("../../routes/logistics/trips"));
const enterprise_1 = __importDefault(require("../../routes/logistics/enterprise"));
const tracking_1 = __importDefault(require("../../routes/logistics/tracking"));
const rbac_middleware_1 = require("../../middleware/rbac.middleware");
const router = (0, express_1.Router)();
// Enterprise extensions (SAP/Oracle/Dynamics parity)
router.use('/enterprise', enterprise_1.default);
// ============================================================================
// VEHICLE TRACKING (GPS/API Providers)
// ============================================================================
router.use('/tracking', tracking_1.default);
// ============================================================================
// DASHBOARD (must be before /:id routes)
// ============================================================================
router.get('/dashboard', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.REPORTS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getDashboardStats);
// ============================================================================
// WORKSPACE
// ============================================================================
router.get('/workspace', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.VEHICLES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsWorkspaceController.getLogisticsWorkspace);
// ============================================================================
// VEHICLES
// ============================================================================
router.get('/vehicles', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.VEHICLES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getVehicles);
router.get('/vehicles/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.VEHICLES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getVehicleById);
router.post('/vehicles', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.VEHICLES_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.createVehicle);
router.put('/vehicles/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.VEHICLES_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.updateVehicle);
router.delete('/vehicles/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.VEHICLES_DELETE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.deleteVehicle);
// ============================================================================
// DRIVERS
// ============================================================================
router.get('/drivers', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.DRIVERS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getDrivers);
router.get('/drivers/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.DRIVERS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getDriverById);
router.post('/drivers', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.DRIVERS_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.createDriver);
router.put('/drivers/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.DRIVERS_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.updateDriver);
router.delete('/drivers/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.DRIVERS_DELETE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.deleteDriver);
// ============================================================================
// DOCUMENT PROCESSING (OCR)
// ============================================================================
router.use('/documents', documents_1.default);
// ============================================================================
// TRIPS API (Database-driven)
// ============================================================================
router.use('/trips', trips_1.default);
// Legacy trip routes (kept for backward compatibility)
router.get('/trips-legacy', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.TRIPS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getTrips);
router.get('/trips-legacy/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.TRIPS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getTripById);
router.post('/trips-legacy', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.TRIPS_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.createTrip);
router.put('/trips-legacy/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.TRIPS_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.updateTrip);
router.post('/trips-legacy/:id/start', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.TRIPS_START, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.startTrip);
router.post('/trips-legacy/:id/complete', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.TRIPS_COMPLETE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.completeTrip);
// ============================================================================
// FUEL MANAGEMENT
// ============================================================================
router.get('/fuel', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.FUEL_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getFuelTransactions);
router.post('/fuel', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.FUEL_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.createFuelTransaction);
router.post('/fuel/:id/reconcile', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.FUEL_RECONCILE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.reconcileFuelTransaction);
// ============================================================================
// LOAD PLANNING
// ============================================================================
router.get('/loads', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.LOADS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getLoads);
router.get('/loads/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.LOADS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getLoadById);
router.post('/loads', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.LOADS_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.createLoad);
router.put('/loads/:id/status', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.LOADS_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.updateLoadStatus);
// ============================================================================
// MAINTENANCE
// ============================================================================
router.get('/maintenance', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.MAINTENANCE_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.getMaintenanceRecords);
router.post('/maintenance', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.MAINTENANCE_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), logisticsController.createMaintenanceRecord);
// ============================================================================
// ROUTES (Route Planning & Management)
// ============================================================================
router.get('/routes', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.ROUTES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getRoutes);
router.get('/routes/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.ROUTES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getRouteById);
router.post('/routes', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.ROUTES_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.createRoute);
router.put('/routes/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.ROUTES_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.updateRoute);
router.delete('/routes/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.ROUTES_DELETE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.deleteRoute);
// ============================================================================
// INCIDENTS (Safety & Compliance)
// ============================================================================
router.get('/incidents', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.INCIDENTS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getIncidents);
router.get('/incidents/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.INCIDENTS_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getIncidentById);
router.post('/incidents', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.INCIDENTS_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.createIncident);
router.put('/incidents/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.INCIDENTS_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.updateIncident);
router.delete('/incidents/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.INCIDENTS_DELETE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.deleteIncident);
// ============================================================================
// GEOFENCES (GPS Zone Management)
// ============================================================================
router.get('/geofences', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.GEOFENCES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getGeofences);
router.get('/geofences/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.GEOFENCES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getGeofenceById);
router.post('/geofences', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.GEOFENCES_CREATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.createGeofence);
router.put('/geofences/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.GEOFENCES_UPDATE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.updateGeofence);
router.delete('/geofences/:id', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.GEOFENCES_DELETE, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.deleteGeofence);
router.get('/geofence-events', (0, rbac_middleware_1.requirePermission)(rbac_middleware_1.Permission.GEOFENCES_VIEW, rbac_middleware_1.Permission.ADMIN_FULL_ACCESS), routesIncidentsGeofencesController.getGeofenceEvents);
// ============================================================================
// ACCOUNTING INTEGRATION (TODO: implement controller methods)
// ============================================================================
// router.get('/accounting/validate',
//   requirePermission(Permission.REPORTS_VIEW, Permission.ADMIN_FULL_ACCESS),
//   logisticsController.validateAccountingEntries
// );
// router.get('/accounting/pl-impact',
//   requirePermission(Permission.REPORTS_VIEW, Permission.ADMIN_FULL_ACCESS),
//   logisticsController.getAccountingPLImpact
// );
// router.get('/accounting/audit-trail',
//   requirePermission(Permission.REPORTS_VIEW, Permission.ADMIN_FULL_ACCESS),
//   logisticsController.getAccountingAuditTrail
// );
exports.default = router;
//# sourceMappingURL=logistics.routes.js.map