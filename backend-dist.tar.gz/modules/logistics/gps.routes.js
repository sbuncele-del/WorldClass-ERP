"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const gps_service_1 = require("./gps.service");
const router = (0, express_1.Router)();
// Webhook endpoint for Cartrack
router.post('/cartrack', async (req, res) => {
    try {
        const data = req.body;
        // It's crucial to validate the incoming data structure and authenticate the request
        // For now, we'll assume the data is valid
        await (0, gps_service_1.processCartrackData)(data);
        res.status(200).json({ status: 'success', message: 'Data received' });
    }
    catch (error) {
        console.error('Error processing Cartrack data:', error);
        res.status(500).json({ status: 'error', message: 'Internal Server Error' });
    }
});
// Placeholder for MiX Telematics
router.post('/mixtelematics', async (req, res) => {
    res.status(501).json({ status: 'info', message: 'MiX Telematics integration not yet implemented' });
});
// Placeholder for Ctrack
router.post('/ctrack', async (req, res) => {
    res.status(501).json({ status: 'info', message: 'Ctrack integration not yet implemented' });
});
exports.default = router;
//# sourceMappingURL=gps.routes.js.map