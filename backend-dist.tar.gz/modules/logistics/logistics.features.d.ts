import { TenantFeatures } from '../../types';
/**
 * Logistics feature flags mapped to cohesive identifiers used in middleware + UI.
 * Each entry aligns with SAP/Oracle/Microsoft parity requirements.
 */
export declare const LOGISTICS_FEATURE_FLAGS: {
    readonly ATMS: "logistics_atms";
    readonly YARD: "logistics_yard_management";
    readonly DOCK: "logistics_dock_scheduling";
    readonly FREIGHT_AUDIT: "logistics_freight_audit";
    readonly CARRIER_CONTRACTS: "logistics_carrier_contracts";
    readonly REVENUE_RECOGNITION: "logistics_delivery_revenue";
    readonly FREIGHT_BILLING: "logistics_freight_billing";
    readonly ROUTE_PROFITABILITY: "logistics_route_profitability";
    readonly CARRIER_SCORING: "logistics_carrier_scoring";
    readonly POWER_BI_EXPORT: "logistics_power_bi";
    readonly AI_ROUTE_OPTIMIZATION: "logistics_ai_route_optimization";
    readonly PREDICTIVE_MAINTENANCE: "logistics_predictive_maintenance";
    readonly IOT_INGESTION: "logistics_iot_ingestion";
    readonly PROCESS_GENOME: "logistics_process_genome";
};
export type LogisticsFeatureName = typeof LOGISTICS_FEATURE_FLAGS[keyof typeof LOGISTICS_FEATURE_FLAGS];
/**
 * Helper to safely read a feature flag on the tenant payload.
 * Keeps backward compatibility with tenants that do not yet have the new keys.
 */
export declare const isFeatureEnabled: (features: TenantFeatures | undefined, feature: LogisticsFeatureName) => boolean;
/**
 * Upgrade path content used by backend + frontend to show customers what toggles unlock.
 */
export declare const LOGISTICS_UPGRADE_PATHS: Record<LogisticsFeatureName, string>;
//# sourceMappingURL=logistics.features.d.ts.map