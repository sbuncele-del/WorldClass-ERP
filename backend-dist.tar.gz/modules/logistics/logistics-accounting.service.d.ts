export interface JournalLineInput {
    account_code: string;
    debit_amount?: number;
    credit_amount?: number;
    description: string;
    cost_center_id?: string;
}
export interface TripAccountingData {
    trip_id: string;
    trip_number: string;
    customer_id?: string;
    customer_name?: string;
    revenue_amount: number;
    trip_date: Date;
}
export interface FuelAccountingData {
    transaction_id: string;
    vehicle_id: string;
    vehicle_registration?: string;
    driver_id?: string;
    driver_name?: string;
    fuel_station: string;
    litres: number;
    total_amount: number;
    payment_method: 'CASH' | 'CARD' | 'FUEL_CARD' | 'ACCOUNT';
    transaction_date: Date;
}
export interface DriverPaymentData {
    payment_id: string;
    driver_id: string;
    driver_name: string;
    payment_type: 'SALARY' | 'ALLOWANCE' | 'BONUS' | 'ADVANCE';
    gross_amount: number;
    deductions: number;
    net_amount: number;
    payment_date: Date;
    payment_method: 'CASH' | 'EFT';
}
export declare class LogisticsAccountingService {
    private journalService;
    constructor();
    /**
     * Check if logistics accounting integration is enabled
     */
    isEnabled(tenantId: string): Promise<boolean>;
    /**
     * Create journal entry for trip completion (delivery revenue)
     * Debit: Accounts Receivable
     * Credit: Delivery Revenue
     */
    recordTripRevenue(tenantId: string, data: TripAccountingData, userId: string): Promise<{
        journalEntryId: string;
        balanced: boolean;
    } | null>;
    /**
     * Create journal entry for fuel purchase
     * Debit: Fuel Expense
     * Credit: Accounts Payable (ACCOUNT) / Cash (CASH/CARD)
     */
    recordFuelPurchase(tenantId: string, data: FuelAccountingData, userId: string): Promise<{
        journalEntryId: string;
        balanced: boolean;
    } | null>;
    /**
     * Create journal entry for driver payment
     * Debit: Driver Wages
     * Credit: Cash/Bank
     */
    recordDriverPayment(tenantId: string, data: DriverPaymentData, userId: string): Promise<{
        journalEntryId: string;
        balanced: boolean;
    } | null>;
    /**
     * Validate that all logistics journal entries balance (Debits = Credits)
     */
    validateAllEntriesBalance(tenantId: string): Promise<{
        total: number;
        balanced: number;
        unbalanced: {
            entry_id: string;
            entry_number: string;
            difference: number;
        }[];
    }>;
    /**
     * Get P&L impact from logistics transactions
     */
    getPLImpact(tenantId: string, dateFrom: Date, dateTo: Date): Promise<{
        revenue: {
            delivery: number;
            freight: number;
            total: number;
        };
        expenses: {
            fuel: number;
            wages: number;
            maintenance: number;
            tolls: number;
            total: number;
        };
        netIncome: number;
    }>;
    /**
     * Get audit trail for logistics journal entries
     */
    getAuditTrail(tenantId: string, options?: {
        limit?: number;
        offset?: number;
        source_type?: string;
    }): Promise<{
        entries: Array<{
            entry_id: string;
            entry_number: string;
            entry_date: Date;
            description: string;
            source_type: string;
            status: string;
            total_debit: number;
            total_credit: number;
            created_by: string;
            created_at: Date;
            posted_at: Date | null;
        }>;
        total: number;
    }>;
}
export default LogisticsAccountingService;
//# sourceMappingURL=logistics-accounting.service.d.ts.map