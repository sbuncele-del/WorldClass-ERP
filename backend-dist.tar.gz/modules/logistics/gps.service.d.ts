export declare function processCartrackData(data: any): Promise<void>;
//# sourceMappingURL=gps.service.d.ts.map