/**
 * Logistics Controller V2
 * Tenant-aware handlers for fleet, vehicles, drivers, shipments, and routes
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getVehicles: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getVehicleById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createVehicle: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDrivers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getShipments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createShipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getRoutes: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getLogisticsDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getVehicles: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getVehicleById: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createVehicle: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getDrivers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getShipments: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createShipment: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getRoutes: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getLogisticsDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=logistics.controller.v2.d.ts.map