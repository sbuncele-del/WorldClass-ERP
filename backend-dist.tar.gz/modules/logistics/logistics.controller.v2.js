"use strict";
/**
 * Logistics Controller V2
 * Tenant-aware handlers for fleet, vehicles, drivers, shipments, and routes
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLogisticsDashboard = exports.getRoutes = exports.createShipment = exports.getShipments = exports.getDrivers = exports.createVehicle = exports.getVehicleById = exports.getVehicles = void 0;
const database_1 = __importDefault(require("../../config/database"));
const logistics_accounting_service_1 = require("./logistics-accounting.service");
const accountingService = new logistics_accounting_service_1.LogisticsAccountingService();
function getTenantContext(req) {
    const tenantId = req.tenant?.id;
    if (!tenantId) {
        throw new Error('Tenant ID not found');
    }
    return {
        tenantId,
        userId: req.user?.id
    };
}
// Helper to get table name
const getTableName = (table) => `logistics.${table}`;
// ============================================================================
// FLEET & VEHICLES
// ============================================================================
const getVehicles = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { page = '1', limit = '50', status, vehicle_type, search } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        // Check if table exists
        const tableCheck = await database_1.default.query(`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'logistics' AND table_name = 'vehicles'
      ) as exists
    `);
        if (!tableCheck.rows[0].exists) {
            return res.json({
                vehicles: [],
                total: 0,
                page: 1,
                totalPages: 0,
                message: 'Logistics module not initialized. Please run database migration.'
            });
        }
        let query = `
      SELECT v.*
      FROM logistics.vehicles v
      WHERE v.tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (status) {
            query += ` AND v.status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        else {
            query += ` AND v.status = 'ACTIVE'`;
        }
        if (vehicle_type) {
            query += ` AND v.vehicle_type = $${paramCount}`;
            values.push(vehicle_type);
            paramCount++;
        }
        if (search) {
            query += ` AND (v.vehicle_registration ILIKE $${paramCount} OR v.make ILIKE $${paramCount} OR v.model ILIKE $${paramCount})`;
            values.push(`%${search}%`);
            paramCount++;
        }
        query += ` ORDER BY v.vehicle_registration ASC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        // Get total count
        const countQuery = `SELECT COUNT(*) FROM logistics.vehicles WHERE tenant_id = $1`;
        const countResult = await database_1.default.query(countQuery, [tenantId]);
        res.json({
            success: true,
            vehicles: result.rows,
            total: parseInt(countResult.rows[0].count),
            page: parseInt(page),
            totalPages: Math.ceil(parseInt(countResult.rows[0].count) / parseInt(limit))
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        console.error('Error fetching vehicles:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch vehicles', error: error.message });
    }
};
exports.getVehicles = getVehicles;
const getVehicleById = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { id } = req.params;
        const result = await database_1.default.query(`SELECT * FROM logistics.vehicles WHERE vehicle_id = $1 AND tenant_id = $2`, [id, tenantId]);
        if (result.rows.length === 0) {
            return res.status(404).json({ success: false, message: 'Vehicle not found' });
        }
        res.json({ success: true, vehicle: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch vehicle', error: error.message });
    }
};
exports.getVehicleById = getVehicleById;
const createVehicle = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const vehicleData = req.body;
        const result = await database_1.default.query(`INSERT INTO logistics.vehicles (
        tenant_id, vehicle_registration, make, model, year, vehicle_type,
        capacity_kg, capacity_m3, fuel_type, status, notes
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
      RETURNING *`, [
            tenantId,
            vehicleData.vehicle_registration || vehicleData.registration_number,
            vehicleData.make,
            vehicleData.model,
            vehicleData.year,
            vehicleData.vehicle_type,
            vehicleData.capacity_kg || vehicleData.capacity_weight,
            vehicleData.capacity_m3 || vehicleData.capacity_volume,
            vehicleData.fuel_type,
            vehicleData.status || 'ACTIVE',
            vehicleData.notes
        ]);
        res.status(201).json({ success: true, vehicle: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to create vehicle', error: error.message });
    }
};
exports.createVehicle = createVehicle;
// ============================================================================
// DRIVERS
// ============================================================================
const getDrivers = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, search, page = '1', limit = '50' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `SELECT * FROM logistics.drivers WHERE tenant_id = $1`;
        const values = [tenantId];
        let paramCount = 2;
        if (status) {
            query += ` AND status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        if (search) {
            query += ` AND (first_name ILIKE $${paramCount} OR last_name ILIKE $${paramCount} OR license_number ILIKE $${paramCount})`;
            values.push(`%${search}%`);
            paramCount++;
        }
        query += ` ORDER BY last_name, first_name LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        res.json({ success: true, drivers: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch drivers', error: error.message });
    }
};
exports.getDrivers = getDrivers;
// ============================================================================
// SHIPMENTS
// ============================================================================
const getShipments = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, customer_id, date_from, date_to, page = '1', limit = '50' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `
      SELECT s.*, c.customer_name
      FROM logistics.shipments s
      LEFT JOIN customers c ON s.customer_id = c.id
      WHERE s.tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (status) {
            query += ` AND s.status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        if (customer_id) {
            query += ` AND s.customer_id = $${paramCount}`;
            values.push(customer_id);
            paramCount++;
        }
        if (date_from) {
            query += ` AND s.scheduled_pickup_date >= $${paramCount}`;
            values.push(date_from);
            paramCount++;
        }
        if (date_to) {
            query += ` AND s.scheduled_pickup_date <= $${paramCount}`;
            values.push(date_to);
            paramCount++;
        }
        query += ` ORDER BY s.created_at DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        res.json({ success: true, shipments: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch shipments', error: error.message });
    }
};
exports.getShipments = getShipments;
const createShipment = async (req, res) => {
    try {
        const { tenantId, userId } = getTenantContext(req);
        const shipmentData = req.body;
        const result = await database_1.default.query(`INSERT INTO logistics.shipments (
        tenant_id, shipment_number, customer_id, origin_address, destination_address,
        scheduled_pickup_date, scheduled_delivery_date, weight, volume, 
        status, priority, notes, created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING *`, [
            tenantId,
            shipmentData.shipment_number || `SHP-${Date.now()}`,
            shipmentData.customer_id,
            shipmentData.origin_address,
            shipmentData.destination_address,
            shipmentData.scheduled_pickup_date,
            shipmentData.scheduled_delivery_date,
            shipmentData.weight,
            shipmentData.volume,
            shipmentData.status || 'PENDING',
            shipmentData.priority || 'NORMAL',
            shipmentData.notes,
            userId
        ]);
        res.status(201).json({ success: true, shipment: result.rows[0] });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to create shipment', error: error.message });
    }
};
exports.createShipment = createShipment;
// ============================================================================
// ROUTES
// ============================================================================
const getRoutes = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        const { status, date, page = '1', limit = '50' } = req.query;
        const offset = (parseInt(page) - 1) * parseInt(limit);
        let query = `
      SELECT r.*, v.vehicle_registration, d.first_name || ' ' || d.last_name as driver_name
      FROM logistics.routes r
      LEFT JOIN logistics.vehicles v ON r.vehicle_id = v.vehicle_id
      LEFT JOIN logistics.drivers d ON r.driver_id = d.driver_id
      WHERE r.tenant_id = $1
    `;
        const values = [tenantId];
        let paramCount = 2;
        if (status) {
            query += ` AND r.status = $${paramCount}`;
            values.push(status);
            paramCount++;
        }
        if (date) {
            query += ` AND r.route_date = $${paramCount}`;
            values.push(date);
            paramCount++;
        }
        query += ` ORDER BY r.route_date DESC, r.created_at DESC LIMIT $${paramCount} OFFSET $${paramCount + 1}`;
        values.push(parseInt(limit), offset);
        const result = await database_1.default.query(query, values);
        res.json({ success: true, routes: result.rows });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch routes', error: error.message });
    }
};
exports.getRoutes = getRoutes;
// ============================================================================
// DASHBOARD
// ============================================================================
const getLogisticsDashboard = async (req, res) => {
    try {
        const { tenantId } = getTenantContext(req);
        // Get vehicle stats
        const vehicleStats = await database_1.default.query(`SELECT 
        COUNT(*) as total_vehicles,
        COUNT(*) FILTER (WHERE status = 'ACTIVE') as active_vehicles,
        COUNT(*) FILTER (WHERE status = 'MAINTENANCE') as maintenance_vehicles
       FROM logistics.vehicles WHERE tenant_id = $1`, [tenantId]);
        // Get driver stats
        const driverStats = await database_1.default.query(`SELECT 
        COUNT(*) as total_drivers,
        COUNT(*) FILTER (WHERE status = 'AVAILABLE') as available_drivers
       FROM logistics.drivers WHERE tenant_id = $1`, [tenantId]);
        // Get shipment stats
        const shipmentStats = await database_1.default.query(`SELECT 
        COUNT(*) as total_shipments,
        COUNT(*) FILTER (WHERE status = 'PENDING') as pending_shipments,
        COUNT(*) FILTER (WHERE status = 'IN_TRANSIT') as in_transit_shipments,
        COUNT(*) FILTER (WHERE status = 'DELIVERED') as delivered_shipments
       FROM logistics.shipments WHERE tenant_id = $1`, [tenantId]);
        res.json({
            success: true,
            dashboard: {
                vehicles: vehicleStats.rows[0],
                drivers: driverStats.rows[0],
                shipments: shipmentStats.rows[0]
            }
        });
    }
    catch (error) {
        if (error.message === 'Tenant ID not found') {
            return res.status(401).json({ success: false, message: 'Unauthorized - tenant not found' });
        }
        res.status(500).json({ success: false, message: 'Failed to fetch dashboard', error: error.message });
    }
};
exports.getLogisticsDashboard = getLogisticsDashboard;
exports.default = {
    getVehicles: exports.getVehicles,
    getVehicleById: exports.getVehicleById,
    createVehicle: exports.createVehicle,
    getDrivers: exports.getDrivers,
    getShipments: exports.getShipments,
    createShipment: exports.createShipment,
    getRoutes: exports.getRoutes,
    getLogisticsDashboard: exports.getLogisticsDashboard
};
//# sourceMappingURL=logistics.controller.v2.js.map