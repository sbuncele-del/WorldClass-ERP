"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LOGISTICS_UPGRADE_PATHS = exports.isFeatureEnabled = exports.LOGISTICS_FEATURE_FLAGS = void 0;
/**
 * Logistics feature flags mapped to cohesive identifiers used in middleware + UI.
 * Each entry aligns with SAP/Oracle/Microsoft parity requirements.
 */
exports.LOGISTICS_FEATURE_FLAGS = {
    ATMS: 'logistics_atms',
    YARD: 'logistics_yard_management',
    DOCK: 'logistics_dock_scheduling',
    FREIGHT_AUDIT: 'logistics_freight_audit',
    CARRIER_CONTRACTS: 'logistics_carrier_contracts',
    REVENUE_RECOGNITION: 'logistics_delivery_revenue',
    FREIGHT_BILLING: 'logistics_freight_billing',
    ROUTE_PROFITABILITY: 'logistics_route_profitability',
    CARRIER_SCORING: 'logistics_carrier_scoring',
    POWER_BI_EXPORT: 'logistics_power_bi',
    AI_ROUTE_OPTIMIZATION: 'logistics_ai_route_optimization',
    PREDICTIVE_MAINTENANCE: 'logistics_predictive_maintenance',
    IOT_INGESTION: 'logistics_iot_ingestion',
    PROCESS_GENOME: 'logistics_process_genome',
};
/**
 * Helper to safely read a feature flag on the tenant payload.
 * Keeps backward compatibility with tenants that do not yet have the new keys.
 */
const isFeatureEnabled = (features, feature) => Boolean(features && features[feature]);
exports.isFeatureEnabled = isFeatureEnabled;
/**
 * Upgrade path content used by backend + frontend to show customers what toggles unlock.
 */
exports.LOGISTICS_UPGRADE_PATHS = {
    [exports.LOGISTICS_FEATURE_FLAGS.ATMS]: 'Unlock AI-assisted transportation plans with constraint-based optimization.',
    [exports.LOGISTICS_FEATURE_FLAGS.YARD]: 'Digitize yard zones/slots for live capacity orchestration.',
    [exports.LOGISTICS_FEATURE_FLAGS.DOCK]: 'Automate dock door scheduling with conflict detection.',
    [exports.LOGISTICS_FEATURE_FLAGS.FREIGHT_AUDIT]: 'Auto-match carrier invoices vs contracted rates before payment.',
    [exports.LOGISTICS_FEATURE_FLAGS.CARRIER_CONTRACTS]: 'Version carrier contracts + enforce SLA targets across the network.',
    [exports.LOGISTICS_FEATURE_FLAGS.REVENUE_RECOGNITION]: 'Trigger IFRS-compliant revenue recognition at delivery confirmation.',
    [exports.LOGISTICS_FEATURE_FLAGS.FREIGHT_BILLING]: 'Generate freight bills + GL postings automatically per trip.',
    [exports.LOGISTICS_FEATURE_FLAGS.ROUTE_PROFITABILITY]: 'See per-route revenue, cost, and utilization margins instantly.',
    [exports.LOGISTICS_FEATURE_FLAGS.CARRIER_SCORING]: 'Score each carrier monthly on on-time %, damage, billing accuracy.',
    [exports.LOGISTICS_FEATURE_FLAGS.POWER_BI_EXPORT]: 'Stream logistics cubes into embedded Power BI workspaces.',
    [exports.LOGISTICS_FEATURE_FLAGS.AI_ROUTE_OPTIMIZATION]: 'Use reinforcement learning to re-plan routes when exceptions occur.',
    [exports.LOGISTICS_FEATURE_FLAGS.PREDICTIVE_MAINTENANCE]: 'Predict vehicle component failures 30+ days before downtime.',
    [exports.LOGISTICS_FEATURE_FLAGS.IOT_INGESTION]: 'Ingest CAN bus, ELD, and cold-chain IoT telemetry in real time.',
    [exports.LOGISTICS_FEATURE_FLAGS.PROCESS_GENOME]: 'Layer AI-native orchestration that legacy ERPs cannot replicate.',
};
//# sourceMappingURL=logistics.features.js.map