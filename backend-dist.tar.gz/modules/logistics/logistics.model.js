"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=logistics.model.js.map