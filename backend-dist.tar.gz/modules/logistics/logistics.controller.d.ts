import { Request, Response } from 'express';
/**
 * GET /api/logistics/vehicles
 * Get all vehicles with filtering
 */
export declare const getVehicles: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/vehicles/:id
 * Get single vehicle by ID
 */
export declare const getVehicleById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/logistics/vehicles
 * Create new vehicle
 */
export declare const createVehicle: (req: Request, res: Response) => Promise<void>;
/**
 * PUT /api/logistics/vehicles/:id
 * Update vehicle
 */
export declare const updateVehicle: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * DELETE /api/logistics/vehicles/:id
 * Delete vehicle (soft delete)
 */
export declare const deleteVehicle: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/drivers
 * Get all drivers
 */
export declare const getDrivers: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/drivers/:id
 * Get single driver
 */
export declare const getDriverById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/logistics/drivers
 * Create new driver
 */
export declare const createDriver: (req: Request, res: Response) => Promise<void>;
/**
 * PUT /api/logistics/drivers/:id
 * Update driver
 */
export declare const updateDriver: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * DELETE /api/logistics/drivers/:id
 * Delete driver (soft delete)
 */
export declare const deleteDriver: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/trips
 * Get all trips with filtering
 */
export declare const getTrips: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/logistics/trips/:id
 * Get single trip with stops
 */
export declare const getTripById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/logistics/trips
 * Create new trip
 */
export declare const createTrip: (req: Request, res: Response) => Promise<void>;
/**
 * PUT /api/logistics/trips/:id
 * Update trip
 */
export declare const updateTrip: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/logistics/trips/:id/start
 * Start trip (driver action)
 */
export declare const startTrip: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/logistics/trips/:id/complete
 * Complete trip with POD
 */
export declare const completeTrip: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/fuel
 * Get fuel transactions
 */
export declare const getFuelTransactions: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/logistics/fuel
 * Create fuel transaction
 */
export declare const createFuelTransaction: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/logistics/fuel/:id/reconcile
 * Reconcile fuel transaction
 */
export declare const reconcileFuelTransaction: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/loads
 * Get all loads
 */
export declare const getLoads: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/logistics/loads/:id
 * Get single load with items
 */
export declare const getLoadById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * POST /api/logistics/loads
 * Create new load
 */
export declare const createLoad: (req: Request, res: Response) => Promise<void>;
/**
 * PUT /api/logistics/loads/:id/status
 * Update load status
 */
export declare const updateLoadStatus: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/logistics/maintenance
 * Get maintenance records
 */
export declare const getMaintenanceRecords: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/logistics/maintenance
 * Create maintenance record
 */
export declare const createMaintenanceRecord: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/logistics/dashboard
 * Get logistics dashboard stats
 */
export declare const getDashboardStats: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=logistics.controller.d.ts.map