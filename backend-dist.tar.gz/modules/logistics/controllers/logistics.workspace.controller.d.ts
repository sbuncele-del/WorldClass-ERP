import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Logistics Workspace Controller
 * Provides aggregated data for the Logistics & Transport dashboard
 */
/**
 * GET /api/logistics/workspace
 * Returns all data needed for the Logistics & Transport workspace dashboard
 */
export declare const getLogisticsWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=logistics.workspace.controller.d.ts.map