import { TenantFeatures } from '../../../types';
import { TransportationPlanPayload, YardOverviewFilters, DockAppointmentPayload, FreightAuditPayload, CarrierContractPayload, RevenueRecognitionPayload, RouteProfitabilityFilters, CarrierScorePayload, IotEventPayload, PredictiveMaintenancePayload, FeatureGateResponse } from './logistics.enterprise.types';
export declare class LogisticsEnterpriseService {
    static upsertTransportationPlan(tenantId: string, userId: string, payload: TransportationPlanPayload): Promise<{
        planId: any;
    }>;
    static getTransportationPlans(tenantId: string): Promise<any[]>;
    static getYardOverview(tenantId: string, filters?: YardOverviewFilters): Promise<{
        zones: any[];
        recentMovements: any[];
    }>;
    static scheduleDockAppointment(tenantId: string, userId: string, payload: DockAppointmentPayload): Promise<any>;
    static submitFreightAudit(tenantId: string, userId: string, payload: FreightAuditPayload): Promise<any>;
    static upsertCarrierContract(tenantId: string, userId: string, payload: CarrierContractPayload): Promise<{
        contractId: any;
    }>;
    static scoreCarrier(tenantId: string, payload: CarrierScorePayload): Promise<any>;
    static recordFinanceEvent(tenantId: string, userId: string, payload: RevenueRecognitionPayload): Promise<any>;
    static getRouteProfitability(tenantId: string, filters?: RouteProfitabilityFilters): Promise<any[]>;
    static ingestIotEvent(tenantId: string, payload: IotEventPayload): Promise<any>;
    static createPredictiveMaintenanceAlert(tenantId: string, userId: string, payload: PredictiveMaintenancePayload): Promise<any>;
    static getFeatureGateResponse(features: TenantFeatures | undefined, tenantPlan: string): FeatureGateResponse;
    static getBenchmarkSnapshot(): Promise<import("./logistics.enterprise.types").BenchmarkSnapshot>;
}
export default LogisticsEnterpriseService;
//# sourceMappingURL=logistics.enterprise.service.d.ts.map