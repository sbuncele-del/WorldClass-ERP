"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getInnovationRoadmap = exports.getBenchmarks = exports.getFeatureGates = exports.createPredictiveMaintenanceAlert = exports.ingestIotEvent = exports.getRouteProfitability = exports.recordRevenueRecognition = exports.scoreCarrierPerformance = exports.upsertCarrierContract = exports.submitFreightAudit = exports.scheduleDockAppointment = exports.getYardOverview = exports.listTransportationPlans = exports.upsertTransportationPlan = void 0;
const logistics_enterprise_service_1 = __importDefault(require("./logistics.enterprise.service"));
const logistics_features_1 = require("../logistics.features");
const assertTenantContext = (req) => {
    if (!req.tenant || !req.user) {
        throw new Error('Tenant context required. Ensure tenantMiddleware runs before enterprise routes.');
    }
};
const upsertTransportationPlan = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const plan = await logistics_enterprise_service_1.default.upsertTransportationPlan(req.tenant.id, req.user.id, payload);
        res.status(201).json(plan);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to save transportation plan', details: error.message });
    }
};
exports.upsertTransportationPlan = upsertTransportationPlan;
const listTransportationPlans = async (req, res) => {
    try {
        assertTenantContext(req);
        const plans = await logistics_enterprise_service_1.default.getTransportationPlans(req.tenant.id);
        res.json({ plans });
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to fetch transportation plans', details: error.message });
    }
};
exports.listTransportationPlans = listTransportationPlans;
const getYardOverview = async (req, res) => {
    try {
        assertTenantContext(req);
        const overview = await logistics_enterprise_service_1.default.getYardOverview(req.tenant.id, {
            zoneType: req.query.zoneType,
            includeMovements: req.query.includeMovements === 'true',
        });
        res.json(overview);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to load yard overview', details: error.message });
    }
};
exports.getYardOverview = getYardOverview;
const scheduleDockAppointment = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const appointment = await logistics_enterprise_service_1.default.scheduleDockAppointment(req.tenant.id, req.user.id, payload);
        res.status(201).json(appointment);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to schedule dock appointment', details: error.message });
    }
};
exports.scheduleDockAppointment = scheduleDockAppointment;
const submitFreightAudit = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const result = await logistics_enterprise_service_1.default.submitFreightAudit(req.tenant.id, req.user.id, payload);
        res.status(201).json(result);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to submit freight audit', details: error.message });
    }
};
exports.submitFreightAudit = submitFreightAudit;
const upsertCarrierContract = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const contract = await logistics_enterprise_service_1.default.upsertCarrierContract(req.tenant.id, req.user.id, payload);
        res.status(201).json(contract);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to upsert carrier contract', details: error.message });
    }
};
exports.upsertCarrierContract = upsertCarrierContract;
const scoreCarrierPerformance = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const score = await logistics_enterprise_service_1.default.scoreCarrier(req.tenant.id, payload);
        res.status(201).json(score);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to score carrier', details: error.message });
    }
};
exports.scoreCarrierPerformance = scoreCarrierPerformance;
const recordRevenueRecognition = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const record = await logistics_enterprise_service_1.default.recordFinanceEvent(req.tenant.id, req.user.id, payload);
        res.status(201).json(record);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to record finance event', details: error.message });
    }
};
exports.recordRevenueRecognition = recordRevenueRecognition;
const getRouteProfitability = async (req, res) => {
    try {
        assertTenantContext(req);
        const filters = {
            routeId: req.query.routeId,
            periodStart: req.query.periodStart,
            periodEnd: req.query.periodEnd,
        };
        const snapshots = await logistics_enterprise_service_1.default.getRouteProfitability(req.tenant.id, filters);
        res.json({ snapshots });
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to fetch route profitability', details: error.message });
    }
};
exports.getRouteProfitability = getRouteProfitability;
const ingestIotEvent = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const event = await logistics_enterprise_service_1.default.ingestIotEvent(req.tenant.id, payload);
        res.status(201).json(event);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to ingest IoT event', details: error.message });
    }
};
exports.ingestIotEvent = ingestIotEvent;
const createPredictiveMaintenanceAlert = async (req, res) => {
    try {
        assertTenantContext(req);
        const payload = req.body;
        const alert = await logistics_enterprise_service_1.default.createPredictiveMaintenanceAlert(req.tenant.id, req.user.id, payload);
        res.status(201).json(alert);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to create predictive maintenance alert', details: error.message });
    }
};
exports.createPredictiveMaintenanceAlert = createPredictiveMaintenanceAlert;
const getFeatureGates = async (req, res) => {
    try {
        assertTenantContext(req);
        const response = logistics_enterprise_service_1.default.getFeatureGateResponse(req.tenant.features, req.tenant.subscription_plan);
        res.json(response);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to load feature flags', details: error.message });
    }
};
exports.getFeatureGates = getFeatureGates;
const getBenchmarks = async (_req, res) => {
    try {
        const data = await logistics_enterprise_service_1.default.getBenchmarkSnapshot();
        res.json(data);
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to load benchmarks', details: error.message });
    }
};
exports.getBenchmarks = getBenchmarks;
/**
 * Simple helper endpoint for frontend to know which innovations remain locked.
 */
const getInnovationRoadmap = async (req, res) => {
    try {
        assertTenantContext(req);
        const featureResponse = logistics_enterprise_service_1.default.getFeatureGateResponse(req.tenant.features, req.tenant.subscription_plan);
        const innovation = {
            processGenomeUnlocked: featureResponse.flags[logistics_features_1.LOGISTICS_FEATURE_FLAGS.PROCESS_GENOME],
            pendingFeatures: Object.entries(featureResponse.flags)
                .filter(([, enabled]) => !enabled)
                .map(([key]) => ({
                feature: key,
                message: featureResponse.upgradePaths[key],
            })),
        };
        res.json({ ...featureResponse, innovation });
    }
    catch (error) {
        res.status(500).json({ error: 'Failed to load innovation roadmap', details: error.message });
    }
};
exports.getInnovationRoadmap = getInnovationRoadmap;
//# sourceMappingURL=logistics.enterprise.controller.js.map