import { Response } from 'express';
import { TenantRequest } from '../../../types';
export declare const upsertTransportationPlan: (req: TenantRequest, res: Response) => Promise<void>;
export declare const listTransportationPlans: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getYardOverview: (req: TenantRequest, res: Response) => Promise<void>;
export declare const scheduleDockAppointment: (req: TenantRequest, res: Response) => Promise<void>;
export declare const submitFreightAudit: (req: TenantRequest, res: Response) => Promise<void>;
export declare const upsertCarrierContract: (req: TenantRequest, res: Response) => Promise<void>;
export declare const scoreCarrierPerformance: (req: TenantRequest, res: Response) => Promise<void>;
export declare const recordRevenueRecognition: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getRouteProfitability: (req: TenantRequest, res: Response) => Promise<void>;
export declare const ingestIotEvent: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createPredictiveMaintenanceAlert: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getFeatureGates: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getBenchmarks: (_req: TenantRequest, res: Response) => Promise<void>;
/**
 * Simple helper endpoint for frontend to know which innovations remain locked.
 */
export declare const getInnovationRoadmap: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=logistics.enterprise.controller.d.ts.map