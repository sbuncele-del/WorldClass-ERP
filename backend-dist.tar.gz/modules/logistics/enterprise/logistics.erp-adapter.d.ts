import { BenchmarkSnapshot } from './logistics.enterprise.types';
export interface ErpBridgePayload {
    tenantId: string;
    sourceEntity: string;
    sourceReference?: string;
    payload: Record<string, unknown>;
}
/**
 * ERP bridge adapter - converts unified logistics payloads into SAP, Oracle, and Dynamics friendly shapes.
 * This creates a "migration ready" layer without rewriting the core logistics stack.
 */
export declare class LogisticsErpAdapter {
    /**
     * Generates SAP TM ready payload.
     * // UPGRADE_PATH: extend mappings when SAP introduces new TM APIs.
     */
    static toSap(payload: Record<string, unknown>): Record<string, unknown>;
    /**
     * Oracle Transportation Management mapping.
     */
    static toOracle(payload: Record<string, unknown>): Record<string, unknown>;
    /**
     * Microsoft Dynamics 365 Supply Chain mapping.
     */
    static toDynamics(payload: Record<string, unknown>): Record<string, unknown>;
    /**
     * Unified canonical payload is already the same object, but we keep a clone for checksum stability.
     */
    static toUnified(payload: Record<string, unknown>): Record<string, unknown>;
    static persistSnapshot(params: ErpBridgePayload): Promise<void>;
}
export declare const BENCHMARK_BASELINE: BenchmarkSnapshot;
//# sourceMappingURL=logistics.erp-adapter.d.ts.map