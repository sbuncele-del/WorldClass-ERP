/**
 * FINANCIAL CONTROLLER (Repository Pattern)
 *
 * Repository-backed, tenant-aware endpoints for core financial flows.
 * Legacy endpoints remain available via the previous controller for unported actions.
 */
import { Response } from 'express';
import { TenantRequest } from '../../../types';
export declare const createJournalEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const listJournalEntries: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getJournalEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const postJournalEntry: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const reverseJournalEntry: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getChartOfAccounts: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAccount: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTrialBalance: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAccountLedger: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCOATemplates: (_req: TenantRequest, res: Response) => Promise<void>;
export declare const applyCOATemplate: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getGeneralLedger: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAccountLedgerByCode: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getFiscalYears: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getFiscalPeriods: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCashFlowStatement: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getIncomeStatement: (_req: TenantRequest, res: Response) => Promise<void>;
export declare const getTaxSettings: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createTaxSetting: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateTaxSetting: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDimensions: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createDimension: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateDimension: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getDashboard: (req: TenantRequest, res: Response) => Promise<void>;
//# sourceMappingURL=financial.controller.v2.d.ts.map