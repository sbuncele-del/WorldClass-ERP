import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Financial Workspace Controller
 * Provides aggregated data for the Financial Management dashboard
 */
/**
 * GET /api/financial/workspace
 * Returns all data needed for the Financial Management workspace dashboard
 */
export declare const getFinancialWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=financial.workspace.controller.d.ts.map