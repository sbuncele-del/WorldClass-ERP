/**
 * Period Management Controller
 * REST API endpoints for fiscal years and accounting periods
 */
import { Request, Response } from 'express';
export declare const getAllFiscalYears: (_req: Request, res: Response) => Promise<void>;
export declare const getFiscalYear: (req: Request, res: Response) => Promise<void>;
export declare const getCurrentFiscalYear: (_req: Request, res: Response) => Promise<void>;
export declare const createFiscalYear: (req: Request, res: Response) => Promise<void>;
export declare const setCurrentFiscalYear: (req: Request, res: Response) => Promise<void>;
export declare const closeFiscalYear: (req: Request, res: Response) => Promise<void>;
export declare const getFiscalYearWithPeriods: (req: Request, res: Response) => Promise<void>;
export declare const getAllPeriods: (req: Request, res: Response) => Promise<void>;
export declare const getPeriod: (req: Request, res: Response) => Promise<void>;
export declare const getCurrentPeriod: (_req: Request, res: Response) => Promise<void>;
export declare const getOpenPeriods: (req: Request, res: Response) => Promise<void>;
export declare const createPeriod: (req: Request, res: Response) => Promise<void>;
export declare const openPeriod: (req: Request, res: Response) => Promise<void>;
export declare const closePeriod: (req: Request, res: Response) => Promise<void>;
export declare const lockPeriod: (req: Request, res: Response) => Promise<void>;
export declare const setCurrentPeriod: (req: Request, res: Response) => Promise<void>;
export declare const validatePeriodClose: (req: Request, res: Response) => Promise<void>;
export declare const getPeriodSummary: (_req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=period.controller.d.ts.map