/**
 * Dimensions Controller V2
 * Tenant-aware REST API endpoints for financial dimensions management
 *
 * NOTE: This v2 controller enforces tenant context at the controller level.
 * The underlying DimensionsService will need to be updated to accept tenantId
 * for full multi-tenant isolation.
 *
 * Manages: Cost Centers, Departments, Projects, Products, Locations
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
export declare const getAllCostCenters: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCostCenter: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createCostCenter: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateCostCenter: (req: TenantRequest, res: Response) => Promise<void>;
export declare const deleteCostCenter: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAllDepartments: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getDepartment: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createDepartment: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateDepartment: (req: TenantRequest, res: Response) => Promise<void>;
export declare const deleteDepartment: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAllProjects: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getProject: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createProject: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateProject: (req: TenantRequest, res: Response) => Promise<void>;
export declare const deleteProject: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAllProducts: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getProduct: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createProduct: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateProduct: (req: TenantRequest, res: Response) => Promise<void>;
export declare const deleteProduct: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAllLocations: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getLocation: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createLocation: (req: TenantRequest, res: Response) => Promise<void>;
export declare const updateLocation: (req: TenantRequest, res: Response) => Promise<void>;
export declare const deleteLocation: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getDimensionSummary: (req: TenantRequest, res: Response) => Promise<void>;
export {};
//# sourceMappingURL=dimensions.controller.v2.d.ts.map