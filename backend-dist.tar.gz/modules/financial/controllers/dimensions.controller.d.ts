/**
 * Dimensions Controller
 * REST API endpoints for financial dimensions management
 */
import { Request, Response } from 'express';
export declare const getAllCostCenters: (req: Request, res: Response) => Promise<void>;
export declare const getCostCenter: (req: Request, res: Response) => Promise<void>;
export declare const createCostCenter: (req: Request, res: Response) => Promise<void>;
export declare const updateCostCenter: (req: Request, res: Response) => Promise<void>;
export declare const deleteCostCenter: (req: Request, res: Response) => Promise<void>;
export declare const getAllDepartments: (req: Request, res: Response) => Promise<void>;
export declare const getDepartment: (req: Request, res: Response) => Promise<void>;
export declare const createDepartment: (req: Request, res: Response) => Promise<void>;
export declare const updateDepartment: (req: Request, res: Response) => Promise<void>;
export declare const deleteDepartment: (req: Request, res: Response) => Promise<void>;
export declare const getAllProjects: (req: Request, res: Response) => Promise<void>;
export declare const getProject: (req: Request, res: Response) => Promise<void>;
export declare const createProject: (req: Request, res: Response) => Promise<void>;
export declare const updateProject: (req: Request, res: Response) => Promise<void>;
export declare const deleteProject: (req: Request, res: Response) => Promise<void>;
export declare const getAllProducts: (req: Request, res: Response) => Promise<void>;
export declare const getProduct: (req: Request, res: Response) => Promise<void>;
export declare const createProduct: (req: Request, res: Response) => Promise<void>;
export declare const updateProduct: (req: Request, res: Response) => Promise<void>;
export declare const deleteProduct: (req: Request, res: Response) => Promise<void>;
export declare const getAllLocations: (req: Request, res: Response) => Promise<void>;
export declare const getLocation: (req: Request, res: Response) => Promise<void>;
export declare const createLocation: (req: Request, res: Response) => Promise<void>;
export declare const updateLocation: (req: Request, res: Response) => Promise<void>;
export declare const deleteLocation: (req: Request, res: Response) => Promise<void>;
export declare const getDimensionSummary: (_req: Request, res: Response) => Promise<void>;
//# sourceMappingURL=dimensions.controller.d.ts.map