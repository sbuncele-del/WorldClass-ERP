import { Request, Response } from 'express';
/**
 * Financial Controller
 * REST API endpoints for financial management
 */
/**
 * POST /api/financial/journal-entries
 * Create a new journal entry
 */
export declare const createJournalEntry: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/journal-entries
 * List all journal entries with filters
 */
export declare const listJournalEntries: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/journal-entries/:id
 * Get single journal entry with lines
 */
export declare const getJournalEntry: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/financial/journal-entries/:id/post
 * Post a journal entry to the ledger
 */
export declare const postJournalEntry: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/financial/journal-entries/:id/reverse
 * Reverse a posted journal entry
 */
export declare const reverseJournalEntry: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/chart-of-accounts
 * Get all accounts (hierarchical)
 */
export declare const getChartOfAccounts: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/chart-of-accounts/:code
 * Get single account details
 */
export declare const getAccount: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/reports/trial-balance
 * Get trial balance for a period
 */
export declare const getTrialBalance: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/reports/account-ledger/:code
 * Get general ledger for a specific account
 */
export declare const getAccountLedger: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/dashboard
 * Get financial dashboard statistics
 */
export declare const getDashboard: (_req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/coa-templates
 * Get all available Chart of Accounts templates
 */
export declare const getCOATemplates: (_req: Request, res: Response) => Promise<void>;
/**
 * POST /api/financial/coa-templates/:templateId/apply
 * Apply a Chart of Accounts template
 * ⚠️ WARNING: This will DELETE all existing accounts and replace with template
 */
export declare const applyCOATemplate: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/ledger/general
 * Get general ledger with all posted transactions
 */
export declare const getGeneralLedger: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/ledger/accounts/:accountCode
 * Get account ledger for specific account
 */
export declare const getAccountLedgerByCode: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/fiscal-years
 * Get list of fiscal years
 */
export declare const getFiscalYears: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/fiscal-periods
 * Get list of fiscal periods (months)
 */
export declare const getFiscalPeriods: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/cash-flow
 * Get cash flow statement
 */
export declare const getCashFlowStatement: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/income-statement
 * Get income statement (returns placeholder data - table setup needed)
 */
export declare const getIncomeStatement: (req: Request, res: Response) => Promise<void>;
/**
 * GET /api/financial/tax-settings
 * Get all tax settings/codes
 */
export declare const getTaxSettings: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/financial/tax-settings
 * Create a new tax setting
 */
export declare const createTaxSetting: (req: Request, res: Response) => Promise<void>;
/**
 * PUT /api/financial/tax-settings/:id
 * Update a tax setting
 */
export declare const updateTaxSetting: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
/**
 * GET /api/financial/dimensions
 * Get all financial dimensions
 */
export declare const getDimensions: (req: Request, res: Response) => Promise<void>;
/**
 * POST /api/financial/dimensions
 * Create a new dimension
 */
export declare const createDimension: (req: Request, res: Response) => Promise<void>;
/**
 * PUT /api/financial/dimensions/:id
 * Update a dimension
 */
export declare const updateDimension: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=financial.controller.d.ts.map