"use strict";
/**
 * Period Management Controller
 * REST API endpoints for fiscal years and accounting periods
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPeriodSummary = exports.validatePeriodClose = exports.setCurrentPeriod = exports.lockPeriod = exports.closePeriod = exports.openPeriod = exports.createPeriod = exports.getOpenPeriods = exports.getCurrentPeriod = exports.getPeriod = exports.getAllPeriods = exports.getFiscalYearWithPeriods = exports.closeFiscalYear = exports.setCurrentFiscalYear = exports.createFiscalYear = exports.getCurrentFiscalYear = exports.getFiscalYear = exports.getAllFiscalYears = void 0;
const period_service_1 = require("../services/period.service");
const periodService = new period_service_1.PeriodService();
// ===== FISCAL YEARS =====
const getAllFiscalYears = async (_req, res) => {
    try {
        const fiscalYears = await periodService.getAllFiscalYears();
        res.json({
            success: true,
            data: fiscalYears,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getAllFiscalYears = getAllFiscalYears;
const getFiscalYear = async (req, res) => {
    try {
        const { id } = req.params;
        const fiscalYear = await periodService.getFiscalYearById(id);
        if (!fiscalYear) {
            res.status(404).json({
                success: false,
                error: 'Fiscal year not found',
            });
            return;
        }
        res.json({
            success: true,
            data: fiscalYear,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getFiscalYear = getFiscalYear;
const getCurrentFiscalYear = async (_req, res) => {
    try {
        const fiscalYear = await periodService.getCurrentFiscalYear();
        if (!fiscalYear) {
            res.status(404).json({
                success: false,
                error: 'No current fiscal year set',
            });
            return;
        }
        res.json({
            success: true,
            data: fiscalYear,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getCurrentFiscalYear = getCurrentFiscalYear;
const createFiscalYear = async (req, res) => {
    try {
        const userId = req.body.user_id || 'system';
        const data = {
            ...req.body,
            user_id: userId,
        };
        const id = await periodService.createFiscalYear(data);
        res.status(201).json({
            success: true,
            data: { id },
            message: 'Fiscal year created successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.createFiscalYear = createFiscalYear;
const setCurrentFiscalYear = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.body.user_id || 'system';
        await periodService.setCurrentFiscalYear(id, userId);
        res.json({
            success: true,
            message: 'Current fiscal year updated successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.setCurrentFiscalYear = setCurrentFiscalYear;
const closeFiscalYear = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.body.user_id || 'system';
        await periodService.closeFiscalYear(id, userId);
        res.json({
            success: true,
            message: 'Fiscal year closed successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.closeFiscalYear = closeFiscalYear;
const getFiscalYearWithPeriods = async (req, res) => {
    try {
        const { id } = req.params;
        const fiscalYearWithPeriods = await periodService.getFiscalYearWithPeriods(id);
        if (!fiscalYearWithPeriods) {
            res.status(404).json({
                success: false,
                error: 'Fiscal year not found',
            });
            return;
        }
        res.json({
            success: true,
            data: fiscalYearWithPeriods,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getFiscalYearWithPeriods = getFiscalYearWithPeriods;
// ===== ACCOUNTING PERIODS =====
const getAllPeriods = async (req, res) => {
    try {
        const { fiscal_year_id } = req.query;
        const periods = await periodService.getAllPeriods(fiscal_year_id);
        res.json({
            success: true,
            data: periods,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getAllPeriods = getAllPeriods;
const getPeriod = async (req, res) => {
    try {
        const { id } = req.params;
        const period = await periodService.getPeriodById(id);
        if (!period) {
            res.status(404).json({
                success: false,
                error: 'Period not found',
            });
            return;
        }
        res.json({
            success: true,
            data: period,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getPeriod = getPeriod;
const getCurrentPeriod = async (_req, res) => {
    try {
        const period = await periodService.getCurrentPeriod();
        if (!period) {
            res.status(404).json({
                success: false,
                error: 'No current period set',
            });
            return;
        }
        res.json({
            success: true,
            data: period,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getCurrentPeriod = getCurrentPeriod;
const getOpenPeriods = async (req, res) => {
    try {
        const { fiscal_year_id } = req.query;
        const periods = await periodService.getOpenPeriods(fiscal_year_id);
        res.json({
            success: true,
            data: periods,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getOpenPeriods = getOpenPeriods;
const createPeriod = async (req, res) => {
    try {
        const userId = req.body.user_id || 'system';
        const data = {
            ...req.body,
            user_id: userId,
        };
        const id = await periodService.createPeriod(data);
        res.status(201).json({
            success: true,
            data: { id },
            message: 'Period created successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.createPeriod = createPeriod;
const openPeriod = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.body.user_id || 'system';
        await periodService.openPeriod(id, userId);
        res.json({
            success: true,
            message: 'Period opened successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.openPeriod = openPeriod;
const closePeriod = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.body.user_id || 'system';
        const force = req.body.force || false;
        await periodService.closePeriod(id, userId, force);
        res.json({
            success: true,
            message: 'Period closed successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.closePeriod = closePeriod;
const lockPeriod = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.body.user_id || 'system';
        await periodService.lockPeriod(id, userId);
        res.json({
            success: true,
            message: 'Period locked successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.lockPeriod = lockPeriod;
const setCurrentPeriod = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.body.user_id || 'system';
        await periodService.setCurrentPeriod(id, userId);
        res.json({
            success: true,
            message: 'Current period updated successfully',
        });
    }
    catch (error) {
        res.status(400).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.setCurrentPeriod = setCurrentPeriod;
const validatePeriodClose = async (req, res) => {
    try {
        const { id } = req.params;
        const validation = await periodService.validatePeriodClose(id);
        res.json({
            success: true,
            data: validation,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.validatePeriodClose = validatePeriodClose;
// ===== SUMMARY & UTILITIES =====
const getPeriodSummary = async (_req, res) => {
    try {
        const summary = await periodService.getPeriodSummary();
        res.json({
            success: true,
            data: summary,
        });
    }
    catch (error) {
        res.status(500).json({
            success: false,
            error: error instanceof Error ? error.message : 'An error occurred',
        });
    }
};
exports.getPeriodSummary = getPeriodSummary;
//# sourceMappingURL=period.controller.js.map