/**
 * Period Controller V2
 * Tenant-aware REST API endpoints for fiscal years and accounting periods
 *
 * NOTE: This v2 controller enforces tenant context at the controller level.
 * The underlying PeriodService will need to be updated to accept tenantId
 * for full multi-tenant isolation.
 */
import { Request, Response } from 'express';
interface TenantRequest extends Request {
    tenant?: {
        id: string;
    };
    user?: {
        id: string;
        email: string;
        role: string;
        permissions: string[];
        first_name?: string;
        last_name?: string;
    };
}
export declare const getAllFiscalYears: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getFiscalYear: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCurrentFiscalYear: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createFiscalYear: (req: TenantRequest, res: Response) => Promise<void>;
export declare const setCurrentFiscalYear: (req: TenantRequest, res: Response) => Promise<void>;
export declare const closeFiscalYear: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getFiscalYearWithPeriods: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getAllPeriods: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getPeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getCurrentPeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getOpenPeriods: (req: TenantRequest, res: Response) => Promise<void>;
export declare const createPeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const openPeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const closePeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const lockPeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const setCurrentPeriod: (req: TenantRequest, res: Response) => Promise<void>;
export declare const validatePeriodClose: (req: TenantRequest, res: Response) => Promise<void>;
export declare const getPeriodSummary: (req: TenantRequest, res: Response) => Promise<void>;
export {};
//# sourceMappingURL=period.controller.v2.d.ts.map