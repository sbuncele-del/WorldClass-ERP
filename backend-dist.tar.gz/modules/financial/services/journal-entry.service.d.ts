import { CreateJournalEntryRequest } from '../models/journal-entry.model';
/**
 * Journal Entry Service
 * Handles creation, validation, posting, and reversal of journal entries
 * NOW WITH REAL DATABASE OPERATIONS!
 */
export declare class JournalEntryService {
    /**
     * Create a new journal entry (DRAFT status)
     */
    createJournalEntry(request: CreateJournalEntryRequest, userId: string): Promise<string>;
    /**
     * Post a journal entry to the ledger
     * This updates all account balances
     */
    postJournalEntry(journalEntryId: string, userId: string): Promise<void>;
    /**
     * Reverse a posted journal entry
     */
    reverseJournalEntry(originalJournalId: string, reversalDate: Date, reason: string, userId: string): Promise<string>;
    /**
     * Get trial balance for a period
     */
    getTrialBalance(_fiscalYear: number, _fiscalPeriod: number): Promise<any[]>;
    private generateJournalNumber;
    private getFiscalPeriod;
    private getAccountByCode;
    private insertJournalEntry;
    private getJournalEntryById;
    private getJournalEntryLines;
    private updateAccountBalance;
    private updateJournalStatus;
    private scheduleReversal;
    private linkReversalEntries;
}
//# sourceMappingURL=journal-entry.service.d.ts.map