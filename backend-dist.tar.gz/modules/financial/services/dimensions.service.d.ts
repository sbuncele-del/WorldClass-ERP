/**
 * Dimensions Service
 * Business logic for managing financial dimensions
 */
import { CostCenter, Department, Project, Product, Location, CreateCostCenterDTO, CreateDepartmentDTO, CreateProjectDTO, CreateProductDTO, CreateLocationDTO, DimensionSummary } from '../models/dimensions.model';
export declare class DimensionsService {
    getAllCostCenters(includeInactive?: boolean): Promise<CostCenter[]>;
    getCostCenterByCode(code: string): Promise<CostCenter | null>;
    createCostCenter(data: CreateCostCenterDTO, userId: string): Promise<string>;
    updateCostCenter(code: string, data: Partial<CreateCostCenterDTO>, userId: string): Promise<void>;
    deleteCostCenter(code: string): Promise<void>;
    getAllDepartments(includeInactive?: boolean): Promise<Department[]>;
    getDepartmentByCode(code: string): Promise<Department | null>;
    createDepartment(data: CreateDepartmentDTO, userId: string): Promise<string>;
    updateDepartment(code: string, data: Partial<CreateDepartmentDTO>, userId: string): Promise<void>;
    deleteDepartment(code: string): Promise<void>;
    getAllProjects(includeInactive?: boolean): Promise<Project[]>;
    getProjectByCode(code: string): Promise<Project | null>;
    createProject(data: CreateProjectDTO, userId: string): Promise<string>;
    updateProject(code: string, data: Partial<CreateProjectDTO>, userId: string): Promise<void>;
    deleteProject(code: string): Promise<void>;
    getAllProducts(includeInactive?: boolean): Promise<Product[]>;
    getProductByCode(code: string): Promise<Product | null>;
    createProduct(data: CreateProductDTO, userId: string): Promise<string>;
    updateProduct(code: string, data: Partial<CreateProductDTO>, userId: string): Promise<void>;
    deleteProduct(code: string): Promise<void>;
    getAllLocations(includeInactive?: boolean): Promise<Location[]>;
    getLocationByCode(code: string): Promise<Location | null>;
    createLocation(data: CreateLocationDTO, userId: string): Promise<string>;
    updateLocation(code: string, data: Partial<CreateLocationDTO>, userId: string): Promise<void>;
    deleteLocation(code: string): Promise<void>;
    getDimensionSummary(): Promise<DimensionSummary>;
}
//# sourceMappingURL=dimensions.service.d.ts.map