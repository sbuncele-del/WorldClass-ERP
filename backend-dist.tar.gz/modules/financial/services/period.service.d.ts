/**
 * Period Management Service
 * Business logic for fiscal years and accounting periods
 */
import { FiscalYear, AccountingPeriod, CreateFiscalYearDTO, CreatePeriodDTO, FiscalYearWithPeriods, PeriodSummary, PeriodValidation } from '../models/period.model';
export declare class PeriodService {
    getAllFiscalYears(): Promise<FiscalYear[]>;
    getFiscalYearById(id: string): Promise<FiscalYear | null>;
    getFiscalYearByCode(code: string): Promise<FiscalYear | null>;
    getCurrentFiscalYear(): Promise<FiscalYear | null>;
    createFiscalYear(data: CreateFiscalYearDTO): Promise<string>;
    setCurrentFiscalYear(year_id: string, user_id: string): Promise<void>;
    closeFiscalYear(year_id: string, user_id: string): Promise<void>;
    getAllPeriods(fiscal_year_id?: string): Promise<AccountingPeriod[]>;
    getPeriodById(id: string): Promise<AccountingPeriod | null>;
    getPeriodByCode(code: string): Promise<AccountingPeriod | null>;
    getCurrentPeriod(): Promise<AccountingPeriod | null>;
    getOpenPeriods(fiscal_year_id?: string): Promise<AccountingPeriod[]>;
    createPeriod(data: CreatePeriodDTO): Promise<string>;
    openPeriod(period_id: string, user_id: string): Promise<void>;
    closePeriod(period_id: string, user_id: string, force?: boolean): Promise<void>;
    lockPeriod(period_id: string, user_id: string): Promise<void>;
    setCurrentPeriod(period_id: string, user_id: string): Promise<void>;
    validatePeriodClose(period_id: string): Promise<PeriodValidation>;
    private autoOpenNextPeriod;
    getFiscalYearWithPeriods(year_id: string): Promise<FiscalYearWithPeriods | null>;
    getPeriodSummary(): Promise<PeriodSummary>;
}
//# sourceMappingURL=period.service.d.ts.map