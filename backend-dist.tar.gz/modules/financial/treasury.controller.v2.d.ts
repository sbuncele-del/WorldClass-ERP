/**
 * Treasury Controller V2
 * Tenant-aware handlers for treasury management, cash positions, and forecasting
 *
 * IMPORTANT: Uses TenantRequest for typed tenant context from middleware.
 */
import { Response } from 'express';
import { TenantRequest } from '../../types';
export declare const getCashPositions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getCashForecasts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createCashForecast: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getIntercompanyTransfers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const createIntercompanyTransfer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
export declare const getTreasuryDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
declare const _default: {
    getCashPositions: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getCashForecasts: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createCashForecast: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getIntercompanyTransfers: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    createIntercompanyTransfer: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
    getTreasuryDashboard: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
};
export default _default;
//# sourceMappingURL=treasury.controller.v2.d.ts.map