/**
 * Chart of Accounts Templates
 * Pre-configured COA templates for different South African business types
 */
export interface TemplateAccount {
    code: string;
    name: string;
    account_type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
    level: number;
    parent_code?: string;
    is_header?: boolean;
    normal_balance: 'DEBIT' | 'CREDIT';
    is_active?: boolean;
}
export declare const TEMPLATE_SMALL_BUSINESS: TemplateAccount[];
export declare const TEMPLATE_RETAIL: TemplateAccount[];
export declare const TEMPLATE_PROFESSIONAL_SERVICES: TemplateAccount[];
export declare const TEMPLATE_MANUFACTURING: TemplateAccount[];
export interface COATemplate {
    id: string;
    name: string;
    description: string;
    industry: string;
    accounts: TemplateAccount[];
    account_count: number;
    suitable_for: string[];
    compliance: string[];
}
export declare const COA_TEMPLATES: COATemplate[];
//# sourceMappingURL=coa-templates.d.ts.map