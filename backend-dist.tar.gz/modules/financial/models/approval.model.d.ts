/**
 * Approval Workflows TypeScript Models
 * Type definitions for approval workflow system
 */
export declare enum ApprovalStatus {
    PENDING = "PENDING",
    IN_PROGRESS = "IN_PROGRESS",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    CANCELLED = "CANCELLED",
    ESCALATED = "ESCALATED"
}
export declare enum ApprovalAction {
    SUBMITTED = "SUBMITTED",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    CANCELLED = "CANCELLED",
    ESCALATED = "ESCALATED",
    REASSIGNED = "REASSIGNED",
    COMMENTED = "COMMENTED"
}
export declare enum ApprovalDecision {
    APPROVED = "APPROVED",
    REJECTED = "REJECTED"
}
export declare enum EntityType {
    JOURNAL_ENTRY = "JOURNAL_ENTRY",
    PURCHASE_ORDER = "PURCHASE_ORDER",
    INVOICE = "INVOICE",
    PAYMENT = "PAYMENT"
}
export declare enum ApproverRole {
    MANAGER = "MANAGER",
    FINANCIAL_CONTROLLER = "FINANCIAL_CONTROLLER",
    CFO = "CFO",
    CEO = "CEO",
    ADMIN = "ADMIN"
}
export declare enum NotificationType {
    NEW_REQUEST = "NEW_REQUEST",
    APPROVED = "APPROVED",
    REJECTED = "REJECTED",
    ESCALATED = "ESCALATED",
    REMINDER = "REMINDER",
    COMPLETED = "COMPLETED",
    REASSIGNED = "REASSIGNED"
}
export interface ApprovalLevel {
    level: number;
    approver_role: string;
    approver_title: string;
    approver_user_id?: number;
    required: boolean;
    parallel?: boolean;
}
export interface ApprovalWorkflowRule {
    rule_id?: number;
    rule_name: string;
    entity_type: string;
    description?: string;
    min_amount?: number;
    max_amount?: number;
    account_types?: string[];
    source_types?: string[];
    dimension_codes?: string[];
    approval_levels: ApprovalLevel[];
    require_all_levels: boolean;
    allow_skip_levels: boolean;
    auto_approve_threshold?: number;
    escalation_days?: number;
    is_active: boolean;
    priority: number;
    created_at?: Date;
    updated_at?: Date;
    created_by?: number;
    updated_by?: number;
}
export interface ApprovalRequest {
    request_id?: number;
    entity_type: string;
    entity_id: number;
    entity_reference?: string;
    rule_id?: number;
    requested_by: number;
    requested_at?: Date;
    amount?: number;
    description?: string;
    status: ApprovalStatus;
    current_level: number;
    total_levels: number;
    completed_at?: Date;
    completed_by?: number;
    metadata?: Record<string, any>;
}
export interface ApprovalHistory {
    history_id?: number;
    request_id: number;
    action: ApprovalAction;
    level_number?: number;
    approver_id?: number;
    approver_name?: string;
    approver_role?: string;
    decision?: ApprovalDecision;
    comments?: string;
    action_at?: Date;
    time_taken_hours?: number;
    ip_address?: string;
    user_agent?: string;
    attachments?: Array<{
        filename: string;
        url: string;
        size: number;
    }>;
}
export interface ApprovalDelegate {
    delegate_id?: number;
    principal_user_id: number;
    delegate_user_id: number;
    entity_types?: string[];
    max_amount?: number;
    start_date: Date;
    end_date: Date;
    is_active: boolean;
    reason?: string;
    created_at?: Date;
    created_by?: number;
}
export interface ApprovalNotification {
    notification_id?: number;
    request_id: number;
    user_id: number;
    notification_type: NotificationType;
    title: string;
    message: string;
    action_url?: string;
    is_read: boolean;
    read_at?: Date;
    sent_at?: Date;
    email_sent: boolean;
    email_sent_at?: Date;
    metadata?: Record<string, any>;
}
export interface SubmitForApprovalDTO {
    entity_type: string;
    entity_id: number;
    entity_reference?: string;
    amount?: number;
    description?: string;
    requested_by: number;
    metadata?: Record<string, any>;
}
export interface ApproveRejectDTO {
    request_id: number;
    approver_id: number;
    approver_name: string;
    approver_role: string;
    decision: ApprovalDecision;
    comments?: string;
    ip_address?: string;
    user_agent?: string;
}
export interface CreateWorkflowRuleDTO {
    rule_name: string;
    entity_type: string;
    description?: string;
    min_amount?: number;
    max_amount?: number;
    account_types?: string[];
    source_types?: string[];
    approval_levels: ApprovalLevel[];
    require_all_levels?: boolean;
    auto_approve_threshold?: number;
    escalation_days?: number;
    priority?: number;
    created_by: number;
}
export interface UpdateWorkflowRuleDTO {
    rule_name?: string;
    description?: string;
    min_amount?: number;
    max_amount?: number;
    approval_levels?: ApprovalLevel[];
    require_all_levels?: boolean;
    auto_approve_threshold?: number;
    escalation_days?: number;
    is_active?: boolean;
    priority?: number;
    updated_by: number;
}
export interface PendingApproval {
    request_id: number;
    entity_type: string;
    entity_id: number;
    entity_reference: string;
    description: string;
    amount: number;
    requested_by: number;
    requester_name: string;
    requested_at: Date;
    current_level: number;
    total_levels: number;
    awaiting_role: string;
    awaiting_title: string;
    days_pending: number;
    is_escalated: boolean;
}
export interface ApprovalSummary {
    total_pending: number;
    pending_my_approval: number;
    pending_my_level: number;
    approved_today: number;
    rejected_today: number;
    escalated_count: number;
    avg_approval_time_hours: number;
}
export interface WorkflowMatchResult {
    matched: boolean;
    rule?: ApprovalWorkflowRule;
    auto_approved?: boolean;
    reason?: string;
}
export interface ApprovalRequestResponse {
    request: ApprovalRequest;
    history: ApprovalHistory[];
    current_approvers: Array<{
        role: string;
        title: string;
        user_id?: number;
        user_name?: string;
    }>;
    can_approve: boolean;
    can_reject: boolean;
}
export interface ApprovalHistoryDetail extends ApprovalHistory {
    entity_reference?: string;
    entity_description?: string;
    entity_amount?: number;
    final_status?: ApprovalStatus;
}
//# sourceMappingURL=approval.model.d.ts.map