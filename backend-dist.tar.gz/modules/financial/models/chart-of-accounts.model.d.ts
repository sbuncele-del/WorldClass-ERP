/**
 * Chart of Accounts Model
 * The foundation of the financial system - defines all accounts
 */
export declare enum AccountType {
    ASSET = "ASSET",
    LIABILITY = "LIABILITY",
    EQUITY = "EQUITY",
    REVENUE = "REVENUE",
    EXPENSE = "EXPENSE",
    CONTRA_ASSET = "CONTRA_ASSET",
    CONTRA_LIABILITY = "CONTRA_LIABILITY"
}
export declare enum AccountCategory {
    CURRENT_ASSET = "CURRENT_ASSET",
    FIXED_ASSET = "FIXED_ASSET",
    INTANGIBLE_ASSET = "INTANGIBLE_ASSET",
    OTHER_ASSET = "OTHER_ASSET",
    CURRENT_LIABILITY = "CURRENT_LIABILITY",
    LONG_TERM_LIABILITY = "LONG_TERM_LIABILITY",
    SHARE_CAPITAL = "SHARE_CAPITAL",
    RETAINED_EARNINGS = "RETAINED_EARNINGS",
    RESERVES = "RESERVES",
    OPERATING_REVENUE = "OPERATING_REVENUE",
    OTHER_INCOME = "OTHER_INCOME",
    COST_OF_SALES = "COST_OF_SALES",
    OPERATING_EXPENSE = "OPERATING_EXPENSE",
    FINANCIAL_EXPENSE = "FINANCIAL_EXPENSE",
    TAX_EXPENSE = "TAX_EXPENSE"
}
export declare enum NormalBalance {
    DEBIT = "DEBIT",// Assets, Expenses
    CREDIT = "CREDIT"
}
export interface ChartOfAccounts {
    id: string;
    account_code: string;
    account_name: string;
    account_type: AccountType;
    account_category: AccountCategory;
    normal_balance: NormalBalance;
    parent_account_id?: string;
    level: number;
    is_header: boolean;
    is_active: boolean;
    is_system_account: boolean;
    allow_manual_entry: boolean;
    require_cost_center: boolean;
    currency_code: string;
    allow_foreign_currency: boolean;
    default_tax_code?: string;
    is_tax_relevant: boolean;
    requires_reconciliation: boolean;
    opening_balance: number;
    current_balance: number;
    description?: string;
    company_id: string;
    created_at: Date;
    updated_at: Date;
    created_by: string;
}
export declare const CHART_OF_ACCOUNTS_TABLE_SQL = "\nCREATE TABLE IF NOT EXISTS chart_of_accounts (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  account_code VARCHAR(20) NOT NULL,\n  account_name VARCHAR(200) NOT NULL,\n  account_type VARCHAR(50) NOT NULL,\n  account_category VARCHAR(50) NOT NULL,\n  normal_balance VARCHAR(10) NOT NULL,\n  \n  parent_account_id UUID REFERENCES chart_of_accounts(id),\n  level INTEGER NOT NULL DEFAULT 1,\n  is_header BOOLEAN NOT NULL DEFAULT false,\n  \n  is_active BOOLEAN NOT NULL DEFAULT true,\n  is_system_account BOOLEAN NOT NULL DEFAULT false,\n  allow_manual_entry BOOLEAN NOT NULL DEFAULT true,\n  require_cost_center BOOLEAN NOT NULL DEFAULT false,\n  \n  currency_code VARCHAR(3) NOT NULL DEFAULT 'ZAR',\n  allow_foreign_currency BOOLEAN NOT NULL DEFAULT false,\n  \n  default_tax_code VARCHAR(20),\n  is_tax_relevant BOOLEAN NOT NULL DEFAULT false,\n  \n  requires_reconciliation BOOLEAN NOT NULL DEFAULT false,\n  \n  opening_balance DECIMAL(18, 2) NOT NULL DEFAULT 0.00,\n  current_balance DECIMAL(18, 2) NOT NULL DEFAULT 0.00,\n  \n  description TEXT,\n  company_id UUID NOT NULL,\n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  created_by UUID NOT NULL,\n  \n  CONSTRAINT unique_account_code_per_company UNIQUE (company_id, account_code),\n  CONSTRAINT fk_company FOREIGN KEY (company_id) REFERENCES companies(id)\n);\n\nCREATE INDEX idx_coa_account_code ON chart_of_accounts(account_code);\nCREATE INDEX idx_coa_account_type ON chart_of_accounts(account_type);\nCREATE INDEX idx_coa_company ON chart_of_accounts(company_id);\nCREATE INDEX idx_coa_parent ON chart_of_accounts(parent_account_id);\nCREATE INDEX idx_coa_active ON chart_of_accounts(is_active) WHERE is_active = true;\n";
export declare const STANDARD_COA_ZA: ({
    code: string;
    name: string;
    type: string;
    category: string;
    is_header: boolean;
    parent?: undefined;
    requires_reconciliation?: undefined;
    allow_manual_entry?: undefined;
    is_tax_relevant?: undefined;
    is_system_account?: undefined;
} | {
    code: string;
    name: string;
    type: string;
    category: string;
    parent: string;
    is_header: boolean;
    requires_reconciliation?: undefined;
    allow_manual_entry?: undefined;
    is_tax_relevant?: undefined;
    is_system_account?: undefined;
} | {
    code: string;
    name: string;
    type: string;
    category: string;
    parent: string;
    is_header?: undefined;
    requires_reconciliation?: undefined;
    allow_manual_entry?: undefined;
    is_tax_relevant?: undefined;
    is_system_account?: undefined;
} | {
    code: string;
    name: string;
    type: string;
    category: string;
    parent: string;
    requires_reconciliation: boolean;
    is_header?: undefined;
    allow_manual_entry?: undefined;
    is_tax_relevant?: undefined;
    is_system_account?: undefined;
} | {
    code: string;
    name: string;
    type: string;
    category: string;
    parent: string;
    allow_manual_entry: boolean;
    is_header?: undefined;
    requires_reconciliation?: undefined;
    is_tax_relevant?: undefined;
    is_system_account?: undefined;
} | {
    code: string;
    name: string;
    type: string;
    category: string;
    parent: string;
    is_tax_relevant: boolean;
    is_header?: undefined;
    requires_reconciliation?: undefined;
    allow_manual_entry?: undefined;
    is_system_account?: undefined;
} | {
    code: string;
    name: string;
    type: string;
    category: string;
    parent: string;
    is_system_account: boolean;
    is_header?: undefined;
    requires_reconciliation?: undefined;
    allow_manual_entry?: undefined;
    is_tax_relevant?: undefined;
})[];
//# sourceMappingURL=chart-of-accounts.model.d.ts.map