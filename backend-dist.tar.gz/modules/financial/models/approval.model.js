"use strict";
/**
 * Approval Workflows TypeScript Models
 * Type definitions for approval workflow system
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationType = exports.ApproverRole = exports.EntityType = exports.ApprovalDecision = exports.ApprovalAction = exports.ApprovalStatus = void 0;
// ==================== ENUMS ====================
var ApprovalStatus;
(function (ApprovalStatus) {
    ApprovalStatus["PENDING"] = "PENDING";
    ApprovalStatus["IN_PROGRESS"] = "IN_PROGRESS";
    ApprovalStatus["APPROVED"] = "APPROVED";
    ApprovalStatus["REJECTED"] = "REJECTED";
    ApprovalStatus["CANCELLED"] = "CANCELLED";
    ApprovalStatus["ESCALATED"] = "ESCALATED";
})(ApprovalStatus || (exports.ApprovalStatus = ApprovalStatus = {}));
var ApprovalAction;
(function (ApprovalAction) {
    ApprovalAction["SUBMITTED"] = "SUBMITTED";
    ApprovalAction["APPROVED"] = "APPROVED";
    ApprovalAction["REJECTED"] = "REJECTED";
    ApprovalAction["CANCELLED"] = "CANCELLED";
    ApprovalAction["ESCALATED"] = "ESCALATED";
    ApprovalAction["REASSIGNED"] = "REASSIGNED";
    ApprovalAction["COMMENTED"] = "COMMENTED";
})(ApprovalAction || (exports.ApprovalAction = ApprovalAction = {}));
var ApprovalDecision;
(function (ApprovalDecision) {
    ApprovalDecision["APPROVED"] = "APPROVED";
    ApprovalDecision["REJECTED"] = "REJECTED";
})(ApprovalDecision || (exports.ApprovalDecision = ApprovalDecision = {}));
var EntityType;
(function (EntityType) {
    EntityType["JOURNAL_ENTRY"] = "JOURNAL_ENTRY";
    EntityType["PURCHASE_ORDER"] = "PURCHASE_ORDER";
    EntityType["INVOICE"] = "INVOICE";
    EntityType["PAYMENT"] = "PAYMENT";
})(EntityType || (exports.EntityType = EntityType = {}));
var ApproverRole;
(function (ApproverRole) {
    ApproverRole["MANAGER"] = "MANAGER";
    ApproverRole["FINANCIAL_CONTROLLER"] = "FINANCIAL_CONTROLLER";
    ApproverRole["CFO"] = "CFO";
    ApproverRole["CEO"] = "CEO";
    ApproverRole["ADMIN"] = "ADMIN";
})(ApproverRole || (exports.ApproverRole = ApproverRole = {}));
var NotificationType;
(function (NotificationType) {
    NotificationType["NEW_REQUEST"] = "NEW_REQUEST";
    NotificationType["APPROVED"] = "APPROVED";
    NotificationType["REJECTED"] = "REJECTED";
    NotificationType["ESCALATED"] = "ESCALATED";
    NotificationType["REMINDER"] = "REMINDER";
    NotificationType["COMPLETED"] = "COMPLETED";
    NotificationType["REASSIGNED"] = "REASSIGNED";
})(NotificationType || (exports.NotificationType = NotificationType = {}));
//# sourceMappingURL=approval.model.js.map