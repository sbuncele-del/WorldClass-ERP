"use strict";
/**
 * Financial Dimensions Models
 * Type definitions for multi-dimensional reporting
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=dimensions.model.js.map