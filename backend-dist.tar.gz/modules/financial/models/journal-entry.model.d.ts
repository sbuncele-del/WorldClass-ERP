/**
 * Universal Journal Entry Model
 * Single source of truth for ALL financial transactions
 * Inspired by SAP's Universal Journal (ACDOCA)
 */
export declare enum JournalSource {
    MANUAL = "MANUAL",// Manual journal entry
    BANK_TRANSACTION = "BANK_TRANSACTION",
    SALES_INVOICE = "SALES_INVOICE",
    PURCHASE_INVOICE = "PURCHASE_INVOICE",
    PAYMENT = "PAYMENT",
    RECEIPT = "RECEIPT",
    PAYROLL = "PAYROLL",
    INVENTORY = "INVENTORY",
    DEPRECIATION = "DEPRECIATION",
    ADJUSTMENT = "ADJUSTMENT",
    OPENING_BALANCE = "OPENING_BALANCE",
    CLOSING = "CLOSING",
    LOGISTICS_TRIP = "LOGISTICS_TRIP",
    LOGISTICS_FUEL = "LOGISTICS_FUEL",
    LOGISTICS_DRIVER_PAY = "LOGISTICS_DRIVER_PAY"
}
export declare enum JournalStatus {
    DRAFT = "DRAFT",
    PENDING_APPROVAL = "PENDING_APPROVAL",
    APPROVED = "APPROVED",
    POSTED = "POSTED",
    REVERSED = "REVERSED",
    REJECTED = "REJECTED"
}
export interface JournalEntryHeader {
    id: string;
    journal_number: string;
    journal_date: Date;
    posting_date: Date;
    source_type: JournalSource;
    source_document_id?: string;
    source_document_number?: string;
    status: JournalStatus;
    posted_at?: Date;
    posted_by?: string;
    description: string;
    notes?: string;
    fiscal_year: number;
    fiscal_period: number;
    is_adjusting_entry: boolean;
    total_debit: number;
    total_credit: number;
    currency_code: string;
    exchange_rate: number;
    is_reversing: boolean;
    reverse_on_date?: Date;
    reversed_by_journal_id?: string;
    reverses_journal_id?: string;
    requires_approval: boolean;
    approved_by?: string;
    approved_at?: Date;
    company_id: string;
    created_at: Date;
    updated_at: Date;
    created_by: string;
    updated_by?: string;
}
export interface JournalEntryLine {
    id: string;
    journal_entry_id: string;
    line_number: number;
    account_id: string;
    account_code: string;
    account_name: string;
    debit_amount: number;
    credit_amount: number;
    currency_code: string;
    exchange_rate: number;
    debit_amount_base: number;
    credit_amount_base: number;
    cost_center_id?: string;
    department_id?: string;
    project_id?: string;
    product_id?: string;
    location_id?: string;
    tax_code?: string;
    tax_amount?: number;
    is_tax_line: boolean;
    is_reconciled: boolean;
    reconciled_at?: Date;
    reconciliation_id?: string;
    line_description?: string;
    reference?: string;
    created_at: Date;
    updated_at: Date;
}
export declare const JOURNAL_ENTRY_TABLES_SQL = "\n-- Journal Entry Header\nCREATE TABLE IF NOT EXISTS journal_entries (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  journal_number VARCHAR(50) NOT NULL UNIQUE,\n  journal_date DATE NOT NULL,\n  posting_date DATE NOT NULL,\n  \n  source_type VARCHAR(50) NOT NULL,\n  source_document_id UUID,\n  source_document_number VARCHAR(100),\n  \n  status VARCHAR(30) NOT NULL DEFAULT 'DRAFT',\n  posted_at TIMESTAMP WITH TIME ZONE,\n  posted_by UUID,\n  \n  description TEXT NOT NULL,\n  notes TEXT,\n  \n  fiscal_year INTEGER NOT NULL,\n  fiscal_period INTEGER NOT NULL,\n  is_adjusting_entry BOOLEAN NOT NULL DEFAULT false,\n  \n  total_debit DECIMAL(18, 2) NOT NULL,\n  total_credit DECIMAL(18, 2) NOT NULL,\n  \n  currency_code VARCHAR(3) NOT NULL DEFAULT 'ZAR',\n  exchange_rate DECIMAL(12, 6) NOT NULL DEFAULT 1.000000,\n  \n  is_reversing BOOLEAN NOT NULL DEFAULT false,\n  reverse_on_date DATE,\n  reversed_by_journal_id UUID,\n  reverses_journal_id UUID,\n  \n  requires_approval BOOLEAN NOT NULL DEFAULT false,\n  approved_by UUID,\n  approved_at TIMESTAMP WITH TIME ZONE,\n  \n  company_id UUID NOT NULL,\n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  created_by UUID NOT NULL,\n  updated_by UUID,\n  \n  CONSTRAINT check_balanced CHECK (total_debit = total_credit),\n  CONSTRAINT fk_company FOREIGN KEY (company_id) REFERENCES companies(id),\n  CONSTRAINT fk_reversed_by FOREIGN KEY (reversed_by_journal_id) REFERENCES journal_entries(id),\n  CONSTRAINT fk_reverses FOREIGN KEY (reverses_journal_id) REFERENCES journal_entries(id)\n);\n\n-- Journal Entry Lines\nCREATE TABLE IF NOT EXISTS journal_entry_lines (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  journal_entry_id UUID NOT NULL,\n  line_number INTEGER NOT NULL,\n  \n  account_id UUID NOT NULL,\n  account_code VARCHAR(20) NOT NULL,\n  account_name VARCHAR(200) NOT NULL,\n  \n  debit_amount DECIMAL(18, 2) NOT NULL DEFAULT 0.00,\n  credit_amount DECIMAL(18, 2) NOT NULL DEFAULT 0.00,\n  \n  currency_code VARCHAR(3) NOT NULL DEFAULT 'ZAR',\n  exchange_rate DECIMAL(12, 6) NOT NULL DEFAULT 1.000000,\n  debit_amount_base DECIMAL(18, 2) NOT NULL DEFAULT 0.00,\n  credit_amount_base DECIMAL(18, 2) NOT NULL DEFAULT 0.00,\n  \n  cost_center_id UUID,\n  department_id UUID,\n  project_id UUID,\n  product_id UUID,\n  location_id UUID,\n  \n  tax_code VARCHAR(20),\n  tax_amount DECIMAL(18, 2),\n  is_tax_line BOOLEAN NOT NULL DEFAULT false,\n  \n  is_reconciled BOOLEAN NOT NULL DEFAULT false,\n  reconciled_at TIMESTAMP WITH TIME ZONE,\n  reconciliation_id UUID,\n  \n  line_description TEXT,\n  reference VARCHAR(100),\n  \n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  \n  CONSTRAINT fk_journal_entry FOREIGN KEY (journal_entry_id) REFERENCES journal_entries(id) ON DELETE CASCADE,\n  CONSTRAINT fk_account FOREIGN KEY (account_id) REFERENCES chart_of_accounts(id),\n  CONSTRAINT check_debit_or_credit CHECK (\n    (debit_amount > 0 AND credit_amount = 0) OR \n    (credit_amount > 0 AND debit_amount = 0) OR\n    (debit_amount = 0 AND credit_amount = 0)\n  )\n);\n\n-- Indexes for performance\nCREATE INDEX idx_je_journal_number ON journal_entries(journal_number);\nCREATE INDEX idx_je_journal_date ON journal_entries(journal_date);\nCREATE INDEX idx_je_posting_date ON journal_entries(posting_date);\nCREATE INDEX idx_je_status ON journal_entries(status);\nCREATE INDEX idx_je_fiscal_period ON journal_entries(fiscal_year, fiscal_period);\nCREATE INDEX idx_je_company ON journal_entries(company_id);\nCREATE INDEX idx_je_source ON journal_entries(source_type, source_document_id);\n\nCREATE INDEX idx_jel_journal_entry ON journal_entry_lines(journal_entry_id);\nCREATE INDEX idx_jel_account ON journal_entry_lines(account_id);\nCREATE INDEX idx_jel_cost_center ON journal_entry_lines(cost_center_id);\nCREATE INDEX idx_jel_reconciled ON journal_entry_lines(is_reconciled);\n";
export interface CreateJournalEntryRequest {
    journal_date: string;
    description: string;
    source_type: JournalSource;
    lines: Array<{
        account_code: string;
        debit_amount?: number;
        credit_amount?: number;
        description?: string;
        cost_center_id?: string;
        tax_code?: string;
    }>;
    notes?: string;
    requires_approval?: boolean;
}
export declare class JournalEntryValidator {
    static validateBalance(lines: JournalEntryLine[]): boolean;
    static validateAtLeastTwoLines(lines: JournalEntryLine[]): boolean;
    static validateNoHeaderAccounts(_lines: JournalEntryLine[], _accounts: any[]): boolean;
}
//# sourceMappingURL=journal-entry.model.d.ts.map