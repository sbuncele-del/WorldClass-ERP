"use strict";
/**
 * Period Management Models
 * TypeScript interfaces for fiscal years and accounting periods
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=period.model.js.map