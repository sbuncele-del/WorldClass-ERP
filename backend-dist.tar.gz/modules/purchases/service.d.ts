/**
 * Purchase Invoice Service
 * Handles CRUD operations for purchase invoices
 */
export interface PurchaseInvoiceLine {
    line_number: number;
    description: string;
    quantity: number;
    unit_price: number;
    line_total: number;
    vat_rate?: number;
    vat_amount?: number;
    expense_account_id: number;
}
export interface CreatePurchaseInvoiceDto {
    supplier_id: number;
    supplier_invoice_number?: string;
    invoice_date: string;
    due_date: string;
    reference?: string;
    notes?: string;
    lines: PurchaseInvoiceLine[];
    tenant_id?: string;
}
export interface UpdatePurchaseInvoiceDto {
    invoice_date?: string;
    due_date?: string;
    supplier_invoice_number?: string;
    reference?: string;
    notes?: string;
    lines?: PurchaseInvoiceLine[];
}
export interface PurchaseInvoiceFilters {
    status?: string;
    supplier_id?: number;
    from_date?: string;
    to_date?: string;
    search?: string;
}
export declare class PurchasesService {
    /**
     * Create a new purchase invoice (DRAFT status)
     */
    createInvoice(dto: CreatePurchaseInvoiceDto, userId?: number): Promise<any>;
    /**
     * Get invoice by ID
     */
    getInvoiceById(invoiceId: number, tenantId: string): Promise<any>;
    /**
     * List invoices with filters
     */
    listInvoices(filters: PurchaseInvoiceFilters, tenantId: string, page?: number, limit?: number): Promise<any>;
    /**
     * Update invoice (only DRAFT status can be updated)
     */
    updateInvoice(invoiceId: number, dto: UpdatePurchaseInvoiceDto, tenantId: string, userId?: number): Promise<any>;
    /**
     * Post invoice to GL (change status from DRAFT to POSTED)
     */
    postInvoice(invoiceId: number, tenantId: string, userId?: number): Promise<any>;
    /**
     * Delete invoice (only DRAFT status can be deleted - soft delete)
     */
    deleteInvoice(invoiceId: number, tenantId: string, userId?: number): Promise<void>;
}
declare const _default: PurchasesService;
export default _default;
//# sourceMappingURL=service.d.ts.map