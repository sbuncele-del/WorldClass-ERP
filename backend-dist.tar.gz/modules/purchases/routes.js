"use strict";
/**
 * Purchase Invoice Routes
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const controller_1 = __importDefault(require("./controller"));
const router = express_1.default.Router();
// Create invoice
router.post('/invoices', controller_1.default.createInvoice.bind(controller_1.default));
// List invoices
router.get('/invoices', controller_1.default.listInvoices.bind(controller_1.default));
// Get invoice by ID
router.get('/invoices/:id', controller_1.default.getInvoice.bind(controller_1.default));
// Update invoice (DRAFT only)
router.put('/invoices/:id', controller_1.default.updateInvoice.bind(controller_1.default));
// Post invoice to GL
router.put('/invoices/:id/post', controller_1.default.postInvoice.bind(controller_1.default));
// Delete invoice (DRAFT only, soft delete)
router.delete('/invoices/:id', controller_1.default.deleteInvoice.bind(controller_1.default));
exports.default = router;
//# sourceMappingURL=routes.js.map