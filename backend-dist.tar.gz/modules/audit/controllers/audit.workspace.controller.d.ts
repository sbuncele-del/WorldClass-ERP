import { Response } from 'express';
import { TenantRequest } from '../../../types';
/**
 * Audit-Ready Workspace Controller
 * Provides aggregated data for the Audit-Ready Module dashboard
 */
/**
 * GET /api/audit/workspace
 * Returns all data needed for the Audit-Ready workspace dashboard
 */
export declare const getAuditWorkspace: (req: TenantRequest, res: Response) => Promise<Response<any, Record<string, any>>>;
//# sourceMappingURL=audit.workspace.controller.d.ts.map