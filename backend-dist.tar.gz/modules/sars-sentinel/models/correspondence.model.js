"use strict";
/**
 * SARS Correspondence Model
 * Tracks all SARS letters, notices, and communications
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CORRESPONDENCE_TABLE_SQL = exports.UrgencyLevel = exports.CorrespondenceStatus = exports.CorrespondenceSource = exports.DocumentType = void 0;
var DocumentType;
(function (DocumentType) {
    DocumentType["VAT_VERIFICATION"] = "VAT_VERIFICATION";
    DocumentType["VAT_AUDIT"] = "VAT_AUDIT";
    DocumentType["PAYE_AUDIT"] = "PAYE_AUDIT";
    DocumentType["PAYE_VERIFICATION"] = "PAYE_VERIFICATION";
    DocumentType["INCOME_TAX_ASSESSMENT"] = "INCOME_TAX_ASSESSMENT";
    DocumentType["ITA34_RETURN"] = "ITA34_RETURN";
    DocumentType["ITA88_OBJECTION"] = "ITA88_OBJECTION";
    DocumentType["CUSTOMS_NOTICE"] = "CUSTOMS_NOTICE";
    DocumentType["UIF_VERIFICATION"] = "UIF_VERIFICATION";
    DocumentType["SDL_VERIFICATION"] = "SDL_VERIFICATION";
    DocumentType["GENERAL_CORRESPONDENCE"] = "GENERAL_CORRESPONDENCE";
})(DocumentType || (exports.DocumentType = DocumentType = {}));
var CorrespondenceSource;
(function (CorrespondenceSource) {
    CorrespondenceSource["EFILING"] = "EFILING";
    CorrespondenceSource["EMAIL"] = "EMAIL";
    CorrespondenceSource["MANUAL_UPLOAD"] = "MANUAL_UPLOAD";
    CorrespondenceSource["POSTAL_MAIL"] = "POSTAL_MAIL";
})(CorrespondenceSource || (exports.CorrespondenceSource = CorrespondenceSource = {}));
var CorrespondenceStatus;
(function (CorrespondenceStatus) {
    CorrespondenceStatus["NEW"] = "NEW";
    CorrespondenceStatus["IN_PROGRESS"] = "IN_PROGRESS";
    CorrespondenceStatus["PENDING_REVIEW"] = "PENDING_REVIEW";
    CorrespondenceStatus["PENDING_SUBMISSION"] = "PENDING_SUBMISSION";
    CorrespondenceStatus["SUBMITTED"] = "SUBMITTED";
    CorrespondenceStatus["CLOSED"] = "CLOSED";
    CorrespondenceStatus["ESCALATED"] = "ESCALATED";
})(CorrespondenceStatus || (exports.CorrespondenceStatus = CorrespondenceStatus = {}));
var UrgencyLevel;
(function (UrgencyLevel) {
    UrgencyLevel["LOW"] = "LOW";
    UrgencyLevel["MEDIUM"] = "MEDIUM";
    UrgencyLevel["HIGH"] = "HIGH";
    UrgencyLevel["CRITICAL"] = "CRITICAL";
})(UrgencyLevel || (exports.UrgencyLevel = UrgencyLevel = {}));
// SQL Schema
exports.CORRESPONDENCE_TABLE_SQL = `
CREATE TABLE IF NOT EXISTS sars_correspondence (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference_number VARCHAR(100) NOT NULL,
  document_type VARCHAR(50) NOT NULL,
  source VARCHAR(50) NOT NULL,
  received_date TIMESTAMP WITH TIME ZONE NOT NULL,
  deadline_date TIMESTAMP WITH TIME ZONE,
  status VARCHAR(50) NOT NULL DEFAULT 'NEW',
  urgency_level VARCHAR(20) NOT NULL DEFAULT 'MEDIUM',
  confidence_score DECIMAL(3, 2) DEFAULT 0.00,
  
  subject TEXT NOT NULL,
  original_document_url TEXT NOT NULL,
  parsed_content JSONB,
  ai_summary TEXT,
  
  assigned_to_user_id UUID,
  assigned_to_department VARCHAR(100),
  client_id UUID NOT NULL,
  company_id UUID NOT NULL,
  
  tags TEXT[],
  notes TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_by UUID NOT NULL,
  updated_by UUID,
  
  CONSTRAINT fk_client FOREIGN KEY (client_id) REFERENCES clients(id),
  CONSTRAINT fk_assigned_user FOREIGN KEY (assigned_to_user_id) REFERENCES users(id)
);

CREATE INDEX idx_correspondence_deadline ON sars_correspondence(deadline_date) WHERE deadline_date IS NOT NULL;
CREATE INDEX idx_correspondence_status ON sars_correspondence(status);
CREATE INDEX idx_correspondence_client ON sars_correspondence(client_id);
CREATE INDEX idx_correspondence_urgency ON sars_correspondence(urgency_level);
CREATE INDEX idx_correspondence_document_type ON sars_correspondence(document_type);
`;
//# sourceMappingURL=correspondence.model.js.map