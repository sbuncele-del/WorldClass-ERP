/**
 * SARS Correspondence Model
 * Tracks all SARS letters, notices, and communications
 */
export declare enum DocumentType {
    VAT_VERIFICATION = "VAT_VERIFICATION",
    VAT_AUDIT = "VAT_AUDIT",
    PAYE_AUDIT = "PAYE_AUDIT",
    PAYE_VERIFICATION = "PAYE_VERIFICATION",
    INCOME_TAX_ASSESSMENT = "INCOME_TAX_ASSESSMENT",
    ITA34_RETURN = "ITA34_RETURN",
    ITA88_OBJECTION = "ITA88_OBJECTION",
    CUSTOMS_NOTICE = "CUSTOMS_NOTICE",
    UIF_VERIFICATION = "UIF_VERIFICATION",
    SDL_VERIFICATION = "SDL_VERIFICATION",
    GENERAL_CORRESPONDENCE = "GENERAL_CORRESPONDENCE"
}
export declare enum CorrespondenceSource {
    EFILING = "EFILING",
    EMAIL = "EMAIL",
    MANUAL_UPLOAD = "MANUAL_UPLOAD",
    POSTAL_MAIL = "POSTAL_MAIL"
}
export declare enum CorrespondenceStatus {
    NEW = "NEW",
    IN_PROGRESS = "IN_PROGRESS",
    PENDING_REVIEW = "PENDING_REVIEW",
    PENDING_SUBMISSION = "PENDING_SUBMISSION",
    SUBMITTED = "SUBMITTED",
    CLOSED = "CLOSED",
    ESCALATED = "ESCALATED"
}
export declare enum UrgencyLevel {
    LOW = "LOW",
    MEDIUM = "MEDIUM",
    HIGH = "HIGH",
    CRITICAL = "CRITICAL"
}
export interface ParsedContent {
    reference_number?: string;
    tax_period?: string;
    tax_type?: string;
    amount_due?: number;
    query_description?: string;
    required_documents?: string[];
    action_items?: string[];
}
export interface SARSCorrespondence {
    id: string;
    reference_number: string;
    document_type: DocumentType;
    source: CorrespondenceSource;
    received_date: Date;
    deadline_date?: Date;
    status: CorrespondenceStatus;
    urgency_level: UrgencyLevel;
    confidence_score: number;
    subject: string;
    original_document_url: string;
    parsed_content: ParsedContent;
    ai_summary?: string;
    assigned_to_user_id?: string;
    assigned_to_department?: string;
    client_id: string;
    company_id: string;
    tags: string[];
    notes?: string;
    created_at: Date;
    updated_at: Date;
    created_by: string;
    updated_by?: string;
}
export declare const CORRESPONDENCE_TABLE_SQL = "\nCREATE TABLE IF NOT EXISTS sars_correspondence (\n  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),\n  reference_number VARCHAR(100) NOT NULL,\n  document_type VARCHAR(50) NOT NULL,\n  source VARCHAR(50) NOT NULL,\n  received_date TIMESTAMP WITH TIME ZONE NOT NULL,\n  deadline_date TIMESTAMP WITH TIME ZONE,\n  status VARCHAR(50) NOT NULL DEFAULT 'NEW',\n  urgency_level VARCHAR(20) NOT NULL DEFAULT 'MEDIUM',\n  confidence_score DECIMAL(3, 2) DEFAULT 0.00,\n  \n  subject TEXT NOT NULL,\n  original_document_url TEXT NOT NULL,\n  parsed_content JSONB,\n  ai_summary TEXT,\n  \n  assigned_to_user_id UUID,\n  assigned_to_department VARCHAR(100),\n  client_id UUID NOT NULL,\n  company_id UUID NOT NULL,\n  \n  tags TEXT[],\n  notes TEXT,\n  \n  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),\n  created_by UUID NOT NULL,\n  updated_by UUID,\n  \n  CONSTRAINT fk_client FOREIGN KEY (client_id) REFERENCES clients(id),\n  CONSTRAINT fk_assigned_user FOREIGN KEY (assigned_to_user_id) REFERENCES users(id)\n);\n\nCREATE INDEX idx_correspondence_deadline ON sars_correspondence(deadline_date) WHERE deadline_date IS NOT NULL;\nCREATE INDEX idx_correspondence_status ON sars_correspondence(status);\nCREATE INDEX idx_correspondence_client ON sars_correspondence(client_id);\nCREATE INDEX idx_correspondence_urgency ON sars_correspondence(urgency_level);\nCREATE INDEX idx_correspondence_document_type ON sars_correspondence(document_type);\n";
//# sourceMappingURL=correspondence.model.d.ts.map