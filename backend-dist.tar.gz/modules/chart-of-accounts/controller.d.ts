import { Request, Response } from 'express';
export declare class ChartOfAccountsController {
    private service;
    constructor();
    getAllAccounts: (req: Request, res: Response) => Promise<void>;
    getAccountById: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    createAccount: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    updateAccount: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    deleteAccount: (req: Request, res: Response) => Promise<Response<any, Record<string, any>>>;
    getChildAccounts: (req: Request, res: Response) => Promise<void>;
    getAccountTree: (req: Request, res: Response) => Promise<void>;
    getAccountTypes: (req: Request, res: Response) => Promise<void>;
    seedDefaultAccounts: (req: Request, res: Response) => Promise<void>;
}
//# sourceMappingURL=controller.d.ts.map