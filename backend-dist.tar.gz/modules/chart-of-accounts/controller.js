"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChartOfAccountsController = void 0;
const service_1 = require("./service");
class ChartOfAccountsController {
    constructor() {
        this.getAllAccounts = async (req, res) => {
            try {
                const { accountType, isActive, search } = req.query;
                const filters = {};
                if (accountType)
                    filters.accountType = accountType;
                if (isActive !== undefined)
                    filters.isActive = isActive === 'true';
                if (search)
                    filters.search = search;
                const accounts = await this.service.getAllAccounts(filters);
                res.json({
                    success: true,
                    data: accounts,
                    count: accounts.length,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.getAccountById = async (req, res) => {
            try {
                const accountId = parseInt(req.params.id);
                const account = await this.service.getAccountById(accountId);
                if (!account) {
                    return res.status(404).json({
                        success: false,
                        error: 'Account not found',
                    });
                }
                res.json({
                    success: true,
                    data: account,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.createAccount = async (req, res) => {
            try {
                const { account_code, account_name, account_type, parent_account_id, description, is_active } = req.body;
                if (!account_code || !account_name || !account_type) {
                    return res.status(400).json({
                        success: false,
                        error: 'account_code, account_name, and account_type are required',
                    });
                }
                const account = await this.service.createAccount({
                    account_code,
                    account_name,
                    account_type,
                    parent_account_id,
                    description,
                    is_active,
                });
                res.status(201).json({
                    success: true,
                    data: account,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.updateAccount = async (req, res) => {
            try {
                const accountId = parseInt(req.params.id);
                const { account_name, description, is_active } = req.body;
                const account = await this.service.updateAccount(accountId, {
                    account_name,
                    description,
                    is_active,
                });
                if (!account) {
                    return res.status(404).json({
                        success: false,
                        error: 'Account not found',
                    });
                }
                res.json({
                    success: true,
                    data: account,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.deleteAccount = async (req, res) => {
            try {
                const accountId = parseInt(req.params.id);
                const deleted = await this.service.deleteAccount(accountId);
                if (!deleted) {
                    return res.status(404).json({
                        success: false,
                        error: 'Account not found or is a system account',
                    });
                }
                res.json({
                    success: true,
                    message: 'Account deleted successfully',
                });
            }
            catch (error) {
                res.status(400).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.getChildAccounts = async (req, res) => {
            try {
                const parentId = parseInt(req.params.id);
                const children = await this.service.getChildAccounts(parentId);
                res.json({
                    success: true,
                    data: children,
                    count: children.length,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.getAccountTree = async (req, res) => {
            try {
                const tree = await this.service.getAccountTree();
                res.json({
                    success: true,
                    data: tree,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.getAccountTypes = async (req, res) => {
            try {
                const types = ['ASSET', 'LIABILITY', 'EQUITY', 'REVENUE', 'EXPENSE'];
                res.json({
                    success: true,
                    data: types,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.seedDefaultAccounts = async (req, res) => {
            try {
                const result = await this.service.seedDefaultAccounts();
                res.json({
                    success: true,
                    message: `Created ${result.created} default accounts`,
                    data: result.accounts,
                });
            }
            catch (error) {
                res.status(500).json({
                    success: false,
                    error: error.message,
                });
            }
        };
        this.service = new service_1.ChartOfAccountsService();
    }
}
exports.ChartOfAccountsController = ChartOfAccountsController;
//# sourceMappingURL=controller.js.map