"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const controller_1 = require("./controller");
const router = (0, express_1.Router)();
const controller = new controller_1.ChartOfAccountsController();
// Chart of Accounts routes
router.get('/accounts', controller.getAllAccounts);
router.get('/accounts/:id', controller.getAccountById);
router.post('/accounts', controller.createAccount);
router.put('/accounts/:id', controller.updateAccount);
router.delete('/accounts/:id', controller.deleteAccount);
// Account hierarchy
router.get('/accounts/:id/children', controller.getChildAccounts);
router.get('/tree', controller.getAccountTree);
// Utilities
router.get('/types', controller.getAccountTypes);
router.post('/seed-default', controller.seedDefaultAccounts);
exports.default = router;
//# sourceMappingURL=routes.js.map