export interface ChartAccount {
    account_id: number;
    account_code: string;
    account_name: string;
    account_type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
    parent_account_id?: number;
    description?: string;
    is_active: boolean;
    is_system_account: boolean;
    created_at: Date;
    updated_at: Date;
}
export declare class ChartOfAccountsService {
    private pool;
    constructor();
    getAllAccounts(filters?: {
        accountType?: string;
        isActive?: boolean;
        search?: string;
    }): Promise<ChartAccount[]>;
    getAccountById(accountId: number): Promise<ChartAccount | null>;
    createAccount(data: {
        account_code: string;
        account_name: string;
        account_type: string;
        parent_account_id?: number;
        description?: string;
        is_active?: boolean;
    }): Promise<ChartAccount>;
    updateAccount(accountId: number, data: {
        account_name?: string;
        description?: string;
        is_active?: boolean;
    }): Promise<ChartAccount | null>;
    deleteAccount(accountId: number): Promise<boolean>;
    getChildAccounts(parentId: number): Promise<ChartAccount[]>;
    getAccountTree(): Promise<any[]>;
    seedDefaultAccounts(): Promise<{
        created: number;
        accounts: ChartAccount[];
    }>;
}
//# sourceMappingURL=service.d.ts.map