import{c as o}from"./createLucideIcon-ua9rjxd_.js";const c=o("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);export{c as C};
