import{c as e}from"./createLucideIcon-ua9rjxd_.js";const t=e("x",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);export{t as X};
