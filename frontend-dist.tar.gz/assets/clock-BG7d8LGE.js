import{c}from"./createLucideIcon-ua9rjxd_.js";const e=c("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);export{e as C};
