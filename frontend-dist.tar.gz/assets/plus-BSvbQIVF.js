import{c as e}from"./createLucideIcon-ua9rjxd_.js";const s=e("plus",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]]);export{s as P};
